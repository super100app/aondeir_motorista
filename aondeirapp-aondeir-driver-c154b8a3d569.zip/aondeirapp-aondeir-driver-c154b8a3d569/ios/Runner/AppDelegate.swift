import UIKit
import Flutter
import FirebaseCore
import GoogleMaps

@main
@objc class AppDelegate: FlutterAppDelegate {
  override func application(
    _ application: UIApplication,
    didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
  ) -> Bool {
    FirebaseApp.configure()
    
    // Configure Google Maps with a specific Maps API key
    // TODO: Replace with your Google Maps Platform API key (not Firebase API key)
    // Get your key from: https://console.cloud.google.com/google/maps-apis/credentials
    let mapsApiKey = "AIzaSyBx97paRTNDLG6MQMbq3lWMhRPdKblN3Os"
    GMSServices.provideAPIKey(mapsApiKey)
    print("📍 Google Maps configured with API key: \(String(mapsApiKey.prefix(10)))...")
    
    GeneratedPluginRegistrant.register(with: self)
    return super.application(application, didFinishLaunchingWithOptions: launchOptions)
  }
}
