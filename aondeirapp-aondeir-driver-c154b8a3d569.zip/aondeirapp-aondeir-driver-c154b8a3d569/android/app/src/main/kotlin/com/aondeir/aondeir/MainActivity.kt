package com.aondeir.motoristaapp

import io.flutter.embedding.engine.FlutterEngine
import io.flutter.embedding.engine.FlutterEngineCache
import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity() {
    private val CHANNEL = "com.yourdomain.aondeir/MainActivity"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        // Armazena o FlutterEngine no cache, se necessário
        FlutterEngineCache.getInstance().put("my_flutter_engine", flutterEngine)
    }
}
