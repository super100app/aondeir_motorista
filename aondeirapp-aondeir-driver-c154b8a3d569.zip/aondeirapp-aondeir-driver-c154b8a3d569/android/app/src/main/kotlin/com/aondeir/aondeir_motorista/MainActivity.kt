package com.aondeir.aondeir_motorista

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
