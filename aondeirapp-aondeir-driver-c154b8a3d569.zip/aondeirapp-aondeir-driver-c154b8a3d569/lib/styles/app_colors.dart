import 'package:flutter/material.dart';

/// Arquivo centralizado de cores do aplicativo
/// Para facilitar a manutenção e personalização das cores dos componentes
class AppColors {
  // Cores primárias do aplicativo
  static const Color primary = Color.fromARGB(255, 136, 129, 129);
  static const Color primaryDark = Color.fromRGBO(38, 84, 26, 1);
  static const Color accent = Color(0xFFFE7E27);

  // Cores para botões de ação
  static const Color buttonPrimary = Colors.grey;
  static const Color buttonSecondary = Colors.orange;
  static const Color buttonTertiary = Color(0xFFF9AD1E);
  static const Color buttonTransparent = Colors.transparent;
  static const Color buttonWhite = Colors.white;

  // Cores de texto dos botões
  static const Color buttonTextPrimary = Colors.white;
  static const Color buttonTextSecondary = Colors.white;
  static const Color buttonTextDark = Colors.black;

  // Cores de borda dos botões
  static const Color buttonBorderPrimary = Colors.grey;
  static const Color buttonBorderSecondary = Colors.orange;

  // Cores de sombra dos botões
  static const Color buttonShadowPrimary = Colors.black45;
  static const Color buttonShadowSecondary = Colors.transparent;

  // Cores de fundo
  static const Color backgroundWhite = Colors.white;
  static const Color backgroundTransparent = Colors.transparent;

  // Cores de status
  static const Color error = Colors.red;
  static const Color success = Colors.green;
  static const Color warning = Colors.orange;
  static const Color info = Colors.blue;
}

