import 'package:shared_preferences/shared_preferences.dart';

class PersonalizacaoService {
  static const String _permitirIconeFlutuanteKey = 'personalizacao_permitir_icone_flutuante';

  static Future<bool> getPermitirIconeFlutuante() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_permitirIconeFlutuanteKey, false);
    return false;
  }

  static Future<void> setPermitirIconeFlutuante(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_permitirIconeFlutuanteKey, value);
  }
}

