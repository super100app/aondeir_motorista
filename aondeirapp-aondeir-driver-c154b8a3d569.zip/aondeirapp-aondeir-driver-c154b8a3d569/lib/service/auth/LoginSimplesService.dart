import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import 'dart:convert' as convert;

class LoginSimplesService extends ChangeNotifier {
  final storage = new FlutterSecureStorage();

  execute(vEmail, vPassword) async {
    try {
      String url = dotenv.env['BASE_URL']! +
          "api/motorista/celular/login?versao=" +
          dotenv.env['VERSAO_APP']!;
      var response = await http.post(
        Uri.parse(url),
        body: {"username": vEmail, "password": vPassword},
      );
      print("🫶 passou aqui - execute");
      var json = convert.jsonDecode(response.body);
      if (response.statusCode == 200) {
        await storage.write(key: 'jwt', value: json["token"]);
        return {'status': response.statusCode, 'data': json};
      } else if (response.statusCode == 401) {
        throw json['message'];
      }
    } catch (e) {
      throw e;
    }
  }

  save() {
    notifyListeners();
  }
}
