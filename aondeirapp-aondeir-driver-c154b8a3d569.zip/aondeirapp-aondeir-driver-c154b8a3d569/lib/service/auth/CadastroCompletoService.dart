import 'package:aondeir_motorista/service/UsuarioService.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/Usuario.dart';
import '../../screens/Usuario/Menu/Cadastro/OpcoesScreen.dart';

class CadastroCompletoService extends ChangeNotifier {

  final BuildContext context;

  CadastroCompletoService(this.context) {
  }

  execute(Usuario usuario, context) async {
    try {
      if (usuario.motorista['situacao_cadastral'] != "ATIVO") {
        var usuarioService = Provider.of<UsuarioService>(this.context, listen: false);
        await usuarioService.pegarEtapaAtualCadastro();
        return Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => OpcoesScreen(),
          ),
        );
      }
    } catch (e) {
      throw e;
    }
  }

  save() {
    notifyListeners();
  }
}
