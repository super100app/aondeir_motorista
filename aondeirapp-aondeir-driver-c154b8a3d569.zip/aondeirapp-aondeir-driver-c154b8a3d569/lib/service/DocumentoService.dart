import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import 'dart:convert' as convert;

class DocumentoService extends ChangeNotifier {
  final storage = new FlutterSecureStorage();
  var documento = {};
  var tipoDocumento = "";
  var tipoDocumentoId;
  var imagePath = "";
  var usuarioId;

  pegarDocumento() async {
    try {
      String url = dotenv.env['BASE_URL']! +
          "api/motorista/pegar-documento/" +
          tipoDocumentoId.toString();

      var token = await storage.read(key: 'jwt');

      var response = await http.get(Uri.parse(url), headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        final json = await convert.jsonDecode(response.body);
        this.documento = json['documento'];
        await this.save();
      } else if (response.statusCode == 404) {
        this.documento = {};
        await this.save();
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  save() {
    notifyListeners();
  }
}
