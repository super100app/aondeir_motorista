import 'dart:io';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/widgets.dart';
import 'firebase/FirebaseRealtimeConfigService.dart';

class FirebasePresenceService with WidgetsBindingObserver {
  static final FirebasePresenceService _instance = FirebasePresenceService._internal();
  
  factory FirebasePresenceService() => _instance;
  
  FirebasePresenceService._internal();

  final DatabaseReference _database = FirebaseRealtimeConfigService.getDatabase().ref();
  DatabaseReference? _myPresenceRef;
  DatabaseReference? _connectedRef;
  int? _currentUserId;
  bool _isObserverAdded = false;
  Map<String, dynamic>? _extraMetadata; // Metadados extras (corrida, plataforma, etc)

  Future<void> initialize(int usuarioId, {int? corridaId}) async {
    try {
      
      // Se já está inicializado para o mesmo usuário
      if (_currentUserId == usuarioId && _myPresenceRef != null) {
        
        // Atualizar metadados SOMENTE se corridaId foi fornecido
        if (corridaId != null) {
          _extraMetadata = {
            'plataforma': Platform.isIOS ? 'iOS' : 'Android',
            'corridaId': corridaId,
            'temCorrida': true,
          };
        }
        
        await _setOnline();
        return;
      }
      
      // Primeira inicialização: guardar metadados
      _extraMetadata = {
        'plataforma': Platform.isIOS ? 'iOS' : 'Android',
        'corridaId': corridaId,
        'temCorrida': corridaId != null,
      };

      _currentUserId = usuarioId;
      _myPresenceRef = _database.child('presence').child(usuarioId.toString());
      _connectedRef = FirebaseRealtimeConfigService.getDatabase().ref('.info/connected');

      // Configurar listener para detectar conexão/desconexão
      _connectedRef!.onValue.listen((event) {
        final connected = event.snapshot.value as bool?;
        
        if (connected == true) {
          _setOnline();
        } 
      });

      // Adicionar observer do ciclo de vida do app
      if (!_isObserverAdded) {
        WidgetsBinding.instance.addObserver(this);
        _isObserverAdded = true;
      }

    } catch (error) {
      print('❌ [FirebasePresence] Erro ao inicializar usuário $usuarioId: $error');
      rethrow;
    }
  }

  /// Detecta mudanças no estado do app (foreground/background)
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) async {
    
    switch (state) {
      case AppLifecycleState.resumed:
        await _setOnline();
        break;
      case AppLifecycleState.inactive:
        // NÃO marcar como offline - pode ser só uma transição temporária
        break;
      case AppLifecycleState.paused:
        // NÃO marcar como offline - app está minimizado mas ainda rodando
        break;
      case AppLifecycleState.detached:
        await setOffline();
        break;
      case AppLifecycleState.hidden:
        // NÃO marcar como offline
        break;
    }
  }

  /// Marca o usuário como online e configura handler de desconexão automática
  Future<void> _setOnline() async {
    try {
      if (_myPresenceRef == null || _currentUserId == null) {
        return;
      }

      // IMPORTANTE: Cancelar qualquer onDisconnect anterior antes de configurar um novo
      await _myPresenceRef!.onDisconnect().cancel();
      print('🔄 [FirebasePresence] onDisconnect anterior cancelado');

      // Configurar PRIMEIRO o handler de desconexão
      // Isso é executado automaticamente pelo Firebase quando a conexão é perdida
      await _myPresenceRef!.onDisconnect().set({
        'status': 'offline',
        'lastChanged': ServerValue.timestamp,
      });

      // DEPOIS marcar como online (com metadados)
      final dataToSend = {
        'status': 'online',
        'lastChanged': ServerValue.timestamp,
        if (_extraMetadata != null) 'metadata': _extraMetadata,
      };
      
      await _myPresenceRef!.set(dataToSend);
    } catch (error) {
      print('❌ [FirebasePresence] Erro ao marcar como online: $error');
    }
  }

  Future<void> setOffline() async {
    try {
      if (_myPresenceRef == null || _currentUserId == null) {
        return;
      }

      await _myPresenceRef!.set({
        'status': 'offline',
        'lastChanged': ServerValue.timestamp,
      });
    } catch (error) {
      print('❌ [FirebasePresence] ERRO ao marcar como offline: $error');
    }
  }

  Future<void> dispose() async {
    await setOffline();
    
    // Remover observer
    if (_isObserverAdded) {
      WidgetsBinding.instance.removeObserver(this);
      _isObserverAdded = false;
    }
    
    _myPresenceRef = null;
    _connectedRef = null;
    _currentUserId = null;
  }

}
