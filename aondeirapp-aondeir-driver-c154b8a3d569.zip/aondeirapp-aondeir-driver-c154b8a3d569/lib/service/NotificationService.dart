import 'package:flutter/foundation.dart';

class NotificationService extends ChangeNotifier {
  static final NotificationService _instance = NotificationService._internal();
  factory NotificationService() => _instance;
  NotificationService._internal();

  bool _novaCorridaRecebida = false;
  String _ultimaNotificacao = '';

  bool get novaCorridaRecebida => _novaCorridaRecebida;
  String get ultimaNotificacao => _ultimaNotificacao;

  // Método para notificar que uma nova corrida chegou via notificação
  void notificarNovaCorrida(String tipoNotificacao) {
    _novaCorridaRecebida = true;
    _ultimaNotificacao = tipoNotificacao;
    print("🔔 NotificationService: Nova corrida notificada - $tipoNotificacao");
    notifyListeners();
  }

  // Método para resetar o status após processar
  void resetarStatus() {
    _novaCorridaRecebida = false;
    _ultimaNotificacao = '';
    notifyListeners();
  }

  // Método para verificar se há nova corrida e resetar
  bool verificarNovaCorrida() {
    if (_novaCorridaRecebida) {
      resetarStatus();
      return true;
    }
    return false;
  }
} 