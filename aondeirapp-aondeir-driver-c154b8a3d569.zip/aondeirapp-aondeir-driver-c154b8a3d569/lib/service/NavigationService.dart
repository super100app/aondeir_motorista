import 'package:flutter/material.dart';

class NavigationService extends ChangeNotifier {
  static navigateTo(String routeName) async {
    var navigatorKey = await GlobalKey<NavigatorState>();
    return navigatorKey.currentState!.pushNamed(routeName);
  }

  save() {
    notifyListeners();
  }
}
