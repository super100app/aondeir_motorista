import 'dart:convert';
import 'dart:io';

import 'package:aondeir_motorista/service/LogErroService.dart';
import 'package:provider/provider.dart';
import 'package:aondeir_motorista/models/Usuario.dart';
import 'package:aondeir_motorista/service/CorridaService.dart';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import 'dart:convert' as convert;
import 'package:dio/dio.dart';
import 'package:http_parser/http_parser.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart' as overlay;

class UsuarioService extends ChangeNotifier {
  final storage = new FlutterSecureStorage();
  final BuildContext? context;
  final dio = Dio();
  var ufForm = "";

  var usuario = new Usuario(
    id: 0,
    name: "",
    email: "",
    celular: "",
    tipoId: 0,
    status: "",
    doc: "",
    franquia: "",
    motorista: "",
    dados_bancarios: "",
    versaoAppMotorista: '0',
    versaoApp: "0",
  );
  bool possuiDadosBancarios = false;

  var errorsForm = {};
  var dadosPessoaisForm = {};
  var dadosEnderecoForm = {};
  var dadosVeiculoForm = {};
  var etapaCadastro = {};

  UsuarioService(this.context) {}

  conectarMotorista() async {
    try {
      String url = dotenv.env['BASE_URL']! + "api/motorista/conectar";
      var token = await storage.read(key: 'jwt');
      var response = await http.post(Uri.parse(url), headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        final json = convert.jsonDecode(response.body);
        this.usuario.motorista['logado'] = json['status'];
        this.usuario.motorista['situacao'] = json['situacao'];
        
        // ✅ Persistir estado de "logado" no storage para uso quando app for reaberto
        await storage.write(key: 'motorista_logado', value: json['status']?.toString() ?? '');
        print("✅ [UsuarioService] Estado 'logado' salvo no storage: ${json['status']}");
        
        this.save();
        
        // Solicitar permissão de overlay quando o motorista se conectar
        if (Platform.isAndroid) {
          bool? hasPermission = await overlay.FlutterOverlayWindow.isPermissionGranted();
          if (hasPermission != true) {
            print("⚠️ Solicitando permissão de overlay ao conectar motorista");
            await overlay.FlutterOverlayWindow.requestPermission();
          } else {
            print("✅ Permissão de overlay já concedida");
          }
        }
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  desconectarMotorista() async {
    try {
      String url = dotenv.env['BASE_URL']! + "api/motorista/desconectar";
      var token = await storage.read(key: 'jwt');
      var response = await http.post(Uri.parse(url), headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        final json = convert.jsonDecode(response.body);
        this.usuario.motorista['logado'] = json['status'];
        this.usuario.motorista['situacao'] = json['situacao'];
        
        // ✅ Persistir estado de "logado" no storage
        await storage.write(key: 'motorista_logado', value: json['status']?.toString() ?? '');
        print("✅ [UsuarioService] Estado 'logado' salvo no storage: ${json['status']}");
        
        this.save();

        var corridaService =
            Provider.of<CorridaService>(this.context!, listen: false);
        corridaService.corridas.clear();
        corridaService.save();
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  pegarDadosBancarios() async {
    try {
      String url =
          dotenv.env['BASE_URL']! + "api/motorista/pegar-dados-Bancarios";
      var token = await storage.read(key: 'jwt');
      var response = await http.get(Uri.parse(url), headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        final json = convert.jsonDecode(response.body);
        if (json['dadosBancarios'] != null) {
          this.usuario.dados_bancarios = json['dadosBancarios'];

          await this.save();
        }
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  // pegarEtapaAtualCadastro() async {
  //   try {
  //     String url = dotenv.env['BASE_URL']! + "api/motorista/pegar-etapas";
  //     var token = await storage.read(key: 'jwt');
  //     var response = await http.get(Uri.parse(url), headers: {
  //       HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
  //     });
  //     if (response.statusCode == 200) {
  //       final json = await convert.jsonDecode(response.body);
  //       this.etapaCadastro = json['etapa'];
  //       await this.save();
  //     }
  //   } on http.ClientException catch (e) {
  //     throw e;
  //   }
  // }

  cadastrarContaBancaria(dataForm) async {
    try {
      String url =
          dotenv.env['BASE_URL']! + "api/motorista/cadastrar-conta-bancaria";
      var token = await storage.read(key: 'jwt');
      var response = await http.post(Uri.parse(url), body: dataForm, headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });
      print("---cadastrarContaBancaria--- LOG LOG LOG LOG ");
      final json = await convert.jsonDecode(response.body);
      print(json['status']);
      if (response.statusCode == 200) {
        final json = await convert.jsonDecode(response.body);
        this.usuario.dados_bancarios = json['conta_bancaria'];
        this.etapaCadastro = json['etapa'];
        await this.save();
        return true;
      } else if (response.statusCode == 400) {
        final json = await convert.jsonDecode(response.body);
        this.errorsForm = json;
        await this.save();
        return false;
      } else {
        return false;
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  salvarDadosPessoais() async {
    try {
      String url =
          dotenv.env['BASE_URL']! + "api/motorista/salvar-dados-pessoais";
      var token = await storage.read(key: 'jwt');
      var response =
          await http.post(Uri.parse(url), body: dadosPessoaisForm, headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });
      if (response.statusCode == 200) {
        final json = await convert.jsonDecode(response.body);
        Usuario usuario = Usuario.fromJson(json['usuario']);
        this.usuario = usuario;
        this.etapaCadastro = json['etapa'];
        this.errorsForm = {};
        await this.save();
        return true;
      } else if (response.statusCode == 400) {
        final json = await convert.jsonDecode(response.body);
        this.errorsForm = json;
        await this.save();
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  salvarFotoPerfil(path) async {
    try {
      var token = await storage.read(key: 'jwt');
      String url = dotenv.env['BASE_URL']! + "api/motorista/salvar-foto-perfil";

      var request = http.MultipartRequest('POST', Uri.parse(url))
        ..headers['authorization'] = 'Bearer $token'
        ..files.add(await http.MultipartFile.fromPath(
          'file',
          path,
          contentType: MediaType('image', 'jpeg'),
        ));
      var response = await http.Client().send(request);

      if (response.statusCode == 200) {
        var responseString = await utf8.decodeStream(response.stream);

        final json = await convert.jsonDecode(responseString);

        this.usuario.motorista['foto_perfil'] =
            json['usuario']['motorista']['foto_perfil'];
        this.etapaCadastro = json['etapa'];
        await this.save();
        return true;
      } else {
        return false;
      }
    } catch (e) {}
  }

  salvarDadosEndereco() async {
    try {
      String url =
          dotenv.env['BASE_URL']! + "api/motorista/salvar-dados-endereco";
      var token = await storage.read(key: 'jwt');
      var response =
          await http.post(Uri.parse(url), body: dadosEnderecoForm, headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });
      if (response.statusCode == 200) {
        final json = await convert.jsonDecode(response.body);
        this.usuario.motorista = json['usuario']['motorista'];
        this.etapaCadastro = json['etapa'];
        await this.save();
        return true;
      } else if (response.statusCode == 400) {
        final json = await convert.jsonDecode(response.body);
        this.errorsForm = json;
        await this.save();
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  salvarDadosVeiculo() async {
    try {
      String url =
          dotenv.env['BASE_URL']! + "api/motorista/salvar-dados-veiculo";
      var token = await storage.read(key: 'jwt');
      var response =
          await http.post(Uri.parse(url), body: dadosVeiculoForm, headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });
      if (response.statusCode == 200) {
        final json = await convert.jsonDecode(response.body);
        this.usuario.motorista = json['usuario']['motorista'];
        this.etapaCadastro = json['etapa'];
        await this.save();
        return true;
      } else if (response.statusCode == 400) {
        final json = await convert.jsonDecode(response.body);
        this.errorsForm = json;
        await this.save();
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  salvaDocumentoAntecedenteCriminal(path) async {
    try {
      var token = await storage.read(key: 'jwt');
      String url = dotenv.env['BASE_URL']! +
          "api/motorista/salvar-foto-antecedente-criminal";

      var request = http.MultipartRequest('POST', Uri.parse(url))
        ..headers['authorization'] = 'Bearer $token'
        ..files.add(await http.MultipartFile.fromPath(
          'file',
          path,
          contentType: MediaType('image', 'jpeg'),
        ));
      var response = await http.Client().send(request);

      if (response.statusCode == 200) {
        var responseString = await utf8.decodeStream(response.stream);

        final json = await convert.jsonDecode(responseString);
        this.usuario.motorista['foto_antecedente_criminal'] =
            json['usuario']['motorista']['foto_antecedente_criminal'];
        this.etapaCadastro = json['etapa'];
        await this.save();
        return true;
      } else {}
    } catch (e) {}
  }

  salvaDocumentoCnh(path) async {
    var logErroService =
        Provider.of<LogErroService>(this.context!, listen: false);
    try {
      var token = await storage.read(key: 'jwt');
      String url = dotenv.env['BASE_URL']! + "api/motorista/salvar-foto-cnh";

      var request = http.MultipartRequest('POST', Uri.parse(url))
        ..headers['authorization'] = 'Bearer $token'
        ..files.add(await http.MultipartFile.fromPath(
          'file',
          path,
          contentType: MediaType('image', 'jpeg'),
        ));
      var response = await http.Client().send(request);

      if (response.statusCode == 200) {
        var responseString = await utf8.decodeStream(response.stream);

        final json = await convert.jsonDecode(responseString);
        this.usuario.motorista['foto_cnh'] =
            json['usuario']['motorista']['foto_cnh'];
        this.etapaCadastro = json['etapa'];
        await this.save();
        return true;
      } else {
        return false;
      }
    } catch (e) {
      await logErroService.addErro("DocumentoCnhScreen - salvaDocumento",
          'Erro durante a execução: $e', "stackTrace");
      throw Exception('Erro durante a execução: $e');
    }
  }

  salvaDocumentoComprovanteResidencia(path) async {
    try {
      var token = await storage.read(key: 'jwt');
      String url = dotenv.env['BASE_URL']! +
          "api/motorista/salvar-foto-comprovante-residencia";

      var request = http.MultipartRequest('POST', Uri.parse(url))
        ..headers['authorization'] = 'Bearer $token'
        ..files.add(await http.MultipartFile.fromPath(
          'file',
          path,
          contentType: MediaType('image', 'jpeg'),
        ));
      var response = await http.Client().send(request);

      if (response.statusCode == 200) {
        var responseString = await utf8.decodeStream(response.stream);

        final json = await convert.jsonDecode(responseString);
        this.usuario.motorista['foto_comprovante_residencia'] =
            json['usuario']['motorista']['foto_comprovante_residencia'];
        this.etapaCadastro = json['etapa'];
        await this.save();
        return true;
      } else {}
    } catch (e) {}
  }

  salvaDocumentoCrlv(path) async {
    try {
      var token = await storage.read(key: 'jwt');
      String url = dotenv.env['BASE_URL']! + "api/motorista/salvar-foto-crlv";

      String fileType = 'image/jpeg';
      if (path.endsWith('.pdf')) {
        fileType = 'application/pdf';
      } else if (path.endsWith('.png')) {
        fileType = 'image/png';
      } else if (path.endsWith('.jpg')) {
        fileType = 'image/jpeg';
      }

      var request = http.MultipartRequest('POST', Uri.parse(url))
        ..headers['authorization'] = 'Bearer $token'
        ..files.add(await http.MultipartFile.fromPath(
          'file',
          path,
          contentType: MediaType.parse(fileType),
        ));

      var response = await http.Client().send(request);

      if (response.statusCode == 200) {
        var responseString = await utf8.decodeStream(response.stream);

        final json = await convert.jsonDecode(responseString);
        this.usuario.motorista['foto_crlv'] =
            json['usuario']['motorista']['foto_crlv'];
        this.etapaCadastro = json['etapa'];
        await this.save();
        return true;
      } else {}
    } catch (e) {
      throw e;
    }
  }

  salvaDocumentoVeiculoFrontal(path) async {
    try {
      var token = await storage.read(key: 'jwt');
      String url =
          dotenv.env['BASE_URL']! + "api/motorista/salvar-foto-veiculo-frontal";

      var request = http.MultipartRequest('POST', Uri.parse(url))
        ..headers['authorization'] = 'Bearer $token'
        ..files.add(await http.MultipartFile.fromPath(
          'file',
          path,
          contentType: MediaType('image', 'jpeg'),
        ));
      var response = await http.Client().send(request);

      if (response.statusCode == 200) {
        var responseString = await utf8.decodeStream(response.stream);

        final json = await convert.jsonDecode(responseString);
        this.usuario.motorista['foto_veiculo_frontal'] =
            json['usuario']['motorista']['foto_veiculo_frontal'];
        this.etapaCadastro = json['etapa'];
        await this.save();
        return true;
      } else {}
    } catch (e) {}
  }

  salvaDocumentoVeiculoTraseira(path) async {
    try {
      var token = await storage.read(key: 'jwt');
      String url = dotenv.env['BASE_URL']! +
          "api/motorista/salvar-foto-veiculo-traseira";

      var request = http.MultipartRequest('POST', Uri.parse(url))
        ..headers['authorization'] = 'Bearer $token'
        ..files.add(await http.MultipartFile.fromPath(
          'file',
          path,
          contentType: MediaType('image', 'jpeg'),
        ));
      var response = await http.Client().send(request);

      if (response.statusCode == 200) {
        var responseString = await utf8.decodeStream(response.stream);

        final json = await convert.jsonDecode(responseString);
        this.usuario.motorista['foto_veiculo_traseira'] =
            json['usuario']['motorista']['foto_veiculo_traseira'];
        this.etapaCadastro = json['etapa'];
        await this.save();
        return true;
      } else {}
    } catch (e) {}
  }

  pegarEtapaAtualCadastro() async {
    try {
      String url =
          dotenv.env['BASE_URL']! + "api/motorista/pegar-etapa-atual-cadastro";
      var token = await storage.read(key: 'jwt');
      var response = await http.get(Uri.parse(url), headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });
      if (response.statusCode == 200) {
        final json = await convert.jsonDecode(response.body);
        this.etapaCadastro = json['etapa'];
        await this.save();
      } else if (response.statusCode == 400) {}
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  excluirConta() async {
    try {
      String url = dotenv.env['BASE_URL']! + "api/motorista/excluir-conta";
      var token = await storage.read(key: 'jwt');
      var response =
          await http.post(Uri.parse(url), body: dadosEnderecoForm, headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });
      if (response.statusCode == 200) {
        return true;
      } else if (response.statusCode == 204) {
        return false;
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  save() {
    notifyListeners();
  }

  /// Verifica se o motorista está conectado, primeiro verificando o estado em memória,
  /// e se não estiver disponível, verifica o estado persistido no storage
  Future<String?> getMotoristaLogadoStatus() async {
    try {
      // Primeiro, tentar obter do estado em memória
      var motorista = this.usuario.motorista;
      if (motorista is Map && motorista['logado'] != null) {
        String? logado = motorista['logado']?.toString();
        if (logado != null && logado.isNotEmpty) {
          print("✅ [UsuarioService] Estado 'logado' obtido da memória: $logado");
          return logado;
        }
      }
      
      // Se não estiver em memória, verificar no storage
      String? logadoPersistido = await storage.read(key: 'motorista_logado');
      if (logadoPersistido != null && logadoPersistido.isNotEmpty) {
        print("✅ [UsuarioService] Estado 'logado' obtido do storage: $logadoPersistido");
        // Atualizar o estado em memória também
        if (motorista is Map) {
          motorista['logado'] = logadoPersistido;
        }
        return logadoPersistido;
      }
      
      print("⚠️ [UsuarioService] Estado 'logado' não encontrado nem em memória nem no storage");
      return null;
    } catch (e) {
      print("❌ [UsuarioService] Erro ao obter estado 'logado': $e");
      return null;
    }
  }
}
