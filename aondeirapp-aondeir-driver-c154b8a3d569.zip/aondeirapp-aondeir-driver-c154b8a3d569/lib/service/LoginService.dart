import 'dart:io';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'dart:convert' as convert;
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';

import '../models/Usuario.dart';
import 'UsuarioService.dart';
import 'UpdateService.dart';
import 'FirebasePresenceService.dart';

class LoginService extends ChangeNotifier {
  final BuildContext? context;
  var vEmail = "";
  var vPassword = "";

  final storage = new FlutterSecureStorage();

  LoginService(this.context) {}

  save() {
    notifyListeners();
  }

  getUsarioLogado(token) async {
    try {
      String url = dotenv.env['BASE_URL']! +
          'api/motorista/celular/getLogado?versao=' +
          dotenv.env['VERSAO_APP']!;
      var response = await http.get(Uri.parse(url), headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        var json = convert.jsonDecode(response.body);
        var usuarioService =
            Provider.of<UsuarioService>(this.context!, listen: false);
        final updateService = Provider.of<UpdateService>(context!, listen: false);
        Usuario usuario = Usuario.fromJson(json['usuario']);
        usuarioService.usuario = usuario;
        // usuarioService.usuario.versaoApp = json['versaoApp'];
        
        // ✅ Persistir estado de "logado" do motorista no storage após login
        if (usuario.motorista is Map && usuario.motorista['logado'] != null) {
          String? logado = usuario.motorista['logado']?.toString();
          if (logado != null && logado.isNotEmpty) {
            await storage.write(key: 'motorista_logado', value: logado);
            print("✅ [LoginService] Estado 'logado' salvo no storage após login: $logado");
          }
        }
        
        await usuarioService.save();
        
        // ✅ Verificar se as versões são diferentes
        if (dotenv.env['VERSAO_APP']! != json['versaoAtual']) {
          updateService.showUpdateModal(context!);
        }
        
        notifyListeners();
        
        // Tentar obter e salvar token FCM com retry e timeout
        try {
          String? fcmToken;
          int maxRetries = 3;
          
          for (int i = 0; i < maxRetries; i++) {
            try {
              fcmToken = await FirebaseMessaging.instance
                  .getToken()
                  .timeout(Duration(seconds: 10));
              
              if (fcmToken != null) {
                print('✅ Token FCM obtido no LoginService');
                break;
              }
            } catch (e) {
              print('❌ Tentativa ${i + 1}/$maxRetries de obter FCM token falhou: $e');
              if (i < maxRetries - 1) {
                await Future.delayed(Duration(seconds: 2));
              } else {
                print('⚠️ Continuando sem salvar token FCM');
                return true; // Não bloqueia o login
              }
            }
          }
          
          if (fcmToken != null) {
            String urlFirebase = dotenv.env['BASE_URL']! + 'api/firebase/salvar-token';
            await http.post(
              Uri.parse(urlFirebase), 
              body: {"tokenFirebase": fcmToken},
              headers: {
                HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
              }
            ).timeout(Duration(seconds: 10));
            print('✅ Token FCM salvo no backend');
          }
        } catch (e) {
          print('❌ Erro ao salvar token FCM, mas continuando login: $e');
        }

        return true;
      }
      return false;
    } catch (e) {
      print("🚨 getUsarioLogado erro: ");
      print(e);
      return false;
    }
  }
}
