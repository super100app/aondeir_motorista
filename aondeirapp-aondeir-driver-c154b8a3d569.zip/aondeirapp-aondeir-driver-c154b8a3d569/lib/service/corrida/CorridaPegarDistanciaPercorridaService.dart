import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class CorridaPegarDistanciaPercorridaService extends ChangeNotifier {
  var distanciaPercorrida = 0.0;

  execute(corrida) async {
    try {
      if (corrida != null && corrida['distancia_percorrida_metros'] != null) {
        distanciaPercorrida = corrida['distancia_percorrida_metros'].toDouble();
        await this.save();
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  save() {
    notifyListeners();
  }
}
