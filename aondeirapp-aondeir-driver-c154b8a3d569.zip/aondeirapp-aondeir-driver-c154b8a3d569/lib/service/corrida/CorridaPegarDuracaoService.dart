import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class CorridaPegarDuracaoService extends ChangeNotifier {
  var duracaoEmSegundos;

  execute(corrida) async {
    try {
      var dataInicioCorrida = DateTime.parse(corrida['data_iniciado']);
      var dataAtual = DateTime.now();

      var diferencaEmMilissegundos =
          dataAtual.difference(dataInicioCorrida).inMilliseconds;

      this.duracaoEmSegundos = diferencaEmMilissegundos ~/ 1000;

      await this.save();
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  save() {
    notifyListeners();
  }
}
