import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;

class CorridaGuardarDistanciaPercorridaOfflineService extends ChangeNotifier {
  final storage = new FlutterSecureStorage();

  execute(distancia) async {
    try {
      await storage.write(
          key: 'distanciaPercorridaOff', value: distancia.toString());
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  save() {
    notifyListeners();
  }
}
