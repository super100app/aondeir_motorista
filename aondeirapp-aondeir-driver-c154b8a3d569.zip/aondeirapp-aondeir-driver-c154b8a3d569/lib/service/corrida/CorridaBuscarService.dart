import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_overlay_apps/flutter_overlay_apps.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:provider/provider.dart';
import 'dart:convert' as convert;
import '../../models/Corrida.dart';
import '../CorridaService.dart';


class CorridaBuscarService extends ChangeNotifier {
  final storage = new FlutterSecureStorage();
  final BuildContext context;

  CorridaBuscarService(this.context) {}


  execute([dynamic lat, dynamic long]) async {
    try {
      var corridaService = Provider.of<CorridaService>(context, listen: false);

      await corridaService.pegarCorridaAndamento();

      String url = dotenv.env['BASE_URL']! +
          "api/motorista/chamada/buscar-chamada?ios=" +
          (Platform.isIOS ? 'true' : 'falso');

      if (lat != null) {
        url = url + "&latitude=" + lat.toString();
      }

      if (long != null) {
        url = url + "&longitude=" + long.toString();
      }

      var token = await storage.read(key: 'jwt');

      var response = await http.get(Uri.parse(url), headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        var data = convert.jsonDecode(response.body);
        var corridaService =
            Provider.of<CorridaService>(context, listen: false);

        await corridaService.removerTodasCorridas();
        if (data['corridas'] != null) {
          for (var row in data['corridas']) {
            Corrida corrida = Corrida.fromJson(row);
            await corridaService.addCorrida(corrida);
          }
        }

        if (data['corrida'] != null) {
          Corrida corrida = Corrida.fromJson(data['corrida']);
          await corridaService.addCorrida(corrida);
          // await showOverlayCorrida();
        }
        
        // Marcar que a lista foi atualizada
        corridaService.listaAtualizada = true;
        corridaService.save();
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }
  save() {
    notifyListeners();
  }
}
