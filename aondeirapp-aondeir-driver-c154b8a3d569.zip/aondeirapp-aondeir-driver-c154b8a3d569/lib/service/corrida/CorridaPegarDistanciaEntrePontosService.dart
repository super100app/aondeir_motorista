import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;

class CorridaPegarDistanciaEntrePontosService extends ChangeNotifier {
  double distanciaEntreOsPontos = 0.0;

  execute(Position posicaoAnterior, Position posicaoNova) async {
    try {
      distanciaEntreOsPontos = await Geolocator.distanceBetween(
        posicaoAnterior.latitude,
        posicaoAnterior.longitude,
        posicaoNova.latitude,
        posicaoNova.longitude,
      );

      await this.save();
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  save() {
    notifyListeners();
  }
}
