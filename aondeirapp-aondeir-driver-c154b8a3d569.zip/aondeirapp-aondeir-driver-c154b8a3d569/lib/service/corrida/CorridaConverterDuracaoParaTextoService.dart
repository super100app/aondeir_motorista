import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class CorridaConverterDuracaoParaTextoService extends ChangeNotifier {
  var duracaoCorrida = "";

  execute(corrida) async {
    try {
      print('🟨🟨🟨 - 2222 obterValorMinutoEmSegundos');
      var segundos = corrida['duracao_segundos'];

      var horas = segundos ~/ 3600;
      segundos %= 3600;

      var minutos = segundos ~/ 60;
      var segundosRestantes = segundos % 60;

      if (horas > 0) {
        duracaoCorrida += horas.toString() + "h ";
      }

      if (minutos > 0 || horas > 0) {
        duracaoCorrida += minutos.toString() + "min ";
      }

      duracaoCorrida += segundosRestantes.toString().padLeft(2, '0') + "seg";

      return duracaoCorrida;
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  save() {
    notifyListeners();
  }
}
