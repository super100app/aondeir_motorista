import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;

class CorridaSalvarCoordenadasService extends ChangeNotifier {
  final storage = new FlutterSecureStorage();

  execute(corrida) async {
    try {
      var coordenadas = await storage.read(key: 'coordenadas');

      if (coordenadas != null && coordenadas.length > 0) {
        String url = dotenv.env['BASE_URL']! +
            "api/corrida-macaneta/salvar-coordenadas-rota/" +
            corrida['id'].toString();
        var token = await storage.read(key: 'jwt');

        var response = await http.post(Uri.parse(url), body: {
          "coordenadas": coordenadas,
        }, headers: {
          HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
        });

        if (response.statusCode == 200) {
          await storage.delete(key: 'coordenadas');
        }
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  save() {
    notifyListeners();
  }
}
