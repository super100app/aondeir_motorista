import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;

class CorridaGuardarCoordenadasOfflineService extends ChangeNotifier {
  List<Map<String, double>> coordenadas = [];
  final storage = new FlutterSecureStorage();

  execute(Position localizacao, distancia) async {
    try {
      coordenadas.add({
        "latitude": localizacao.latitude,
        "longitude": localizacao.longitude,
        "distancia": distancia,
      });

      String coordenadasString = json.encode(coordenadas);

      await storage.write(key: 'coordenadas', value: coordenadasString);

      await this.save();
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  save() {
    notifyListeners();
  }
}
