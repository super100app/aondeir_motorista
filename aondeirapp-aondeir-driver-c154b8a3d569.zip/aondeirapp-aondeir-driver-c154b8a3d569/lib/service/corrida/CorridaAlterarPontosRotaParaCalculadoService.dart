import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class CorridaAlterarPontosRotaParaCalculadoService extends ChangeNotifier {
  final storage = new FlutterSecureStorage();

  execute(corrida, partidaLatitude, partidaLongitude, destinoLatitude,
      destinoLongitude) async {
    try {
      String url = dotenv.env['BASE_URL']! +
          "api/corrida-macaneta/alterar-pontos-rota-para-calculado/" +
          corrida['id'].toString();
      var token = await storage.read(key: 'jwt');
      await http.post(Uri.parse(url), body: {
        "endereco_partida_latitude": partidaLatitude.toString(),
        "endereco_partida_longitude": partidaLongitude.toString(),
        "endereco_destino_latitude": destinoLatitude.toString(),
        "endereco_destino_longitude": destinoLongitude.toString(),
      }, headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  save() {
    notifyListeners();
  }
}
