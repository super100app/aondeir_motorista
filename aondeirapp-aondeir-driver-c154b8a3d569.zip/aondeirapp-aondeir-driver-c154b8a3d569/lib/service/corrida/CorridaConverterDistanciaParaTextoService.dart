import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class CorridaConverterDistanciaParaTextoService extends ChangeNotifier {
  var distanciaPercorridaFormatada = "0";

  execute(corrida) async {
    try {
      if (corrida != null && corrida['distancia_percorrida_metros'] != null) {
        double distanceInKilometers =
            double.parse(corrida['distancia_percorrida_metros'].toString()) /
                1000;

        if (distanceInKilometers < 1) {
          var numeroFormatadoMetros = distanceInKilometers
              .toStringAsFixed(3)
              .toString()
              .replaceAll('.', ',');

          distanciaPercorridaFormatada =
              numeroFormatadoMetros.substring(2) + " m";
        } else {
          var numeroFormatadoKm = distanceInKilometers.toStringAsFixed(1);
          distanciaPercorridaFormatada =
              numeroFormatadoKm.replaceAll('.', ',') + " km";
        }
        return distanciaPercorridaFormatada;
      } else {
        return distanciaPercorridaFormatada;
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  save() {
    notifyListeners();
  }
}
