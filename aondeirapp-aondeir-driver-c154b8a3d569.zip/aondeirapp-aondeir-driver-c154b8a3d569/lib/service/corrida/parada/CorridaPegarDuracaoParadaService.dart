import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class CorridaPegarDuracaoParadaService extends ChangeNotifier {
  var duracaoEmSegundos = 0;

  execute(dataInicio) async {
    try {
      var dataInicioCorrida = DateTime.parse(dataInicio);
      var dataAtual = DateTime.now();

      var diferencaEmMilissegundos =
          dataAtual.difference(dataInicioCorrida).inMilliseconds;

      this.duracaoEmSegundos = diferencaEmMilissegundos ~/ 1000;

      await this.save();
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  save() {
    notifyListeners();
  }
}
