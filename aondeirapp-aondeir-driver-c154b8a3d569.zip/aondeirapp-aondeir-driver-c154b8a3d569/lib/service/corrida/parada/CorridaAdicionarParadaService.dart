import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'dart:convert' as convert;

class CorridaAdicionarParadaService extends ChangeNotifier {
  final storage = new FlutterSecureStorage();
  var dataInicioParada;
  var tempoTotalParadaSegundos = 0;

  execute(latitude, longitude, endereco) async {
    try {
      String url = dotenv.env['BASE_URL']! +
          "api/motorista/chamada-parada/adicionar-parada";
      var token = await storage.read(key: 'jwt');
      var response = await http.post(Uri.parse(url), body: {
        "latitude": latitude,
        "longitude": longitude,
        "endereco": endereco,
      }, headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        var resp = convert.jsonDecode(response.body);
        dataInicioParada = resp['data_inicio_parada'];
        tempoTotalParadaSegundos = resp['tempo_total_parado_segundos'];

        notifyListeners();
      } else {
        var resp = convert.jsonDecode(response.body);

        if (resp.containsKey('message')) {
          throw http.ClientException(resp['message']);
        } else if (resp.containsKey('latitude') ||
            resp.containsKey('longitude') ||
            resp.containsKey('endereco')) {
          throw http.ClientException(
              'Não foi possível obter a localização da parada. Tente novamente.');
        } else {
          throw http.ClientException(
              'Ocorreu um problema ao iniciar a parada. Tente novamente.');
        }
      }
    } on http.ClientException catch (e) {
      throw e;
    } catch (e) {
      throw 'Ocorreu um problema ao iniciar a parada. Tente novamente.';
    }
  }

  save() {
    notifyListeners();
  }
}
