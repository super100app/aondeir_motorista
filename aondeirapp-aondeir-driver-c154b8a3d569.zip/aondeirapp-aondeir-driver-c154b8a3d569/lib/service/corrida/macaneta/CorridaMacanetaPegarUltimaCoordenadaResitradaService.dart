import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'dart:convert' as convert;

import '../../../models/Coordenada.dart';

class CorridaMacanetaPegarUltimaCoordenadaResitradaService
    extends ChangeNotifier {
  final storage = new FlutterSecureStorage();
  var ultimaCoordenadaRegistrada = new Coordenada(latitude: 0, longitude: 0);

  execute() async {
    try {
      String url = dotenv.env['BASE_URL']! +
          "api/corrida-macaneta/pegar-ultima-coordenada-registrada-rota";
      var token = await storage.read(key: 'jwt');
      var response = await http.get(Uri.parse(url), headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        var resp = convert.jsonDecode(response.body);

        resp['ultimaCoordenadaRegistrada']['latitude'] =
            double.parse(resp['ultimaCoordenadaRegistrada']['latitude']);
        resp['ultimaCoordenadaRegistrada']['longitude'] =
            double.parse(resp['ultimaCoordenadaRegistrada']['longitude']);

        Coordenada coordenada =
            Coordenada.fromJson(resp['ultimaCoordenadaRegistrada']);

        ultimaCoordenadaRegistrada = coordenada;
        await this.save();
      } else if (response.statusCode == 404) {}
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  save() {
    notifyListeners();
  }
}
