import 'package:aondeir_motorista/service/SocketService.dart';
import 'package:aondeir_motorista/service/firebase/FirebaseRealtimeService.dart';
import 'package:aondeir_motorista/service/firebase/FirebaseRealtimeConfigService.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:provider/provider.dart';
import 'package:firebase_database/firebase_database.dart';

class MotoristaAtualizaLocalizacaoService extends ChangeNotifier {
  final storage = new FlutterSecureStorage();
  final BuildContext context;

  MotoristaAtualizaLocalizacaoService(this.context) {}

  execute(int motoristaId, Position position) async {
    try {
      // ⚡ MIGRAÇÃO: Usar Firebase Realtime Database em vez de WebSocket
      bool enviadoComSucesso = false;
      
      // Tentar usar o Provider primeiro (se disponível)
      try {
        var firebaseService = Provider.of<FirebaseRealtimeService>(this.context, listen: false);
        await firebaseService.enviarCoordenadasFirebase(
          position.latitude.toString(),
          position.longitude.toString(),
          motoristaId,
        );
        enviadoComSucesso = true;
        print('✅ [MotoristaAtualizaLocalizacaoService] Coordenadas enviadas via Firebase (Provider)');
      } catch (providerError) {
        print('⚠️ [MotoristaAtualizaLocalizacaoService] Provider não disponível, usando Firebase direto: $providerError');
        
        // Se Provider não disponível, usar Firebase diretamente (mesma lógica do FirebaseRealtimeService)
        try {
          // Garantir que Firebase está online
          FirebaseRealtimeConfigService.getDatabase().goOnline();
          
          final database = FirebaseRealtimeConfigService.getDatabase().ref();
          final coordenadasRef = database.child('coordenadas/$motoristaId');
          
          final dadosCoordenadas = {
            'latitude': position.latitude.toString(),
            'longitude': position.longitude.toString(),
            'usuarioId': motoristaId,
            'timestamp': DateTime.now().millisecondsSinceEpoch,
            'dataAtualizacao': DateTime.now().toIso8601String()
          };
          
          await coordenadasRef.set(dadosCoordenadas);
          enviadoComSucesso = true;
          print('✅ [MotoristaAtualizaLocalizacaoService] Coordenadas enviadas via Firebase (direto)');
        } catch (firebaseError) {
          print('❌ [MotoristaAtualizaLocalizacaoService] Erro ao enviar via Firebase direto: $firebaseError');
        }
      }
      
      // Fallback para WebSocket se Firebase falhar
      if (!enviadoComSucesso) {
        print('🔄 [MotoristaAtualizaLocalizacaoService] Usando WebSocket como fallback');
        try {
          var socketService = Provider.of<SocketService>(this.context, listen: false);
          socketService.socket?.emit("cordenadas", { 
              "latitude": position.latitude.toString(),
              "longitude": position.longitude.toString(),
              "usuarioId": motoristaId
          });
          print('✅ [MotoristaAtualizaLocalizacaoService] Coordenadas enviadas via WebSocket');
        } catch (socketError) {
          print('❌ [MotoristaAtualizaLocalizacaoService] Erro ao usar WebSocket: $socketError');
        }
      }
      
    } on http.ClientException catch (e) {
      print("🚨🚨entrou no service de atualizar localizacao motoristra");
      print(e.message);
    } catch (e) {
      print('❌ [MotoristaAtualizaLocalizacaoService] Erro geral: $e');
    }
  }

  save() {
    notifyListeners();
  }
}
