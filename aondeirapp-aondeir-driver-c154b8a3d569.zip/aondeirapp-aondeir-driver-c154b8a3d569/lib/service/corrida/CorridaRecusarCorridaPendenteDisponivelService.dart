import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'dart:convert' as convert;

class CorridaRecusarCorridaPendenteDisponivelService extends ChangeNotifier {
  final storage = new FlutterSecureStorage();

  execute(corridaId) async {
    try {
      String url = dotenv.env['BASE_URL']! +
          "api/motorista/chamada/recusar-chamada-pendente-disponivel/" +
          corridaId.toString();
      var token = await storage.read(key: 'jwt');

      var response = await http.get(Uri.parse(url), headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        var data = convert.jsonDecode(response.body);
        return data;
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  save() {
    notifyListeners();
  }
}
