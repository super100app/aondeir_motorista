import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'dart:convert' as convert;

class CorridaPegarCoordenadasNaoCalculadaService extends ChangeNotifier {
  final storage = new FlutterSecureStorage();
  var coordenadasRegistrada = [];
  late Position partida;
  late Position destino;

  execute(corrida) async {
    try {
      String url = dotenv.env['BASE_URL']! +
          "api/corrida-macaneta/pegar-coordenadas-nao-calculadas/" +
          corrida['id'].toString();
      var token = await storage.read(key: 'jwt');
      var response = await http.get(Uri.parse(url), headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      convert.jsonDecode(response.body);
      if (response.statusCode == 200) {
        var resp = convert.jsonDecode(response.body);
        coordenadasRegistrada = resp['coordenadas'];
        partida = Position(
            longitude: double.parse(coordenadasRegistrada.first['longitude']),
            latitude: double.parse(coordenadasRegistrada.first['latitude']),
            timestamp: DateTime.now(),
            altitudeAccuracy: 0,
            accuracy: 0,
            altitude: 0,
            heading: 0,
            speed: 0,
            headingAccuracy: 0,
            speedAccuracy: 0,
            );

        destino = Position(
            longitude: double.parse(coordenadasRegistrada.last['longitude']),
            latitude: double.parse(coordenadasRegistrada.last['latitude']),
            timestamp: DateTime.now(),
            altitudeAccuracy: 0,
            accuracy: 0,
            altitude: 0,
            heading: 0,
            speed: 0,
            headingAccuracy: 0,
            speedAccuracy: 0);
        await this.save();
      } else if (response.statusCode == 404) {}
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  save() {
    notifyListeners();
  }
}
