import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'dart:convert' as convert;

class CorridaSalvarCoordenadaRotaService extends ChangeNotifier {
  final storage = new FlutterSecureStorage();

  execute(coordenadas) async {
    try {
      String url = dotenv.env['BASE_URL']! +
          "api/motorista/chamada/salvar-coordenada-rota";
      var token = await storage.read(key: 'jwt');
      var response = await http.post(Uri.parse(url), body: {
        "coordenadas": coordenadas
      }, headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        final json = convert.jsonDecode(response.body);
        return json['corrida'];
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  save() {
    notifyListeners();
  }
}
