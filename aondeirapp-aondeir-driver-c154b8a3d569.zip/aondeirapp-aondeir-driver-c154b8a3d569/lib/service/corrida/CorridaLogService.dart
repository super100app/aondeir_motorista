import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'dart:convert' as convert;

class CorridaLogService extends ChangeNotifier {
  final storage = new FlutterSecureStorage();
  final BuildContext context;

  CorridaLogService(this.context) {}

  static Future<bool> registrarFirebaseRealtimeAtivado({
    required int usuarioMotoristaId,
    int? corridaId,
    int? corridaStatusId,
    String? mensagem,
  }) async {
    try {
      String url = dotenv.env['BASE_URL']! + "api/corrida-log/firebase-realtime-ativado";
      var token = await FlutterSecureStorage().read(key: 'jwt');
      var response = await http.post(Uri.parse(url), headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      }, body: {
        'usuarioMotoristaId': usuarioMotoristaId.toString(),
        'corridaId': corridaId?.toString() ?? '',
        'corridaStatusId': corridaStatusId?.toString() ?? '',
        'mensagem': mensagem ?? '',
      });

      if (response.statusCode == 200 || response.statusCode == 201) {
        return true;
      } else {
        return false;
      }
    } on http.ClientException catch (e) {
      print('❌ [CorridaLogService] Erro ao registrar Firebase Realtime ativado: $e');
      throw e;
    }
  }

  static Future<bool> registrarFirebaseNotificacaoRecebida({
    required int usuarioMotoristaId,
    int? corridaId,
    int? corridaStatusId,
    String? mensagem,
  }) async {
    try {
      String url = dotenv.env['BASE_URL']! + "api/corrida-log/firebase-notificacao-recebida";
      var token = await FlutterSecureStorage().read(key: 'jwt');
      var response = await http.post(Uri.parse(url), headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      }, body: {
        'usuarioMotoristaId': usuarioMotoristaId.toString(),
        'corridaId': corridaId?.toString() ?? '',
        'corridaStatusId': corridaStatusId?.toString() ?? '',
        'mensagem': mensagem ?? '',
      });

      if (response.statusCode == 200 || response.statusCode == 201) {
        return true;
      } else {
        return false;
      }
    } on http.ClientException catch (e) {
      print('❌ [CorridaLogService] Erro ao registrar notificação recebida: $e');
      throw e;
    }
  }

  static Future<bool> registrarFirebaseNotificacaoAberta({
    required int usuarioMotoristaId,
    int? corridaId,
    int? corridaStatusId,
    String? mensagem,
  }) async {
    try {
      String url = dotenv.env['BASE_URL']! + "api/corrida-log/firebase-notificacao-aberta";
      var token = await FlutterSecureStorage().read(key: 'jwt');
      var response = await http.post(Uri.parse(url), headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      }, body: {
        'usuarioMotoristaId': usuarioMotoristaId.toString(),
        'corridaId': corridaId?.toString() ?? '',
        'corridaStatusId': corridaStatusId?.toString() ?? '',
        'mensagem': mensagem ?? '',
      });

      if (response.statusCode == 200 || response.statusCode == 201) {
        return true;
      } else {
        return false;
      }
    } on http.ClientException catch (e) {
      print('❌ [CorridaLogService] Erro ao registrar notificação aberta: $e');
      throw e;
    }
  }

  static Future<List<Map<String, dynamic>>?> buscarLogsPorUsuario(int usuarioId) async {
    try {
      String url = dotenv.env['BASE_URL']! + "api/corrida-log/usuario/$usuarioId";
      var token = await FlutterSecureStorage().read(key: 'jwt');
      
      var response = await http.get(Uri.parse(url), headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        var data = convert.jsonDecode(response.body);
        return List<Map<String, dynamic>>.from(data['logs']);
      } else {
        print('❌ [CorridaLogService] Erro ao buscar logs do usuário: ${response.statusCode}');
        return null;
      }
    } on http.ClientException catch (e) {
      print('❌ [CorridaLogService] Erro ao buscar logs do usuário: $e');
      throw e;
    }
  }

  static Future<List<Map<String, dynamic>>?> buscarLogsPorCorrida(int corridaId) async {
    try {
      String url = dotenv.env['BASE_URL']! + "api/corrida-log/corrida/$corridaId";
      var token = await FlutterSecureStorage().read(key: 'jwt');
      
      var response = await http.get(Uri.parse(url), headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        var data = convert.jsonDecode(response.body);
        return List<Map<String, dynamic>>.from(data['logs']);
      } else {
        print('❌ [CorridaLogService] Erro ao buscar logs da corrida: ${response.statusCode}');
        return null;
      }
    } on http.ClientException catch (e) {
      print('❌ [CorridaLogService] Erro ao buscar logs da corrida: $e');
      throw e;
    }
  }

  save() {
    notifyListeners();
  }
}
