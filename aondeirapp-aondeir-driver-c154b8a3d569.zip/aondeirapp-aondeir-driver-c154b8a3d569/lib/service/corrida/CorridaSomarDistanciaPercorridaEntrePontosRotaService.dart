import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class CorridaSomarDistanciaPercorridaEntrePontosRotaService
    extends ChangeNotifier {
  double totalPercorrido = 0.0;

  execute(novaDistancia) async {
    try {
      totalPercorrido = totalPercorrido + novaDistancia;
      await this.save();
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  save() {
    notifyListeners();
  }
}
