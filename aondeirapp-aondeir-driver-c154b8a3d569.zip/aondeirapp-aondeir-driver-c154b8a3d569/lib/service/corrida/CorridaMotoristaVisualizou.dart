import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:provider/provider.dart';
import 'dart:convert' as convert;
import '../CorridaService.dart';
import '../UsuarioService.dart';

class CorridaMotoristaVisualizouService extends ChangeNotifier {
  final storage = new FlutterSecureStorage();
  final BuildContext context;

  CorridaMotoristaVisualizouService(this.context) {}

  execute() async {
    try {
      Provider.of<UsuarioService>(context, listen: false);
      var corridaService = Provider.of<CorridaService>(context, listen: false);

      var corrida = await corridaService.pegarCorridaAndamento();

      String url = dotenv.env['BASE_URL']! +
          "api/motorista-visualizou/" +
          corrida['id'].toString();

      var token = await storage.read(key: 'jwt');

      var response = await http.get(Uri.parse(url), headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        convert.jsonDecode(response.body);
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  save() {
    notifyListeners();
  }
}
