import 'dart:io';
import 'package:aondeir_motorista/models/Categoria.dart';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:http/http.dart' as http;
import 'dart:convert' as convert;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class CategoriaService extends ChangeNotifier {
  final storage = new FlutterSecureStorage();

  buscarCategoriasMacaneta() async {
    try {
      String url = dotenv.env['BASE_URL']! +
          "api/motorista/categoria/buscar-categorias-macaneta";

      var token = await storage.read(key: 'jwt');

      var response = await http.get(Uri.parse(url), headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      List<Categoria> listaCategoria = [];

      if (response.statusCode == 200) {
        final json = convert.jsonDecode(response.body);

        for (var element in json['categorias']) {
          var categoria = Categoria.fromJson(element);
          listaCategoria.add(categoria);
        }
      }

      return listaCategoria;
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  save() {
    notifyListeners();
  }
}
