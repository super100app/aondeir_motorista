import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:http/http.dart' as http;
import 'dart:convert' as convert;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class FirebaseService extends ChangeNotifier {
  final storage = new FlutterSecureStorage();

  salvarFirebaseToken(tokenFirebase) async {
    try {
      String url = dotenv.env['BASE_URL']! + "api/firebase/salvar-token";
      var token = await storage.read(key: 'jwt');
      var response = await http.post(Uri.parse(url), body: {
        tokenFirebase: tokenFirebase
      }, headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });
      if (response.statusCode == 200) {
        await this.save();
        return true;
      } else if (response.statusCode == 400) {
        await convert.jsonDecode(response.body);
        await this.save();
        return true;
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  save() {
    notifyListeners();
  }
}
