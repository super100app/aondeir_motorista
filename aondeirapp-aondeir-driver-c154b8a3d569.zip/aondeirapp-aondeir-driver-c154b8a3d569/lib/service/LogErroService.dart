import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;

class LogErroService extends ChangeNotifier {
  final storage = new FlutterSecureStorage();

  addErro(funcao, e, stackTrace) async {
    try {
      String url = dotenv.env['BASE_URL']! + "api/log-erro";
      var token = await storage.read(key: 'jwt');
   
      var response = await http.post(
        Uri.parse(url),headers: {
          HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
        },
        body: {
          "funcao": funcao,
          "erro": e,
          "stackTrace": stackTrace,
        },
      );
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  save() {
    notifyListeners();
  }
}
