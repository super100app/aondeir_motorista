import 'package:flutter/material.dart';

class StatusService extends ChangeNotifier {
  var disponivel = true;

  save() {
    notifyListeners();
  }
}
