import 'dart:io';
import 'package:aondeir_motorista/models/Banco.dart';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:http/http.dart' as http;
import 'dart:convert' as convert;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class BancoService extends ChangeNotifier {
  final storage = new FlutterSecureStorage();
  List<Banco> bancos = [];

  pegarBancos() async {
    try {
      String url = dotenv.env['BASE_URL']! + "api/bancos/pegar";

      var token = await storage.read(key: 'jwt');

      var response = await http.get(Uri.parse(url), headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        final json = await convert.jsonDecode(response.body);

        List<Banco> listaBancos = [];
        for (var element in json['bancos']) {
          var banco = Banco.fromJson(element);
          listaBancos.add(banco);
        }

        this.bancos = listaBancos;
        await this.save();
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  save() {
    notifyListeners();
  }
}
