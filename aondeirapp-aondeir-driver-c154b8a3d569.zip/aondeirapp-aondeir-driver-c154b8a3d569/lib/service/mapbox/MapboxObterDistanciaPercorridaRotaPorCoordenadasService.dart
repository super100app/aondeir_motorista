import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert' as convert;

class MapboxObterDistanciaPercorridaRotaPorCoordenadasService
    extends ChangeNotifier {
  var distancia = 0.0;
  execute(coordenadas) async {
    try {
      String url =
          "https://api.mapbox.com/directions/v5/mapbox/driving/${coordenadas}?access_token=sk.eyJ1IjoiYW9uZGVpcmFwcCIsImEiOiJjbGhhamd5MjkwaTBqM2hudHpiNnNvM2JyIn0.N6f0K7qHPpj4ByOdTxJcIQ";

      var response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        var json = convert.jsonDecode(response.body);

        if (json["routes"][0]['distance'] > 0) {
          distancia = json["routes"][0]['distance'];
          await this.save();
        }
      } else {
        convert.jsonDecode(response.body);
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  save() {
    notifyListeners();
  }
}
