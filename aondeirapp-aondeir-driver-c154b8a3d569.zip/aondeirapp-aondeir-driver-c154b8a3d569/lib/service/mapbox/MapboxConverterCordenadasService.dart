import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class MapboxConverterCordenadasService extends ChangeNotifier {
  var coordenadasCorvertidas;
  execute(coordenadas) async {
    try {
      if (coordenadas.length > 0) {
        coordenadasCorvertidas = coordenadas
            .map((coord) => '${coord['longitude']},${coord['latitude']}')
            .join(';');
        await this.save();
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  save() {
    notifyListeners();
  }
}
