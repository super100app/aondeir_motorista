import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'dart:convert' as convert;

class MapboxRecalcularRotaService extends ChangeNotifier {
  final storage = new FlutterSecureStorage();
  var rota;
  var distancia = 0.0;
  var duracao = 0.0;

  execute(partidaLatitude, partidaLongitude, destinoLatitude,
      destinoLongitude) async {
    try {
      String url = dotenv.env['BASE_URL']! + "api/mapbox/pegar-rota";
      var token = await storage.read(key: 'jwt');
      var response = await http.post(Uri.parse(url), body: {
        "endereco_partida_latitude": partidaLatitude.toString(),
        "endereco_partida_longitude": partidaLongitude.toString(),
        "endereco_destino_latitude": destinoLatitude.toString(),
        "endereco_destino_longitude": destinoLongitude.toString(),
      }, headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      convert.jsonDecode(response.body);
      if (response.statusCode == 200) {
        var resp = convert.jsonDecode(response.body);
        rota = resp['rota'];
        distancia = resp['distancia'];
        duracao = resp['duracao'];
        await this.save();
      } else if (response.statusCode == 404) {}
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  save() {
    notifyListeners();
  }
}
