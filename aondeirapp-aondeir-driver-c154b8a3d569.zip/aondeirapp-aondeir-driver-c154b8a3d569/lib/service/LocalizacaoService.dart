import 'dart:async';
import 'package:aondeir_motorista/service/SocketService.dart';
import 'package:aondeir_motorista/service/firebase/FirebaseRealtimeService.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';
import 'CorridaService.dart';

class LocalizacaoService extends ChangeNotifier {
  final BuildContext? context;
  var latitudeMotorista = "";
  var longitudeMotorista = "";
  var distanceInMeters = "";
  var numeroFormatado = null;
  var longeDoEmbarque = false;
  var isKm = true;
  double distanciaMinima = 50.0;

  final storage = new FlutterSecureStorage();

  final LocationSettings locationSettingsDefault = LocationSettings(
    accuracy: LocationAccuracy.low,
    // accuracy: LocationAccuracy.best,
    distanceFilter: 100,
  );

  final AndroidSettings locationSettingsAndroid = AndroidSettings(
      accuracy: LocationAccuracy.low,
      // accuracy: LocationAccuracy.best,
      distanceFilter: 100,
      foregroundNotificationConfig: const ForegroundNotificationConfig(
        notificationText:
            "O aplicativo continuará recebendo sua localização mesmo quando você não o estiver usando",
        notificationTitle: "Executando em segundo plano",
        enableWakeLock: true,
      ));

  final AppleSettings locationSettingsApple = AppleSettings(
    // accuracy: LocationAccuracy.bestForNavigation,
    accuracy: LocationAccuracy.low,
    activityType: ActivityType.fitness,
    distanceFilter: 100,
    pauseLocationUpdatesAutomatically: true,
    showBackgroundLocationIndicator: false,
  );

  LocalizacaoService(this.context) {}

  save() {
    notifyListeners();
  }

  Future getAddreesToCoordinate(latitude, longitude) async {
    try {
      List<Placemark> placemarks =
          await placemarkFromCoordinates(latitude, longitude);
      if (placemarks.length > 0) {
        var numeroRua = placemarks[0].street.toString().isNotEmpty
            ? placemarks[0].street.toString() + ", "
            : "";

        var nomeRua = placemarks[0].name.toString().isNotEmpty
            ? placemarks[0].name.toString() + " - "
            : "";

        var bairro = placemarks[0].subLocality.toString().isNotEmpty
            ? placemarks[0].subLocality.toString() + ", "
            : "";

        var cidade = placemarks[0].subAdministrativeArea.toString().isNotEmpty
            ? placemarks[0].subAdministrativeArea.toString() + " - "
            : "";

        var estado = placemarks[0].administrativeArea.toString().isNotEmpty
            ? placemarks[0].administrativeArea.toString() + ", "
            : "";

        var cep = placemarks[0].postalCode.toString().isNotEmpty
            ? placemarks[0].postalCode.toString()
            : "";

        var endereco = numeroRua + nomeRua + bairro + cidade + estado + cep;

        return endereco;
      } else {
        throw Exception(
            'Ops! Nenhum endereço encontrado para as coordenadas fornecidas.');
      }
    } catch (e) {
      throw Exception(
          'Ops! Ocorreu um erro ao buscar o endereço da sua localização');
    }
  }

  Future<Position> getCurrentLocationAberturaCorrida() async {
    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        throw Exception('Ops! Os serviços de localização estão desativados.');
      }

      LocationPermission permission = await Geolocator.checkPermission();

      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          throw Exception('Ops! A permissão de localização foi negada.');
        }
      }

      if (permission == LocationPermission.deniedForever) {
        throw Exception('Ops! Ops! A permissão de localização foi negada.');
      }

      return await Geolocator.getCurrentPosition().then((value) {
        return value;
      });
    } catch (e) {
      throw Exception(
          'Ops! Ocorreu um erro ao buscar o endereço da sua localização. teste');
    }
  }

  Future<void> getCurrentLocation(usuarioMtoristaId) async {
    try {
      Position position = await Geolocator.getCurrentPosition().then((value) {
        return value;
      });
      latitudeMotorista = position.latitude.toString();
      longitudeMotorista = position.longitude.toString();
      print("getCurrentLocation - atualizarLocalizacaoAtual");
      await atualizarLocalizacaoAtual(usuarioMtoristaId);
    } catch (e) {
      throw e;
    }
  }

  // startListening(usuarioMtoristaId) async {
  //   var locationSettings;
  //   if (defaultTargetPlatform == TargetPlatform.android) {
  //     locationSettings = locationSettingsAndroid;
  //   } else if (defaultTargetPlatform == TargetPlatform.iOS ||
  //       defaultTargetPlatform == TargetPlatform.macOS) {
  //     locationSettings = locationSettingsApple;
  //   } else {
  //     locationSettings = locationSettingsDefault;
  //   }

  //   Geolocator.getPositionStream(locationSettings: locationSettings)
  //       .listen((Position? position) async {
  //     if (position != null) {
  //       latitudeMotorista = position.latitude.toString();
  //       longitudeMotorista = position.longitude.toString();
  //       await this.save();
  //       print("getPositionStream - atualizarLocalizacaoAtual");
  //       await atualizarLocalizacaoAtual(usuarioMtoristaId);
  //     }
  //   });
  // }

  atualizarLocalizacaoAtual(usuarioMtoristaId) async {
    print("----atualizarLocalizacaoAtual----");
    try {
      // ⚡ MIGRAÇÃO: Usar Firebase Realtime Database em vez de WebSocket
      try {
        var firebaseService = Provider.of<FirebaseRealtimeService>(this.context!, listen: false);
        await firebaseService.enviarCoordenadasFirebase(
          this.latitudeMotorista.toString(),
          this.longitudeMotorista.toString(),
          usuarioMtoristaId,
        );
        print('✅ [LocalizacaoService] Coordenadas enviadas via Firebase com sucesso');
      } catch (error) {
        print('❌ [LocalizacaoService] Erro ao enviar coordenadas via Firebase: $error');
        // Fallback para WebSocket em caso de erro
        var socketService = Provider.of<SocketService>(this.context!, listen: false);
        socketService.socket?.emit("cordenadas", {
            "latitude": this.latitudeMotorista.toString(),
            "longitude": this.longitudeMotorista.toString(),
            "usuarioId": usuarioMtoristaId
        });
        print('🔄 [LocalizacaoService] Usando WebSocket como fallback');
      }
      
      return true;
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  calculateDistance() async {
    var corridaService =
        Provider.of<CorridaService>(this.context!, listen: false);

    var corrida = await corridaService.pegarCorridaAndamento();

    if (latitudeMotorista != null &&
        latitudeMotorista != null &&
        corrida != null) {
      double startLatitude = double.parse(latitudeMotorista);
      double startLongitude = double.parse(longitudeMotorista);
      double endLatitude = double.parse(corrida['latitude_partida']);
      double endLongitude = double.parse(corrida['longitude_partida']);

      double distanceInMeters = Geolocator.distanceBetween(
        startLatitude,
        startLongitude,
        endLatitude,
        endLongitude,
      );

      distanceInMeters = distanceInMeters;

      double distanceInKilometers = distanceInMeters / 1000;

      var numeroFormatado = distanceInKilometers
          .toStringAsFixed(3)
          .toString()
          .replaceAll('.', ',');

      this.isKm = true;

      if (distanceInKilometers < 1) {
        numeroFormatado = numeroFormatado.substring(2);
        this.isKm = false;
      }

      this.numeroFormatado = numeroFormatado;
    }
  }
}
