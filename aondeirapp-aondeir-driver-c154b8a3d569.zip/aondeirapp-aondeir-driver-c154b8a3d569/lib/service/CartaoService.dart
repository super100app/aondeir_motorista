import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:http/http.dart' as http;
import 'dart:convert' as convert;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import '../models/Cartao.dart';

class CartaoService extends ChangeNotifier {
  final storage = new FlutterSecureStorage();
  var holder_name = "";
  var holder_document = "";
  var number_digits = "";
  var number = "";
  var exp_month = "";
  var exp_year = "";
  var cvv = "";
  var brand = "";
  var cep = "";
  var rua = "";
  var rua_numero = "";
  var bairro = "";
  var cidade = "";
  var estado = "";
  var complemento = "";
  List<Cartao> cartoes = [];
  var cartaoSelecionadoId = "";
  var errorsForm = null;

  cadastrar() async {
    try {
      String url =
          dotenv.env['BASE_URL']! + "api/pagarme/cadastrar-cartao-credito";

      var token = await storage.read(key: 'jwt');
      var response = await http.post(Uri.parse(url), body: {
        "holder_name": holder_name,
        "holder_document": holder_document,
        "number": number,
        "exp_month": exp_month,
        "exp_year": exp_year,
        "cvv": cvv,
        "cep": cep,
        "rua": rua,
        "rua_numero": rua_numero,
        "bairro": bairro,
        "cidade": cidade,
        "estado": estado,
        "complemento": complemento,
      }, headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });
      if (response.statusCode == 200) {
        final json = convert.jsonDecode(response.body);
        Cartao.fromJson(json['cartao']);

        return true;
      } else {
        final json = convert.jsonDecode(response.body);
        this.errorsForm = json;

        this.save();
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  pegarCartoes() async {
    try {
      String url = dotenv.env['BASE_URL']! + "api/pagarme/pegar-cartoes";

      var token = await storage.read(key: 'jwt');

      var response = await http.get(Uri.parse(url), headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        final json = convert.jsonDecode(response.body);

        List<Cartao> listaCartoes = [];
        for (var element in json['cartoes']) {
          var cartao = Cartao.fromJson(element);
          listaCartoes.add(cartao);
        }

        this.cartoes = listaCartoes;
        this.save();
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  save() {
    notifyListeners();
  }
}
