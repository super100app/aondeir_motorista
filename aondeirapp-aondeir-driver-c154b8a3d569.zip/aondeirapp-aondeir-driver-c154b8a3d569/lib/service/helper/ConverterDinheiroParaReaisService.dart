import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';

class ConverterDinheiroParaReaisService extends ChangeNotifier {
  var valorConvertido = "";

  Future<String> execute(valor) async {
    try {
      var formatador = NumberFormat.currency(locale: 'pt_BR', symbol: 'R\$');
      valorConvertido = formatador.format(valor);
      return valorConvertido;
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  save() {
    notifyListeners();
  }
}
