import 'package:flutter/material.dart';

class VariavelControleService extends ChangeNotifier {
  final BuildContext? context;
  var checkIsLogged = false;
  var checkHasCorrida = false;
  var chatAlertaDisparo = false;
  var chatAlerta = false;
  bool startSocket = false;

  VariavelControleService(this.context) {}
  save() {
    notifyListeners();
  }
}
