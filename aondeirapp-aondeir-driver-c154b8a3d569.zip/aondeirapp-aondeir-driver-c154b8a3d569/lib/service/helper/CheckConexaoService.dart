import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class CheckConexaoService extends ChangeNotifier {
  var connectionStatus;
  var connectionDescricao;

  execute() async {
    try {
      var connectivityResult = await Connectivity().checkConnectivity();
    
      if (connectivityResult[0] == ConnectivityResult.mobile) {
        connectionStatus = true;
        connectionDescricao = 'Conectado via dados móveis';
      } else if (connectivityResult[0] == ConnectivityResult.wifi) {
        connectionStatus = true;
        connectionDescricao = 'Conectado via wifi';
      } else {
        connectionStatus = false;
        connectionDescricao = 'Sem conexão com a rede';
      }

      await this.save();
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  save() {
    notifyListeners();
  }
}
