import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class CalcularSegundosRestanteService extends ChangeNotifier {
  var segundosRestantes;

  execute(segundos) async {
    try {
      segundosRestantes = segundos % 60;
      await this.save();
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  save() {
    notifyListeners();
  }
}
