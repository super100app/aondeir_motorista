import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class ConverterSegundoParaMinutoService extends ChangeNotifier {
  int minutos = 0;

  execute(segundos) async {
    try {
      print('🟨🟨🟨 - 1111 obterValorMinutoEmSegundos');
      minutos = segundos ~/ 60;
      await this.save();
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  save() {
    notifyListeners();
  }
}
