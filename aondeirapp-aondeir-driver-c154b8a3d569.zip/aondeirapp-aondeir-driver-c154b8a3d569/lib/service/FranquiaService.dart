import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import 'dart:convert' as convert;

import '../models/Franquia.dart';

class FranquiaService extends ChangeNotifier {
  final storage = new FlutterSecureStorage();
  List<Franquia> franquias = [];

  pegarFranquias() async {
    try {
      String url = dotenv.env['BASE_URL']! + "api/franquia/pegar-franquias";

      var token = await storage.read(key: 'jwt');

      var response = await http.get(Uri.parse(url), headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        final json = convert.jsonDecode(response.body);

        List<Franquia> listaFranquias = [];
        for (var element in json['franquias']) {
          var franquia = Franquia.fromJson(element);
          listaFranquias.add(franquia);
        }

        this.franquias = listaFranquias;
        this.save();
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  save() {
    notifyListeners();
  }
}
