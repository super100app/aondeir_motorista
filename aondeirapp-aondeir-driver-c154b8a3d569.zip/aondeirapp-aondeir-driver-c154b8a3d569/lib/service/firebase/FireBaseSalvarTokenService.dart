import 'dart:io';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;

class FireBaseSalvarTokenService extends ChangeNotifier {
  final storage = new FlutterSecureStorage();

  execute() async {
    try {
      var token = await storage.read(key: 'jwt');
      print('🔑 Obtendo Token FCM...');
      
      // Adicionar timeout e retry logic para evitar bloqueio no login
      String? fcmToken;
      int maxRetries = 3;
      
      for (int i = 0; i < maxRetries; i++) {
        try {
          fcmToken = await FirebaseMessaging.instance
              .getToken()
              .timeout(Duration(seconds: 10));
          
          if (fcmToken != null) {
            print('✅ Token FCM obtido: ${fcmToken.substring(0, 20)}...');
            break;
          }
        } catch (e) {
          print('❌ Tentativa ${i + 1}/$maxRetries falhou: $e');
          if (i < maxRetries - 1) {
            await Future.delayed(Duration(seconds: 2));
          } else {
            print('⚠️ Não foi possível obter token FCM após $maxRetries tentativas');
            print('⚠️ Continuando login sem salvar token (será tentado novamente depois)');
            return; // Não bloqueia o login
          }
        }
      }
      
      if (fcmToken == null) {
        print('⚠️ Token FCM é nulo, pulando salvamento');
        return;
      }
      
      String urlFirebase = dotenv.env['BASE_URL']! + 'api/firebase/salvar-token';
      
      var responseFirebase = await http.post(
        Uri.parse(urlFirebase), 
        body: {"tokenFirebase": fcmToken},
        headers: {
          HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
        }
      ).timeout(Duration(seconds: 10));
      
      if (responseFirebase.statusCode == 200) {
        print('✅ Token Firebase salvo com sucesso no backend');
      } else {
        print('⚠️ Erro ao salvar token no backend: ${responseFirebase.statusCode}');
      }
    } catch (e) {
      print('❌ Erro ao salvar token Firebase: $e');
      // NÃO lança exceção para não bloquear o login
      // O token pode ser salvo em uma próxima tentativa
    }
  }

  save() {
    notifyListeners();
  }
}
