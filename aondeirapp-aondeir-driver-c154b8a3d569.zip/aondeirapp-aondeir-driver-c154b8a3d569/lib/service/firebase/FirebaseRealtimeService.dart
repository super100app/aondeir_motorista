import 'dart:async';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../corrida/CorridaBuscarService.dart';
import '../UsuarioService.dart';
import '../corrida/CorridaLogService.dart';
import '../CorridaService.dart';
import 'package:just_audio/just_audio.dart';
import 'package:audio_session/audio_session.dart';
import 'package:volume_controller/volume_controller.dart';
import 'dart:io';
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart' as overlay;
import '../../screens/Usuario/BottomNavigationBar/NavigationScreen.dart';
import '../../screens/Modal/ModalPadrao.dart';
import 'FirebaseRealtimeConfigService.dart';

class FirebaseRealtimeService extends ChangeNotifier {
  final DatabaseReference _database = FirebaseRealtimeConfigService.getDatabase().ref();
  StreamSubscription<DatabaseEvent>? _novaCorridaSubscription;
  StreamSubscription<DatabaseEvent>? _corridaSubscription;
  StreamSubscription<DatabaseEvent>? _atualizarListaSubscription;
  StreamSubscription<DatabaseEvent>? _mensagemSubscription;
  final BuildContext context;
  bool _isInitialized = false;
  
  // Getter para acessar o database
  DatabaseReference get database => _database;

  FirebaseRealtimeService(this.context) {
    _initializeFirebase();
  }

  // Inicializa Firebase para conexão otimizada
  void _initializeFirebase() async {
    if (!_isInitialized) {
      FirebaseRealtimeConfigService.getDatabase().goOnline();
      _isInitialized = true;
    }
  }

  // Verifica e garante conexão Firebase ativa
  Future<void> _ensureFirebaseConnection() async {
    try {
      FirebaseRealtimeConfigService.getDatabase().goOnline();
      
      // Teste rápido de conectividade
      await _database.child('.info/connected').once().then((snapshot) {
        bool connected = snapshot.snapshot.value == true;
        
        if (!connected) {
          FirebaseRealtimeConfigService.getDatabase().goOnline();
        }
      });
      
    } catch (error) {
      print("❌ [FirebaseRealtime] Erro ao verificar conexão: $error");
      FirebaseRealtimeConfigService.getDatabase().goOnline();
    }
  }

  // Método público para forçar inicialização rápida do Firebase
  Future<void> initializeForFastConnection() async {
    await _ensureFirebaseConnection();
  }

  // Inicia o listener para novas corridas
  void startListeningForNewCorridas(String userId) async {
    
    if (userId.isEmpty || userId == 'null' || userId == '0') {
      return;
    }
    
    // Configurar Firebase para conexão otimizada
    FirebaseRealtimeConfigService.getDatabase().goOnline();
    
    // Cancela subscription anterior se existir
    _novaCorridaSubscription?.cancel();
    
    // Cria o caminho para o nó de novas corridas do usuário
    final novaCorridaRef = _database.child('novaCorrida/$userId');
    // Teste de conectividade antes de configurar o listener
    try {
      final testRef = _database.child('teste');
      await testRef.set({'teste': 'conectividade'});
      await testRef.remove();
    } catch (e) {
      print("❌ FirebaseRealtimeService: Erro no teste de conectividade: $e");
    }
    
    _novaCorridaSubscription = novaCorridaRef.onValue.listen(
      (DatabaseEvent event) async {
        if (event.snapshot.value != null) {
          // Registrar no backend que a notificação foi recebida
          try {
            final usuarioService = Provider.of<UsuarioService>(context, listen: false);
            final usuario = usuarioService.usuario;
            
            if (usuario != null) {
                        // Extrair dados do evento do Firebase
          final dadosCorrida = Map<String, dynamic>.from(event.snapshot.value as Map);
          
          int? corridaId;
          int? statusId;
          
          if (dadosCorrida != null) {
             // Tratar diferentes tipos de dados
            var corridaIdRaw = dadosCorrida['corridaId'];
            if (corridaIdRaw is int) {
              corridaId = corridaIdRaw;
            } else if (corridaIdRaw is String) {
              corridaId = int.tryParse(corridaIdRaw);
            } else if (corridaIdRaw is double) {
              corridaId = corridaIdRaw.toInt();
            }
            
            if (dadosCorrida['corridaStatus'] != null) {
              var statusIdRaw = dadosCorrida['corridaStatus']['id'];
              if (statusIdRaw is int) {
                statusId = statusIdRaw;
              } else if (statusIdRaw is String) {
                statusId = int.tryParse(statusIdRaw);
              } else if (statusIdRaw is double) {
                statusId = statusIdRaw.toInt();
              }
            }
          }
          
              final resultado = await CorridaLogService.registrarFirebaseNotificacaoRecebida(
                usuarioMotoristaId: usuario.id,
                corridaId: corridaId,
                corridaStatusId: statusId,
                mensagem: 'Nova corrida recebida via Firebase Realtime Database',
              );
            }
          } catch (error) {
            print("❌ FirebaseRealtimeService: Erro ao registrar log de notificação recebida: $error");
            print("🔍 FirebaseRealtimeService: Stack trace: ${error.toString()}");
          }
          
          // Processa a nova corrida
          await _processarNovaCorrida(event.snapshot.value);
          
          // Remove o dado após processar (opcional - para evitar reprocessamento)
          // Aguarda um pouco antes de remover para garantir que foi processado
          Future.delayed(Duration(seconds: 1), () async {
            try {
              await novaCorridaRef.remove();
            } catch (e) {
              print("⚠️ FirebaseRealtimeService: Erro ao remover dados: $e");
            }
          });
        }
      },
      onError: (error) {
        print("❌ FirebaseRealtimeService: ===== ERRO NO LISTENER =====");
        print("❌ FirebaseRealtimeService: Erro no listener: $error");
        print("🔍 FirebaseRealtimeService: Stack trace: ${error.toString()}");
      },
    );
    
    // Registrar no backend que o Firebase Realtime foi ativado
    try {
      final usuarioService = Provider.of<UsuarioService>(context, listen: false);
      final usuario = usuarioService.usuario;
      
      if (usuario != null) {
        final resultado = await CorridaLogService.registrarFirebaseRealtimeAtivado(
          usuarioMotoristaId: usuario.id,
          mensagem: 'Firebase Realtime Database ativado para receber novas corridas',
        );
      }
    } catch (error) {
      print("❌ FirebaseRealtimeService: Erro ao registrar log de ativação: $error");
      print("🔍 FirebaseRealtimeService: Stack trace: ${error.toString()}");
    }
  }

  // Para o listener
  void stopListening() {
    _novaCorridaSubscription?.cancel();
    _novaCorridaSubscription = null;
  }

  // Processa uma nova corrida recebida
  Future<void> _processarNovaCorrida(dynamic data) async {
    final startTime = DateTime.now();
    try {
      var usuarioService = Provider.of<UsuarioService>(context, listen: false);
      var corridaService = Provider.of<CorridaService>(context, listen: false);
      
      // Verificar se a corrida está cancelada
      bool corridaCancelada = false;
      bool ehCorridaEmAndamento = false;
      
      if (data is Map) {
        final dataMap = Map<String, dynamic>.from(data);
        
        // O status vem diretamente em corridaStatus
        String? status = dataMap['corridaStatus']?.toString().toUpperCase();
        int? corridaIdCancelada = dataMap['corridaId'] as int?;
        
        print("📋 Status da corrida: $status | ID: $corridaIdCancelada");
        
        if (status != null && status.contains('CANCELADA')) {
          corridaCancelada = true;
          
          // Verificar se é a corrida que o motorista está em andamento
          // corridaService.corrida é um Map
          final corridaAtual = corridaService.corrida;
          
          if (corridaAtual != null && 
              corridaAtual is Map &&
              corridaAtual.isNotEmpty &&
              corridaIdCancelada != null) {
            
            // Pegar o ID da corrida atual (pode estar em diferentes campos)
            int? corridaAtualId;
            if (corridaAtual['id'] != null) {
              corridaAtualId = corridaAtual['id'] as int?;
            }
            
            if (corridaAtualId != null && corridaAtualId == corridaIdCancelada) {
              ehCorridaEmAndamento = true;
              print("⚠️ CORRIDA EM ANDAMENTO FOI CANCELADA! Abrindo app para notificar motorista...");
            } else {
              print("❌ Corrida cancelada detectada (não é a corrida em andamento), não processando");
              return; // Não processa, não toca som, não abre overlay
            }
          } else {
            print("❌ Corrida cancelada detectada (motorista não tem corrida em andamento), não processando");
            return; // Não processa, não toca som, não abre overlay
          }
        }
      }
      
      // Se for corrida em andamento cancelada, APENAS abre o app (não busca corridas)
      if (corridaCancelada && ehCorridaEmAndamento) {
        print("🚨 Abrindo app por cancelamento de corrida em andamento...");
        await _openApp(); // Método para abrir o app diretamente
        return; // SAI AQUI, não executa o resto do código
      }
      
      // Se chegou aqui, não é corrida em andamento cancelada, processa normalmente
      var corridaBuscarService = Provider.of<CorridaBuscarService>(
        context, 
        listen: false
      );

      await corridaBuscarService.execute('', '');
      
      // Verifica se o app está em background (apenas para novas corridas)
      AppLifecycleState? state = WidgetsBinding.instance.lifecycleState;
      if (state == AppLifecycleState.paused || state == AppLifecycleState.detached) {
        await _openOverlay();
      }
      
      // Registrar no backend que a notificação foi aberta
      try {
        final usuario = usuarioService.usuario;
        if (usuario != null) {
          // Extrair dados da corrida processada
          int? corridaId;
          int? statusId;
          if (data is Map) {
            final dataMap = Map<String, dynamic>.from(data);
            corridaId = dataMap['corridaId'] as int?;
            if (dataMap['corridaStatus'] != null) {
              final statusMap = Map<String, dynamic>.from(dataMap['corridaStatus']);
              statusId = statusMap['id'] as int?;
            }
          }
          
          await CorridaLogService.registrarFirebaseNotificacaoAberta(
            usuarioMotoristaId: usuario.id,
            corridaId: corridaId,
            corridaStatusId: statusId,
            mensagem: 'Motorista abriu a notificação de nova corrida',
          );
        }
      } catch (error) {
        print("❌ FirebaseRealtimeService: Erro ao registrar log de notificação aberta: $error");
      }
      
      if (usuarioService.usuario.motorista['logado'] != 'CONECTADO') {
        // Mostra alerta para conectar
      } else {
        // Toca o som de nova corrida
        await _playNewCorridaSound();
      }
      
      final totalTime = DateTime.now().difference(startTime);
      
    } catch (e) {
      final errorTime = DateTime.now().difference(startTime);
      print("❌ FirebaseRealtimeService: Erro ao processar nova corrida após ${errorTime.inMilliseconds}ms: $e");
    }
  }

  // Abre o overlay quando o app está em background
  Future<void> _openOverlay() async {
    if (Platform.isAndroid) {
      // Verifica permissão de sobreposição usando flutter_overlay_window
      bool? hasPermission = await overlay.FlutterOverlayWindow.isPermissionGranted();
      if (hasPermission != true) {
        await overlay.FlutterOverlayWindow.requestPermission();
      }

      bool canLaunch = await FlutterForegroundTask.isRunningService;
      if (canLaunch) {
        FlutterForegroundTask.launchApp("/");
      } else {
        try {
          await FlutterForegroundTask.startService(
          notificationTitle: 'Serviço Ativo',
          notificationText: 'Aguardando evento...',
        );
        } catch (e) {
          print("❌ Erro ao iniciar serviço: $e");
        }        
      }
    }
  }

  // Abre o app diretamente (usado para corrida em andamento cancelada)
  Future<void> _openApp() async {
    if (Platform.isAndroid) {
      try {
        // Fecha overlay se estiver aberto
        bool isOverlayActive = await overlay.FlutterOverlayWindow.isActive();
        if (isOverlayActive) {
          await overlay.FlutterOverlayWindow.closeOverlay();
        }
        
        // Tenta abrir o app via Foreground Task
        bool canLaunch = await FlutterForegroundTask.isRunningService;
        if (canLaunch) {
          FlutterForegroundTask.launchApp("/");
          print("✅ App aberto via FlutterForegroundTask");
        } else {
          // Fallback: iniciar serviço e abrir
          await FlutterForegroundTask.startService(
            notificationTitle: 'Aondeir',
            notificationText: 'Corrida cancelada',
          );
          FlutterForegroundTask.launchApp("/");
          print("✅ Serviço iniciado e app aberto");
        }
        
        // Tocar som de alerta
        await _playNewCorridaSound();
        
      } catch (e) {
        print("❌ Erro ao abrir app: $e");
      }
    }
  }

  // Toca o som de nova corrida
  Future<void> _playNewCorridaSound() async {
    try {
      final volumeController = VolumeController.instance;
      volumeController.showSystemUI = true;
      // await volumeController.setVolume(1.0);
      
      final audioPlayer = AudioPlayer();
      final session = await AudioSession.instance;
      await session.configure(AudioSessionConfiguration.speech());
      await audioPlayer.setAsset('assets/toques/viagemdisponivel.mp3');
      // await audioPlayer.setVolume(1.0);
      await audioPlayer.play();
    } catch (e) {
      print("❌ Erro ao tocar som: $e");
    }
  }



  // Inicia o listener para cancelamentos de corrida
  void startListeningForCorridaCancelada(String userId) async {
    try {
      if (userId.isEmpty || userId == 'null' || userId == '0') {
        print("❌ [FirebaseRealtime] userId inválido: '$userId'");
        return;
      }

      // Garantir que Firebase está online e conectado
      await _ensureFirebaseConnection();

      // Parar listener anterior se existir
      _corridaSubscription?.cancel();
      
      // Iniciar novo listener
      final corridaRef = _database.child('corridaCanceladaPeloPassageiroFireBase/$userId');
      _corridaSubscription = corridaRef.onValue.listen(
        (event) => _processarCancelamentoCorrida(event, userId),
        onError: (error) {
          print("❌ [FirebaseRealtime] Erro no listener de cancelamento: $error");
        }
      );
    } catch (error) {
      print("❌ [FirebaseRealtime] Erro ao iniciar listener de cancelamento: $error");
    }
  }

  // Inicia o listener para cancelamentos de corrida com callback personalizado
  void startListeningForCorridaCanceladaWithCallback(String userId, Function(Map<dynamic, dynamic>) callback) async {
    try {
      if (userId.isEmpty || userId == 'null' || userId == '0') {
        print("❌ [FirebaseRealtime] userId inválido: '$userId'");
        return;
      }

      // Garantir que Firebase está online e conectado
      await _ensureFirebaseConnection();
      
      // Parar listener anterior se existir
      _corridaSubscription?.cancel();
      
      // Iniciar novo listener com callback
      final corridaRef = _database.child('corridaCanceladaPeloPassageiroFireBase/$userId');
      _corridaSubscription = corridaRef.onValue.listen(
        (event) => _processarCancelamentoCorridaWithCallback(event, userId, callback),
        onError: (error) {
          print("❌ [FirebaseRealtime] Erro no listener de cancelamento: $error");
        }
      );
      
    } catch (error) {
      print("❌ [FirebaseRealtime] Erro ao iniciar listener de cancelamento com callback: $error");
    }
  }

  // ⚡ NOVO MÉTODO: Enviar coordenadas via Firebase Realtime Database
  Future<void> enviarCoordenadasFirebase(String latitude, String longitude, int usuarioId) async {
    try {
      await _ensureFirebaseConnection();
      
      // Criar referência para coordenadas do usuário
      final coordenadasRef = _database.child('coordenadas/$usuarioId');
      
      // Preparar dados das coordenadas
      final dadosCoordenadas = {
        'latitude': latitude,
        'longitude': longitude,
        'usuarioId': usuarioId,
        'timestamp': DateTime.now().millisecondsSinceEpoch,
        'dataAtualizacao': DateTime.now().toIso8601String()
      };
      
      // Salvar no Firebase
      await coordenadasRef.set(dadosCoordenadas);
      
    } catch (error) {
      print('❌ [FirebaseRealtime] Erro ao enviar coordenadas via Firebase: $error');
      throw error;
    }
  }

  // Processa dados de cancelamento de corrida
  void _processarCancelamentoCorrida(DatabaseEvent event, String userId) async {
    try {
      if (event.snapshot.value == null) {
        return;
      }

      var data = event.snapshot.value as Map<dynamic, dynamic>;
      // Verificar se é um cancelamento
      String? status = data['status']?.toString();
      // Verificar se é especificamente um cancelamento pelo passageiro
      if (status == 'CANCELADA' && data['msg']?.toString().contains('cancelada pelo passageiro') == true) {
        var corridaData = data['corrida'];
        if (corridaData != null) {
          // Navegar para tela inicial
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => NavigationScreen()),
          );
          
          // Resetar estado do serviço
          var corridaService = Provider.of<CorridaService>(context, listen: false);
          corridaService.resetarStateService();
          
          // Mostrar modal de cancelamento
          if (corridaData['id'] != null) {
            showDialog<String>(
              context: context,
              builder: (BuildContext context) => ModalPadrao(
                message: "Corrida cancelada Motivo: ${corridaData['motivo_descricao_cancelamento'] ?? 'Não informado'}",
                loading: true
              )
            );
          }
        }
        
        // Limpar dados do Firebase após processar
        await _database.child('corridaCanceladaPeloPassageiroFireBase/$userId').remove();
      }
      
    } catch (error) {
      print("❌ [FirebaseRealtime] Erro ao processar cancelamento: $error");
    }
  }

  // Processa dados de cancelamento de corrida com callback personalizado
  void _processarCancelamentoCorridaWithCallback(DatabaseEvent event, String userId, Function(Map<dynamic, dynamic>) callback) async {
    try {
      if (event.snapshot.value == null) {
        return;
      }
      var data = event.snapshot.value as Map<dynamic, dynamic>;
      
      // Verificar se é um cancelamento
      String? status = data['status']?.toString();
      
      // Verificar se é realmente um cancelamento
      bool isCancelada = status == 'CANCELADA' || 
                        data['msg']?.toString().toLowerCase().contains('cancelada') == true ||
                        data['msg']?.toString().toLowerCase().contains('cancelou') == true;
      
      if (isCancelada) {
        
        // Chamar callback personalizado
        callback(data);
        
        // Limpar dados do Firebase após processar
        await _database.child('corridaCanceladaPeloPassageiroFireBase/$userId').remove();
      }
      
    } catch (error) {
      print("❌ [FirebaseRealtime] Erro ao processar cancelamento com callback: $error");
    }
  }

  // Para o listener de cancelamento
  void stopListeningForCorridaCancelada() {
    try {
      _corridaSubscription?.cancel();
      _corridaSubscription = null;
    } catch (error) {
      print("❌ [FirebaseRealtime] Erro ao parar listener de cancelamento: $error");
    }
  }

  // Inicia o listener para atualizações silenciosas de lista de corridas
  // Usado quando outro motorista aceita uma corrida ou quando há cancelamento
  // Apenas atualiza a lista sem tocar som ou fazer overlay
  void startListeningForAtualizarListaCorridas(String userId) async {
    try {
      if (userId.isEmpty || userId == 'null' || userId == '0') {
        print("❌ [FirebaseRealtime] userId inválido para atualizar lista: '$userId'");
        return;
      }

      // Garantir que Firebase está online e conectado
      await _ensureFirebaseConnection();

      // Parar listener anterior se existir
      _atualizarListaSubscription?.cancel();
      
      // Iniciar novo listener
      final atualizarListaRef = _database.child('atualizarListaCorridas/$userId');
      _atualizarListaSubscription = atualizarListaRef.onValue.listen(
        (event) => _processarAtualizacaoListaCorridas(event, userId),
        onError: (error) {
          print("❌ [FirebaseRealtime] Erro no listener de atualizar lista: $error");
        }
      );
      
      print("✅ [FirebaseRealtime] Listener de atualizar lista iniciado para userId: $userId");
    } catch (error) {
      print("❌ [FirebaseRealtime] Erro ao iniciar listener de atualizar lista: $error");
    }
  }

  /// Converte dados do Firebase (Map<Object?, Object?>) para Map<String, dynamic>
  Map<String, dynamic> _convertToMapStringDynamic(dynamic value) {
    if (value == null) {
      return {};
    }
    
    if (value is Map) {
      Map<String, dynamic> result = {};
      value.forEach((key, val) {
        String stringKey = key.toString();
        if (val is Map) {
          result[stringKey] = _convertToMapStringDynamic(val);
        } else if (val is List) {
          result[stringKey] = val.map((item) {
            if (item is Map) {
              return _convertToMapStringDynamic(item);
            }
            return item;
          }).toList();
        } else {
          result[stringKey] = val;
        }
      });
      return result;
    }
    
    return {};
  }

  /// Inicia listener em tempo real para mensagens do chat
  void iniciarListenerMensagemChat(String userId, int corridaId, Function(Map<dynamic, dynamic>) onMensagemRecebida) async {
    try {
      if (userId.isEmpty || userId == 'null' || userId == '0' || corridaId == 0) {
        print("❌ [FirebaseRealtime] userId ou corridaId inválido para mensagens");
        return;
      }

      // Garantir que Firebase está online e conectado
      await _ensureFirebaseConnection();

      // Parar listener anterior se existir
      _mensagemSubscription?.cancel();
      
      // Iniciar novo listener
      final mensagemRef = _database.child('mensagemChatChamada/$userId/$corridaId');
      _mensagemSubscription = mensagemRef.onValue.listen(
        (event) {
          if (event.snapshot.value != null) {
            print("💬 [FirebaseRealtime] Evento recebido do Firebase - userId: $userId, corridaId: $corridaId");
            print("💬 [FirebaseRealtime] Evento snapshot.value: ${event.snapshot.value}");
            
            // Converter Map<Object?, Object?> para Map<String, dynamic>
            var rawData = event.snapshot.value;
            Map<String, dynamic> data = _convertToMapStringDynamic(rawData);
            
            print("💬 [FirebaseRealtime] Dados recebidos (convertidos): ${data.toString()}");
            onMensagemRecebida(data);
            
            // Limpar mensagem após processar
            Future.delayed(Duration(milliseconds: 500), () async {
              try {
                await mensagemRef.remove();
              } catch (error) {
                print("❌ [FirebaseRealtime] Erro ao limpar mensagem: $error");
              }
            });
          }
        },
        onError: (error) {
          print("❌ [FirebaseRealtime] Erro no listener de mensagens: $error");
        }
      );
      
      print("✅ [FirebaseRealtime] Listener de mensagens iniciado para corrida $corridaId");
    } catch (error) {
      print("❌ [FirebaseRealtime] Erro ao iniciar listener de mensagens: $error");
    }
  }

  /// Para o listener de mensagens
  void pararListenerMensagemChat() {
    try {
      _mensagemSubscription?.cancel();
      _mensagemSubscription = null;
    } catch (error) {
      print("❌ [FirebaseRealtime] Erro ao parar listener de mensagens: $error");
    }
  }

  // Processa atualização silenciosa da lista de corridas
  void _processarAtualizacaoListaCorridas(DatabaseEvent event, String userId) async {
    try {
      if (event.snapshot.value == null) {
        return;
      }

      print("🔄 [FirebaseRealtime] Atualizando lista de corridas silenciosamente...");
      
      // Apenas busca a lista de corridas novamente, sem tocar som ou fazer overlay
      var corridaBuscarService = Provider.of<CorridaBuscarService>(
        context, 
        listen: false
      );

      await corridaBuscarService.execute('', '');
      
      print("✅ [FirebaseRealtime] Lista de corridas atualizada silenciosamente");
      
      // Limpar dados do Firebase após processar
      try {
        await _database.child('atualizarListaCorridas/$userId').remove();
      } catch (e) {
        print("⚠️ [FirebaseRealtime] Erro ao limpar dados de atualizar lista: $e");
      }
      
    } catch (error) {
      print("❌ [FirebaseRealtime] Erro ao processar atualização de lista: $error");
    }
  }

  // Para o listener de atualizar lista
  void stopListeningForAtualizarListaCorridas() {
    try {
      _atualizarListaSubscription?.cancel();
      _atualizarListaSubscription = null;
    } catch (error) {
      print("❌ [FirebaseRealtime] Erro ao parar listener de atualizar lista: $error");
    }
  }

  @override
  void dispose() {
    stopListening();
    stopListeningForCorridaCancelada();
    stopListeningForAtualizarListaCorridas();
    super.dispose();
  }
}
