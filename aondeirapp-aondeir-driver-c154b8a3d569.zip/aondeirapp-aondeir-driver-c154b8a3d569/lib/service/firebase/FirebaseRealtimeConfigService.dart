import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';

class FirebaseRealtimeConfigService {
  static FirebaseDatabase? _databaseInstance;
  
  /// Obtém instância do FirebaseDatabase configurada com URL do .env
  static FirebaseDatabase getDatabase() {
    if (_databaseInstance != null) {
      return _databaseInstance!;
    }
    
    try {
      // Obter URL do Firebase Realtime do .env
      final databaseURL = dotenv.env['FIREBASE_REALTIME_URL'];
      
      if (databaseURL == null || databaseURL.isEmpty) {
        print('⚠️ [FirebaseRealtimeConfig] FIREBASE_REALTIME_URL não encontrado no .env, usando instância padrão');
        _databaseInstance = FirebaseDatabase.instance;
        return _databaseInstance!;
      }
      
      print('✅ [FirebaseRealtimeConfig] Configurando Firebase Realtime com URL: $databaseURL');
      
      // Obter app padrão do Firebase
      final app = Firebase.app();
      
      // Criar instância do FirebaseDatabase com URL customizada
      _databaseInstance = FirebaseDatabase.instanceFor(
        app: app,
        databaseURL: databaseURL,
      );
      
      return _databaseInstance!;
    } catch (e) {
      print('❌ [FirebaseRealtimeConfig] Erro ao configurar Firebase Realtime: $e');
      print('⚠️ [FirebaseRealtimeConfig] Usando instância padrão do Firebase');
      _databaseInstance = FirebaseDatabase.instance;
      return _databaseInstance!;
    }
  }
  
  /// Reseta a instância (útil para testes ou mudança de ambiente)
  static void reset() {
    _databaseInstance = null;
  }
}

