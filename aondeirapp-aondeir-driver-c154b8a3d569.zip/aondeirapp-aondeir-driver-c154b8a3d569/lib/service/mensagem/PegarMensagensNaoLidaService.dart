import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import 'dart:convert' as convert;

class PegarMensagensNaoLidaService extends ChangeNotifier {
  final storage = new FlutterSecureStorage();
  int qtdMensagemMatrizNaoLida = 0;
  int qtdMensagemFranquiaNaoLida = 0;
  int qtdMensagemNaoLida = 0;

  execute() async {
    try {
      String url = dotenv.env['BASE_URL']! +
          "api/chat-franquia/pegar-qtd-mensagens-nao-lida";

      var token = await storage.read(key: 'jwt');

      var response = await http.get(Uri.parse(url), headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        var resp = convert.jsonDecode(response.body);

        this.qtdMensagemMatrizNaoLida = resp['qtdMensagemMatrizNaoLida'];
        this.qtdMensagemFranquiaNaoLida = resp['qtdMensagemFranquiaNaoLida'];
        this.qtdMensagemNaoLida = resp['qtdMensagemNaoLida'];

        this.save();
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  save() {
    notifyListeners();
  }
}
