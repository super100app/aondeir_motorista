import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'dart:io';

class UpdateService extends ChangeNotifier {
  bool _isUpdateAvailable = false;
  String _currentVersion = '0.0.0';
  String _latestVersion = '0.0.0';
  bool _isModalShowing = false; // ✅ Prevenir múltiplas modais

  bool get isUpdateAvailable => _isUpdateAvailable;
  String get currentVersion => _currentVersion;
  String get latestVersion => _latestVersion;

  // ✅ Verificar se deve mostrar aviso
  bool shouldShowUpdateWarning() {
    return _isUpdateAvailable;
  }

  // ✅ Resetar flag de modal (para casos especiais)
  void resetModalFlag() {
    _isModalShowing = false;
    print('🔄 UpdateService - Flag de modal resetada');
  }

  // ✅ Abrir loja de aplicativos
  Future<void> _openAppStore() async {
    try {
      if (Platform.isIOS) {
        await _openAppStoreIOS();
      } else if (Platform.isAndroid) {
        await _openAppStoreAndroid();
      } else {
        print('❌ Plataforma não suportada para redirecionamento');
        return;
      }
    } catch (e) {
      print('❌ Erro ao abrir loja: $e');
    }
  }

  // ✅ Abrir App Store no iOS
  Future<void> _openAppStoreIOS() async {
    try {
      // URL do App Store para o app do motorista
      const String appStoreUrl = 'https://apps.apple.com/cv/app/aonde-ir-motorista/id6444587115';
      
      if (await canLaunchUrl(Uri.parse(appStoreUrl))) {
        await launchUrl(Uri.parse(appStoreUrl), mode: LaunchMode.externalApplication);
        print('✅ App Store aberto com sucesso');
      } else {
        print('❌ Não foi possível abrir o App Store');
      }
    } catch (e) {
      print('❌ Erro ao abrir App Store: $e');
    }
  }

  // ✅ Abrir Google Play Store no Android
  Future<void> _openAppStoreAndroid() async {
    try {
      // URL da Google Play Store para o app do motorista
      const String playStoreUrl = 'https://play.google.com/store/apps/details?id=com.aondeir.motoristaapp';
      
      if (await canLaunchUrl(Uri.parse(playStoreUrl))) {
        await launchUrl(Uri.parse(playStoreUrl), mode: LaunchMode.externalApplication);
        print('✅ Google Play Store aberto com sucesso');
      } else {
        print('❌ Não foi possível abrir a Google Play Store');
      }
    } catch (e) {
      print('❌ Erro ao abrir Google Play Store: $e');
    }
  }

  // ✅ Mostrar modal simples de aviso
  void showUpdateModal(BuildContext context) {
    print('🚀 UpdateService - Tentando mostrar modal');
    print('🚀 UpdateService - _isUpdateAvailable: $_isUpdateAvailable');
    print('🚀 UpdateService - _isModalShowing: $_isModalShowing');
    print('🚀 UpdateService - Context mounted: ${context.mounted}');
    
    // ✅ Prevenir múltiplas modais
    if (_isModalShowing) {
      print('⚠️ UpdateService - Modal já está sendo exibida, ignorando');
      return;
    }
    
    // ✅ Sempre mostrar modal quando chamado (versão diferente detectada)
    print('✅ UpdateService - Condição atendida, mostrando modal');
    _isModalShowing = true; // ✅ Marcar como exibindo
    
    print('🎨 UpdateService - Iniciando showDialog...');
    showDialog(
      context: context,
      barrierDismissible: true, // Permite fechar tocando fora
      builder: (BuildContext context) {
        print('🎨 UpdateService - Builder executado, criando AlertDialog...');
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
          ),
          title: Row(
            children: [
              Icon(
                Icons.system_update,
                color: Colors.orange,
                size: 28,
              ),
              SizedBox(width: 10),
              Text(
                'Atualização Disponível',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.grey[800],
                ),
              ),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Uma nova versão do aplicativo está disponível.',
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.grey[600],
                ),
              ),
              SizedBox(height: 15),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                print('🔘 UpdateService - Botão "Mais Tarde" pressionado');
                Navigator.of(context).pop();
                _isModalShowing = false; // ✅ Resetar flag ao fechar
                print('Motorista escolheu "Mais Tarde"');
              },
              child: Text(
                'Mais Tarde',
                style: TextStyle(
                  color: Colors.grey[600],
                  fontSize: 16,
                ),
              ),
            ),
            ElevatedButton(
              onPressed: () async {
                print('🔘 UpdateService - Botão "Atualizar Agora" pressionado');
                Navigator.of(context).pop();
                _isModalShowing = false; // ✅ Resetar flag ao fechar
                print('Motorista escolheu atualizar agora');
                
                // ✅ Abrir loja de aplicativos
                await _openAppStore();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.orange,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              child: Text(
                'Atualizar Agora',
                style: TextStyle(fontSize: 16),
              ),
            ),
          ],
        );
      },
    );
  }
}
