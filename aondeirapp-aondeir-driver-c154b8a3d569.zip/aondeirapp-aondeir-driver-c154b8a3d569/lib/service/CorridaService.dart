import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_overlay_apps/flutter_overlay_apps.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:dio/dio.dart';
import 'dart:convert' as convert;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:intl/intl.dart';
import '../models/Corrida.dart';
import '../models/Mensagem.dart';
import '../models/Transaca.dart';

class CorridaService extends ChangeNotifier {
  final BuildContext? context;

  final storage = new FlutterSecureStorage();
  List<Corrida> corridas = [];
  List<Corrida> corridasPendentes = [];
  List<Corrida> corridasHitorico = [];
  late Corrida corridaAguardandoAceite;
  var resp = false;
  var dataInicio;
  var dataFim;
  var total_coletado_dia = "0,00";
  var total_corrida_dia = "0";
  late Corrida corridaSelecionadaDetalhes;
  var corrida = {};
  var tarifa = {};
  var status = "";
  var pedido = {};
  var valorFinalCorridaMacaneta;
  int duracaoSegundos = 0;
  double distanciaPercorridaMacaneta = 0;
  late Position localizacaoAtual;
  var localizacaoAtualLatitude;
  var localizacaoAtualLongitude;
  List<Mensagem> mensagens = [];
  var formCorridaMacaneta = {
    "telefone": "",
    "nome": "",
    "categoria_selecionada_id": "",
  };
  var formCorridaMacanetaMotivoCancelamento = {
    "motivoId": "",
    "motivoDescricao": ""
  };
  var enderecoDestinoTexto;
  var enderecoDestinoLatitude;
  var enderecoDestinoLongitude;

  var formErrorsCorridaMacaneta = null;
  var enderecoDestinoMacanetaTexto;
  var enderecoDestinoMacanetaLatitude;
  var enderecoDestinoMacanetaLongitude;

  var modalAlerta = false;
  var listaAtualizada = false; // Flag para indicar quando a lista foi atualizada
  
  var corridaValor = "0,01";

  CorridaService(this.context) {}

  resetarStateService() {
    corrida = {};
    tarifa = {};
    status = "";
    pedido = {};
    notifyListeners();
  }

  Future getCorridasPendentes() async {
    try {
      String url = dotenv.env['BASE_URL']! + "api/corridas/pegar-pendentes";
      var token = await storage.read(key: 'jwt');

      var response = await http.get(Uri.parse(url), headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        final json = convert.jsonDecode(response.body);

        List<Corrida> listaCorrida = [];
        for (var element in json['corridas']) {
          var corrida = Corrida.fromJson(element);
          listaCorrida.add(corrida);
        }

        this.corridasPendentes = listaCorrida;
        this.save();
      }
    } catch (e) {
      throw Exception('Failed to load data');
    }
  }

  alterarStatusCorrida(idStatus, nomeStatus, idCorrida) async {
    try {
      String url =
          dotenv.env['BASE_URL']! + "api/corrida/alterando-status/" + idCorrida;
      var token = await storage.read(key: 'jwt');

      var response = await http.post(Uri.parse(url), body: {
        "id": idStatus,
        "name": nomeStatus
      }, headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        var resp = convert.jsonDecode(response.body);
        this.corrida = resp['corrida'];
        this.status = resp['corrida']['status']['id'].toString();
        this.pedido = resp['corrida']['pedidos'][0];

        notifyListeners();
        return true;
      }
    } catch (e) {
      throw Exception('Failed to load data');
    }
  }

  aceitarCorrida(idCorrida) async {
    try {
      String url = dotenv.env['BASE_URL']! + "api/aceitar-corrida/" + idCorrida;
      var token = await storage.read(key: 'jwt');
      var response = await http.post(Uri.parse(url), headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        return true;
      }

      if (response.statusCode == 400) {
        final respError = convert.jsonDecode(response.body);
        throw new http.ClientException(respError['message']);
      }

      if (response.statusCode == 500) {
        final respError = convert.jsonDecode(response.body);
        throw new http.ClientException(respError['message']);
      }

      // Outros status codes não tratados cairão no catch padrão
      throw Exception('Ops! Ocorreu um erro ao aceitar a corrida. Tente mais tarde novamente.');

    } on http.ClientException catch (e) {
      throw HttpException(e.toString());
    } catch (e) {
      throw Exception(
          'Ops! Ocorreu um erro ao aceitar a corrida. Tente mais tarde novamente.');
    }
  }

  pegarCorridaAndamento() async {
    try {
      String url =
          dotenv.env['BASE_URL']! + "api/get-corrida-andamento-motorista";
      var token = await storage.read(key: 'jwt');
      var response = await http.get(Uri.parse(url), headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });
      
      if (response.statusCode == 200) {
        var resp = convert.jsonDecode(response.body);
       
        if (resp['corrida'] != null) {
          this.status = resp['corrida']['status']['id'].toString();
          this.corrida = resp['corrida'];
          this.pedido = resp['corrida']['pedidos'][0];
          this.tarifa = resp['corrida']['tarifa'];
        }
      
        notifyListeners();
        return resp['corrida'];
      } else if (response.statusCode == 204) {
        this.status = "";
        this.corrida = {};
        this.pedido = {};
        this.tarifa = {};
        notifyListeners();
        return null; // ⚡ CORREÇÃO: Retornar null explicitamente
      } else {
        return null;
      }
    } catch (e) {
      print('🚨🚨pegarCorridaAndamento');
      print(e);
      print('🚨🚨pegarCorridaAndamento');
      throw Exception('Failed to load data');
    }
  }

  pagarCorrida(idCorrida) async {
    try {
      String url = dotenv.env['BASE_URL']! + "api/pagar-corrida/" + idCorrida;
      var token = await storage.read(key: 'jwt');
      var response = await http.post(Uri.parse(url), headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        this.getCorridasPendentes();
        return true;
      }
    } catch (e) {
      throw Exception('Failed to load data');
    }
  }

  trocarFormaPagamentoPagar() async {
    try {
      print("CorridaService - trocarFormaPagamento");
      String url = dotenv.env['BASE_URL']! +
          "api/corrida/trocar-forma-pagamento-motorista/" +
          this.corrida['id'].toString();
      var token = await storage.read(key: 'jwt');

      var response = await http.post(Uri.parse(url), body: {
        "metodo_pagamento": 'DINHEIRO'
      }, headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });
      if (response.statusCode == 200) {
        return true;
      }
      
    } catch (e) {
      print("erro");
      print(e);
      throw Exception('Failed to load data');
    }
  }

  cancelarCorrida(idCorrida) async {
    try {
      String url = dotenv.env['BASE_URL']! +
          "api/get-corrida-aguardando-aceite-motorista/" +
          idCorrida;
      var token = await storage.read(key: 'jwt');
      var response = await http.get(Uri.parse(url), headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        var resp = convert.jsonDecode(response.body);
        Corrida corrida = Corrida.fromJson(resp['corrida']);
        var idProcurado = corrida.id;

        bool existeCorridaComID =
            corridas.any((corrida) => corrida.id == idProcurado);

        if (existeCorridaComID) {
          this.corridas.removeWhere((corrida) => corrida.id == idProcurado);
          this.save();
        } else {}
      }
    } catch (e) {
      throw Exception('Failed to load data');
    }
  }

  cancelarCorridaPendente(idCorrida) async {
    try {
      String url =
          dotenv.env['BASE_URL']! + "api/get-corrida-pendente/" + idCorrida;
      var token = await storage.read(key: 'jwt');
      var response = await http.get(Uri.parse(url), headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        var resp = convert.jsonDecode(response.body);
        Corrida corrida = Corrida.fromJson(resp['corrida']);
        var idProcurado = corrida.id;

        bool existeCorridaComID =
            corridasPendentes.any((corrida) => corrida.id == idProcurado);

        if (existeCorridaComID) {
          this
              .corridasPendentes
              .removeWhere((corrida) => corrida.id == idProcurado);
          this.save();
        } else {}
      }
    } catch (e) {
      throw Exception('Failed to load data');
    }
  }

  removerCorridaLista(data) async {
    try {
      Corrida corrida = Corrida.fromJson(data['corrida']);
      var idProcurado = corrida.id;
      bool existeCorridaComID =
          corridas.any((corrida) => corrida.id == idProcurado);
      bool existeCorridaPendenteComID =
          corridasPendentes.any((corrida) => corrida.id == idProcurado);

      if (existeCorridaComID) {
        this.corridas.removeWhere((corrida) => corrida.id == idProcurado);
      }

      if (existeCorridaPendenteComID) {
        this
            .corridasPendentes
            .removeWhere((corrida) => corrida.id == idProcurado);
      }

      this.save();
    } catch (e) {}
  }

  removerCorridaListaById(idCorrida) async {
    print(idCorrida);
    var idProcurado = int.tryParse(idCorrida.toString()) ?? idCorrida;
    bool existeCorridaComID =
        this.corridas.any((corrida) => corrida.id == idProcurado);

    if (existeCorridaComID) {
      String url = dotenv.env['BASE_URL']! + "api/recusar-corrida/" + idCorrida;
      var token = await storage.read(key: 'jwt');
      var response = await http.post(Uri.parse(url), headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });
      
    }
    this.corridas.removeWhere((corrida) => corrida.id == idProcurado);
    removerCorridaOverlay();
    await this.save();
  }

  removerCorridaPendenteListaById(idCorrida) async {
    try {
      var idProcurado = idCorrida;
      bool existeCorridaComID =
          corridasPendentes.any((corrida) => corrida.id == idProcurado);

      if (existeCorridaComID) {
        this.corridasPendentes.removeWhere(
            (corridasPendente) => corridasPendente.id == idProcurado);

        removerCorridaOverlay();
      }

      await this.save();
    } catch (e) {}
  }

  add(data) async {
    try {
      Corrida corrida = Corrida.fromJson(data['corrida']);
      var idProcurado = corrida.id;
      bool existeCorridaComID =
          corridas.any((corrida) => corrida.id == idProcurado);

      if (existeCorridaComID == false) {
        this.corridas.add(corrida);
        this.save();
      } else {}
    } catch (e) {}
  }

  addCorrida(Corrida corrida) async {
    try {
      var idProcurado = corrida.id;
      bool existeCorridaComID =
          corridas.any((corrida) => corrida.id == idProcurado);

      if (existeCorridaComID == false) {
        this.corridas.add(corrida);
        this.corridaAguardandoAceite = corrida;
        await this.save();
      }
    } catch (e) {}
  }

  removerTodasCorridas() async {
    if (this.corridas.isNotEmpty) {
      this.corridas.clear();
    }
    await this.save();
  }

  addCorridaParaPendente(corridaJson) async {
    try {
      Corrida corrida = Corrida.fromJson(corridaJson);
      var idProcurado = corrida.id;

      bool existeCorridaComID =
          corridasPendentes.any((corrida) => corrida.id == idProcurado);

      if (!existeCorridaComID) {
        this.corridasPendentes.add(corrida);
        await this.save();
      } else {}
    } catch (e) {}
  }

  cancelarAndamento(corridaId, motivoId, motivoDescricao) async {
    try {
      String url = dotenv.env['BASE_URL']! +
          "api/corrida/cancelar-em-andamento-motorista/" +
          corridaId.toString();
      var token = await storage.read(key: 'jwt');

      var response = await http.post(Uri.parse(url), body: {
        "motivoId": motivoId,
        "motivoDescricao": motivoDescricao,
      }, headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        var resp = convert.jsonDecode(response.body);
        corrida = resp['corrida'];
        notifyListeners();
        return true;
      }
    } catch (e) {
      throw Exception(
          'Ops! Ocorreu um erro ao cancelar a corrida em andamento. Tente mais tarde novamente.');
    }
  }

  finalizarCorrida(idCorrida) async {
    try {
      final dio = Dio(BaseOptions(
        connectTimeout: const Duration(seconds: 30),
        receiveTimeout: const Duration(seconds: 30),
      ));

      String url =
          dotenv.env['BASE_URL']! + "api/corrida/finalizar/" + idCorrida;
      var token = await storage.read(key: 'jwt');

      var response = await dio.post(url, data: {
        "id": "7",
        "name": "FINALIZADA",
        "endereco_destino_latitude": enderecoDestinoLatitude.toString(),
        "endereco_destino_longitude": enderecoDestinoLongitude.toString(),
        "endereco_destino_texto": enderecoDestinoTexto.toString(),
      }, options: Options(
        headers: {
          HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
        },
      ));

      if (response.statusCode == 200) {
        var resp = response.data;
        this.corrida = resp['corrida'];
        this.status = resp['corrida']['status']['id'].toString();

        return true;
      } else {
        throw ('Não foi possível finalizar a corrida no momento. Tente novamente em instantes.');
      }

    } on DioException catch (e) {
      if (e.type == DioExceptionType.connectionTimeout) {
        throw ('Não foi possível se conectar. Verifique sua conexão com a internet e tente novamente.');
      } else if (e.type == DioExceptionType.receiveTimeout) {
        throw ('A operação está demorando mais que o esperado. Tente novamente em alguns segundos.');
      }
      throw ('Ocorreu um imprevisto ao finalizar a corrida. Tente novamente.');
    } catch (e) {
      throw e;
    }
  }

  // finalizarCorrida(idCorrida) async {
  //   try {
  //     String url =
  //         dotenv.env['BASE_URL']! + "api/corrida/finalizar/" + idCorrida;
  //     var token = await storage.read(key: 'jwt');

  //     var response = await http.post(Uri.parse(url), body: {
  //       "id": "7",
  //       "name": "FINALIZADA",
  //       "endereco_destino_latitude": enderecoDestinoLatitude.toString(),
  //       "endereco_destino_longitude": enderecoDestinoLongitude.toString(),
  //       "endereco_destino_texto": enderecoDestinoTexto.toString(),
  //     }, headers: {
  //       HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
  //     });

  //     if (response.statusCode == 200) {
  //       var resp = convert.jsonDecode(response.body);
  //       this.corrida = resp['corrida'];
  //       this.status = resp['corrida']['status']['id'].toString();

  //       return true;
  //     }

  //     notifyListeners();
  //   } catch (e) {
  //     throw e;
  //   }
  // }

  pegarMensagens(corridaId) async {
    try {
      String url = dotenv.env['BASE_URL']! +
          "api/chamada/chat/motorista/pegar-mensagens/" +
          corridaId.toString();
      var token = await storage.read(key: 'jwt');
      var response = await http.get(Uri.parse(url), headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        var resp = convert.jsonDecode(response.body);
        mensagens.clear();
        for (var msg in resp['mensagens']) {
          var mensagem = Mensagem.fromJson(msg);
          this.mensagens.add(mensagem);
          this.save();
        }
      }
    } catch (e) {
      throw Exception('Failed to load data pegarMensagens');
    }
  }

  addNovaMensagemLista(mensagemNova) async {
    try {
      Mensagem mensagem = Mensagem.fromJson(mensagemNova);
      var idProcurado = mensagem.id;
      bool existeMensagemComID =
          this.mensagens.any((mensagem) => mensagem.id == idProcurado);

      if (existeMensagemComID == false) {
        this.mensagens.add(mensagem);
        
        // Verificar se é mensagem do passageiro (tipoId == 3) e modalAlerta ainda não foi mostrado
        var remetenteTipoId = mensagem.remetente?['tipoId'];
        print("💬 [CorridaService] addNovaMensagemLista - remetenteTipoId: $remetenteTipoId, modalAlerta: ${this.modalAlerta}");
        
        if (remetenteTipoId == 3 && this.modalAlerta == false) {
          // Não definir modalAlerta aqui - deixar para o listener decidir
          // Isso evita que o modal seja mostrado múltiplas vezes
          print("💬 [CorridaService] Mensagem do passageiro recebida, modalAlerta será gerenciado pelo listener");
        }
        
        await this.save();
      } else {}
    } catch (e) {
      throw Exception('Failed to load data');
    }
  }

  enviarMensagem(mensagem, idDestinatario, idCorrida) async {
    try {
      String url = dotenv.env['BASE_URL']! +
          "api/chamada/chat/motorista/enviar-mensangem-para-passageiro/" +
          idCorrida +
          '?ios=' +
          (Platform.isIOS ? 'true' : 'falso');
      var token = await storage.read(key: 'jwt');

      var response = await http.post(Uri.parse(url), body: {
        "mensagem": mensagem,
        "destinatario_id": idDestinatario
      }, headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        var resp = convert.jsonDecode(response.body);

        Mensagem mensagem = Mensagem.fromJson(resp['mensagem']);
        var idProcurado = mensagem.id;
        bool existeMensagemComID =
            this.mensagens.any((mensagem) => mensagem.id == idProcurado);
        if (existeMensagemComID == false) {
          this.mensagens.add(mensagem);
          this.save();
        } else {}
      }
    } catch (e) {
      throw Exception('Failed to load data');
    }
  }

  gerarQrCode() async {
    try {
      String url = dotenv.env['BASE_URL']! +
          "api/pagarme/gerar-qrcode-pix-corrida/" +
          this.corrida['id'].toString();
      var token = await storage.read(key: 'jwt');
      var response = await http.post(Uri.parse(url), body: {}, headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        var json = convert.jsonDecode(response.body);
        Transacao transacao = Transacao.fromJson(json['transacao']);
        this.save();
        return transacao;
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  pagarViaCartao() async {
    try {
      String url =
          dotenv.env['BASE_URL']! + "api/pagarme/gerar-pedido-cartao-credito";
      var token = await storage.read(key: 'jwt');
      var response = await http.post(Uri.parse(url), body: {}, headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        return ("Sucesso cartao creditoo");
      } else {
        var json = convert.jsonDecode(response.body);
        throw json['message'];
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  criarCorridaMacaneta() async {
    try {
      String url =
          dotenv.env['BASE_URL']! + "api/corrida-macaneta/criar-corrida";
      var token = await storage.read(key: 'jwt');
      var response = await http
          .post(Uri.parse(url), body: this.formCorridaMacaneta, headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 201) {
        convert.jsonDecode(response.body);
        this.formErrorsCorridaMacaneta = null;

        return 201;
      } else if (response.statusCode == 400) {
        var json = convert.jsonDecode(response.body);
        this.formErrorsCorridaMacaneta = json;
        await this.save();
        return 400;
      } else if (response.statusCode == 404) {
        return false;
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  alterarStatusCorridaMacaneta() async {
    try {
      String url = dotenv.env['BASE_URL']! +
          "api/corrida-macaneta/alterar-status-aguardando-passageiro/" +
          corrida['id'].toString();
      var token = await storage.read(key: 'jwt');
      var response = await http
          .post(Uri.parse(url), body: this.formCorridaMacaneta, headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        var json = convert.jsonDecode(response.body);
        this.corrida['status'] = json['status'];
        await this.save();
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  iniciarCorridaMacaneta() async {
    try {
      String url = dotenv.env['BASE_URL']! +
          "api/corrida-macaneta/iniciar/" +
          corrida['id'].toString();
      var token = await storage.read(key: 'jwt');
      var response = await http
          .post(Uri.parse(url), body: this.formCorridaMacaneta, headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        var json = convert.jsonDecode(response.body);
        this.corrida['status'] = json['status'];
        this.corrida = json['corrida'];
        await this.save();
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  finalizarCorridaMacaneta() async {
    try {
      String url = dotenv.env['BASE_URL']! +
          "api/corrida-macaneta/finalizar/" +
          corrida['id'].toString();
      var token = await storage.read(key: 'jwt');
      var response = await http.post(Uri.parse(url), body: {
        "endereco_destino_latitude": enderecoDestinoMacanetaLatitude.toString(),
        "endereco_destino_longitude":
            enderecoDestinoMacanetaLongitude.toString(),
        "endereco_destino_texto": enderecoDestinoMacanetaTexto.toString(),
        "distancia_percorrida": distanciaPercorridaMacaneta.toString()
      }, headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        var json = convert.jsonDecode(response.body);
        this.corrida['status'] = json['status'];
        this.corrida = json['corrida'];
        await this.save();
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  confirmarPagamentoMacaneta() async {
    try {
      String url =
          dotenv.env['BASE_URL']! + "api/corrida-macaneta/confirmar-pagamento";
      var token = await storage.read(key: 'jwt');
      var response = await http
          .post(Uri.parse(url), body: this.formCorridaMacaneta, headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        return true;
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  cancelarCorridaMacaneta() async {
    try {
      String url = dotenv.env['BASE_URL']! +
          "api/corrida-macaneta/cancelar/" +
          corrida['id'].toString();
      var token = await storage.read(key: 'jwt');
      var response = await http.post(Uri.parse(url),
          body: this.formCorridaMacanetaMotivoCancelamento,
          headers: {
            HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
          });

      if (response.statusCode == 200) {
        return true;
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  salvarValorCalculadoMacaneta() async {
    try {
      String url = dotenv.env['BASE_URL']! +
          "api/corrida-macaneta/salvar-valor/" +
          corrida['id'].toString();
      var token = await storage.read(key: 'jwt');
      var response = await http.post(Uri.parse(url), body: {
        "duracao_segundos": duracaoSegundos.toString(),
        "distancia_percorrida_metros": distanciaPercorridaMacaneta.toString()
      }, headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        var resp = convert.jsonDecode(response.body);
        var corridaValor =
            double.parse(resp['corrida']['valor_corrida'].toString());

        var tarifaValorMinimo = double.parse(tarifa['valor_minimo'].toString());

        if (corridaValor > tarifaValorMinimo) {
          this.corrida['valor_corrida'] =
              double.parse(resp['corrida']['valor_corrida'].toString())
                  .toStringAsFixed(2);
          await this.save();
        }
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  salvarLocalizacaoRotaMacaneta() async {
    try {
      String url = dotenv.env['BASE_URL']! +
          "api/corrida-macaneta/salvar-localizacao-rota/" +
          corrida['id'].toString();
      var token = await storage.read(key: 'jwt');
      var response = await http.post(Uri.parse(url), body: {
        "latitude": localizacaoAtualLatitude.toString(),
        "longitude": localizacaoAtualLongitude.toString(),
      }, headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {}
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  pegarCorridas() async {
    try {
      String url = dotenv.env['BASE_URL']! +
          "api/motorista/pegar-corridas?data_inicio_filtrado=" +
          dataInicio +
          "&data_fim_filtrado=" +
          dataFim;
      var token = await storage.read(key: 'jwt');
      var response = await http.get(Uri.parse(url), headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        final json = convert.jsonDecode(response.body);
        print("corridasHitoric json: $json");
        List<Corrida> listaCorrida = [];
        for (var element in json['corridas']) {
          var corrida = Corrida.fromJson(element);
          listaCorrida.add(corrida);
        }

        this.corridasHitorico = listaCorrida;
        print("corridasHitorico: $listaCorrida");
        this.save();
      }
    } catch (e) {
      print("corridasHitorico error: $e");
      throw Exception('Failed to load data');
    }
  }

  pegarTotalColetadoDia() async {
    try {
      String url =
          dotenv.env['BASE_URL']! + "api/motorista/pegar-total-coletado-dia";
      var token = await storage.read(key: 'jwt');
      var response = await http.get(Uri.parse(url), headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        var json = convert.jsonDecode(response.body);
        String stringValue = json['total'].toString();
        double valor = double.parse(stringValue);
        final formatoReais = NumberFormat("#,##0.00", "pt_BR");
        this.total_coletado_dia = formatoReais.format(valor);
        this.save();
      }
    } catch (e) {
      throw Exception('Failed to load data');
    }
  }

  pegarTotalColetado() async {
    try {
      String url = dotenv.env['BASE_URL']! +
          "api/motorista/pegar-total-coletado?data_inicio=" +
          dataInicio +
          "&data_fim=" +
          dataFim;
      var token = await storage.read(key: 'jwt');
      var response = await http.get(Uri.parse(url), headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        var json = convert.jsonDecode(response.body);
        String stringValue = json['total'].toString();
        double valor = double.parse(stringValue);
        final formatoReais = NumberFormat("#,##0.00", "pt_BR");
        this.total_coletado_dia = formatoReais.format(valor);
        this.save();
      }
    } catch (e) {
      throw Exception('Failed to load data');
    }
  }

  pegarTotalCorridasDia() async {
    try {
      String url =
          dotenv.env['BASE_URL']! + "api/motorista/pegar-total-corrida-dia";
      var token = await storage.read(key: 'jwt');
      var response = await http.get(Uri.parse(url), headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        var json = convert.jsonDecode(response.body);
        this.total_corrida_dia = json['total'].toString();
        this.save();
      }
    } catch (e) {
      throw Exception('Failed to load data');
    }
  }

  pegarTotalCorridas() async {
    try {
      String url = dotenv.env['BASE_URL']! +
          "api/motorista/pegar-total-corrida?data_inicio=" +
          dataInicio +
          "&data_fim=" +
          dataFim;
      var token = await storage.read(key: 'jwt');
      var response = await http.get(Uri.parse(url), headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        var json = convert.jsonDecode(response.body);

        this.total_corrida_dia = json['total'].toString();
        this.save();
      }
    } catch (e) {
      throw Exception('Failed to load data');
    }
  }

  Future<bool> verificarSeExisteCorridaPendenteLista(corridaId) async {
    try {
      var idProcurado = corridaId;

      bool existeCorridaComID =
          corridasPendentes.any((corrida) => corrida.id == idProcurado);

      if (!existeCorridaComID) {
        return true;
      } else {
        return false;
      }
    } catch (e) {
      return false;
    }
  }

  removerCorridaOverlay() async {
    FlutterOverlayApps.sendDataToAndFromOverlay(
        {"corrida": null, "status_chamada": "CORRIDA_NAO_ACEITA"});
  }

  save() {
    notifyListeners();
  }
}
