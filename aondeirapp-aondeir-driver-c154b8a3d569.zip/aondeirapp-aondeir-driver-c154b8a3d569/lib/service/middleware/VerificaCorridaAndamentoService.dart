import 'package:aondeir_motorista/service/CorridaService.dart';
import 'package:aondeir_motorista/service/middleware/CurrentScreenService.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:provider/provider.dart';

import '../../screens/Usuario/BottomNavigationBar/NavigationScreen.dart';
import '../../screens/Usuario/Home/Corrida/DetalhesCorridaScreen.dart';
import '../../screens/Usuario/Menu/AberturaCorrida/DetalhesMacanetaScreen.dart';
import '../corrida/macaneta/CorridaMacanetaPegarEmAndamentoService.dart';

class VerificaCorridaAndamentoService extends ChangeNotifier {
  final BuildContext? context;
  final storage = new FlutterSecureStorage();
  bool temCorridaAndamento = false;

  VerificaCorridaAndamentoService(this.context) {}

  Future<void> execute(context) async {
    try {
      
      var corridaService = Provider.of<CorridaService>(context!, listen: false);
      var currentScreenService =
          Provider.of<CurrentScreenService>(context!, listen: false);
      var corridaMacanetaPegarEmAndamentoService =
          Provider.of<CorridaMacanetaPegarEmAndamentoService>(context,
              listen: false);
      await corridaService.pegarCorridaAndamento();
      var corridaMacanetaResp =
          await corridaMacanetaPegarEmAndamentoService.execute();

      if (corridaService.corrida.isNotEmpty) {
        temCorridaAndamento = true;
        if (currentScreenService.currentScreen != "DetalhesCorridaScreen") {
          await Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => DetalhesCorridaScreen(),
            ),
          );
        }
      } else if (corridaMacanetaResp.isNotEmpty) {
        temCorridaAndamento = true;
        if (currentScreenService.currentScreen != "DetalhesMacanetaScreen") {
          await Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => DetalhesMacanetaScreen(),
            ),
          );
        }
      } else {
        temCorridaAndamento = false;
        await Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => NavigationScreen(),
          ),
        );
      }

      notifyListeners();
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  save() {
    notifyListeners();
  }
}
