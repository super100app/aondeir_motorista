import 'package:flutter/material.dart';

class CurrentScreenService extends ChangeNotifier {
  String _currentScreen = "";

  String get currentScreen => _currentScreen;

  void setCurrentScreen(String screen) {
    _currentScreen = screen;
    notifyListeners();
  }

  save() {
    notifyListeners();
  }
}
