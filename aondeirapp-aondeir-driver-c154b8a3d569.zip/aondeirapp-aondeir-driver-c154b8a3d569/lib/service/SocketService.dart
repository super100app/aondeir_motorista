import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:provider/provider.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;
import 'package:socket_io_client/socket_io_client.dart';
import 'package:aondeir_motorista/service/CorridaService.dart';
import 'package:aondeir_motorista/service/UsuarioService.dart';
import '../models/Corrida.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class SocketService extends ChangeNotifier {
  IO.Socket? _socket;
  IO.Socket? get socket => _socket;
  final BuildContext context;

  SocketService(this.context) {
    String url = dotenv.env['BASE_URL']!;
    initSocket(url);
  }
  final storage = new FlutterSecureStorage();

  Future<void> initSocket(String url) async {
    var usuarioService = Provider.of<UsuarioService>(this.context, listen: false);
    var token = await storage.read(key: 'jwt');

    if (usuarioService.usuario.id == null || usuarioService.usuario.id == 0) {
      print("🚨 Nenhum usuário logado. Cancelando conexão ao socket.");
    } else {
      _socket = IO.io(url, OptionBuilder()
      .setTransports(['websocket'])
      .enableReconnection()
      .setReconnectionAttempts(double.infinity)
      .setReconnectionDelay(1000)
      .setQuery(
        {
          'usuarioId': usuarioService.usuario.id,
          'token': token,
        })
      .build());

      // Adicionar listeners para debug
      _socket?.onConnect((_) {
      });

      _socket?.onDisconnect((_) {
        print("❌ Socket desconectado!");
      });

      _socket?.onConnectError((error) {
        print("❌ Erro na conexão do socket: $error");
      });

      _socket?.onError((error) {
        print("❌ Erro no socket: $error");
      });

      socket?.connect();
    }
  }

  Future<void> retryConnection() async {
    String url = dotenv.env['BASE_URL']!;
    initSocket(url);
  }

  void addCorrida(data) {
    var corridaService =
        Provider.of<CorridaService>(this.context, listen: false);

    Corrida corrida = Corrida.fromJson(data['corrida']);
    corridaService.corridas.add(corrida);
    corridaService.resp = true;
    corridaService.save();
    notifyListeners();
  }

  void emitEvent(String event, dynamic data) {
    if (_socket != null) {
      _socket!.emit(event, data);
    }
  }

  void disconnectSocket() {
    if (_socket != null) {
      _socket!.disconnect();
    }
  }

  bool isConnected() {
    return _socket?.connected ?? false;
  }

  void logSocketStatus() {
    print("🔌 SocketService: Status da conexão:");
    print("🔌 SocketService: Socket existe: ${_socket != null}");
    print("🔌 SocketService: Socket conectado: ${_socket?.connected}");
    print("🔌 SocketService: Socket ID: ${_socket?.id}");
  }
}