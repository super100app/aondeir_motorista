import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';

class ToqueService extends ChangeNotifier {
  late AudioPlayer player = AudioPlayer();
  bool _isPlaying = false;

  execute(caminhoAquivo) async {
    try {
      // Se já está tocando, não toca novamente
      if (_isPlaying) {
        print("🔇 ToqueService: Já está tocando, ignorando nova chamada");
        return;
      }
      
      _isPlaying = true;
      
      // Para o player anterior se existir
      await player.stop();
      player = AudioPlayer();
      
      await player.setSource(AssetSource(caminhoAquivo));
      await player.resume();
      
      // Adiciona listener para detectar quando o som termina
      player.onPlayerComplete.listen((_) {
        _isPlaying = false;
        print("🔇 ToqueService: Som finalizado");
      });
      
      print("🔊 ToqueService: Tocando $caminhoAquivo");
    } catch (e) {
      _isPlaying = false;
      print("❌ ToqueService: Erro ao tocar $caminhoAquivo: $e");
    }
  }

  save() {
    notifyListeners();
  }
}
