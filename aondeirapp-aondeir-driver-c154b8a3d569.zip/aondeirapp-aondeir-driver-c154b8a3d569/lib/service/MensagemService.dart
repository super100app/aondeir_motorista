import 'dart:io';

import 'package:aondeir_motorista/models/MensagemFranquia.dart';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import 'dart:convert' as convert;

class MensagemService extends ChangeNotifier {
  final storage = new FlutterSecureStorage();
  List<MensagemFranquia> mensagensFranquia = [];
  List<MensagemFranquia> mensagensFranquiaMatriz = [];
  var mensagem = "";
  var mensagemMatriz = "";

  pegarMensagensFranquiaMatriz() async {
    try {
      String url =
          dotenv.env['BASE_URL']! + "api/chat-franquia/pegar-mensagens-matriz";

      var token = await storage.read(key: 'jwt');

      var response = await http.get(Uri.parse(url), headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        var resp = convert.jsonDecode(response.body);

        mensagensFranquiaMatriz.clear();
        for (var msg in resp['mensagens']) {
          var mensagem = MensagemFranquia.fromJson(msg);
          this.mensagensFranquiaMatriz.add(mensagem);
          this.save();
        }
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  pegarMensagensFranquia() async {
    try {
      String url =
          dotenv.env['BASE_URL']! + "api/chat-franquia/pegar-mensagens";

      var token = await storage.read(key: 'jwt');

      var response = await http.get(Uri.parse(url), headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        var resp = convert.jsonDecode(response.body);

        mensagensFranquia.clear();
        for (var msg in resp['mensagens']) {
          var mensagem = MensagemFranquia.fromJson(msg);
          this.mensagensFranquia.add(mensagem);
          this.save();
        }
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  visualizarMensagens() async {
    try {
      if (mensagensFranquia.length > 0) {
        String url =
            dotenv.env['BASE_URL']! + "api/chat-franquia/visualizar-mensagens";

        var token = await storage.read(key: 'jwt');

        await http.post(Uri.parse(url), headers: {
          HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
        });
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  visualizarMensagensMatriz() async {
    try {
      if (mensagensFranquiaMatriz.length > 0) {
        String url = dotenv.env['BASE_URL']! +
            "api/chat-franquia/visualizar-mensagens-matriz";

        var token = await storage.read(key: 'jwt');

        await http.post(Uri.parse(url), headers: {
          HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
        });
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  enviarMensagemFranquia() async {
    try {
      String url =
          dotenv.env['BASE_URL']! + "api/chat-franquia/enviar-mensangem";

      var token = await storage.read(key: 'jwt');

      var response = await http.post(Uri.parse(url), body: {
        "mensagem": mensagem
      }, headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        var resp = convert.jsonDecode(response.body);

        var mensagem = MensagemFranquia.fromJson(resp['mensagem']);
        this.mensagensFranquia.add(mensagem);
        this.save();
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  enviarMensagemFranquiaMatriz() async {
    try {
      String url =
          dotenv.env['BASE_URL']! + "api/chat-franquia/enviar-mensangem-matriz";

      var token = await storage.read(key: 'jwt');

      var response = await http.post(Uri.parse(url), body: {
        "mensagem": mensagemMatriz
      }, headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        var resp = convert.jsonDecode(response.body);

        var mensagem = MensagemFranquia.fromJson(resp['mensagem']);
        this.mensagensFranquiaMatriz.add(mensagem);
        this.save();
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  addNovaMensagemLista(mensagemNova) async {
    try {
      MensagemFranquia mensagem = MensagemFranquia.fromJson(mensagemNova);
      var idProcurado = mensagem.id;
      await this
          .mensagensFranquia
          .any((mensagem) => mensagem.id == idProcurado);
      this.mensagensFranquia.add(mensagem);
      this.save();
    } catch (e) {
      throw Exception('Failed to load data');
    }
  }

  addNovaMensagemListaMatriz(mensagemNova) async {
    try {
      MensagemFranquia mensagem = MensagemFranquia.fromJson(mensagemNova);
      this.mensagensFranquiaMatriz.add(mensagem);
      this.save();
    } catch (e) {
      throw Exception('Failed to load data');
    }
  }

  save() {
    notifyListeners();
  }
}
