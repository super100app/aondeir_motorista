import 'dart:io';
import 'package:aondeir_motorista/models/Saque.dart';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:http/http.dart' as http;
import 'dart:convert' as convert;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:intl/intl.dart';

class GanhoService extends ChangeNotifier {
  final storage = new FlutterSecureStorage();
  var ganhos_dia = "0,00";
  var dataInicio;
  var dataFim;
  var saqueAutomatico;
  var saldoDiponivel = 0.0;
  var saldoPendente = 0.0;
  var tarifas;

  var chavePix;
  var tipoChavePix;
  var valorSolicitado;
  var valorTaxaSaque;
  var valorSaque;
  var saldoDisponivelCarteira;
  var valorFinalComPercentual;
  var carteiraDescontadoFormatado;
  // var mensagemRetorno;

  pegarGanhosDia() async {
    try {
      String url = dotenv.env['BASE_URL']! + "api/ganhos/pegar-ganhos-dia";

      var token = await storage.read(key: 'jwt');

      var response = await http.get(
        Uri.parse(url),
        headers: {
          HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
        },
      );

      if (response.statusCode == 200) {
        var json = convert.jsonDecode(response.body);
        final formatoReais = NumberFormat("#,##0.00", "pt_BR");
        this.ganhos_dia = formatoReais.format(json['total']);
        this.save();
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  pegarGanhos() async {
    try {
      String url =
          dotenv.env['BASE_URL']! +
          "api/ganhos/pegar-ganhos?data_inicio=" +
          dataInicio +
          "&data_fim=" +
          dataFim;

      var token = await storage.read(key: 'jwt');
      var response = await http.get(
        Uri.parse(url),
        headers: {
          HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
        },
      );

      if (response.statusCode == 200) {
        var json = convert.jsonDecode(response.body);
        final formatoReais = NumberFormat("#,##0.00", "pt_BR");
        this.ganhos_dia = formatoReais.format(json['total']);
        this.save();
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  pegarDadosSaque() async {
    try {
      String url =
          dotenv.env['BASE_URL']! +
          "api/saque-automatico/configuracao-saque-automatico/index";

      print(url);

      var token = await storage.read(key: 'jwt');
      var response = await http.get(
        Uri.parse(url),
        headers: {
          HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
        },
      );

      print(response);

      if (response.statusCode == 200) {
        var json = convert.jsonDecode(response.body);
        print(json);

        saqueAutomatico = json['saqueAutomatico'];
        tarifas = json['tarifas'];
        this.save(); // Notificar listeners sobre a mudança
      }
    } on http.ClientException catch (e) {
      print(e);
      throw e;
    }
  }

  pegarSaldoDiponivel() async {
    try {
      String url =
          dotenv.env['BASE_URL']! +
          "api/saque-automatico/saldo-disponivel-saque";

      print(url);

      var token = await storage.read(key: 'jwt');

      var response = await http.get(
        Uri.parse(url),
        headers: {
          HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
        },
      );

      print(response);

      if (response.statusCode == 200) {
        var json = convert.jsonDecode(response.body);
        print('✅INICIO✅ ');
        print(json);
        print(json['saldoDiponivel']);
        print('✅ FIIIM✅ ');

        // saldoDiponivel = json['saldoDiponivel'];
        // saldoPendente = json['saldoPendente'];
        saldoDiponivel = json['saldoDiponivel'].toDouble();
        saldoPendente = json['saldoPendente'].toDouble();
      }
    } on http.ClientException catch (e) {
      print(e);
      throw e;
    }
  }

  // List<Saque> historicoSaques = [];
  // pegarListaPix() async {
  //   try {
  //     String url = dotenv.env['BASE_URL']! + "api/saque/getSaques";
  //     var token = await storage.read(key: 'jwt');
  //     var response = await http.get(
  //       Uri.parse(url),
  //       headers: {HttpHeaders.authorizationHeader: 'Bearer $token'},

  //     );

  //     if (response.statusCode == 200) {
  //       var lista = convert.jsonDecode(response.body);
  //       historicoSaques = List<Saque>.from(lista.map((s) => Saque.fromJson(s)));
  //       return historicoSaques;
  //     }
  //   } on http.ClientException catch (e) {
  //     print(e);
  //     throw e;
  //   }
  // }
  List<Saque> historicoSaques = [];
  Future<List<Saque>> pegarListaPix(
    DateTime dataInicio,
    DateTime dataFim,
  ) async {
    try {
      final String inicio =
          "${dataInicio.year}-${dataInicio.month.toString().padLeft(2, '0')}-${dataInicio.day.toString().padLeft(2, '0')}";
      final String fim =
          "${dataFim.year}-${dataFim.month.toString().padLeft(2, '0')}-${dataFim.day.toString().padLeft(2, '0')}";
      String url =
          "${dotenv.env['BASE_URL']}api/saque/getSaques?data_inicio=$inicio&data_fim=$fim";
      var token = await storage.read(key: 'jwt');
      var response = await http.get(
        Uri.parse(url),
        headers: {HttpHeaders.authorizationHeader: 'Bearer $token'},
      );

      if (response.statusCode == 200) {
        var lista = convert.jsonDecode(response.body);
        historicoSaques = List<Saque>.from(lista.map((s) => Saque.fromJson(s)));
        return historicoSaques;
      } else {
        throw Exception('Erro ao buscar saques: ${response.statusCode}');
      }
    } on http.ClientException catch (e) {
      print(e);
      throw e;
    }
  }

  Future<bool> sacarSaldo() async {
    try {
      String url = dotenv.env['BASE_URL']! + "api/saque/solicitar";
      var token = await storage.read(key: 'jwt');
      var response = await http.post(
        Uri.parse(url),
        body: {
          'valor': this.valorSolicitado.toString(),
          'chaveTipo': this.tipoChavePix.toString(),
          'chave': this.chavePix.toString(),
        },
        headers: {HttpHeaders.authorizationHeader: 'Bearer $token'},
      );

      if (response.statusCode == 200) {
        await this.save();
        return true;
      } else if (response.statusCode == 400) {
        await convert.jsonDecode(response.body);
        print(response.body);
        // this.mensagemRetorno = '';
        await this.save();
        return false;
      } else {
        return false;
      }
    } on http.ClientException catch (e) {
      print(e);
      return false;
    } catch (e) {
      print(e);
      return false;
    }
  }

  Future<bool> validarSaque() async {
    try {
      String url = dotenv.env['BASE_URL']! + "api/saque-automatico/validar-saque";

      var token = await storage.read(key: 'jwt');
      var response = await http.post(
        Uri.parse(url),
        headers: {
          HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
        },
      );

      if (response.statusCode == 200) {
        var json = convert.jsonDecode(response.body);
        return json['success'] == true;
      } else if (response.statusCode == 400) {
        var json = convert.jsonDecode(response.body);
        throw Exception(json['message']);
      } else {
        throw Exception('Erro ao validar saque');
      }
    } on http.ClientException catch (e) {
      throw e;
    } catch (e) {
      throw Exception('$e');
    }
  }

  save() {
    notifyListeners();
  }
}
