import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:http/http.dart' as http;
import 'dart:convert' as convert;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:intl/intl.dart';
import '../models/Recarga.dart';
import '../models/Transaca.dart';

class RecargaService extends ChangeNotifier {
  final storage = new FlutterSecureStorage();
  var saldo_investido = "0,00";
  double saldo_atual = 0.0;
  var creditos_consumidos_dia = "0,00";
  List<Recarga> recargas = [];
  var dataInicio;
  var dataFim;

  gerarPedido(valorRecarga) async {
    try {
      String url = dotenv.env['BASE_URL']! + "api/pagarme/criarPedido";
      var token = await storage.read(key: 'jwt');
      var response = await http.post(Uri.parse(url), body: {
        "valor_recarga": valorRecarga
      }, headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        var json = convert.jsonDecode(response.body);
        Transacao transacao = Transacao.fromJson(json['transacao']);
        this.save();
        return transacao;
      } else if (response.statusCode == 400) {
        var json = convert.jsonDecode(response.body);
        throw json['message'];
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  gerarPedidoViaCartaoCredito(valorRecarga, cartaoSelecionado) async {
    try {
      String url =
          dotenv.env['BASE_URL']! + "api/pagarme/criar-pedido-cartao-credito";
      var token = await storage.read(key: 'jwt');

      var response = await http.post(Uri.parse(url), body: {
        "cartao_selecionado": cartaoSelecionado,
        "valor_recarga": valorRecarga,
      }, headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        var json = convert.jsonDecode(response.body);

        return json['status_recarga'];
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  pegarSaldoInvestido() async {
    try {
      String url =
          dotenv.env['BASE_URL']! + "api/recargas/pegar-saldo-investido";

      var token = await storage.read(key: 'jwt');

      var response = await http.get(Uri.parse(url), headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        var json = convert.jsonDecode(response.body);

        if (json['total'] == 0) {
          this.saldo_atual = 0.0;
          this.saldo_investido = "0,00";
        } else {
          String stringValue = json['total'];
          double valor = double.parse(stringValue);
          this.saldo_atual = valor;
          final formatoReais = NumberFormat("#,##0.00", "pt_BR");
          this.saldo_investido = formatoReais.format(valor);
        }

        this.save();
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  pegarTotalCreditosConsumidosDia() async {
    try {
      String url = dotenv.env['BASE_URL']! +
          "api/recargas/pegar-total-creditos-consumidos-dia";

      var token = await storage.read(key: 'jwt');

      var response = await http.get(Uri.parse(url), headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        var json = convert.jsonDecode(response.body);
        String stringValue = json['total'].toString();
        double valor = double.parse(stringValue);
        final formatoReais = NumberFormat("#,##0.00", "pt_BR");
        this.creditos_consumidos_dia = formatoReais.format(valor);
        this.save();
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  pegarTotalCreditosConsumidos() async {
    try {
      String url = dotenv.env['BASE_URL']! +
          "api/recargas/pegar-total-creditos-consumidos?data_inicio=" +
          dataInicio +
          "&data_fim=" +
          dataFim;

      var token = await storage.read(key: 'jwt');

      var response = await http.get(Uri.parse(url), headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        var json = convert.jsonDecode(response.body);
        String stringValue = json['total'].toString();
        double valor = double.parse(stringValue);
        final formatoReais = NumberFormat("#,##0.00", "pt_BR");
        this.creditos_consumidos_dia = formatoReais.format(valor);
        this.save();
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  pegarLista() async {
    try {
      String url = dotenv.env['BASE_URL']! + "api/recargas/pegar-lista";

      var token = await storage.read(key: 'jwt');

      var response = await http.get(Uri.parse(url), headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        var json = convert.jsonDecode(response.body);
        List<Recarga> listaRecarga = [];
        for (var element in json['recargas']) {
          var recarga = Recarga.fromJson(element);
          listaRecarga.add(recarga);
        }

        this.recargas = listaRecarga;
        this.save();
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  save() {
    notifyListeners();
  }
}
