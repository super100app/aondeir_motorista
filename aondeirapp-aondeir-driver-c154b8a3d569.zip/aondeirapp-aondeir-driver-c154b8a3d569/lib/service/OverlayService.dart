import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart' as overlay;
import 'package:android_intent_plus/android_intent.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:aondeir_motorista/firebase_options.dart';
import 'firebase/FirebaseRealtimeConfigService.dart';

class OverlayService {
  static Future<void> showFloatingOverlay() async {
    try {
      // Verificar permissão
      bool hasPermission = await overlay.FlutterOverlayWindow.isPermissionGranted();
      if (!hasPermission) {
        bool? permissionGranted = await overlay.FlutterOverlayWindow.requestPermission();
        if (permissionGranted != true) {
          return;
        }
      }

      // SEMPRE fechar overlay existente antes de reabrir
      bool isActive = await overlay.FlutterOverlayWindow.isActive();
      if (isActive) {
        await overlay.FlutterOverlayWindow.closeOverlay();
        await Future.delayed(Duration(milliseconds: 300));
      }

      await overlay.FlutterOverlayWindow.shareData({
        'showModal': false,
        'tipo': 'FLOATING_BUTTON'
      });

      await Future.delayed(Duration(milliseconds: 100));

      // Abrir overlay com tamanho de botão flutuante (180x180)
      await overlay.FlutterOverlayWindow.showOverlay(
        height: 180,
        width: 180,
        enableDrag: true,
        flag: overlay.OverlayFlag.defaultFlag,
        positionGravity: overlay.PositionGravity.none,
        startPosition: const overlay.OverlayPosition(150, 70),
      );
    } catch (e) {
      print("❌ [showFloatingOverlay] ERRO: $e");
    }
  }

  /// Mostra o overlay como modal de nova corrida (tela cheia).
  static Future<void> showNovaCorridaOverlay(Map<String, dynamic> data) async {
    try {
      bool hasPermission = await overlay.FlutterOverlayWindow.isPermissionGranted();
      if (!hasPermission) {
        return;
      }

      bool isActive = await overlay.FlutterOverlayWindow.isActive();
      if (isActive) {
        await overlay.FlutterOverlayWindow.closeOverlay();
        await Future.delayed(Duration(milliseconds: 300));
      }

      await overlay.FlutterOverlayWindow.shareData({
        'showModal': true,
        ...data
      });
      await Future.delayed(Duration(milliseconds: 200));

      // Abrir overlay em tela cheia (matchParent)
      await overlay.FlutterOverlayWindow.showOverlay(
        height: overlay.WindowSize.matchParent,
        width: overlay.WindowSize.matchParent,
        enableDrag: false,
      );
    } catch (e) {
      print("❌ [showNovaCorridaOverlay] ERRO: $e");
    }
  }

  /// Volta o overlay para o estado de botão flutuante
  static Future<void> voltarParaBotaoFlutuante() async {
    try {
      bool hasPermission = await overlay.FlutterOverlayWindow.isPermissionGranted();
      if (!hasPermission) {
        return;
      }

      bool isActive = await overlay.FlutterOverlayWindow.isActive();
      if (isActive) {
        await overlay.FlutterOverlayWindow.closeOverlay();
        await Future.delayed(Duration(milliseconds: 300));
      }

      await overlay.FlutterOverlayWindow.shareData({
        'showModal': false,
        'tipo': 'FLOATING_BUTTON'
      });

      await Future.delayed(Duration(milliseconds: 100));

      await overlay.FlutterOverlayWindow.showOverlay(
        height: 180,
        width: 180,
        enableDrag: true,
        flag: overlay.OverlayFlag.defaultFlag,
        positionGravity: overlay.PositionGravity.none,
        startPosition: const overlay.OverlayPosition(150, 70),
      );

    } catch (e) {
      print("❌ [voltarParaBotaoFlutuante] ERRO: $e");
    }
  }

  /// Fecha o overlay completamente
  static Future<void> closeOverlay() async {
    try {
      bool isActive = await overlay.FlutterOverlayWindow.isActive();
      if (isActive) {
        await overlay.FlutterOverlayWindow.closeOverlay();
      }
    } catch (e) {
      print("❌ [closeOverlay] ERRO: $e");
    }
  }

  static Future<bool> isOverlayActive() async {
    try {
      return await overlay.FlutterOverlayWindow.isActive();
    } catch (e) {
      return false;
    }
  }

  static Future<void> keepOverlayAlive() async {
    try {
      bool isActive = await overlay.FlutterOverlayWindow.isActive();
      if (!isActive) {
        await showFloatingOverlay();
      }
    } catch (e) {
      print("❌ [keepOverlayAlive] ERRO: $e");
    }
  }

  static Future<void> startPersistentOverlay() async {
    try {
      bool hasPermission = await overlay.FlutterOverlayWindow.isPermissionGranted();
      if (!hasPermission) {
        return;
      }
      await showFloatingOverlay();
    } catch (e) {
      print("❌ [startPersistentOverlay] ERRO: $e");
    }
  }
}

@pragma('vm:entry-point')
void overlayMain() {
  runApp(OverlayMainApp());
}

class OverlayMainApp extends StatefulWidget {
  @override
  _OverlayMainAppState createState() => _OverlayMainAppState();
}

class _OverlayMainAppState extends State<OverlayMainApp> {
  bool _isModalMode = false; 
  Map<String, dynamic>? _corridaData;

  DatabaseReference? _firebaseRef;

  @override
  void initState() {
    super.initState();
    overlay.FlutterOverlayWindow.overlayListener.listen((data) {
      _processarShareData(data);
    });

    _initFirebase();

  }

  Future<void> _initFirebase() async {
    try {
      if (Firebase.apps.isEmpty) {
        await Firebase.initializeApp(
          options: DefaultFirebaseOptions.currentPlatform,
        );
      }

      await Future.delayed(Duration(milliseconds: 500));

      _listenFirebase();
    } catch (e) {
      print("❌ [OverlayMainApp] Erro ao inicializar Firebase: $e");
    }
  }

  void _listenFirebase() {
    try {
      final String motoristaPath = 'notificacao_disponivel_motorista';
      _firebaseRef = FirebaseRealtimeConfigService.getDatabase().ref(motoristaPath);

      _firebaseRef!.onValue.listen((event) {

        if (event.snapshot.value != null) {
          _processarDadosFirebase(event.snapshot.value);
        }
      });
    } catch (e) {
      print("❌ [OverlayMainApp] Erro ao escutar Firebase: $e");
    }
  }

  void _processarDadosFirebase(dynamic data) {
    try {
      if (data is Map) {
        final dataMap = Map<String, dynamic>.from(data);
        _processarShareData(dataMap);
      }
    } catch (e) {
      print("❌ [OverlayMainApp] Erro ao processar dados Firebase: $e");
    }
  }

  void _processarShareData(dynamic data) {
    if (data is! Map<String, dynamic>) {
      return;
    }
    String? status = data['corridaStatus']?.toString().toUpperCase();
    if (status != null && status.contains('CANCELADA')) {
      return;
    }

    bool deveMostrarModal = data['showModal'] == true;

    if (mounted) {
      setState(() {
        _isModalMode = deveMostrarModal;
        _corridaData = deveMostrarModal ? data : null;
      });
    }
  }

  Future<void> _abrirApp() async {
    if (!Platform.isAndroid) return;

    await overlay.FlutterOverlayWindow.closeOverlay();

    const intent = AndroidIntent(
      action: 'android.intent.action.MAIN',
      category: 'android.intent.category.LAUNCHER',
      package: 'com.aondeir.motoristaapp',
      componentName: 'com.aondeir.motoristaapp.MainActivity',
    );
    await intent.launch();

  }

  Future<void> _fecharModal() async {
    await OverlayService.voltarParaBotaoFlutuante();
  }

  @override
  void dispose() {
    _firebaseRef?.onDisconnect();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        backgroundColor: Colors.transparent,
        body: _isModalMode ? _buildModal() : _buildFloatingButton(),
      ),
    );
  }

  Widget _buildFloatingButton() {
    return Container(
      width: 180,
      height: 180,
      alignment: Alignment.center,
      child: Stack(
        children: [
          GestureDetector(
            onTap: _abrirApp,
            child: Container(
              width: 140,
              height: 140,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.transparent,
              ),
              child: ClipOval(
                child: Container(
                  width: 140,
                  height: 140,
                  child: Image.asset(
                    'assets/logo_fundo.png',
                    width: 140,
                    height: 140,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) {
                      return Center(
                        child: Icon(
                          Icons.directions_car,
                          size: 60,
                          color: Colors.white,
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
          ),
          // Botão X para fechar
          Positioned(
            top: -8,
            right: -8,
            child: GestureDetector(
              onTap: () async {
                await overlay.FlutterOverlayWindow.closeOverlay();
              },
              child: Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.transparent,
                ),
                child: Center(
                  child: Container(
                    width: 32,
                    height: 32,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.red,
                      border: Border.all(color: Colors.white, width: 2),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.3),
                          blurRadius: 5,
                          offset: Offset(2, 2),
                        ),
                      ],
                    ),
                    child: Icon(
                      Icons.close,
                      color: Colors.white,
                      size: 18,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildModal() {
    String tempo = _corridaData?['tempo']?.toString() ?? '--';
    String preco = _corridaData?['preco']?.toString() ?? '--';
    String distancia = _corridaData?['distancia']?.toString() ?? '--';
    String embarque = _corridaData?['embarque']?.toString() ?? '--';
    String destino = _corridaData?['destino']?.toString() ?? '--';
    String passageiro = _corridaData?['passageiro']?.toString() ?? '--';
    String title = _corridaData?['title']?.toString() ?? 'Nova Corrida';
    String body = _corridaData?['body']?.toString() ?? 'Você tem uma nova corrida disponível';

    return Center(
      child: Container(
        margin: EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.2),
              blurRadius: 10,
              offset: Offset(0, 5),
            ),
          ],
        ),
        child: SingleChildScrollView(
          child: Container(
            padding: EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                // Título
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.orange,
                  ),
                ),
                SizedBox(height: 8),

                // Corpo
                Text(
                  body,
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.grey[700],
                  ),
                ),
                SizedBox(height: 20),

                // Tempo e botão fechar
                Row(
                  children: [
                    Icon(Icons.access_time, color: Colors.orange, size: 28),
                    SizedBox(width: 8),
                    Text(
                      tempo,
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Spacer(),
                    GestureDetector(
                      onTap: _fecharModal,
                      child: Container(
                        padding: EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.orange, width: 1.5),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          'Fechar',
                          style: TextStyle(
                            color: Colors.orange,
                            fontSize: 14,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 8),

                // Preço
                Text(
                  preco,
                  style: TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    color: Colors.orange,
                  ),
                ),
                SizedBox(height: 12),

                // Distância e avaliação
                Row(
                  children: [
                    Icon(Icons.straighten, size: 18, color: Colors.grey[600]),
                    SizedBox(width: 4),
                    Text(
                      distancia,
                      style: TextStyle(fontSize: 14, color: Colors.grey[800]),
                    ),
                    SizedBox(width: 16),
                    Icon(Icons.person, size: 18, color: Colors.grey[600]),
                    SizedBox(width: 4),
                    Text(
                      passageiro,
                      style: TextStyle(fontSize: 14, color: Colors.grey[800]),
                    ),
                    SizedBox(width: 6),
                    Icon(Icons.star, size: 18, color: Colors.orange),
                    SizedBox(width: 2),
                    Text(
                      '5',
                      style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
                    ),
                  ],
                ),
                SizedBox(height: 16),

                // Embarque
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 2),
                      child: Icon(Icons.person_pin_circle, size: 22, color: Colors.black87),
                    ),
                    SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Embarque',
                            style: TextStyle(
                              fontSize: 13,
                              color: Colors.grey[600],
                            ),
                          ),
                          SizedBox(height: 2),
                          Text(
                            embarque,
                            style: TextStyle(
                              fontSize: 14,
                              color: Colors.black87,
                              height: 1.3,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 14),

                // Destino
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 2),
                      child: Icon(Icons.flag, size: 22, color: Colors.black87),
                    ),
                    SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Destino',
                            style: TextStyle(
                              fontSize: 13,
                              color: Colors.grey[600],
                            ),
                          ),
                          SizedBox(height: 2),
                          Text(
                            destino,
                            style: TextStyle(
                              fontSize: 14,
                              color: Colors.black87,
                              height: 1.3,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 16),

                // Botão visualizar
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton(
                    onPressed: _abrirApp,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.orange,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      elevation: 0,
                    ),
                    child: Text(
                      'Visualizar',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
