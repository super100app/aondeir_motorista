import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:permission_handler/permission_handler.dart';
import 'package:url_launcher/url_launcher.dart';
import 'dart:io';

// class FazerLigacaoService extends ChangeNotifier {
//   execute(telefone) async {
//     try {
//       await Permission.phone.request();
//       if (await Permission.phone.request().isGranted) {
//         final LaunchMode mode = LaunchMode.platformDefault;
//         final String webOnlyWindowName = '_self';
//         final WebViewConfiguration webViewConfiguration =
//             WebViewConfiguration();
//         final String phoneNumber = '+55' + telefone;
//         final Uri phoneUri = Uri(scheme: 'tel', path: phoneNumber);
//         await launchUrl(
//           phoneUri,
//           mode: mode,
//           webOnlyWindowName: webOnlyWindowName,
//           webViewConfiguration: webViewConfiguration,
//         );
//       }
//     } on http.ClientException catch (e) {
//       throw e;
//     }
//   }

class FazerLigacaoService extends ChangeNotifier {
  Future<void> execute(String telefone) async {
    final Uri phoneUri = Uri(scheme: 'tel', path: '+55$telefone');

    if (Platform.isAndroid) {
      final status = await Permission.phone.request();

      if (status.isGranted) {
        if (await canLaunchUrl(phoneUri)) {
          await launchUrl(phoneUri, mode: LaunchMode.externalApplication);
        } else {
          throw 'Não foi possível iniciar a ligação para $phoneUri';
        }
      } else {
        throw 'Permissão de telefone não concedida';
      }
    }

    if (Platform.isIOS) {

      if (await canLaunchUrl(phoneUri)) {
        await launchUrl(phoneUri, mode: LaunchMode.externalApplication);
      } else {
        throw 'Não foi possível iniciar a ligação para $phoneUri';
      }
    }
  }

  save() {
    notifyListeners();
  }
}
