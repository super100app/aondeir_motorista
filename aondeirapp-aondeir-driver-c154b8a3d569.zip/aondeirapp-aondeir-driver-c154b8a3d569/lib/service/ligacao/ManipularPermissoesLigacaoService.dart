import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:permission_handler/permission_handler.dart';

class ManipularPermissoesLigacaoService extends ChangeNotifier {
  execute() async {
    try {
      final PermissionStatus status = await Permission.phone.request();

      switch (status) {
        case PermissionStatus.granted:
          return true;
        case PermissionStatus.denied:
          return false;
        case PermissionStatus.permanentlyDenied:
          return false;
        default:
          return false;
      }
    } on http.ClientException catch (e) {
      throw e;
    }
  }

  save() {
    notifyListeners();
  }
}
