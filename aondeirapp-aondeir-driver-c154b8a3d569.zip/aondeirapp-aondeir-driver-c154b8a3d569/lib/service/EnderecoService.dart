import 'package:aondeir_motorista/models/Endereco.dart';
import 'package:flutter/material.dart';

class EnderecoService extends ChangeNotifier {
  final enderecoAtual = new Endereco(texto: "", latitude: 0, longitude: 0);
  final enderecoPartida = new Endereco(texto: "", latitude: 0, longitude: 0);
  final enderecoDestino = new Endereco(texto: "", latitude: 0, longitude: 0);

  var cadastroEnderecoFavoritoCasa = false;
  var escolherEnderecoCasaMapa = false;
  var cadastroEnderecoFavoritoTrabalho = false;
  var escolherEnderecoTrabalhoMapa = false;
  var escolherEnderecoMapa = false;
  var escolherEnderecoPartidaMapa = false;
  var pontoPartidaConfigurado = false;
  var escolherEnderecoDestinoMapa = false;
  var cidadeAtual = "";
  var enderecoAtualCompletoTexto = "";
  var enderecoAtualNumeroTexto = "";

  save() {
    notifyListeners();
  }
}
