import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class PesquisaEnderecoGeocodificacaoPorCoordenadaService
    extends ChangeNotifier {
  var latitude;
  var longitude;

  execute(latitude, longitude) async {
    try {
      final String apiKey = 'AIzaSyAgn1GSulnI9gEpRTER4abwuzuMkbjxi4c';

      final String url =
          "https://maps.googleapis.com/maps/api/geocode/json?latlng=${latitude},${longitude}&language=pt-BR&key=${apiKey}";

      final response = await http.post(Uri.parse(url));

      if (response.statusCode == 200) {
        final decoded = json.decode(response.body);

        return decoded['results'][0]["formatted_address"];
      } else {
        throw new Exception(
            'Ops! Ocorreu um erro ao buscar o endereço da sua localização');
      }
    } catch (e) {
      if (e is Exception) {
        throw e;
      } else {
        throw 'Ops! Ocorreu um erro ao buscar o endereço da sua localização';
      }
    }
  }

  save() {
    notifyListeners();
  }
}
