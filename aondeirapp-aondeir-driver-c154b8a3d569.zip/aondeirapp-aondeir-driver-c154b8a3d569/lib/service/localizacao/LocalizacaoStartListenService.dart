import 'dart:async';
import 'package:aondeir_motorista/service/localizacao/LocalizacaoAtualizarService.dart';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:geolocator/geolocator.dart';
import 'package:provider/provider.dart';

class LocalizacaoStartListenService extends ChangeNotifier {
  final BuildContext? context;

  final storage = new FlutterSecureStorage();
  late Position position;
  late StreamSubscription<Position> positionStream;
  bool isPositionStreamActive = false;

  final LocationSettings locationSettings = LocationSettings(
      // accuracy: LocationAccuracy.bestForNavigation, 
      accuracy: LocationAccuracy.low,
      distanceFilter: 100);

  LocalizacaoStartListenService(this.context) {}

  execute() async {
    print('----LocalizacaoStartListenService----');
    var localizacaoAtualizarService =
        Provider.of<LocalizacaoAtualizarService>(this.context!, listen: false);

    positionStream = Geolocator.getPositionStream(
      locationSettings: locationSettings,
    ).listen((Position novaPosition) {
      localizacaoAtualizarService.execute(
          novaPosition.latitude, novaPosition.longitude);

      position = novaPosition;
      isPositionStreamActive = true;
    });
  }

  save() {
    notifyListeners();
  }
}
