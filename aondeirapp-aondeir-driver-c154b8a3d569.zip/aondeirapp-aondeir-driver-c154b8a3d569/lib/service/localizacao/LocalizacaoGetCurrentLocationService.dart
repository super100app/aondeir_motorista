import 'dart:async';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

class LocalizacaoGetCurrentLocationService extends ChangeNotifier {
  execute() async {
    try {
      Position position = await Geolocator.getCurrentPosition().then((value) {
        return value;
      });
      return position;
    } on TimeoutException catch (e) {
      throw e;
    } on LocationServiceDisabledException catch (e) {
      throw e;
    } on PermissionDefinitionsNotFoundException catch (e) {
      throw e;
    } on PermissionRequestInProgressException catch (e) {
      throw e;
    } catch (e) {
      throw e;
    }
  }

  save() {
    notifyListeners();
  }
}
