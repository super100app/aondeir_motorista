import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

class LocalizacaoRequestPermissao extends ChangeNotifier {
  execute() async {
    LocationPermission permission = await Geolocator.requestPermission();
    if (permission == LocationPermission.always) {
      return true;
    } else if (permission == LocationPermission.whileInUse) {
      return true;
    } else if (permission == LocationPermission.denied) {
      return false;
    } else if (permission == LocationPermission.deniedForever) {
      return false;
    }
  }

  save() {
    notifyListeners();
  }
}
