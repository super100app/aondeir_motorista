import 'dart:async';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

class LocalizacaoCheckPermissaoLocalizacao extends ChangeNotifier {
  bool serviceEnabled = false;

  Future<void> execute() async {
    serviceEnabled = await Geolocator.isLocationServiceEnabled();

    if (!serviceEnabled) {
      await Geolocator.openLocationSettings();
      serviceEnabled = await Geolocator.isLocationServiceEnabled();
    }

    await this.save();
  }

  save() {
    notifyListeners();
  }
}
