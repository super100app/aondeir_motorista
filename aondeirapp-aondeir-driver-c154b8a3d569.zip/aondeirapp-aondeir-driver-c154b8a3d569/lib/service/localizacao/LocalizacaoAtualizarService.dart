import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;

class LocalizacaoAtualizarService extends ChangeNotifier {
  final storage = new FlutterSecureStorage();
  var latitudeMotorista = "";
  var longitudeMotorista = "";

  execute(latitude, longitude) async {
    try {
      // String url =
      //     dotenv.env['BASE_URL']! + "api/motorista/atualizar-localizacao-atual";
      
      // socketService.socket.emit("cordenadas" + motoristaId.toString(), {
      //     "latitude": position.latitude.toString(),
      //     "longitude": position.longitude.toString(),
      //     "usuarioId": motoristaId
      // });

      // var token = await storage.read(key: 'jwt');
      // var response = await http.post(Uri.parse(url), body: {
      //   "latitude": latitude.toString(),
      //   "longitude": longitude.toString()
      // }, headers: {
      //   HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      // });

      // if (response.statusCode == 200) {
        return true;
      // }
    } on http.ClientException catch (e) {
      throw e;
    } on TimeoutException catch (e) {
      throw e;
    } catch (e) {
      throw e;
    }
  }

  save() {
    notifyListeners();
  }
}
