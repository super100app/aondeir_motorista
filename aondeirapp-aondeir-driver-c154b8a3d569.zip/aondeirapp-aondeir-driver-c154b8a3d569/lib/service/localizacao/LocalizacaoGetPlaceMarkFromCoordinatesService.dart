import 'dart:io';

import 'package:flutter/material.dart';
// import 'package:flutter_geocoder/geocoder.dart';
import 'package:geocoding/geocoding.dart';

class LocalizacaoGetPlaceMarkFromCoordinatesService extends ChangeNotifier {
  execute(latitude, longitude) async {
    var enderecoCompleto = "";
    var cidade = "";
    var numero = "";

    await setLocaleIdentifier("pt-BR");

    // if (Platform.isIOS) {
      List<Placemark> placemarks =
          await placemarkFromCoordinates(latitude, longitude);

      if (placemarks.isNotEmpty) {
        Placemark place = placemarks.first;
        enderecoCompleto =
            "${place.street} - ${place.subLocality}, ${place.locality} - ${place.administrativeArea}, ${place.postalCode}, ${place.country}";
        cidade = "${place.locality}";
        numero = "${place.subThoroughfare}";
      }
    // } else {
    //   // final coordinates = await new Coordinates(latitude, longitude);

    //   // var addresses =
    //   //     await Geocoder.local.findAddressesFromCoordinates(coordinates);

    //   // enderecoCompleto = addresses.first.addressLine.toString();
    //   // numero = addresses.first.featureName!;
    //   // cidade = addresses.first.subAdminArea!;
    // }
    return {
      'enderecoCompleto': enderecoCompleto,
      'cidade': cidade,
      'numero': numero
    };
  }

  save() {
    notifyListeners();
  }
}
