import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

class LocalizacaoCheckPermissao extends ChangeNotifier {
  execute() async {
    LocationPermission permission = await Geolocator.checkPermission();

    if (permission == LocationPermission.always) {
      return LocationPermission.always;
    } else if (permission == LocationPermission.whileInUse) {
      return LocationPermission.whileInUse;
    } else if (permission == LocationPermission.denied) {
      return LocationPermission.denied;
    } else if (permission == LocationPermission.deniedForever) {
      return LocationPermission.deniedForever;
    }
  }

  save() {
    notifyListeners();
  }
}
