import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart' as overlay;
import 'package:provider/provider.dart';
import 'OverlayService.dart';
import 'UsuarioService.dart';

class OverlayLifecycleService {
  /// Gerencia o overlay quando o app é minimizado
  /// Esta função adiciona a funcionalidade de mostrar o botão flutuante quando o app é minimizado
  /// Executa de forma assíncrona e não bloqueante para funcionar mesmo quando minimizado rapidamente
  static Future<void> handleAppPaused(BuildContext context) async {
    try {
      print("🟡 [OverlayLifecycle] INÍCIO - App foi MINIMIZADO - Verificando overlay...");
      
      var usuarioService = Provider.of<UsuarioService>(context, listen: false);
      print("🟡 [OverlayLifecycle] UsuarioService obtido");
      
      // ✅ Usar método robusto que verifica memória e storage
      String? logado = await usuarioService.getMotoristaLogadoStatus();
      
      if (logado == 'CONECTADO') {
        print("🟡 [OverlayLifecycle] Motorista está CONECTADO - Prosseguindo com overlay...");
        
        // Verificar permissão e mostrar overlay quando minimizado
        try {
          // ✅ Verificação rápida de permissão
          print("🟡 [OverlayLifecycle] Verificando permissão de overlay...");
          bool hasPermission = await overlay.FlutterOverlayWindow.isPermissionGranted()
              .timeout(Duration(seconds: 2), onTimeout: () {
                print("⚠️ [OverlayLifecycle] Timeout ao verificar permissão");
                return false;
              });
          
          print("🟡 [OverlayLifecycle] Permissão: $hasPermission");
          
          if (hasPermission) {
            // ✅ Criar overlay de forma rápida, sem delays desnecessários
            print("🟡 [OverlayLifecycle] Criando overlay...");
            await _createOverlayQuickly();
            print("✅ [OverlayLifecycle] Overlay criado quando app minimizado");
          } else {
            print("⚠️ [OverlayLifecycle] Sem permissão de overlay para mostrar botão flutuante");
          }
        } catch (e, stackTrace) {
          print("❌ [OverlayLifecycle] Erro ao criar overlay quando minimizado: $e");
          print("❌ [OverlayLifecycle] StackTrace: $stackTrace");
        }
      } else {
        print("⚠️ [OverlayLifecycle] Motorista NÃO está conectado (status: $logado)");
      }
    } catch (e, stackTrace) {
      print("❌ [OverlayLifecycle] Erro ao processar app pausado: $e");
      print("❌ [OverlayLifecycle] StackTrace: $stackTrace");
    }
  }

  /// Cria o overlay de forma rápida, otimizada para quando o app é minimizado
  static Future<void> _createOverlayQuickly() async {
    try {
      // ✅ SEMPRE fechar overlay existente primeiro para garantir estado limpo
      // Isso é importante quando o app foi reaberto e o overlay pode estar em estado inconsistente
      bool isActive = await overlay.FlutterOverlayWindow.isActive()
          .timeout(Duration(milliseconds: 500), onTimeout: () => false);
      
      if (isActive) {
        print("🔄 [OverlayLifecycle] Overlay já está ativo, fechando para recriar...");
        try {
          await overlay.FlutterOverlayWindow.closeOverlay()
              .timeout(Duration(milliseconds: 300), onTimeout: () => null);
          await Future.delayed(Duration(milliseconds: 200));
        } catch (e) {
          print("⚠️ [OverlayLifecycle] Erro ao fechar overlay existente: $e");
        }
      }

      // Compartilhar dados rapidamente
      await overlay.FlutterOverlayWindow.shareData({
        'showModal': false,
        'tipo': 'FLOATING_BUTTON'
      }).timeout(Duration(milliseconds: 500));

      // ✅ Pequeno delay para garantir que os dados foram compartilhados
      await Future.delayed(Duration(milliseconds: 100));

      // Criar overlay sem delays desnecessários
      await overlay.FlutterOverlayWindow.showOverlay(
        height: 180,
        width: 180,
        enableDrag: true,
        flag: overlay.OverlayFlag.defaultFlag,
        positionGravity: overlay.PositionGravity.none,
        startPosition: const overlay.OverlayPosition(150, 70),
      ).timeout(Duration(seconds: 3));
      
      print("✅ [OverlayLifecycle] Overlay criado com sucesso");
      
    } catch (e) {
      print("❌ [OverlayLifecycle] Erro ao criar overlay rapidamente: $e");
      // Tentar novamente com o método padrão se falhar
      try {
        print("🔄 [OverlayLifecycle] Tentando método padrão como fallback...");
        await OverlayService.showFloatingOverlay();
        print("✅ [OverlayLifecycle] Overlay criado via método padrão");
      } catch (e2) {
        print("❌ [OverlayLifecycle] Erro no fallback: $e2");
      }
    }
  }
}

