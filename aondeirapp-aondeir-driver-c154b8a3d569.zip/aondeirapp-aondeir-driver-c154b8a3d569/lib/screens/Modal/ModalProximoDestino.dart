import 'package:flutter/material.dart';

class ModalProximoDestino extends StatefulWidget {
  final String message;
  const ModalProximoDestino({Key? key, required this.message})
      : super(key: key);

  @override
  _ModalProximoDestinoState createState() =>
      _ModalProximoDestinoState(message: message);
}

class _ModalProximoDestinoState extends State<ModalProximoDestino> {
  final String message;

  _ModalProximoDestinoState({required this.message});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(
        'Ops!',
        textAlign: TextAlign.center,
      ),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            Icons.wallet,
            color: Colors.orange,
            size: 50,
          ),
          SizedBox(height: 10),
          Text(
            "Deseja ir para o próximo destino?",
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.black),
          ),
        ],
      ),
      actions: <Widget>[
        InkWell(
          onTap: () {
            Navigator.pop(context);
          },
          child: Padding(
            padding: EdgeInsets.only(bottom: 10, left: 15, right: 15),
            child: Text(
              'Não',
              style: TextStyle(color: Colors.red),
            ),
          ),
        ),
        InkWell(
          onTap: () {
            Navigator.pop(context, "Sim");
          },
          child: Padding(
            padding: EdgeInsets.only(
              bottom: 10,
              left: 15,
            ),
            child: Text(
              'Sim',
              style: TextStyle(color: Colors.orange),
            ),
          ),
        ),
      ],
    );
  }
}
