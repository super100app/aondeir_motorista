import 'package:aondeir_motorista/screens/Usuario/Menu/Recarga/RecargaPixScreen.dart';
import 'package:flutter/material.dart';

class RecargaAlertSaldoBaixo extends StatefulWidget {
  
  const RecargaAlertSaldoBaixo({
    Key? key,
    
  }) : super(key: key);

  @override
  _RecargaAlertSaldoBaixoState createState() => _RecargaAlertSaldoBaixoState();
}

class _RecargaAlertSaldoBaixoState extends State<RecargaAlertSaldoBaixo> {
  

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(
        'Ops!',
        textAlign: TextAlign.center, 
      ),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            Icons.wallet,
            color: Colors.orange,
            size: 50,
          ),
          SizedBox(
              height: 10), 
          Text(
            "Seu saldo está abaixo de R\$ 1,00 Recarregue para continuar recebendo viagens em seu app",
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.black),
          ),
        ],
      ),
      actions: <Widget>[
        InkWell(
          onTap: () {
            Navigator.pop(context, "Recarregar carteira");
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => RecargaPixScreen(),
              ),
            );
          },
          child: Padding(
            padding: EdgeInsets.only(
              bottom: 10,
              left: 15,
            ),
            child: Text(
              'Recarregar carteira',
              style: TextStyle(color: Colors.orange),
            ),
          ),
        ),
        InkWell(
          onTap: () {
            Navigator.pop(context);
          },
          child: Padding(
            padding: EdgeInsets.only(bottom: 10, left: 15, right: 15),
            child: Text(
              'Fechar',
              style: TextStyle(color: Colors.red),
            ),
          ),
        ),
      ],
    );
  }
}
