import 'package:flutter/material.dart';

class ModalPadrao extends StatefulWidget {
  final String message;
  final bool loading;
  final bool btnFechar;
  
  const ModalPadrao({Key? key, 
  required this.message,
  this.loading = false,
  this.btnFechar = true,
  }) : super(key: key);

  @override
  _ModalPadraoState createState() => _ModalPadraoState(message: message);
}

class _ModalPadraoState extends State<ModalPadrao> {
  final String message;

  _ModalPadraoState({required this.message});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: widget.loading == true
          ? Text(
              'Carregando...',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 16,
                color: Colors.grey[700],
              ),
            )
          :
          Text(
        'Atenção!',
        textAlign: TextAlign.center,
      ),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            Icons.warning,
            color: Colors.orange,
            size: 50,
          ),
          SizedBox(height: 10),
          Text(
            "${message}",
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.black),
          ),
        ],
      ),
      actions: <Widget>[
        if(widget.loading == true || widget.btnFechar == true)
        InkWell(
          onTap: () {
            Navigator.pop(context);
          },
          child: Padding(
            padding: EdgeInsets.only(bottom: 10, left: 15, right: 15),
            child: Text(
              'Fechar',
              style: TextStyle(color: Colors.red),
            ),
          ),
        ),
      ],
    );
  }
}
