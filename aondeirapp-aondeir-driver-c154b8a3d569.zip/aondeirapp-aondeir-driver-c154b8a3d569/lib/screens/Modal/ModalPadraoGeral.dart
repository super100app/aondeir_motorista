import 'package:flutter/material.dart';

class ModalPadraoGeral extends StatefulWidget {
  final String message;
  final String? titulo;
  final bool? btnAcao;
  final bool? closeButton;
  final String? btnAcaoTexto;
  final VoidCallback? btnAcaoClick;
  final bool? loading;

  const ModalPadraoGeral({
    Key? key,
    required this.message,
    this.titulo,
    this.btnAcao,
    this.closeButton,
    this.btnAcaoTexto,
    this.btnAcaoClick,
    this.loading = false,
  }) : super(key: key);

  @override
  _ModalPadraoState createState() => _ModalPadraoState();
}

class _ModalPadraoState extends State<ModalPadraoGeral> {
  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(12.0)),
      ),
      title: widget.loading == true
          ? Text(
              'Atenção!',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 16,
                color: Colors.grey[700],
              ),
            )
          : Text(
              (widget.titulo != null && widget.titulo!.trim().isNotEmpty)
            ? widget.titulo!
            : widget.message,
              textAlign: TextAlign.center,
            ),
      content: widget.loading == true
          ? Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                CircularProgressIndicator(),
                SizedBox(height: 16),
                Text(widget.message),
              ],
            )
          : Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  Icons.warning,
                  color: Colors.orange,
                  size: 50,
                ),
                SizedBox(height: 10),
                Text(
                  widget.message,
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.black),
                ),
              ],
            ),
      actions: widget.loading == true
          ? [
              if (widget.closeButton == true)
                InkWell(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Padding(
                    padding: EdgeInsets.only(bottom: 10, left: 15, right: 15),
                    child: Text(
                      'Fechar',
                      style: TextStyle(color: Colors.red),
                    ),
                  ),
                ),
            ]
          : <Widget>[
              if (widget.btnAcao == true)
                InkWell(
                  onTap: widget.btnAcaoClick,
                  child: Padding(
                    padding: EdgeInsets.only(bottom: 10, left: 15, right: 15),
                    child: Text(
                      widget.btnAcaoTexto ?? 'Acessar',
                      style: TextStyle(color: Colors.red),
                    ),
                  ),
                ),
            ],
    );
  }
}
