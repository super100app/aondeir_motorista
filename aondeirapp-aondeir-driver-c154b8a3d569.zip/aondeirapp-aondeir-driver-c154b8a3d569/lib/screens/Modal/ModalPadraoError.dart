import 'package:flutter/material.dart';

class ModalPadraoError extends StatelessWidget {
  final String message;

  const ModalPadraoError({
    Key? key,
    required this.message,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(12.0))),
      title: Text(
        'Ops!',
        textAlign: TextAlign.center,
      ),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            Icons.error,
            color: Colors.red,
            size: 50,
          ),
          SizedBox(height: 10),
          Text(
            message,
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.black),
          ),
        ],
      ),
      actions: <Widget>[
        InkWell(
          onTap: () {
            Navigator.pop(context);
            Navigator.pop(context, "Fechar");
          },
          child: Padding(
            padding: EdgeInsets.only(bottom: 10, left: 15, right: 15),
            child: Text(
              'Fechar',
              style: TextStyle(color: Colors.orange),
            ),
          ),
        ),
      ],
    );
  }
}
