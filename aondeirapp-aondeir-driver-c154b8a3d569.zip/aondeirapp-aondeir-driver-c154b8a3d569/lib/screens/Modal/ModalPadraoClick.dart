import 'package:flutter/material.dart';

class ModalPadraoClick extends StatelessWidget {
  final String message;
  final bool? btnAcao;
  final bool? btnFechar;
  final String? btnAcaoTexto;
  final VoidCallback? btnAcaoClick;
  final bool? isLoader;
  final bool? isicon;

  const ModalPadraoClick({
    Key? key,
    required this.message,
    this.btnAcao,
    this.btnFechar,
    this.btnAcaoTexto,
    this.btnAcaoClick,
    this.isLoader,
    this.isicon,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
      backgroundColor: Colors.white,
      child: WillPopScope(
        onWillPop: () async {
          return false;
        },
        child: GestureDetector(
          onTap: () {},
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: EdgeInsets.all(20),
                child: Column(
                  children: [
                    if (isicon == true)
                      Icon(
                        Icons.warning,
                        color: Colors.orange,
                        size: 50,
                      ),
                    if (isicon == true) SizedBox(height: 10),
                    if (isLoader == true) CircularProgressIndicator(),
                    if (isLoader == true) SizedBox(height: 10),
                    Text(
                      "${message}",
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.black),
                    ),
                  ],
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  if (btnAcao == true)
                    TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                        if (btnAcaoClick != null) {
                          btnAcaoClick!();
                        }
                      },
                      child: Text(
                        btnAcaoTexto ?? 'Acessar',
                        style: TextStyle(color: Colors.red),
                      ),
                    ),
                  SizedBox(width: 10),
                  if (btnFechar == true)
                    TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      child: Text(
                        'Fechar',
                        style: TextStyle(color: Colors.red),
                      ),
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
