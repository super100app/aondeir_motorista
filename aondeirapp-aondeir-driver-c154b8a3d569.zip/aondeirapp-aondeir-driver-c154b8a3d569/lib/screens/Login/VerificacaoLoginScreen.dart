import 'dart:convert';
import 'dart:ffi';
import 'dart:io';
import 'dart:async';
import 'package:aondeir_motorista/screens/Usuario/Home/Corrida/DetalhesCorridaScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/AberturaCorrida/DetalhesMacanetaScreen.dart';
import 'package:aondeir_motorista/service/CorridaService.dart';
import 'package:aondeir_motorista/service/SocketService.dart';
import 'package:aondeir_motorista/service/auth/CadastroCompletoService.dart';
import 'package:aondeir_motorista/service/firebase/FireBaseSalvarTokenService.dart';
import 'package:aondeir_motorista/service/helper/VariavelControleService.dart';
import 'package:aondeir_motorista/service/localizacao/LocalizacaoCheckPermissao.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import 'package:aondeir_motorista/screens/Usuario/BottomNavigationBar/NavigationScreen.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'dart:convert' as convert;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart' as overlay;

import '../../models/Usuario.dart';
import '../../service/EnderecoService.dart';
import '../../service/UsuarioService.dart';
import '../Cadastro/CadastroScreen.dart';
import '../Permissao/PermissaoGeolocatorScreen.dart';
import '../Permissao/PermissaoOverlayScreen.dart';
import '../../service/localizacao/LocalizacaoGetPlaceMarkFromCoordinatesService.dart';

class VerificacaoLoginScreen extends StatefulWidget {
  final String celular;
  final String tipo;
  const VerificacaoLoginScreen(
      {Key? key, required this.celular, required this.tipo})
      : super(key: key);

  @override
  _VerificacaoLoginScreenState createState() => _VerificacaoLoginScreenState();
}

class _VerificacaoLoginScreenState extends State<VerificacaoLoginScreen> {
  late String celular;
  late String tipo;
  var codigo = "";
  final colorPrimaria = Color.fromARGB(255, 136, 129, 129);
  var errorsForm = null;
  final storage = new FlutterSecureStorage();
  var isLoading = false;
  var textLoading = "";
  bool liberarClick = false;
  int secondsLeft = 59;

  @override
  void initState() {
    super.initState();
    celular = widget.celular;
    tipo = widget.tipo;

    print("CELULLLLAR");
    print(celular);
    iniciarTimer();
  }

  void iniciarTimer() {
    const tempoParaLiberarClick =
        Duration(seconds: 59); // Tempo de espera em segundos

    Timer(tempoParaLiberarClick, () {
      setState(() {
        liberarClick = true;
      });
    });

    const umSegundo = Duration(seconds: 1);
    Timer.periodic(umSegundo, (Timer timer) {
      setState(() {
        if (secondsLeft < 1) {
          timer.cancel();
        } else {
          secondsLeft = secondsLeft - 1;
        }
      });
    });
  }

  void handleLogin() async {
    // ✅ Prevenir múltiplos cliques
    if (isLoading) {
      return;
    }
    
    print("--------------handleLogin----------------------- _VerificacaoLoginScreenState");
    
    // ✅ Mostrar loading imediatamente
    setState(() {
      isLoading = true;
      textLoading = "Verificando código...";
    });
    
    // ✅ Mostrar dialog de loading
    showDialog<String>(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(12.0)),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircularProgressIndicator(),
            SizedBox(height: 16),
            Text(
              textLoading,
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 13, color: Colors.grey[700]),
            ),
          ],
        ),
      ),
    );
    
    try {
      var usuarioService =
          Provider.of<UsuarioService>(this.context, listen: false);
      print("usuarioService");
      var fireBaseSalvarTokenService =
          Provider.of<FireBaseSalvarTokenService>(this.context, listen: false);
      print("fireBaseSalvarTokenService");
      var variavelControleService =
        Provider.of<VariavelControleService>(context, listen: false);
      print('variavelControleService');
      var cadastroCompletoService =
        Provider.of<CadastroCompletoService>(this.context, listen: false);
      print("cadastroCompletoService");
      var socketService = Provider.of<SocketService>(context, listen: false);
      print("socketService");
      var localizacaoCheckPermissao =
          Provider.of<LocalizacaoCheckPermissao>(this.context, listen: false);
      print("localizacaoCheckPermissao");
      var corridaService =
          Provider.of<CorridaService>(this.context, listen: false);
      print("corridaService");
      String url = dotenv.env['BASE_URL']! + "api/motorista/celular/login?versao=" +
            dotenv.env['VERSAO_APP']!; 

      print("url");
      print(url);
      print({"codigo": codigo, "celular": celular});

      var response = await http.post(
        Uri.parse(url),
        body: {"password": codigo, "username": celular},
      ).timeout(Duration(seconds: 30));
      
      // ✅ Fechar loading antes de processar resposta
      if (Navigator.of(context).canPop()) {
        Navigator.of(context).pop();
      }

      print("response.statusCode");
      print(response.statusCode);
      print("response.statusCode⏰⏰⏰⏰⏰⏰⏰⏰⏰⏰⏰");
      if (response.statusCode == 200) {
        var json = convert.jsonDecode(response.body);
        await storage.write(key: 'jwt', value: json["token"]);
        
        variavelControleService.checkIsLogged = true;
        await variavelControleService.save();
        Usuario usuario = Usuario.fromJson(json['usuario']);
        usuarioService.usuario = usuario;
        await usuarioService.save();
        
        socketService.retryConnection();
        
        socketService.socket?.on("motoristaAprovado" + usuario.id.toString(), (data) async => {
          Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => NavigationScreen(),
              ),
          )
        });
        await fireBaseSalvarTokenService.execute();

        await cadastroCompletoService.execute(usuario, context);

        // Verificar e solicitar permissão de overlay se motorista estiver conectado
        if (Platform.isAndroid && usuarioService.usuario.motorista['logado'] == "CONECTADO") {
          bool? hasOverlayPermission = await overlay.FlutterOverlayWindow.isPermissionGranted();
          if (hasOverlayPermission != true) {
            Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => PermissaoOverlayScreen())
            );
            return; // Para aqui e aguarda conceder permissão
          }
        }

        LocationPermission permission =
            await localizacaoCheckPermissao.execute();

        await corridaService.pegarCorridaAndamento();

        if (corridaService.corrida.isEmpty) {
          if (usuarioService.usuario.motorista['logado'] == "CONECTADO") {
            await usuarioService.desconectarMotorista();
          }

          setState(() {
            isLoading = false;
          });

          // timer.cancel();
          print('📍 Permissao do geolocalizacao: permission');
          print(permission);
          if (permission == LocationPermission.denied) {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => PermissaoGeolocatorScreen(),
              ),
            );
          } else {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => NavigationScreen(),
              ),
            );
          }
        } else if (corridaService.corrida.isNotEmpty) {
          setState(() {
            isLoading = false;
          });

          // timer.cancel();

          if (permission == LocationPermission.denied) {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => PermissaoGeolocatorScreen(),
              ),
            );
          }

          if (corridaService.corrida['categoria']['categoria_para_macaneta'] ==
              1) {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => DetalhesMacanetaScreen(),
              ),
            );
          } else {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => DetalhesCorridaScreen(),
              ),
            );
          }
        } else {}
      } else if (response.statusCode == 401) {
        var json = convert.jsonDecode(response.body);
        setState(() {
          errorsForm = json;
          isLoading = false;
        });
        
        // ✅ Mostrar mensagem de erro
        String errorMessage = json['message'] ?? json['error'] ?? 'Código inválido. Tente novamente.';
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(errorMessage),
            backgroundColor: Colors.red,
            duration: Duration(seconds: 4),
          ),
        );
      }
    } catch (e) {
      print('login erro');

      // ✅ Fechar loading em caso de erro
      if (Navigator.of(context).canPop()) {
        Navigator.of(context).pop();
      }
      
      String message = 'Erro ao verificar código. Verifique sua conexão e tente novamente.';
      if (e.toString().contains('TimeoutException') || e.toString().contains('timeout')) {
        message = 'Tempo de espera esgotado. Verifique sua conexão e tente novamente.';
      } else if (e.toString().contains('SocketException') || e.toString().contains('Failed host lookup')) {
        message = 'Erro de conexão. Verifique sua internet e tente novamente.';
      } else {
        message = e.toString();
      }
      
      setState(() {
        isLoading = false;
      });
      print(message);
      
      // ✅ Mostrar SnackBar com erro ao invés de modal
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(message),
          backgroundColor: Colors.red,
          duration: Duration(seconds: 4),
        ),
      );
    }
  }

  void saveUserLoggedIn(bool isLoggedIn, String token) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setBool('isLoggedIn', isLoggedIn);
    prefs.setString('token', token);
  }

  showLoader() {
    if (isLoading == true) {
      showDialog<String>(
        barrierDismissible: false,
        context: context,
        builder: (BuildContext context) => AlertDialog(
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(12.0))),
          title: Container(
            child: Text(
              textLoading,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 13,
                color: Colors.grey[700],
              ),
            ),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(), // Indicador de progresso circular
              SizedBox(
                  height:
                      16), // Espaçamento entre o indicador de progresso e o texto
              Text('Carregando...'), // Texto "Carregando"
            ],
          ),
        ),
      );
    }
  }

  showModalAlertError(String message) async {
    showDialog<String>(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        title: Text(
          'Ops!',
          textAlign: TextAlign.center, // Centraliza o texto
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.error,
              color: Colors.red,
              size: 50,
            ),
            SizedBox(
                height: 10), // Espaçamento entre o ícone e o Widget adicional
            // Adicione aqui o seu Widget adicional
            // Exemplo:
            Text(
              message,
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.black),
            ),
          ],
        ),
        actions: <Widget>[
          InkWell(
            onTap: () {
              Navigator.pop(context, "Fechar");
            },
            child: Padding(
              padding: EdgeInsets.only(bottom: 10, left: 15, right: 15),
              child: Text(
                'Fechar',
                style: TextStyle(color: Colors.orange),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        elevation: 0,
        centerTitle: true,
        automaticallyImplyLeading: false,
        title: Text(
          "Olá, Bem vindo de Volta",
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w700,
            color: Color(0xFFF9AD1E),
          ),
        ),
        backgroundColor: Colors.white,
      ),
      body: Padding(
        padding: EdgeInsets.only(left: 15, right: 15),
        child: Material(
          type: MaterialType.transparency,
          child: new SingleChildScrollView(
            child: Container(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 25),
                    child: Text(
                      "Identificamos esse ${tipo}, vamos confirmar?",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                        color: Color(0xFF979797),
                      ),
                    ),
                  ),
                  SizedBox(height: 63),
                  Container(
                    child: Text(
                      "Verificação de ${tipo}",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  SizedBox(height: 12),
                  Container(
                    child: Text(
                      'Insira o código recebido via mensagem em seu ${tipo}',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w400,
                        color: Color(0xFF959595),
                      ),
                    ),
                  ),
                  SizedBox(height: 15),
                  Container(
                    // padding: EdgeInsets.symmetric(horizontal: 50),
                    width: double.infinity,
                    child: PinCodeTextField(
                      appContext: context,
                      length: 4,
                      keyboardType: TextInputType.number,
                      obscureText: false,
                      animationType: AnimationType.scale,
                      animationDuration: Duration(milliseconds: 300),
                      enableActiveFill: true,
                      pinTheme: PinTheme(
                        shape: PinCodeFieldShape.box,
                        activeColor: Color(0xFFE6E6E6),
                        activeFillColor: Color(0xFFE6E6E6),
                        inactiveColor: Color(0xFFE6E6E6),
                        inactiveFillColor: Color(0xFFE6E6E6),
                        selectedColor: Color(0xFFE6E6E6),
                        selectedFillColor: Color(0xFFE6E6E6),
                        borderRadius: BorderRadius.circular(5),
                        fieldHeight: 54,
                        fieldWidth: 76.75,
                      ),
                      onCompleted: (v) {
                        print("Completed");
                      },
                      onChanged: (value) {
                        setState(() {
                          codigo = value;
                        });
                      },
                      beforeTextPaste: (text) {
                        print("Allowing to paste $text");
                        //if you return true then it will show the paste confirmation dialog. Otherwise if false, then nothing will happen.
                        //but you can show anything you want here, like your pop up saying wrong paste format or etc
                        return true;
                      },
                    ),
                  ),
                  SizedBox(height: 43),
                  Container(
                    alignment: Alignment.center,
                    child: Text(
                      "Esse é o seu ${tipo}?",
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                        color: Color(0xFF979797),
                      ),
                    ),
                  ),
                  SizedBox(height: 5),
                  Container(
                    alignment: Alignment.center,
                    child: Text(
                      celular,
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                        color: Color(0xFFF9AD1E),
                      ),
                    ),
                  ),
                  SizedBox(height: 10),
                  Container(
                    alignment: Alignment.center,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        // Mostra o contador regressivo se _exibirContador for verdadeiro
                        liberarClick == false
                            ? Text(
                                'Solicitar novamente em 00:$secondsLeft',
                                style: TextStyle(
                                    fontSize: 15, fontWeight: FontWeight.bold),
                              )
                            : GestureDetector(
                                onTap: liberarClick
                                    ? () => Navigator.of(context).pop()
                                    : null,
                                child: Container(
                                  alignment: Alignment.center,
                                  child: Text(
                                    'Alterar ${tipo}',
                                    style: TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w400,
                                      color: Color(0xFFD80000),
                                    ),
                                  ),
                                ),
                              ),
                      ],
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(top: 50),
                    child: Column(
                      children: <Widget>[
                        SizedBox(
                          width: double.infinity, // <-- Your width
                          height: 62, // <-- Your height
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              elevation: 0,
                              shadowColor: Colors.transparent,
                              backgroundColor: isLoading 
                                  ? Colors.grey 
                                  : colorPrimaria,
                              foregroundColor: colorPrimaria,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                                side: BorderSide(
                                  color: isLoading 
                                      ? Colors.grey 
                                      : colorPrimaria
                                ),
                              ),
                              // minimumSize: Size(100, 40), //////// HERE
                            ),
                            onPressed: isLoading 
                                ? null 
                                : () {
                                    handleLogin();
                                  },
                            child: Text(
                              "Confirmar",
                              style: TextStyle(
                                fontSize: 18,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
