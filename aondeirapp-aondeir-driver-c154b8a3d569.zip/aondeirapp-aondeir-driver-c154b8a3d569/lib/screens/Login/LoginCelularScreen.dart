import 'dart:convert';
import 'package:aondeir_motorista/screens/Login/VerificacaoLoginScreen.dart';
import 'package:aondeir_motorista/styles/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:http/http.dart' as http;

class LoginCelularScreen extends StatefulWidget {
  const LoginCelularScreen({Key? key}) : super(key: key);

  @override
  _LoginCelularScreenState createState() => _LoginCelularScreenState();
}

class _LoginCelularScreenState extends State<LoginCelularScreen> {
  final colorPrimaria = AppColors.primary;

  final maskCelular = MaskTextInputFormatter(
    mask: "(##) #####-####",
    filter: {"#": RegExp(r'[0-9]')},
  );

  var celular = "";
  var errorsForm = null;
  var isLoading = false;
  var textLoading = "";

  void handleLogin(tipo) async {
    // ✅ Prevenir múltiplos cliques
    if (isLoading) {
      return;
    }
    
    try {
      String url = dotenv.env['BASE_URL']! + "api/usuario/celular-envia-codigo";

      print(url);
      print(celular);
      print(tipo);
      print("LOG NO CELULAR");
      
      // Mostrar loading
      setState(() {
        isLoading = true;
        textLoading = "Enviando código...";
      });
      
      // Mostrar dialog de loading
      showDialog<String>(
        barrierDismissible: false,
        context: context,
        builder: (BuildContext context) => AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(12.0)),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(),
              SizedBox(height: 16),
              Text(
                textLoading,
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 13, color: Colors.grey[700]),
              ),
            ],
          ),
        ),
      );
      
      var response = await http.post(
        Uri.parse(url),
        body: {"celular": celular, "tipo": tipo},
      ).timeout(Duration(seconds: 30));

      print("####################");
      print(response.statusCode);
      print(response.body);

      // Fechar dialog de loading
      if (Navigator.of(context).canPop()) {
        Navigator.of(context).pop();
      }

      if (response.statusCode == 201) {
        setState(() {
          isLoading = false;
        });
        Navigator.of(context).push(
          MaterialPageRoute(
            builder:
                (_) =>
                    VerificacaoLoginScreen(celular: celular, tipo: 'celular'),
          ),
        );
      } else {
        // Tentar decodificar o JSON de erro
        try {
          final json = jsonDecode(response.body);
          String errorMessage = json['celular'] ?? json['message'] ?? json['error'] ?? 'Erro ao enviar código. Tente novamente.';
          
          setState(() {
            errorsForm = {
              'celular': errorMessage
            };
            isLoading = false;
          });
          
          // Mostrar SnackBar com o erro
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(errorMessage),
              backgroundColor: Colors.red,
              duration: Duration(seconds: 4),
            ),
          );
        } catch (e) {
          // Se não conseguir decodificar, mostrar mensagem genérica ou o body da resposta
          String errorMessage = response.body.isNotEmpty 
              ? response.body 
              : 'Erro ao enviar código. Tente novamente.';
          
          setState(() {
            errorsForm = {
              'celular': errorMessage
            };
            isLoading = false;
          });
          
          // Mostrar SnackBar com o erro
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(errorMessage),
              backgroundColor: Colors.red,
              duration: Duration(seconds: 4),
            ),
          );
        }
      }
    } catch (e) {
      print(e);
      setState(() {
        isLoading = false;
      });
    }
  }

  showLoader() {
    if (isLoading == true) {
      showDialog<String>(
        barrierDismissible: false,
        context: context,
        builder:
            (BuildContext context) => AlertDialog(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(12.0)),
              ),
              title: Container(
                child: Text(
                  textLoading,
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 13, color: Colors.grey[700]),
                ),
              ),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CircularProgressIndicator(), // Indicador de progresso circular
                  SizedBox(
                    height: 16,
                  ), // Espaçamento entre o indicador de progresso e o texto
                  Text('Carregando...'), // Texto "Carregando"
                ],
              ),
            ),
      );
    }
  }

  showModalAlertError(String message) async {
    showDialog<String>(
      context: context,
      builder:
          (BuildContext context) => AlertDialog(
            title: Text(
              'Ops!',
              textAlign: TextAlign.center, // Centraliza o texto
            ),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.error, color: Colors.red, size: 50),
                SizedBox(
                  height: 10,
                ), // Espaçamento entre o ícone e o Widget adicional
                // Adicione aqui o seu Widget adicional
                // Exemplo:
                Text(
                  message,
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.black),
                ),
              ],
            ),
            actions: <Widget>[
              InkWell(
                onTap: () {
                  Navigator.pop(context, "Fechar");
                },
                child: Padding(
                  padding: EdgeInsets.only(bottom: 10, left: 15, right: 15),
                  child: Text('Fechar', style: TextStyle(color: Colors.orange)),
                ),
              ),
            ],
          ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Padding(
        padding: EdgeInsets.only(left: 15, right: 15, top: 63),
        child: Material(
          type: MaterialType.transparency,
          child: new SingleChildScrollView(
            child: Container(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Container(
                    alignment: Alignment.center,
                    child: Image.asset('assets/Logo.png', width: 87),
                  ),
                  Row(
                    children: <Widget>[
                      SizedBox(width: 50),
                      Container(
                        width: 43.99,
                        decoration: BoxDecoration(
                          color: colorPrimaria,
                          shape: BoxShape.circle,
                        ),
                        child: IconButton(
                          icon: const Icon(Icons.phone),
                          color: Colors.white,
                          onPressed: () {},
                        ),
                      ),
                    ],
                  ),
                  Row(
                    children: <Widget>[
                      SizedBox(width: 28),
                      Container(
                        child: Text(
                          "Entrar com Celular",
                          textAlign: TextAlign.start,
                          style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 15),
                  Container(
                    child: Text(
                      "Faça seu login:",
                      textAlign: TextAlign.start,
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  SizedBox(height: 5),
                  Container(
                    child: Text(
                      "insira seu número de celular",
                      textAlign: TextAlign.start,
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                        color: Color(0xFF5F5F5F),
                      ),
                    ),
                  ),
                  SizedBox(height: 30),
                  Container(
                    width: double.infinity,
                    child: TextField(
                      inputFormatters: [maskCelular],
                      keyboardType: TextInputType.number,
                      autofocus: false,
                      style: TextStyle(
                        fontSize: 16.0,
                        fontWeight: FontWeight.w400,
                      ),
                      textAlign: TextAlign.center,
                      onChanged: (String value) async {
                        setState(() {
                          errorsForm = null;
                        });
                        setState(() {
                          celular = value;
                        });
                      },
                      decoration: InputDecoration(
                        contentPadding: EdgeInsets.only(
                          left: 15,
                          right: 15,
                          top: 0,
                          bottom: 0,
                        ),
                        border: OutlineInputBorder(),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Color(0xFFE6E6E6)),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Color(0xFFE6E6E6)),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        fillColor: Color(0xFFE6E6E6),
                        filled: true,
                        hintText: 'Insira seu número de celular',
                        errorText:
                            errorsForm?['celular'] != null
                                ? errorsForm['celular']
                                : null,
                      ),
                    ),
                  ),
                  SizedBox(height: 30),
                  // Container(
                  //   child: Text(
                  //     "Como você gostaria de receber o código de login?",
                  //     textAlign: TextAlign.start,
                  //     style: TextStyle(
                  //       fontSize: 14,
                  //       fontWeight: FontWeight.w400,
                  //       color: Colors.black,
                  //     ),
                  //   ),
                  // ),
                  Row(
                    children: <Widget>[
                      // Flexible(
                      //   flex: 1,
                      //   child: Container(
                      //     margin: EdgeInsets.only(top: 10),
                      //     child: Column(
                      //       children: <Widget>[
                      //         SizedBox(
                      //           width: double.infinity, // <-- Your width
                      //           height: 62, // <-- Your height
                      //           child: ElevatedButton(
                      //             style: ElevatedButton.styleFrom(
                      //               elevation: 0,
                      //               shadowColor: Colors.transparent,
                      //               backgroundColor: colorPrimaria,
                      //               foregroundColor: colorPrimaria,
                      //               shape: RoundedRectangleBorder(
                      //                 borderRadius: BorderRadius.circular(12),
                      //                 side: BorderSide(color: colorPrimaria),
                      //               ),
                      //               minimumSize: Size(100, 40), //////// HERE
                      //             ),
                      //             onPressed: () {
                      //               handleLogin("SMS");
                      //             },
                      //             child: Column(
                      //               mainAxisAlignment: MainAxisAlignment.center,
                      //               children: [
                      //                 Text(
                      //                   "Enviar agora",
                      //                   style: TextStyle(
                      //                     fontSize: 15,
                      //                     color: Colors.white,
                      //                   ),
                      //                   textAlign: TextAlign.center,
                      //                 ),
                      //                 Text(
                      //                   "SMS",
                      //                   style: TextStyle(
                      //                     fontSize: 18,
                      //                     color: Colors.white,
                      //                     fontWeight: FontWeight.bold,
                      //                   ),
                      //                   textAlign: TextAlign.center,
                      //                 ),
                      //               ],
                      //             ),
                      //           ),
                      //         ),
                      //         SizedBox(height: 20),
                      //       ],
                      //     ),
                      //   ),
                      // ),
                      SizedBox(width: 0),
                      Flexible(
                        flex: 1,
                        child: Container(
                          margin: EdgeInsets.only(top: 10),
                          child: Column(
                            children: <Widget>[
                              SizedBox(
                                width: double.infinity, // <-- Your width
                                height: 62, // <-- Your height
                                child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    elevation: 0,
                                    shadowColor: AppColors.buttonShadowSecondary,
                                    backgroundColor: isLoading 
                                        ? Colors.grey 
                                        : AppColors.primary,
                                    foregroundColor: AppColors.primary,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(12),
                                      side: BorderSide(
                                        color: isLoading 
                                            ? Colors.grey 
                                            : AppColors.primary
                                      ),
                                    ),
                                    minimumSize: Size(100, 40), //////// HERE
                                  ),
                                  onPressed: isLoading 
                                      ? null 
                                      : () {
                                          handleLogin("WHATSAPP");
                                        },
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text(
                                        "Enviar agora",
                                        style: TextStyle(
                                          fontSize: 15,
                                          color: Colors.white,
                                        ),
                                        textAlign: TextAlign.center,
                                      ),
                                      Text(
                                        "WHATSAPP",
                                        style: TextStyle(
                                          fontSize: 18,
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold,
                                        ),
                                        textAlign: TextAlign.center,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              SizedBox(
                                height: 20,
                                child: Text(
                                  "Recomendado!",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    fontSize: 13,
                                    color: Color(0xFF5F5F5F),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
