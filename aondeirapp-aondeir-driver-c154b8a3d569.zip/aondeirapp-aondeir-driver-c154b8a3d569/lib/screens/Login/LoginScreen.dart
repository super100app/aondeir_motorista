import 'dart:async';
import 'dart:io';
import 'package:aondeir_motorista/screens/Inicio/InitialScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/BottomNavigationBar/NavigationScreen.dart';
import 'package:aondeir_motorista/service/SocketService.dart';
import 'package:aondeir_motorista/styles/app_colors.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'dart:convert' as convert;
import 'package:aondeir_motorista/screens/Cadastro/CadastroScreen.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:provider/provider.dart';
import '../../models/Usuario.dart';
import '../../service/CorridaService.dart';
import '../../service/UsuarioService.dart';
import '../../service/auth/CadastroCompletoService.dart';
import '../../service/firebase/FireBaseSalvarTokenService.dart';
import '../../service/helper/VariavelControleService.dart';
import '../../service/localizacao/LocalizacaoCheckPermissao.dart';
import '../../service/localizacao/LocalizacaoRequestPermissao.dart';
import '../Permissao/PermissaoGeolocatorScreen.dart';
import '../Usuario/Home/Corrida/DetalhesCorridaScreen.dart';
import '../Usuario/Menu/AberturaCorrida/DetalhesMacanetaScreen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final color = const Color(0xFFFE7E27);
  final marrom = const Color.fromRGBO(38, 84, 26, 1);
  var vEmail = "";
  var vPassword = "";
  var errorsForm = null;

  bool isLoading = false;
  String buttonText = 'CADASTRAR';
  String dotText = '';
  late Timer timer;
  int dotCount = 1;

  final storage = new FlutterSecureStorage();

  final TextEditingController _controllerEmail =
      TextEditingController(text: '');
  final TextEditingController _controllerSenha =
      TextEditingController(text: '');

  void initState() {
    super.initState();
  }

  _login() async {
    try {
      var usuarioService =
          Provider.of<UsuarioService>(this.context, listen: false);
      var fireBaseSalvarTokenService =
          Provider.of<FireBaseSalvarTokenService>(this.context, listen: false);
      var cadastroCompletoService =
          Provider.of<CadastroCompletoService>(this.context, listen: false);

      var localizacaoCheckPermissao =
          Provider.of<LocalizacaoCheckPermissao>(this.context, listen: false);

      var corridaService =
          Provider.of<CorridaService>(this.context, listen: false);

      String url = dotenv.env['BASE_URL']! +
          "api/motorista/celular/login?versao=" +
          dotenv.env['VERSAO_APP']!;
      var response = await http.post(
        Uri.parse(url),
        body: {"username": vEmail, "password": vPassword},
      );
      print("🫶 passou aqui - _login");
      if (response.statusCode == 200) {
        var json = convert.jsonDecode(response.body);
        await storage.write(key: 'jwt', value: json["token"]);
        var variavelControleService =
            Provider.of<VariavelControleService>(context, listen: false);
        variavelControleService.checkIsLogged = true;
        await variavelControleService.save();
        Usuario usuario = Usuario.fromJson(json['usuario']);
        usuarioService.usuario = usuario;
        await usuarioService.save();
        var socketService = Provider.of<SocketService>(context, listen: false);
        socketService.retryConnection();
        
        socketService.socket?.on("motoristaAprovado" + usuario.id.toString(), (data) async => {
          Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => NavigationScreen(),
              ),
          )
        });
        await fireBaseSalvarTokenService.execute();

        await cadastroCompletoService.execute(usuario, context);

        LocationPermission permission =
            await localizacaoCheckPermissao.execute();

        await corridaService.pegarCorridaAndamento();

        if (corridaService.corrida.isEmpty) {
          if (usuarioService.usuario.motorista['logado'] == "CONECTADO") {
            await usuarioService.desconectarMotorista();
          }

          setState(() {
            isLoading = false;
          });

          timer.cancel();
          print('📍 Permissao do geolocalizacao: permission');
          print(permission);
          if (permission == LocationPermission.denied) {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => PermissaoGeolocatorScreen(),
              ),
            );
          } else {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => NavigationScreen(),
              ),
            );
          }
        } else if (corridaService.corrida.isNotEmpty) {
          setState(() {
            isLoading = false;
          });

          timer.cancel();

          if (permission == LocationPermission.denied) {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => PermissaoGeolocatorScreen(),
              ),
            );
          }

          if (corridaService.corrida['categoria']['categoria_para_macaneta'] ==
              1) {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => DetalhesMacanetaScreen(),
              ),
            );
          } else {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => DetalhesCorridaScreen(),
              ),
            );
          }
        } else {}
      } else if (response.statusCode == 401) {
        var json = convert.jsonDecode(response.body);
        setState(() {
          errorsForm = json;
          isLoading = false;
        });

        timer.cancel();
      }
    } catch (e) {
      print("🚨 Erro ao tentar logar");
      print(e);
      setState(() {
        isLoading = false;
      });

      Connectivity().checkConnectivity().then((connectivityResult) {
        if (connectivityResult == ConnectivityResult.none) {
          showModalAlertError(
              "Ops! Ocorreu um erro ao tentar fazer o login. Verifique sua conexão com a internet e tente novamente");
        } else {
          showModalAlertError(
              "Ops! Ocorreu um erro ao tentar fazer o login. tente novamente mais tarde");
        }
      });
    }
  }

  setLoaderTrue() async {
    setState(() {
      isLoading = true;
      dotCount = 1;
    });
  }

  setTime() async {
    timer = Timer.periodic(Duration(seconds: 1), (timer) {
      setState(() {
        dotCount = (dotCount % 4) + 1;
      });

      if (dotCount == 1) {
        setState(() {
          dotText = '';
        });
      }
      if (dotCount == 2) {
        setState(() {
          dotText = '.';
        });
      }
      if (dotCount == 3) {
        setState(() {
          dotText = '..';
        });
      }
      if (dotCount == 4) {
        setState(() {
          dotText = '...';
        });
      }
    });
  }

  showModalAlertPermissao() async {
    var localizacaoRequestPermissao =
        Provider.of<LocalizacaoRequestPermissao>(this.context, listen: false);
    showDialog<String>(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        title: const Text('Confirmar'),
        content: const Text(
            'Para ter acesso ao aplicativo é necessário permitir a localização do dispositivo. Deseja permitir?'),
        actions: <Widget>[
          InkWell(
            onTap: () {
              Navigator.pop(context, "Nao");
            },
            child: Padding(
              padding: EdgeInsets.all(15),
              child: Text(
                'Não',
                style: TextStyle(color: Colors.orange),
              ),
            ),
          ),
          InkWell(
            onTap: () {
              Navigator.pop(context, "Sim");
              localizacaoRequestPermissao.execute();
            },
            child: Padding(
              padding: EdgeInsets.all(15),
              child: Text(
                'Sim',
                style: TextStyle(color: Colors.orange),
              ),
            ),
          ),
        ],
      ),
    );
  }

  showModalAlertError(String message) async {
    showDialog<String>(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        title: Text(
          'Ops!',
          textAlign: TextAlign.center,
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.error,
              color: Colors.red,
              size: 50,
            ),
            SizedBox(height: 10),
            Text(
              message,
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.black),
            ),
          ],
        ),
        actions: <Widget>[
          InkWell(
            onTap: () {
              Navigator.pop(context, "Fechar");
            },
            child: Padding(
              padding: EdgeInsets.only(bottom: 10, left: 15, right: 15),
              child: Text(
                'Fechar',
                style: TextStyle(color: Colors.orange),
              ),
            ),
          ),
        ],
      ),
    );
  }

  final _formKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    return MediaQuery(
      data: MediaQuery.of(context).copyWith(textScaler: TextScaler.linear(1.0)),
      child: Form(
        key: _formKey,
        child: Material(
          color: Colors.white,
          type: MaterialType.card,
          child: SingleChildScrollView(
            child: ConstrainedBox(
              constraints:
                  BoxConstraints(maxHeight: MediaQuery.of(context).size.height),
              child: Container(
                margin: const EdgeInsets.only(left: 25, right: 25, top: 80),
                color: Colors.white,
                child: Column(
                  children: <Widget>[
                    Expanded(
                      child: Container(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: <Widget>[
                                Container(
                                  transform:
                                      Matrix4.translationValues(0.0, 0.0, 0.0),
                                  decoration: BoxDecoration(
                                    image: DecorationImage(
                                      image: AssetImage(
                                          "assets/imagemCadastroMotorista.png"),
                                      alignment: Alignment.centerLeft,
                                    ),
                                  ),
                                  child: Padding(
                                    padding:
                                        EdgeInsets.only(bottom: 30, left: 25),
                                    child: SizedBox(
                                      width: 290.0,
                                      height: 50.0,
                                      child: const Text(
                                        "ACESSAR",
                                        style: TextStyle(
                                            fontSize: 40,
                                            fontStyle: FontStyle.normal),
                                      ),
                                    ),
                                  ), /* add child content here */
                                ),
                              ],
                            ),
                            Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: <Widget>[
                                Padding(
                                  padding: EdgeInsets.only(bottom: 25, top: 30),
                                  child: Container(
                                    width: double.infinity,
                                    child: TextField(
                                      controller: _controllerEmail,
                                      autofocus: false,
                                      style: TextStyle(
                                          fontSize: 18.0,
                                          fontWeight: FontWeight.w300),
                                      textAlign: TextAlign.left,
                                      onChanged: (String value) async {
                                        setState(() {
                                          vEmail = value;
                                        });
                                      },
                                      decoration: InputDecoration(
                                        hintText: 'E-mail',
                                        errorText:
                                            errorsForm?['statusCode'] == 401
                                                ? "E-mail não encontrado!"
                                                : null,
                                      ),
                                    ),
                                  ),
                                ),
                                Container(
                                  transform: Matrix4.translationValues(
                                      0.0, -15.0, 0.0),
                                  child: RichText(
                                    text: new TextSpan(
                                      style: new TextStyle(
                                        fontSize: 20.0,
                                      ),
                                      children: [],
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: EdgeInsets.only(bottom: 25),
                                  child: Container(
                                    width: double.infinity,
                                    child: TextField(
                                      controller: _controllerSenha,
                                      obscureText: true,
                                      autofocus: false,
                                      style: TextStyle(
                                          fontSize: 18.0,
                                          fontWeight: FontWeight.w300),
                                      textAlign: TextAlign.left,
                                      onChanged: (String value) async {
                                        setState(() {
                                          vPassword = value;
                                        });
                                      },
                                      decoration: InputDecoration(
                                        hintText: 'Senha',
                                        errorText:
                                            errorsForm?['statusCode'] == 401
                                                ? "Senha inválida"
                                                : null,
                                      ),
                                    ),
                                  ),
                                ),
                                Container(
                                  transform: Matrix4.translationValues(
                                      90.0, -15.0, 0.0),
                                  child: RichText(
                                    text: new TextSpan(
                                      style: new TextStyle(
                                        fontSize: 20.0,
                                      ),
                                      children: [
                                        new TextSpan(
                                          text: 'Esqueceu sua senha?',
                                          style: new TextStyle(
                                            fontStyle: FontStyle.normal,
                                            fontWeight: FontWeight.w300,
                                            fontSize: 16.0,
                                            color: Colors.black54,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Container(
                                  transform:
                                      Matrix4.translationValues(76.0, 0.0, 0.0),
                                  child: Padding(
                                    padding: EdgeInsets.only(top: 30),
                                    child: SizedBox(
                                      width: 250.0,
                                      height: 50.0,
                                      child: ElevatedButton(
                                        style: ButtonStyle(
                                          shape: MaterialStateProperty.all<
                                              RoundedRectangleBorder>(
                                            RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(5.0),
                                                side: BorderSide(
                                                    color: AppColors.buttonBorderPrimary)),
                                          ),
                                          backgroundColor:
                                              MaterialStateProperty.all(
                                                  AppColors.buttonPrimary),
                                          shadowColor:
                                              MaterialStateProperty.all(
                                                  AppColors.buttonShadowPrimary),
                                        ),
                                        onPressed: isLoading == true
                                            ? null
                                            : () async {
                                                await setLoaderTrue();
                                                await setTime();
                                                await _login();
                                              },
                                        child: Row(
                                          children: [
                                            if (isLoading == true)
                                              Text(
                                                "CARREGANDO",
                                                style: TextStyle(
                                                    fontWeight: FontWeight.w500,
                                                    fontSize: 18,
                                                    color: Colors.white),
                                              ),
                                            if (isLoading == true)
                                              Container(
                                                width: 30,
                                                child: Text(
                                                  dotText,
                                                  style: TextStyle(
                                                      fontWeight:
                                                          FontWeight.w500,
                                                      fontSize: 21,
                                                      letterSpacing: 2,
                                                      color: Colors.white),
                                                ),
                                              ),
                                            if (isLoading == true)
                                              SizedBox(width: 20),
                                            if (isLoading == true)
                                              CircularProgressIndicator(
                                                color: Colors.white,
                                                semanticsLabel:
                                                    'Circular progress indicator',
                                              ),
                                            if (isLoading == false)
                                              Expanded(
                                                child: Align(
                                                  alignment: Alignment.center,
                                                  child: Text(
                                                    'ENTRAR',
                                                    style: TextStyle(
                                                      fontWeight:
                                                          FontWeight.w500,
                                                      fontSize: 21,
                                                      color: Colors.white,
                                                      letterSpacing: 2,
                                                    ),
                                                  ),
                                                ),
                                              )
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                InkWell(
                                  onTap: () {
                                    Navigator.of(context).push(
                                        MaterialPageRoute(
                                            builder: (_) => CadastroScreen()));
                                  },
                                  child: Padding(
                                    padding: EdgeInsets.only(top: 5),
                                    child: SizedBox(
                                      width: double.infinity,
                                      height: 60.0,
                                      child: Align(
                                        alignment:
                                            FractionalOffset.bottomCenter,
                                        child: RichText(
                                          text: new TextSpan(
                                            style: new TextStyle(
                                              fontSize: 20.0,
                                            ),
                                            children: [
                                              new TextSpan(
                                                  text: 'Não tem uma conta? ',
                                                  style: new TextStyle(
                                                      fontStyle:
                                                          FontStyle.normal,
                                                      fontWeight:
                                                          FontWeight.w300,
                                                      fontSize: 16.9,
                                                      color: Colors.black)),
                                              new TextSpan(
                                                  text: 'CADASTRAR ',
                                                  style: new TextStyle(
                                                      fontStyle:
                                                          FontStyle.normal,
                                                      fontWeight:
                                                          FontWeight.w300,
                                                      fontSize: 16.9,
                                                      color: Colors.grey)),
                                              new TextSpan(
                                                  text: 'agora',
                                                  style: new TextStyle(
                                                      fontStyle:
                                                          FontStyle.normal,
                                                      fontWeight:
                                                          FontWeight.w300,
                                                      fontSize: 16.9,
                                                      color: Colors.black)),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            )
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
