import 'package:flutter/material.dart';

class TermosUsoScreen extends StatefulWidget {
  const TermosUsoScreen({super.key});

  @override
  State<TermosUsoScreen> createState() => _TermosUsoScreenState();
}

class _TermosUsoScreenState extends State<TermosUsoScreen> {
  @override
  Widget build(BuildContext context) {
    return MediaQuery(
      data: MediaQuery.of(context).copyWith(textScaler: TextScaler.linear(1.0)),
      child:Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        centerTitle: true,
        elevation: 0,
        automaticallyImplyLeading: true,
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: Icon(
            Icons.arrow_back,
            color: Colors.black,
          ),
        ),
        title: Text(
          "Termos de uso",
          style: TextStyle(
            fontSize: 17,
            fontWeight: FontWeight.w400,
            color: Color(0xFF5A5A5A),
          ),
        ),
      ),
      body: Material(
        type: MaterialType.card,
        child: new SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 15),
            child: Container(
              color: Colors.white,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  SizedBox(height: 38),
                  Text(
                    "Termos e Norma’s da Empresa GBA Tecnologia ao aplicativo AONDE IR - MOTORISTA!",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "1- O motorista deve ter no mínimo 21 anos e possuir CNH categoria B com a observação EAR (Exerce Atividade Remunerada).",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "2- O motorista deve possuir um veículo próprio, que atenda aos requisitos de idade e conservação determinados pela empresa (ou lei municipal) que oferece o serviço de aplicativo de transporte. (Mínimo 10 anos e 4 portas com ar condicionado, o carro deve estar em ótimo estado de preservação)",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "3- O motorista deve ter seguro para terceiros e para passageiros, conforme exigências legais.(Seguro APP é Opcional)",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "4- O motorista deve manter o veículo limpo e em boas condições de conservação, incluindo a manutenção mecânica e elétrica em dia.",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "5- O motorista deve utilizar as vias públicas de forma segura, respeitando as leis de trânsito, os limites de velocidade e as sinalizações.",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "6- O motorista deve manter o comportamento profissional durante as viagens, tratando os passageiros com respeito e cordialidade. Caso o passageiro tenha comportamento Rude ou agressivo, o motorista tem todo direito de cancelar a viagem e reportar a central para bloqueio do passageiro. O motorista também deve se manter vestido profissionalmente com Calça, camiseta com manga e sapato fechado ! (Lei municipal) ",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "7- O motorista não pode fumar no veículo durante as viagens.(Lei municipal)",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "8- O motorista não pode transportar passageiros fora do aplicativo de transporte, ou seja, fora do sistema de solicitação de corridas. (Caso seja descoberto, será banido da plataforma )",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "•Para tal serviço use a maçaneta), ou chame a nossa central para despachar as viagens! O não cumprimento dessa norma causa punição de BLOQUEIO e Exclusão no aplicativo.",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "9- O motorista não pode cancelar uma corrida sem justificativa plausível. (Pena/punição de 5 hrs sem receber viagens na plataforma, o próprio app faz a punição automaticamente)",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "10- O motorista não deve realizar viagens clandestina (fora do aplicativo)",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "•O não cumprimento dessa norma causa punição de BLOQUEIO e Exclusão no aplicativo.",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "11- O motorista deve manter o aplicativo de transporte sempre atualizado e em bom funcionamento.(Não nos responsabilizamos por aparelhos antigos e travando, apenas pelo app, caso o app esteja em funcionamento 100% na central, recomendamos o motorista trocar o aparelho ou plano de internet para melhor funcionamento) (a empresa também não se responsabiliza pelo aparelho do motorista)",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "12- O motorista deve respeitar as regras e termos de uso do aplicativo de transporte. (LGPD)",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "13- Todos os motoristas que desejam utilizar o aplicativo de transporte devem pagar uma TAXA para a empresa. Esta TAXA é necessária para cobrir os custos de cadastro, viagens, propaganda e manutenção da plataforma. 13.1- A TAXA É VARIAVEL DE CIDADE PARA CIDADE, CONSULTE AS TAXAS COM O FRANQUEADO LOCAL!",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "14- Norma: Proximidade Responsável no Chamado de Motoristas",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "Objetivo: Esta norma tem como objetivo estabelecer diretrizes para o uso responsável do chamado de proximidade por parte dos motoristas em uma plataforma de transporte. Ela visa garantir a segurança, privacidade e comodidade dos clientes, bem como promover um ambiente de confiança entre motoristas e usuários.",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "Definição de Burlacão de Sistema: Burlacão de sistema refere-se a um motorista que abusa do chamado de proximidade, isto é, se aproxima excessivamente do cliente ao realizar o chamado, violando as regras estabelecidas pela plataforma.",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "Norma: Limite de Proximidade: Os motoristas devem respeitar um limite de proximidade razoável ao utilizar o chamado de proximidade. Esse limite será estabelecido pela plataforma de acordo com critérios de segurança, privacidade e conveniência para os clientes.",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "Definição do Limite: O limite de proximidade será definido levando em consideração fatores como a área geográfica, o tempo estimado de chegada do motorista, as características específicas do local de embarque e outros critérios relevantes.",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "Orientação aos Motoristas: A plataforma fornecerá orientações claras e explícitas aos motoristas sobre o uso adequado do chamado de proximidade, destacando a importância de respeitar o limite estabelecido e evitar comportamentos invasivos.",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "Monitoramento e Detecção: A plataforma implementará medidas de monitoramento e detecção para identificar motoristas que estejam violando o limite de proximidade de forma sistemática. Isso pode incluir análise de dados de localização, feedback dos clientes e outros métodos apropriados.",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "Penalidades: Caso um motorista seja identificado como um “burlacão de sistema“ de acordo com os critérios estabelecidos, ele estará sujeito a penalidades determinadas pela plataforma. As penalidades podem incluir advertências, suspensões temporárias ou permanentes da plataforma, ou até mesmo rescisão do contrato, dependendo da gravidade e recorrência da violação.",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "15- É punido com banimento da plataforma o motorista que tentar burlar o sistema da AONDE IR para receber mais viagens de chamada que outros motoristas, usando de má fé o sistema de chamadas de proximidade de viagem! ",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "16- É obrigatório o uso de vestimenta “Calça“ cobrindo 100% das pernas ! (Lei municipal) e camiseta com manga cobrindo ombros e parcialmente os braços (Lei municipal) !",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "17- É obrigatório o Motorista atender a ligação da Central de suporte e chamada da AONDE IR , (O numero o franqueado local irá informar ao motorista) no horário de serviço em que o motorista está online ou em serviço em corrida ! O não cumprimento dessa norma 17 causa punição de 12hrs no aplicativo AONDE IR - motorista ! Salvo quando em emergência de Saúde ou causas maiores e o motorista esteja mais próximo do cliente em emergência, caso o mesmo não atenda nesta situação, não será punido no app!",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "18- Caso o motorista não esteja pronto/preparado para fazer a corrida após o aceite, e demorar mais de 2 minutos para se deslocar do local em que esteja, será punido em 5 hrs sem receber viagens no aplicativo! Salvo caso o passageiro não responda as mensagens do Chat do aplicativo Passageiro/motorista! Ligação não será contabilizado nesta norma, apenas CHAT! ",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "19- O motorista deve seguir a RISCA a Lei Municipal vigente da cidade onde se encontra trabalhando com a plataforma! 19.1- caso não haja lei municipal, o motorista deverá seguir a risca a LEI Nº 13.640, de 26 DE MARÇO DE 2018",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "20- Política de Atendimento ao Cliente",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "Na nossa busca constante por um serviço de qualidade e respeito aos nossos clientes, estabelecemos as seguintes diretrizes para abordar situações de desacato, discussão ou reclamações relacionadas ao atendimento prestado pelos motoristas.",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "20.1.- Investigação de Reclamações e Desacatos",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "Qualquer reclamação ou desacato relatado por um cliente passageiro será tratado com seriedade e respeito.",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "Um registro será criado para documentar todas as reclamações relacionadas a um motorista específico.",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "20.2.-Notificação e Alerta ao Motorista",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "Se um motorista receber uma reclamação válida, ele será notificado imediatamente sobre a ocorrência.",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "O motorista receberá um alerta sobre a importância de manter um comportamento profissional e cortês com os clientes.",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "20.3.- Reincidência e Medidas Disciplinares",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "Em casos de reincidência, com mais de três reclamações sobre o mesmo assunto e após o motorista ter sido previamente notificado e alertado, medidas disciplinares serão aplicadas.",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "O motorista poderá ser removido da plataforma, sem aviso prévio, se persistir no comportamento inadequado, prejudicando a experiência dos clientes.",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "Nosso objetivo é criar um ambiente seguro e agradável para todos os envolvidos na plataforma, e contamos com a colaboração dos motoristas para garantir que isso seja alcançado. O respeito e a cortesia são fundamentais para manter a confiança dos nossos clientes.",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "Agradecemos a todos os motoristas por seu comprometimento em fornecer um serviço de qualidade e por tratar os clientes com o respeito que eles merecem.",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "21- Obrigação de Transportar Passageiros com Deficiência Visual",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "21.1- Todo motorista de aplicativo deve estar disposto a transportar passageiros com deficiência visual.",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "21.2- O motorista de aplicativo não pode recusar corridas de passageiros com deficiência visual, mesmo que estejam acompanhados de cães guia.",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "21.3- .O motorista de aplicativo deve fornecer assistência ao passageiro com deficiência visual, conforme necessário, para garantir uma viagem segura e confortável.",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "21.4- O motorista deve exigir que o passageiro deficiente visual use cinto de segurança.",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "22- Comportamento Adequado e Respeito",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "22.1- O motorista de aplicativo deve tratar todos os passageiros com respeito, cortesia e dignidade, independentemente de sua condição.",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "22.2- Em caso de cães guia acompanhando o passageiro, o motorista de aplicativo deve permitir que o cão guia viaje no veículo e não pode recusar o acesso ao mesmo.",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "22.3- O motorista de aplicativo não deve fazer comentários ou ações discriminatórias, ofensivas ou prejudiciais em relação ao passageiro com deficiência visual.",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "------------",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "*Todas Estas normas entra em vigor imediatamente na data 11/04/2024*",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "O não cumprimentos destas normas acarretará em banimento OU punição imediato da plataforma !",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    ));
  }
}
