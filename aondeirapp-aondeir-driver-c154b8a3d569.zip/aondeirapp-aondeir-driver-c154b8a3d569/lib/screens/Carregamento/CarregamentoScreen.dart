import 'package:flutter/material.dart';

class CarregamentoScreen extends StatefulWidget {
  const CarregamentoScreen({Key? key}) : super(key: key);

  @override
  _CarregamentoScreenState createState() => _CarregamentoScreenState();
}

class _CarregamentoScreenState extends State<CarregamentoScreen> {
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        return false;
      },
      child: Material(
        type: MaterialType.card,
        child: SingleChildScrollView(
          child: ConstrainedBox(
            constraints:
                BoxConstraints(maxHeight: MediaQuery.of(context).size.height),
            child: Container(
              margin: const EdgeInsets.only(left: 15, right: 15, top: 25),
              color: Colors.white,
              child: Column(
                children: <Widget>[
                  Container(
                    margin: EdgeInsets.only(top: 180),
                    child: Column(
                      children: [
                        Image.asset('assets/Logo.png'),
                      ],
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(top: 20, bottom: 20),
                    child: Column(
                      children: [
                        Center(
                          child: CircularProgressIndicator(),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.end,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          transform: Matrix4.translationValues(0.0, 0.0, 0.0),
                          child: RichText(
                            text: new TextSpan(
                              style: new TextStyle(
                                fontSize: 20.0,
                              ),
                              children: [
                                new TextSpan(
                                    text: 'Carregando...',
                                    style: new TextStyle(
                                        fontStyle: FontStyle.normal,
                                        fontWeight: FontWeight.w300,
                                        fontSize: 20.0,
                                        color: Colors.black54)),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
