import 'package:aondeir_motorista/screens/Permissao/PermissaoBateriaScreen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart' as overlay;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../Usuario/BottomNavigationBar/NavigationScreen.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';

class PermissaoOverlayScreen extends StatefulWidget {
  const PermissaoOverlayScreen({super.key});

  @override
  State<PermissaoOverlayScreen> createState() => _PermissaoOverlayScreenState();
}

class _PermissaoOverlayScreenState extends State<PermissaoOverlayScreen> with WidgetsBindingObserver {
  final storage = new FlutterSecureStorage();
  var textLoading = "";
  bool _isProcessing = false; // Flag para evitar múltiplas execuções

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    
    // Quando o app voltar ao foreground, verificar permissão
    if (state == AppLifecycleState.resumed && _isProcessing) {
      print("🔄 [PermissaoOverlay] App voltou ao foreground, verificando permissão...");
      verificarPermissao();
    }
  }

  autorizar() async {
    // Evitar múltiplas execuções simultâneas
    if (_isProcessing) {
      print("⚠️ [PermissaoOverlay] Já está processando, ignorando...");
      return;
    }
    
    setState(() {
      _isProcessing = true;
    });
    
    print("🚀 [PermissaoOverlay] Solicitando permissão de overlay...");
    
    // Apenas abre a tela de configuração, não espera
    await overlay.FlutterOverlayWindow.requestPermission();
    
    // O didChangeAppLifecycleState vai verificar quando voltar
  }

  verificarPermissao() async {
    print("🔍 [PermissaoOverlay] Verificando permissão...");
    
    if (!mounted) return;
    
    // Aguardar um momento para o sistema processar
    await Future.delayed(Duration(milliseconds: 300));
    
    bool permissaoConcedida = await overlay.FlutterOverlayWindow.isPermissionGranted();
    print("✅ [PermissaoOverlay] Permissão: $permissaoConcedida");

    if (!permissaoConcedida) {
      print("❌ [PermissaoOverlay] Permissão não foi concedida");
      
      if (!mounted) return;
      
      setState(() {
        _isProcessing = false; // Libera o botão
      });
      
      // Mostrar um dialog explicando que a permissão é necessária
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text("Permissão Necessária"),
          content: Text("Para receber notificações de corridas, você precisa permitir que o app seja exibido sobre outros apps."),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                autorizar(); // Tentar novamente
              },
              child: Text("Tentar Novamente"),
            ),
          ],
        ),
      );
      return;
    }

    // Permissão concedida, continuar fluxo
    if (!mounted) return;

    bool permitido = await FlutterForegroundTask.isIgnoringBatteryOptimizations;
    
    if (!mounted) return;
    
    if (permitido == false) {
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => PermissaoBateriaScreen(),
        ),
      );
    } else {
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => NavigationScreen(),
        ),
      );
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: null,
        title: Text(
          "Permissão de sobrepor a outros apps",
          style: TextStyle(fontSize: 17, color: Colors.black),
        ),
        elevation: 0,
        centerTitle: true,
        backgroundColor: Colors.white,
      ),
      body: WillPopScope(
        onWillPop: () async {
          return false;
        },
        child: Padding(
          padding: EdgeInsets.all(15),
          child: Material(
            type: MaterialType.transparency,
            child: new SingleChildScrollView(
              child: Container(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.grey.shade300),
                        borderRadius: BorderRadius.circular(15),
                      ),
                      padding: EdgeInsets.all(15),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            "Permite que esse app seja exibido em sobreposição a outros apps que você esteja usando. Pode haver inteferecia no uso e alteração nas atividades desses apps.",
                            style: TextStyle(
                                color: Colors.grey[600], fontSize: 16),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Container(
                      child: Column(
                        children: <Widget>[
                          SizedBox(
                            width: double.infinity,
                            height: 62,
                            child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                elevation: 0,
                                shadowColor: Colors.transparent,
                                backgroundColor:
                                    _isProcessing 
                                        ? Colors.grey 
                                        : Color.fromARGB(255, 255, 152, 0),
                                foregroundColor:
                                    Color.fromARGB(255, 255, 152, 0),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                minimumSize: Size(100, 40),
                              ),
                              onPressed: _isProcessing ? null : () {
                                autorizar();
                              },
                              child: Text(
                                _isProcessing ? "Aguarde..." : "Avançar",
                                style: TextStyle(
                                  fontSize: 20,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
