import 'dart:io';

import 'package:aondeir_motorista/screens/Permissao/PermissaoOverlayScreen.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import 'package:provider/provider.dart';
import '../../service/CorridaService.dart';
import '../../service/UsuarioService.dart';
import '../../service/localizacao/LocalizacaoRequestPermissao.dart';
import '../Usuario/BottomNavigationBar/NavigationScreen.dart';
import '../Usuario/Home/Corrida/DetalhesCorridaScreen.dart';
import '../Usuario/Menu/AberturaCorrida/DetalhesMacanetaScreen.dart';

class PermissaoGeolocatorScreen extends StatefulWidget {
  const PermissaoGeolocatorScreen({super.key});

  @override
  State<PermissaoGeolocatorScreen> createState() =>
      _PermissaoGeolocatorScreenState();
}

class _PermissaoGeolocatorScreenState extends State<PermissaoGeolocatorScreen> {
  var isLoading = false;
  var textLoading = "";
  autorizar() async {
    try {
      var localizacaoRequestPermissao =
          Provider.of<LocalizacaoRequestPermissao>(this.context, listen: false);
      var corridaService =
          Provider.of<CorridaService>(this.context, listen: false);

      var usuarioService =
          Provider.of<UsuarioService>(this.context, listen: false);

      var resp = await localizacaoRequestPermissao.execute();

      if (resp) {
        setState(() {
          isLoading = true;
          textLoading = "Configurando localização...";
        });
        await showLoader();
        await Future.delayed(Duration(seconds: 3));
        Navigator.of(context).pop();

        setState(() {
          isLoading = false;
        });

        await corridaService.pegarCorridaAndamento();

        if (corridaService.corrida.isNotEmpty) {
          if (corridaService.corrida['categoria']['categoria_para_macaneta'] ==
              1) {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => DetalhesMacanetaScreen(),
              ),
            );
          } else {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => DetalhesCorridaScreen(),
              ),
            );
          }
        } else {
          if (usuarioService.usuario.motorista['logado'] == "CONECTADO") {
            await usuarioService.desconectarMotorista();
          }
          if (Platform.isIOS) { 
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => NavigationScreen(),
              ),
            );
          } else {
            // var permissionOverlay =
            //     await FlutterOverlayWindow.isPermissionGranted();
            // if (permissionOverlay == false) {
            //   Navigator.of(context).push(
            //     MaterialPageRoute(
            //       builder: (_) => PermissaoOverlayScreen(),
            //     ),
            //   );
            // } else {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => NavigationScreen(),
                ),
              );
            // }
          }
        }
      } else {
        setState(() {
          isLoading = false;
        });
      }
    } catch (e) {
      String message = e.toString();
      setState(() {
        isLoading = false;
      });
      showModalAlertError(message);
    }
  }

  showModalAlertError(String message) async {
    showDialog<String>(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        title: Text(
          'Ops!',
          textAlign: TextAlign.center,
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.error,
              color: Colors.red,
              size: 50,
            ),
            SizedBox(height: 10),
            Text(
              message,
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.black),
            ),
          ],
        ),
        actions: <Widget>[
          InkWell(
            onTap: () {
              Navigator.pop(context, "Fechar");
            },
            child: Padding(
              padding: EdgeInsets.only(bottom: 10, left: 15, right: 15),
              child: Text(
                'Fechar',
                style: TextStyle(color: Colors.orange),
              ),
            ),
          ),
        ],
      ),
    );
  }

  showLoader() {
    if (isLoading == true) {
      showDialog<String>(
        barrierDismissible: false,
        context: context,
        builder: (BuildContext context) => AlertDialog(
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(12.0))),
          title: Container(
            child: Text(
              textLoading,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 13,
                color: Colors.grey[700],
              ),
            ),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(),
              SizedBox(height: 16),
              Text('Carregando...'),
            ],
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: null,
        title: Text(
          "Permissão de Localização",
          style: TextStyle(fontSize: 17, color: Colors.black),
        ),
        elevation: 0,
        centerTitle: true,
        backgroundColor: Colors.white,
      ),
      body: WillPopScope(
        onWillPop: () async {
          return false;
        },
        child: Padding(
          padding: EdgeInsets.all(15),
          child: Material(
            type: MaterialType.transparency,
            child: new SingleChildScrollView(
              child: Container(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.grey.shade300),
                        borderRadius: BorderRadius.circular(15),
                      ),
                      padding: EdgeInsets.all(15),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            "Para melhorar sua viagem, precisamos da sua permissão para acessar sua localização.",
                            style: TextStyle(
                                color: Colors.grey[600], fontSize: 16),
                          ),
                          SizedBox(height: 10),
                          Text(
                            "Seu dispositivo terá que:\nUsar GPS, Wi-Fi, redes celulares e sensores",
                            style: TextStyle(
                                color: Colors.grey[600], fontSize: 16),
                          ),
                          SizedBox(height: 10),
                          Text(
                            "Como parte desse serviço, o app pode coletar dados de localização periodicamente quando estiver em primeiro ou em segundo plano. Esses dados tornam o embarque, o suporte e outros processos mais eficientes.",
                            style: TextStyle(
                                color: Colors.grey[600], fontSize: 16),
                          ),
                          SizedBox(height: 10),
                          Text(
                            "Para acessar detalhes, acesse as configurações de localização.",
                            style: TextStyle(
                                color: Colors.grey[600], fontSize: 16),
                          ),
                          SizedBox(height: 10),
                          Text(
                            "Compartilhamento de localização desativado. Toque no botão para ativar",
                            style: TextStyle(
                                color: Colors.grey[600], fontSize: 16),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Container(
                      child: Column(
                        children: <Widget>[
                          SizedBox(
                            width: double.infinity,
                            height: 62,
                            child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                elevation: 0,
                                shadowColor: Colors.transparent,
                                backgroundColor:
                                    Color.fromARGB(255, 255, 152, 0),
                                foregroundColor:
                                    Color.fromARGB(255, 255, 152, 0),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                minimumSize: Size(100, 40),
                              ),
                              onPressed: () {
                                autorizar();
                              },
                              child: Text(
                                "Avançar",
                                style: TextStyle(
                                  fontSize: 20,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
