import 'package:aondeir_motorista/screens/Modal/ModalPadrao.dart';
import 'package:aondeir_motorista/screens/Permissao/PermissaoAlarmeScreen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import '../Usuario/BottomNavigationBar/NavigationScreen.dart';

class PermissaoBateriaScreen extends StatefulWidget {
  const PermissaoBateriaScreen({super.key});

  @override
  State<PermissaoBateriaScreen> createState() => _PermissaoBateriaScreenState();
}

class _PermissaoBateriaScreenState extends State<PermissaoBateriaScreen> {
  var isLoading = false;
  var textLoading = "";

  Future<void> solicitarPermissao() async {
    try {
      setState(() {
        isLoading = true;
        textLoading = "Solicitando permissão...";
      });

      await Future.delayed(Duration(seconds: 2));

      bool permitidoBateria = await FlutterForegroundTask.isIgnoringBatteryOptimizations;
      print("🚀 Permisao de bateria...");
      if (!permitidoBateria) {
        await FlutterForegroundTask.requestIgnoreBatteryOptimization();
      }

      setState(() {
        isLoading = false;
      });

      // bool permitido = await FlutterForegroundTask.canScheduleExactAlarms;
      // print("🚀 Permisao de alarme...");
      // if (!permitido) {
      //    print("🚀 if de alarme...");
      //   Navigator.of(context).push(
      //     MaterialPageRoute(
      //       builder: (_) => PermissaoAlarmeScreen(),
      //     ),
      //   );
      // } else {
         print("🚀 else de alarme...");
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => NavigationScreen(),
          ),
        );
      // } 
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      showModalAlertError(e.toString());
    }
  }

  void showModalAlertError(String message) {
    showDialog(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        title: Text('Erro!', textAlign: TextAlign.center),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.error, color: Colors.red, size: 50),
            SizedBox(height: 10),
            Text(message, textAlign: TextAlign.center, style: TextStyle(color: Colors.black)),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Fechar', style: TextStyle(color: Colors.orange)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text("Permissão de Bateria", style: TextStyle(fontSize: 17, color: Colors.black)),
        elevation: 0,
        centerTitle: true,
        backgroundColor: Colors.white,
      ),
      body: WillPopScope(
        onWillPop: () async => false,
        child: Padding(
          padding: EdgeInsets.all(15),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey.shade300),
                    borderRadius: BorderRadius.circular(15),
                  ),
                  padding: EdgeInsets.all(15),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        "Para garantir o funcionamento adequado do aplicativo, precisamos da sua permissão para ignorar a otimização de bateria.",
                        style: TextStyle(color: Colors.grey[600], fontSize: 16),
                      ),
                      SizedBox(height: 10),
                      Text(
                        "Isso permitirá que o aplicativo continue funcionando corretamente em segundo plano.",
                        style: TextStyle(color: Colors.grey[600], fontSize: 16),
                      ),
                      SizedBox(height: 10),
                      Text(
                        "Você pode alterar essa configuração posteriormente nas configurações do seu dispositivo.",
                        style: TextStyle(color: Colors.grey[600], fontSize: 16),
                      ),
                      SizedBox(height: 10),
                      Text(
                        "Toque no botão abaixo para conceder a permissão.",
                        style: TextStyle(color: Colors.grey[600], fontSize: 16),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  height: 62,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      elevation: 0,
                      shadowColor: Colors.transparent,
                      backgroundColor: Color.fromARGB(255, 255, 152, 0),
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    onPressed: solicitarPermissao,
                    child: Text("Avançar", style: TextStyle(fontSize: 20)),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
