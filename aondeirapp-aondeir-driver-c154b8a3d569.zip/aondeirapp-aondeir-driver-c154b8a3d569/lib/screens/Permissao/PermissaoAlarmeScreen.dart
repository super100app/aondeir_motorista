import 'package:aondeir_motorista/screens/Permissao/PermissaoBateriaScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/BottomNavigationBar/NavigationScreen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';

class PermissaoAlarmeScreen extends StatefulWidget {
  const PermissaoAlarmeScreen({super.key});

  @override
  State<PermissaoAlarmeScreen> createState() => _PermissaoAlarmeScreenState();
}

class _PermissaoAlarmeScreenState extends State<PermissaoAlarmeScreen> {
  var textLoading = "";

  Future<void> autorizar() async {
    setState(() {
      textLoading = "Verificando permissão...";
    });

    // bool hasPermission = await FlutterForegroundTask.canScheduleExactAlarms;

    // if (!hasPermission) {
    //   await FlutterForegroundTask.openAlarmsAndRemindersSettings();
    // }

    verificarPermissao();
  }

  verificarPermissao() async {
    // while (!await FlutterForegroundTask.canScheduleExactAlarms) {
    //   await Future.delayed(const Duration(seconds: 2));
    // }

    verificarMounted();

    // bool permitido = await FlutterForegroundTask.canScheduleExactAlarms;
    // print("🚀 Permisao de alarme...");
    // print(permitido);
    // if (!permitido) {
    //   Navigator.of(context).push(
    //     MaterialPageRoute(
    //       builder: (_) => PermissaoBateriaScreen(),
    //     ),
    //   );
    // } else {
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => NavigationScreen(),
        ),
      );
    // }
  }

  verificarMounted() async {
    while (!mounted) {
      await Future.delayed(const Duration(seconds: 1));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text(
          "Permissão de Alarmes",
          style: TextStyle(fontSize: 17, color: Colors.black),
        ),
        elevation: 0,
        centerTitle: true,
        backgroundColor: Colors.white,
      ),
      body: WillPopScope(
        onWillPop: () async => false,
        child: Padding(
          padding: const EdgeInsets.all(15),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey.shade300),
                    borderRadius: BorderRadius.circular(15),
                  ),
                  padding: const EdgeInsets.all(15),
                  child: const Text(
                    "Precisamos da sua permissão para agendar alarmes exatos. Isso permite que certas funções do aplicativo sejam executadas pontualmente.",
                    style: TextStyle(color: Colors.grey, fontSize: 16),
                  ),
                ),
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  height: 62,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      elevation: 0,
                      shadowColor: Colors.transparent,
                      backgroundColor: Color.fromARGB(255, 255, 152, 0),
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    onPressed: autorizar,
                    child: const Text(
                      "Avançar",
                      style: TextStyle(fontSize: 20),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
