import 'dart:async';
import 'dart:convert';

import 'package:aondeir_motorista/screens/Inicio/InitialScreen.dart';
import 'package:aondeir_motorista/screens/Login/LoginCelularScreen.dart';
import 'package:aondeir_motorista/screens/Login/LoginScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/BottomNavigationBar/NavigationScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/Cadastro/OpcoesScreen.dart';
import 'package:aondeir_motorista/service/SocketService.dart';
import 'package:aondeir_motorista/styles/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:provider/provider.dart';

import '../../models/Usuario.dart';
import '../../service/FranquiaService.dart';
import '../../service/UsuarioService.dart';

class CadastroScreen extends StatefulWidget {
  const CadastroScreen({Key? key}) : super(key: key);

  @override
  _CadastroScreenState createState() => _CadastroScreenState();
}

class _CadastroScreenState extends State<CadastroScreen> {
  final color = const Color(0xFFFE7E27);
  final marrom = const Color.fromRGBO(38, 84, 26, 1);
  final maskCelular = MaskTextInputFormatter(
      mask: "(##) #####-####", filter: {"#": RegExp(r'[0-9]')});
  final maskCpf = MaskTextInputFormatter(
      mask: "###.###.###-##", filter: {"#": RegExp(r'[0-9]')});

  bool isLoading = false;
  String buttonText = 'CADASTRAR';
  String dotText = '';
  late Timer timer;
  int dotCount = 1;

  var nome = "";
  var email = "";
  var senha = "";
  var celular = "";
  var cpf = "";
  var senhaRepita = "";
  var errorsForm = null;
  var franquiaSelecionada;

  final storage = new FlutterSecureStorage();

  final _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      var franquiaService =
          Provider.of<FranquiaService>(context, listen: false);
      await franquiaService.pegarFranquias();
    });
  }

  void handleCadastro() async {
    try {
      String url = dotenv.env['BASE_URL']! + "api/motorista/cadastrar";
      var response = await http.post(
        Uri.parse(url),
        body: {
          "nome": nome,
          "email": email,
          "telefone": celular,
          "cpf": cpf,
          "franquia": franquiaSelecionada == null ? "" : franquiaSelecionada,
          "password": senha,
          "confirm_password": senhaRepita,
        },
      );

      final json = jsonDecode(response.body);

      if (response.statusCode == 201) {
        // await storage.write(key: 'jwt', value: json["token"]);
        // var usuarioService =
        //     Provider.of<UsuarioService>(this.context, listen: false);
        // usuarioService.etapaCadastro = json['etapa'];
        // await usuarioService.save();

        // String url = dotenv.env['BASE_URL']! +
        //     "api/motorista/login?versao=" +
        //     dotenv.env['VERSAO_APP']!;
        // var responseLogin = await http.post(
        //   Uri.parse(url),
        //   body: {"username": celular, "password": senha},
        // );
        print("🫶 passou aqui - handleCadastro");
        // if (responseLogin.statusCode == 200) {
        //   final jsonLogin = jsonDecode(responseLogin.body);
        //   await storage.write(key: 'jwt', value: jsonLogin["token"]);

        //   Usuario usuario = await Usuario.fromJson(jsonLogin['usuario']);
        //   usuarioService.usuario = usuario;
        //   await usuarioService.save();
        //   var socketService = Provider.of<SocketService>(context, listen: false);
        //   await socketService.retryConnection();
          
          
        //   Navigator.of(context).push(
        //     MaterialPageRoute(
        //       builder: (_) => LoginCelularScreen(),
        //     ),
        //   );

        //   timer.cancel();
        // } else {
        setState(() {
          isLoading = false;
        });
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (_) => LoginCelularScreen(),
            ),
          );
        // }
        
        timer.cancel();
      } else {
        setState(() {
          isLoading = false;
          errorsForm = json;
        });
        timer.cancel();
      }
    } catch (e) {}
  }

  setLoaderTrue() async {
    setState(() {
      isLoading = true;
      dotCount = 1;
    });
  }

  setTime() async {
    timer = Timer.periodic(Duration(seconds: 1), (timer) {
      setState(() {
        dotCount = (dotCount % 4) + 1; // Alternar entre 1,
      });

      if (dotCount == 1) {
        setState(() {
          dotText = '';
        });
      }
      if (dotCount == 2) {
        setState(() {
          dotText = '.';
        });
      }
      if (dotCount == 3) {
        setState(() {
          dotText = '..';
        });
      }
      if (dotCount == 4) {
        setState(() {
          dotText = '...';
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    var franquiaService = Provider.of<FranquiaService>(context, listen: true);

    return MediaQuery(
      data: MediaQuery.of(context).copyWith(textScaler: TextScaler.linear(1.0)),
      child: Form(
        key: _formKey,
        child: Material(
          color: Colors.white,
          type: MaterialType.card,
          child: new SingleChildScrollView(
            child: Container(
              padding: const EdgeInsets.only(left: 25, right: 25),
              color: Colors.white,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Container(
                    margin: const EdgeInsets.only(left: 25, right: 25, top: 42),
                    child: Column(
                      children: <Widget>[
                        Container(
                          transform: Matrix4.translationValues(0.0, 0.0, 0.0),
                          decoration: BoxDecoration(
                            image: DecorationImage(
                              image: AssetImage(
                                  "assets/imagemCadastroMotorista.png"),
                              alignment: Alignment.centerLeft,
                            ),
                          ),
                          child: Padding(
                            padding: EdgeInsets.only(bottom: 30, left: 25),
                            child: SizedBox(
                              width: 290.0,
                              height: 50.0,
                              child: const Text(
                                "CADASTRAR",
                                style: TextStyle(
                                    fontSize: 40, fontStyle: FontStyle.normal),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      Padding(
                        padding: EdgeInsets.only(bottom: 25),
                        child: new Row(
                          children: <Widget>[
                            Container(
                              child: Flexible(
                                child: new TextField(
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      fontWeight: FontWeight.w300),
                                  textAlign: TextAlign.left,
                                  onChanged: (String value) async {
                                    setState(() {
                                      nome = value;
                                    });
                                  },
                                  decoration: InputDecoration(
                                    hintText: 'Nome',
                                    errorText: errorsForm?['nome'] != null
                                        ? errorsForm['nome']
                                        : null,
                                  ),
                                ),
                              ),
                            ),
                            Padding(padding: EdgeInsets.all(5)),
                          ],
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(bottom: 25),
                        child: Container(
                          width: double.infinity,
                          child: TextField(
                            autofocus: false,
                            style: TextStyle(
                              fontSize: 18.0,
                              fontWeight: FontWeight.w300,
                            ),
                            textAlign: TextAlign.left,
                            onChanged: (String value) async {
                              setState(() {
                                email = value;
                              });
                            },
                            decoration: InputDecoration(
                              hintText: 'E-mail',
                              errorText: errorsForm?['email'] != null
                                  ? errorsForm['email']
                                  : null,
                            ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(bottom: 25),
                        child: Container(
                          width: double.infinity,
                          child: TextField(
                            inputFormatters: [maskCpf],
                            autofocus: false,
                            style: TextStyle(
                                fontSize: 18.0, fontWeight: FontWeight.w300),
                            textAlign: TextAlign.left,
                            onChanged: (String value) async {
                              setState(() {
                                cpf = value;
                              });
                            },
                            decoration: InputDecoration(
                              hintText: 'CPF',
                              errorText: errorsForm?['cpf'] != null
                                  ? errorsForm['cpf']
                                  : null,
                            ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(bottom: 25),
                        child: Container(
                          width: double.infinity,
                          child: DropdownButton(
                            isExpanded: true,
                            value: franquiaSelecionada,
                            onChanged: (value) {
                              setState(() {
                                franquiaSelecionada = value;
                              });
                            },
                            items: [
                              DropdownMenuItem<String>(
                                value: null,
                                child: Text("Selecione a franquia",
                                    style: TextStyle(
                                      color: Color.fromARGB(255, 136, 129, 129),
                                    )),
                              ),
                              ...franquiaService.franquias.map((item) {
                                return DropdownMenuItem<String>(
                                  value: item.id.toString(),
                                  child: Text(item.nome),
                                );
                              }).toList(),
                            ],
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(bottom: 25),
                        child: new Row(
                          children: <Widget>[
                            Container(
                              width: 180,
                              child: new TextField(
                                style: TextStyle(
                                    fontSize: 18.0,
                                    fontWeight: FontWeight.w300),
                                textAlign: TextAlign.left,
                                obscureText: true,
                                onChanged: (String value) async {
                                  setState(() {
                                    senha = value;
                                  });
                                },
                                decoration: InputDecoration(
                                  hintText: 'Senha',
                                  errorText: errorsForm?['password'] != null
                                      ? errorsForm['password']
                                      : null,
                                ),
                              ),
                            ),
                            Padding(padding: EdgeInsets.all(5)),
                            Container(
                              child: Flexible(
                                child: new TextField(
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      fontWeight: FontWeight.w300),
                                  textAlign: TextAlign.left,
                                  obscureText: true,
                                  onChanged: (String value) async {
                                    setState(() {
                                      senhaRepita = value;
                                    });
                                  },
                                  decoration: InputDecoration(
                                    hintText: 'Confimar senha',
                                    errorText:
                                        errorsForm?['confirm_password'] != null
                                            ? errorsForm['confirm_password']
                                            : null,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(bottom: 25),
                        child: Container(
                          width: double.infinity,
                          child: TextField(
                            inputFormatters: [maskCelular],
                            style: TextStyle(
                                fontSize: 18.0, fontWeight: FontWeight.w300),
                            autofocus: false,
                            textAlign: TextAlign.left,
                            onChanged: (String value) async {
                              setState(() {
                                celular = value;
                              });
                            },
                            decoration: InputDecoration(
                              hintText: 'Celular',
                              errorText: errorsForm?['telefone'] != null
                                  ? errorsForm['telefone']
                                  : null,
                            ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(top: 10),
                        child: SizedBox(
                          width: double.infinity,
                          height: 60.0,
                          child: RichText(
                            text: new TextSpan(
                              style: new TextStyle(
                                fontSize: 20.0,
                              ),
                              children: [
                                new TextSpan(
                                  text:
                                      'Ao clicar em inscrever-se, você concorda com o seguinte',
                                  style: new TextStyle(
                                    fontStyle: FontStyle.normal,
                                    fontWeight: FontWeight.w300,
                                    fontSize: 15.9,
                                    color: Colors.black54,
                                  ),
                                ),
                                new TextSpan(
                                  text:
                                      'Termos e Condições e Politicas de Privacidade ',
                                  style: new TextStyle(
                                    fontStyle: FontStyle.normal,
                                    fontWeight: FontWeight.w300,
                                    fontSize: 15.9,
                                    color: Colors.grey,
                                  ),
                                ),
                                new TextSpan(
                                  text: 'sem agendamento.',
                                  style: new TextStyle(
                                    fontStyle: FontStyle.normal,
                                    fontWeight: FontWeight.w300,
                                    fontSize: 15.9,
                                    color: Colors.black54,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      Container(
                        transform: Matrix4.translationValues(76.0, 0.0, 0.0),
                        child: Padding(
                          padding: EdgeInsets.only(top: 30),
                          child: SizedBox(
                            width: 250.0,
                            height: 50.0,
                            child: ElevatedButton(
                              style: ButtonStyle(
                                shape: MaterialStateProperty.all<
                                    RoundedRectangleBorder>(
                                  RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(5.0),
                                      side: BorderSide(color: AppColors.buttonBorderPrimary)),
                                ),
                                backgroundColor:
                                    MaterialStateProperty.all(AppColors.buttonPrimary),
                                shadowColor:
                                    MaterialStateProperty.all(AppColors.buttonShadowPrimary),
                              ),
                              onPressed: isLoading == true
                                  ? null
                                  : () async {
                                      await setLoaderTrue();
                                      await setTime();
                                      handleCadastro();
                                    },
                              child: Row(
                                children: [
                                  if (isLoading == true)
                                    Text(
                                      "CADASTRANDO",
                                      style: TextStyle(
                                          fontWeight: FontWeight.w500,
                                          fontSize: 18,
                                          color: Colors.white),
                                    ),
                                  if (isLoading == true)
                                    Container(
                                      width: 30,
                                      child: Text(
                                        dotText,
                                        style: TextStyle(
                                            fontWeight: FontWeight.w500,
                                            fontSize: 21,
                                            letterSpacing: 2,
                                            color: Colors.white),
                                      ),
                                    ),
                                  if (isLoading == true) SizedBox(width: 10),
                                  if (isLoading == true)
                                    CircularProgressIndicator(
                                      color: Colors.white,
                                      semanticsLabel:
                                          'Circular progress indicator',
                                    ),
                                  if (isLoading == false)
                                    Expanded(
                                      child: Align(
                                        alignment: Alignment.center,
                                        child: Text(
                                          'CADASTRAR',
                                          style: TextStyle(
                                            fontWeight: FontWeight.w500,
                                            fontSize: 21,
                                            color: Colors.white,
                                            letterSpacing: 2,
                                          ),
                                        ),
                                      ),
                                    )
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                      InkWell(
                        onTap: () {
                          Navigator.of(context).push(
                              MaterialPageRoute(builder: (_) => LoginCelularScreen()));
                        },
                        child: Padding(
                          padding: EdgeInsets.only(top: 5),
                          child: SizedBox(
                            width: double.infinity,
                            height: 60.0,
                            child: Align(
                              alignment: FractionalOffset.bottomCenter,
                              child: RichText(
                                text: new TextSpan(
                                  style: new TextStyle(
                                    fontSize: 20.0,
                                  ),
                                  children: [
                                    new TextSpan(
                                        text: 'já tem uma conta? ',
                                        style: new TextStyle(
                                            fontStyle: FontStyle.normal,
                                            fontWeight: FontWeight.w300,
                                            fontSize: 16.9,
                                            color: Colors.black)),
                                    new TextSpan(
                                        text: 'ACESSAR ',
                                        style: new TextStyle(
                                            fontStyle: FontStyle.normal,
                                            fontWeight: FontWeight.w300,
                                            fontSize: 16.9,
                                            color: Colors.grey)),
                                    new TextSpan(
                                        text: 'agora',
                                        style: new TextStyle(
                                            fontStyle: FontStyle.normal,
                                            fontWeight: FontWeight.w300,
                                            fontSize: 16.9,
                                            color: Colors.black)),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
