import 'package:aondeir_motorista/screens/Cadastro/CadastroScreen.dart';
import 'package:aondeir_motorista/screens/Login/LoginCelularScreen.dart';
import 'package:aondeir_motorista/screens/Login/LoginScreen.dart';
import 'package:aondeir_motorista/styles/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

// import '../../service/SocketService.dart';

class InitialScreen extends StatefulWidget {
  const InitialScreen({Key? key}) : super(key: key);

  @override
  _InitialScreenState createState() => _InitialScreenState();
}

class _InitialScreenState extends State<InitialScreen> {
  final color = const Color(0xFFFE7E27);
  final marrom = const Color.fromRGBO(38, 84, 26, 1);

  final cpfCtrl = '';
  final celularCtrl = '';
  final dataNascimentoCtrl = '';

  @override
  Widget build(BuildContext context) {
    // Provider.of<SocketService>(context);

    return MediaQuery(
      data: MediaQuery.of(context).copyWith(textScaler: TextScaler.linear(1.0)),
      child: WillPopScope(
        onWillPop: () async {
          return false;
        },
        child: Material(
          color: Colors.white,
          type: MaterialType.card,
          child: SingleChildScrollView(
            child: ConstrainedBox(
              constraints:
                  BoxConstraints(maxHeight: MediaQuery.of(context).size.height),
              child: Container(
                margin: const EdgeInsets.only(left: 15, right: 15, top: 25),
                color: Colors.white,
                child: Column(
                  children: <Widget>[
                    Container(
                      margin: EdgeInsets.only(top: 180),
                      child: Column(
                        children: [
                          Image.asset('assets/Logo.png'),
                        ],
                      ),
                    ),
                    Expanded(
                      child: Container(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.end,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              transform:
                                  Matrix4.translationValues(0.0, 0.0, 0.0),
                              child: RichText(
                                text: new TextSpan(
                                  style: new TextStyle(
                                    fontSize: 20.0,
                                  ),
                                  children: [
                                    new TextSpan(
                                        text: 'Bem-vindo(a) ao Aonde Ir®',
                                        style: new TextStyle(
                                            fontStyle: FontStyle.normal,
                                            fontWeight: FontWeight.w300,
                                            fontSize: 20.0,
                                            color: Colors.black54)),
                                  ],
                                ),
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.only(
                                  left: 15, right: 15, bottom: 25),
                              child: new Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  Container(
                                    child: Padding(
                                      padding: EdgeInsets.only(top: 30),
                                      child: SizedBox(
                                        height: 50.0,
                                        child: ElevatedButton(
                                          style: ButtonStyle(
                                            shape: MaterialStateProperty.all<
                                                RoundedRectangleBorder>(
                                              RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          5.0),
                                                  side: BorderSide(
                                                      color: AppColors.buttonBorderPrimary)),
                                            ),
                                            backgroundColor:
                                                MaterialStateProperty.all(
                                                    AppColors.buttonPrimary),
                                            shadowColor:
                                                MaterialStateProperty.all(
                                                    AppColors.buttonShadowPrimary),
                                          ),
                                          onPressed: () async {
                                            Navigator.of(context).push(
                                                MaterialPageRoute(
                                                    builder: (_) =>
                                                        LoginCelularScreen()));
                                          },
                                          child: Text.rich(
                                            TextSpan(
                                              text: '',
                                              children: <TextSpan>[
                                                TextSpan(
                                                  text: 'ACESSAR',
                                                  style: TextStyle(
                                                      fontWeight:
                                                          FontWeight.w500,
                                                      fontSize: 21,
                                                      color: Colors.white,
                                                      letterSpacing: 2),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Padding(padding: EdgeInsets.all(5)),
                                  Container(
                                    child: Padding(
                                      padding: EdgeInsets.only(top: 30),
                                      child: SizedBox(
                                        height: 50.0,
                                        child: ElevatedButton(
                                          style: ButtonStyle(
                                            shape: MaterialStateProperty.all<
                                                RoundedRectangleBorder>(
                                              RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          5.0),
                                                  side: BorderSide(
                                                      color: AppColors.buttonBorderPrimary)),
                                            ),
                                            backgroundColor:
                                                MaterialStateProperty.all(
                                                    AppColors.buttonPrimary),
                                            shadowColor:
                                                MaterialStateProperty.all(
                                                    AppColors.buttonShadowPrimary),
                                          ),
                                          onPressed: () async {
                                            Navigator.of(context).push(
                                              MaterialPageRoute(
                                                builder: (_) =>
                                                    CadastroScreen(),
                                              ),
                                            );
                                          },
                                          child: Text.rich(
                                            TextSpan(
                                              text: '',
                                              children: <TextSpan>[
                                                TextSpan(
                                                  text: 'CADASTRO',
                                                  style: TextStyle(
                                                      fontWeight:
                                                          FontWeight.w500,
                                                      fontSize: 21,
                                                      color: Colors.white,
                                                      letterSpacing: 2),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
