import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class AtualizacaoAppScreen extends StatefulWidget {
  const AtualizacaoAppScreen({Key? key}) : super(key: key);

  @override
  _AtualizacaoAppScreenState createState() => _AtualizacaoAppScreenState();
}

class _AtualizacaoAppScreenState extends State<AtualizacaoAppScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: SvgPicture.asset(
          'assets/svgImage/aondeir.svg',
          width: 87,
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 32.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Text(
                'Mensagem para apps com versão abaixo de 1.0.0',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: Colors.orange,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            SizedBox(height: 16),
            Center(
              child: Text(
                'Seu aplicativo está desatualizado',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.orange,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            SizedBox(height: 16),
            Center(
              child: Text(
                'Mantenha seu aplicativo atualizado para continuar fazendo viagens!',
                style: TextStyle(fontSize: 24),
                textAlign: TextAlign.center,
              ),
            ),
            SizedBox(height: 32),
            Center(
              child: Text(
                'Escolha as lojas abaixo\npara atualizar o Aplicativo',
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.orange,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            SizedBox(height: 32),
            Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                TextButton(
                  onPressed: () {},
                  child: Column(
                    children: [
                      Image.asset(
                        'assets/Icones/google_play.jpg',
                        height: 50,
                      ),
                      SizedBox(height: 8),
                      Text(
                        'Uso Android',
                        style: TextStyle(
                          color: Colors.black,
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 16),
                TextButton(
                  onPressed: () {},
                  child: Column(
                    children: [
                      Image.asset(
                        'assets/Icones/apple_store.jpg',
                        height: 50,
                      ),
                      SizedBox(height: 8),
                      Text(
                        'Uso iPhone Apple',
                        style: TextStyle(
                          color: Colors.black,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
