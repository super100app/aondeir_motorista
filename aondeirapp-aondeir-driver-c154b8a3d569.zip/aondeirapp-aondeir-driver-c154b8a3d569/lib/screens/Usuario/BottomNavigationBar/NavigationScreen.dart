import 'package:aondeir_motorista/styles/app_colors.dart';
import 'dart:io' show Platform;
import 'package:aondeir_motorista/screens/Modal/ModalPadrao.dart';
import 'dart:async';
import 'package:aondeir_motorista/screens/Usuario/Home/Estatistica/EstatisticaScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Home/Mapa/MapaScreen.dart';
import 'package:aondeir_motorista/service/StatusService.dart';
import 'package:aondeir_motorista/service/corrida/CorridaBuscarService.dart';
import 'package:aondeir_motorista/service/toque/ToqueService.dart';
import 'package:aondeir_motorista/service/CorridaService.dart';
import 'package:aondeir_motorista/service/NotificationService.dart';
import 'package:aondeir_motorista/service/FirebasePresenceService.dart';
import 'package:aondeir_motorista/screens/Modal/ModalPadrao.dart';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:geolocator/geolocator.dart';
import 'package:map_launcher/map_launcher.dart';
import 'package:provider/provider.dart';
import 'package:sliding_up_panel/sliding_up_panel.dart';
import '../../../service/LocalizacaoService.dart';
import '../../../service/UsuarioService.dart';
import '../../../service/localizacao/LocalizacaoGetCurrentLocationService.dart';
import '../Home/HomeScreen.dart';

class NavigationScreen extends StatefulWidget {
  @override
  _NavigationScreenState createState() => _NavigationScreenState();
}

class _NavigationScreenState extends State<NavigationScreen> with WidgetsBindingObserver {
  PanelController panelController = PanelController();
  ScrollController scrollController = ScrollController();
  final storage = new FlutterSecureStorage();
  var expanded = false;
  bool aceitaAutomatico = false;
  Timer? _checkCanceledCorridaTimer;
  bool _hasShownCanceledAlert = false;
  bool _isShowingModal = false; // Nova variável para controlar se a modal está sendo exibida

  int _indiceAtual = 1;
  Widget _widgetOptions(index) {
    switch (index) {
      case 0:
         return MapaScreen(tipo: 'mapas'); // Pass any required parameters here

      case 1:
        return HomeScreen();

      case 2:
        setState(() {
          _indiceAtual = 1;
        });
        return HomeScreen();
      default:
        return EstatisticaScreen();
    }
  }

  final ScrollController NavigationScreen = ScrollController();

  @override
  void initState() {
    super.initState();
    
    // Adicionar observer do ciclo de vida do app
    WidgetsBinding.instance.addObserver(this);

    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      // 🔥 Inicializar Firebase Presence quando a NavigationScreen é criada
      await _initializeFirebasePresence();
      
      buscarCorrida();
      modalVerificarConexao();
      _configurarListenerNotificacao();
      _configurarListenerCorridaCancelada();
      _iniciarVerificacaoCorridaCancelada();
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    print('📱 [NavigationScreen] App lifecycle mudou: $state');
    
    if (state == AppLifecycleState.resumed) {
      print('🟢 [NavigationScreen] App voltou ao foreground - Inicializando Firebase Presence');
      _initializeFirebasePresence();
    }
  }

  Future<void> _initializeFirebasePresence() async {
    try {
      var usuarioService = Provider.of<UsuarioService>(context, listen: false);
      print('🔥🔥🔥 [NavigationScreen] ==========================================');
      print('🔥🔥🔥 [NavigationScreen] INICIALIZANDO FIREBASE PRESENCE');
      print('🔥🔥🔥 [NavigationScreen] Motorista ID: ${usuarioService.usuario.id}');
      print('🔥🔥🔥 [NavigationScreen] ==========================================');
      
      await FirebasePresenceService().initialize(usuarioService.usuario.id);
      
      print('✅✅✅ [NavigationScreen] Firebase Presence inicializado com sucesso!');
    } catch (e) {
      print('❌❌❌ [NavigationScreen] Erro ao inicializar Firebase Presence: $e');
    }
  }

  void _iniciarVerificacaoCorridaCancelada() {
    // Verifica a cada 2 segundos se há corrida cancelada
    _checkCanceledCorridaTimer = Timer.periodic(Duration(seconds: 2), (timer) {
      if (mounted) {
        final corridaService = Provider.of<CorridaService>(context, listen: false);
        
        if (corridaService.corrida.isNotEmpty && 
            corridaService.corrida['status'] != null &&
            (corridaService.corrida['status']['id'] == '8' || corridaService.corrida['status']['id'] == 8) &&
            !_hasShownCanceledAlert) {
          
          print("🚫 NavigationScreen: Corrida cancelada detectada via Timer!");
          String motivo = corridaService.corrida['motivo_descricao_cancelamento'] ?? 'Motivo não informado';
        }
      }
    });
  }

  void _resetarEstadoModal() {
    _hasShownCanceledAlert = false;
    _isShowingModal = false;
  }

  @override
  void dispose() {
    _checkCanceledCorridaTimer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  void _configurarListenerCorridaCancelada() {
    // Escuta mudanças no CorridaService para detectar cancelamentos
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final corridaService = Provider.of<CorridaService>(context, listen: false);
      
      print("🔧 NavigationScreen: Configurando listener para corrida cancelada");
      
      // Adiciona listener para detectar quando uma corrida é cancelada
      corridaService.addListener(() {
        // Verifica se a corrida foi cancelada - múltiplas condições
        bool isCorridaNotEmpty = corridaService.corrida.isNotEmpty;
        bool hasStatus = corridaService.corrida['status'] != null;
        bool isStatus8 = corridaService.corrida['status']?['id'] == '8';
        bool isStatus8Int = corridaService.corrida['status']?['id'] == 8;
        
        if (isCorridaNotEmpty && hasStatus && (isStatus8 || isStatus8Int) && !_hasShownCanceledAlert) {
          String motivo = corridaService.corrida['motivo_descricao_cancelamento'] ?? 'Motivo não informado';
        }
      });
    });
  }

  void _configurarListenerNotificacao() {
    // Escuta mudanças no NotificationService
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final notificationService = Provider.of<NotificationService>(context, listen: false);
      
      // Adiciona listener para reagir a novas notificações
      notificationService.addListener(() {
        if (notificationService.verificarNovaCorrida()) {
          print("🔔 NavigationScreen: Nova corrida detectada via notificação!");
          buscarCorrida();
        }
      });
    });
  }

  buscarCorrida() {
    var corridaBuscarService = Provider.of<CorridaBuscarService>(
      context,
      listen: false,
    );
    corridaBuscarService.execute();
  }

  openMap() {
    MapLauncher.showMarker(
      title: "local atual",
      mapType: MapType.google,
      coords: Coords(-23.5618, -46.656),
    );
  }

  conectar() async {
    try {
      // Verificar permissão de localização primeiro
      LocationPermission permission = await Geolocator.checkPermission();
      
      if (permission == LocationPermission.deniedForever) {
        _showModalAlertPermissaoNegada();
        return;
      }
      
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          _showModalAlertPermissaoNegada();
          return;
        }
      }
      
      // Verificar se a localização está ativada
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        _showModalAlertLocalizacao();
        return;
      }

      showLoader("Conectando...");
      var usuarioService = Provider.of<UsuarioService>(context, listen: false);
      var toqueService = Provider.of<ToqueService>(context, listen: false);
      var corridaBuscarService = Provider.of<CorridaBuscarService>(
        context,
        listen: false,
      );
      
      var cordenadas = await _getCurrentLocation();
      
      await Future.delayed(Duration(seconds: 1));

      await usuarioService.conectarMotorista();
      await corridaBuscarService.execute(
        cordenadas.latitude,
        cordenadas.longitude,
      );
      toqueService.execute('toques/toque_botao_online_motorista.mp3');
      Navigator.of(context).pop();
    } catch (e) {
      Navigator.of(context).pop();
      // Se o erro for relacionado à localização, mostrar alerta específico
      if (e.toString().contains('Location services are disabled') || 
          e.toString().contains('Location permission')) {
        _showModalAlertLocalizacao();
      } else {
        // Outros erros
        _showModalAlertError('Erro ao conectar. Tente novamente.');
      }
    }
  }

  Future<Position> _getCurrentLocation() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      return Future.error("Location services are disabled.");
    }

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return Future.error("Location permission are denied.");
      }
    }

    if (permission == LocationPermission.deniedForever) {
      return Future.error("Location Permission are permetly......");
    }

    return await Geolocator.getCurrentPosition();
  }

  void desconectar() async {
    try {
      var usuarioService = Provider.of<UsuarioService>(context, listen: false);
      var corridaBuscarService = Provider.of<CorridaBuscarService>(
        context,
        listen: false,
      );
      showLoader("Desconectando...");
      var cordenadas = await _getCurrentLocation();
      await Future.delayed(Duration(seconds: 1));
      await usuarioService.desconectarMotorista();
      await corridaBuscarService.execute(
        cordenadas.latitude,
        cordenadas.longitude,
      );
      Navigator.of(context).pop();
    } catch (e) {
      Navigator.of(context).pop();
    }
  }

  modalVerificarConexao() async {
    if (!mounted) {
      return;
    }

    var usuarioService = Provider.of<UsuarioService>(context, listen: false);
    setState(() {
      aceitaAutomatico =
          usuarioService.usuario.motorista['aceita_automatico'] == 1
              ? true
              : false;
    });

    usuarioService.usuario.motorista != null &&
            usuarioService.usuario.motorista['logado'] == "DESCONECTADO"
        ? {
          showDialog<String>(
            context: context,
            builder:
                (BuildContext context) => AlertDialog(
                  title: Text('Ops!', textAlign: TextAlign.center),
                  content: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.login, color: Colors.orange, size: 50),
                      SizedBox(height: 10),
                      Text(
                        "Você esta desconectado, deseja se conectar?",
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.black),
                      ),
                    ],
                  ),
                  actions: <Widget>[
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        InkWell(
                          onTap: () {
                            Navigator.pop(context, "Fechar");
                          },
                          child: Padding(
                            padding: EdgeInsets.only(bottom: 10, left: 15),
                            child: Text(
                              'Cancelar',
                              style: TextStyle(color: Colors.red),
                            ),
                          ),
                        ),
                        InkWell(
                          onTap: () async {
                            Navigator.pop(context, "Sim");
                            conectar();
                            // if (panelController.isAttached &&
                            //     panelController.isPanelOpen) {
                            //   panelController.close();
                            // }
                          },
                          child: Padding(
                            padding: EdgeInsets.only(bottom: 10, right: 15),
                            child: Text(
                              'Conectar-se',
                              style: TextStyle(color: Colors.orange),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
          ),
        }
        : null;
  }

  showLoader(texto) {
    showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) => ModalPadrao(
        message: texto,
        loading: false,
        btnFechar: false
      ));
  }

  showModalConectar() {
    showDialog<String>(
      context: context,
      builder:
          (BuildContext context) => AlertDialog(
            title: const Text('Confirmar'),
            content: const Text('Deseja realmente se conectar-se?'),
            actions: <Widget>[
              InkWell(
                onTap: () {
                  Navigator.pop(context, "Nao");
                },
                child: Padding(
                  padding: EdgeInsets.all(15),
                  child: Text('Não', style: TextStyle(color: Colors.orange)),
                ),
              ),
              InkWell(
                onTap: () async {
                  Navigator.pop(context, "Sim");
                  conectar();
                  // if (panelController.isAttached &&
                  //     panelController.isPanelOpen) {
                  //   panelController.close();
                  // }
                },
                child: Padding(
                  padding: EdgeInsets.all(15),
                  child: Text('Sim', style: TextStyle(color: Colors.orange)),
                ),
              ),
            ],
          ),
    );
  }

  showModalDesconectar() {
    showDialog<String>(
      context: context,
      builder:
          (BuildContext context) => AlertDialog(
            title: const Text('Confirmar'),
            content: const Text('Deseja realmente se desconectar?'),
            actions: <Widget>[
              InkWell(
                onTap: () {
                  Navigator.pop(context, "Nao");
                },
                child: Padding(
                  padding: EdgeInsets.all(15),
                  child: Text('Não', style: TextStyle(color: Colors.orange)),
                ),
              ),
              InkWell(
                onTap: () {
                  Navigator.pop(context, "Sim");
                  desconectar();
                  // if (panelController.isAttached &&
                  //     panelController.isPanelOpen) {
                  //   panelController.close();
                  // }
                },
                child: Padding(
                  padding: EdgeInsets.all(15),
                  child: Text('Sim', style: TextStyle(color: Colors.orange)),
                ),
              ),
            ],
          ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // var statusService = Provider.of<StatusService>(context);
    var usuarioService = Provider.of<UsuarioService>(context, listen: true);
    var notificationService = Provider.of<NotificationService>(context, listen: true);
    var corridaService = Provider.of<CorridaService>(context, listen: true);
    
    // Reage a mudanças no NotificationService
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (notificationService.verificarNovaCorrida()) {
        print("🔔 NavigationScreen: Nova corrida detectada no build!");
        buscarCorrida();
      }
      
      // Verifica se há corrida cancelada no build também
      if (corridaService.corrida.isNotEmpty && 
          corridaService.corrida['status'] != null &&
          (corridaService.corrida['status']['id'] == '8' || corridaService.corrida['status']['id'] == 8) &&
          !_hasShownCanceledAlert) {
        print("🚫 NavigationScreen: Corrida cancelada detectada no build!");
        String motivo = corridaService.corrida['motivo_descricao_cancelamento'] ?? 'Motivo não informado';
      }
    });
    
    return MediaQuery(
      data: MediaQuery.of(context).copyWith(textScaler: TextScaler.linear(1.0)),
      child: Scaffold(
        body: WillPopScope(
          onWillPop: () async {
            return false;
          },
          child: CustomScrollView(
            slivers: <Widget>[
              SliverAppBar(
                automaticallyImplyLeading: false,
                expandedHeight:
                    MediaQuery.of(context).size.height -
                    (Platform.isAndroid ? 250 : 150),
                flexibleSpace: _widgetOptions(_indiceAtual),
                // flexibleSpace: HomeScreen(),
              ),
              SliverList(
                delegate: SliverChildBuilderDelegate((_, int index) {
                  return Container(
                    height: 250,
                    width: double.maxFinite,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.2),
                          spreadRadius: 5,
                          blurRadius: 7,
                          offset: Offset(0, 3),
                        ),
                      ],
                    ),
                    child: Column(
                      children: <Widget>[
                        Container(
                          width: double.maxFinite,
                          color: Colors.orange,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[],
                          ),
                        ),
                        // statusService.disponivel == true
                        //     ? buildDragHandle()
                        //     :
                        SizedBox(height: 10),
                        Padding(
                          padding: EdgeInsets.only(
                            left: 15,
                            right: 15,
                            bottom: Platform.isAndroid ? 15 : 2,
                            top: 5,
                          ),
                          child: Table(
                            columnWidths: {2: FlexColumnWidth(1)},
                            children: [
                              TableRow(
                                children: [
                                  BottomNavigationBar(
                                    type: BottomNavigationBarType.fixed,
                                    elevation: 0,
                                    backgroundColor: Colors.transparent,
                                    selectedItemColor: Colors.orange,
                                    unselectedItemColor: Colors.grey,
                                    currentIndex: _indiceAtual,
                                    // currentIndex: 1,
                                    onTap: onTabTapped,
                                    items: [
                                      BottomNavigationBarItem(
                                        icon: Icon(Icons.pin_drop),
                                        label: "Mapas",
                                      ),
                                      BottomNavigationBarItem(
                                        icon: Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: <Widget>[
                                            Padding(
                                              padding: EdgeInsets.only(top: 2),
                                              child:
                                                  usuarioService
                                                                  .usuario
                                                                  .motorista !=
                                                              null &&
                                                          usuarioService
                                                                  .usuario
                                                                  .motorista['logado'] ==
                                                              "CONECTADO"
                                                      ? Text(
                                                        "Conectado",
                                                        style: TextStyle(
                                                          fontSize: 18,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          color: Colors.orange,
                                                        ),
                                                      )
                                                      : Text(
                                                        "Desconectado",
                                                        textAlign:
                                                            TextAlign.center,
                                                        style: TextStyle(
                                                          fontSize: 18,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          color: Colors.grey,
                                                        ),
                                                      ),
                                            ),
                                          ],
                                        ),
                                        label: "",
                                      ),
                                      BottomNavigationBarItem(
                                        icon: Icon(Icons.margin_rounded),
                                        label: "Corridas",
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        SizedBox(height: Platform.isAndroid ? 5 : 0),
                        usuarioService.usuario.motorista != null &&
                                usuarioService.usuario.motorista['logado'] ==
                                    "CONECTADO"
                            ? ElevatedButton(
                              onPressed: () {
                                showModalDesconectar();
                              },
                              child: Padding(
                                padding: EdgeInsets.all(10),
                                child: Text(
                                  "Desconectar",
                                  style: TextStyle(
                                    fontSize: 20,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                              style: ButtonStyle(
                                backgroundColor: MaterialStateProperty.all(
                                  Colors.red,
                                ),
                                shape: MaterialStateProperty.all<
                                  RoundedRectangleBorder
                                >(
                                  RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(50.0),
                                    side: BorderSide(color: Colors.red),
                                  ),
                                ),
                              ),
                            )
                            : ElevatedButton(
                              onPressed: () {
                                showModalConectar();
                              },
                              child: Padding(
                                padding: EdgeInsets.all(10),
                                child: Text(
                                  "Conectar-se",
                                  style: TextStyle(
                                    fontSize: 20,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                              style: ButtonStyle(
                                backgroundColor: MaterialStateProperty.all(
                                  Colors.orange,
                                ),
                                shape: MaterialStateProperty.all<
                                  RoundedRectangleBorder
                                >(
                                  RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(50.0),
                                    side: BorderSide(color: AppColors.buttonBorderSecondary),
                                  ),
                                ),
                              ),
                            ),
                      ],
                    ),
                  );
                }, childCount: 1),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget buildDragHandle() => Center(
    child: Container(
      margin: EdgeInsets.only(top: 10, bottom: 5),
      width: 40,
      height: 4,
      decoration: BoxDecoration(
        color: Colors.grey[300],
        borderRadius: BorderRadius.circular(12),
      ),
    ),
  );

  onTabTapped(int index) {
    setState(() {
      _indiceAtual = index;
    });
  }

  // Método para mostrar alerta de localização desligada
  void _showModalAlertLocalizacao() {
    String mensagem = Platform.isIOS 
        ? 'O serviço de localização está desligado. Para se conectar, ative a localização nas configurações do seu dispositivo:\n\n1. Configurações\n2. Privacidade e Segurança\n3. Serviços de Localização\n4. Ative para este app'
        : 'O serviço de localização está desligado. Para se conectar, ative a localização nas configurações do seu dispositivo.';

    showDialog<String>(
      context: context,
      builder:
          (BuildContext context) => AlertDialog(
            title: Text('Localização Desligada', textAlign: TextAlign.center),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.location_off, color: Colors.red, size: 50),
                SizedBox(height: 10),
                Text(
                  mensagem,
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.black),
                ),
              ],
            ),
            actions: <Widget>[
              InkWell(
                onTap: () {
                  Navigator.pop(context, "Fechar");
                },
                child: Padding(
                  padding: EdgeInsets.all(15),
                  child: Text(
                    'Fechar',
                    style: TextStyle(color: Colors.grey),
                  ),
                ),
              ),
              InkWell(
                onTap: () {
                  Navigator.pop(context, "Configurações");
                  _abrirConfiguracoesLocalizacao();
                },
                child: Padding(
                  padding: EdgeInsets.all(15),
                  child: Text(
                    'Abrir Configurações',
                    style: TextStyle(color: Colors.orange, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ],
          ),
    );
  }

  // Método para mostrar alerta de erro genérico
  void _showModalAlertError(String message) {
    showDialog<String>(
      context: context,
      builder:
          (BuildContext context) => AlertDialog(
            title: Text('Ops!', textAlign: TextAlign.center),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.error, color: Colors.red, size: 50),
                SizedBox(height: 10),
                Text(
                  message,
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.black),
                ),
              ],
            ),
            actions: <Widget>[
              InkWell(
                onTap: () {
                  Navigator.pop(context, "Fechar");
                },
                child: Padding(
                  padding: EdgeInsets.all(15),
                  child: Text(
                    'Fechar',
                    style: TextStyle(color: Colors.orange),
                  ),
                ),
              ),
            ],
          ),
    );
  }

  // Método para mostrar alerta quando permissão foi negada permanentemente
  void _showModalAlertPermissaoNegada() {
    String mensagem = Platform.isIOS 
        ? 'A permissão de localização foi negada permanentemente. Para ativar:\n\n1. Vá em Configurações\n2. Privacidade e Segurança\n3. Serviços de Localização\n4. Encontre este app\n5. Selecione "Sempre" ou "Ao usar o app"'
        : 'A permissão de localização foi negada permanentemente. Para ativar:\n\n1. Vá em Configurações\n2. Aplicativos\n3. Encontre este app\n4. Permissões\n5. Ative a Localização';

    showDialog<String>(
      context: context,
      builder:
          (BuildContext context) => AlertDialog(
            title: Text('Permissão Negada', textAlign: TextAlign.center),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.location_disabled, color: Colors.red, size: 50),
                SizedBox(height: 10),
                Text(
                  mensagem,
                  textAlign: TextAlign.left,
                  style: TextStyle(color: Colors.black, fontSize: 14),
                ),
              ],
            ),
            actions: <Widget>[
              InkWell(
                onTap: () {
                  Navigator.pop(context, "Fechar");
                },
                child: Padding(
                  padding: EdgeInsets.all(15),
                  child: Text(
                    'Fechar',
                    style: TextStyle(color: Colors.grey),
                  ),
                ),
              ),
              InkWell(
                onTap: () {
                  Navigator.pop(context, "Configurações");
                  _abrirConfiguracoesLocalizacao();
                },
                child: Padding(
                  padding: EdgeInsets.all(15),
                  child: Text(
                    'Abrir Configurações',
                    style: TextStyle(color: Colors.orange, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ],
          ),
    );
  }

  // Método para abrir configurações de localização
  void _abrirConfiguracoesLocalizacao() async {
    try {
      // Para Android
      if (Platform.isAndroid) {
        await Geolocator.openLocationSettings();
        print("✅ NavigationScreen: Configurações de localização abertas (Android)");
      }
      // Para iOS
      else if (Platform.isIOS) {
        // No iOS, abrir configurações gerais do app
        await Geolocator.openAppSettings();
        print("✅ NavigationScreen: Configurações do app abertas (iOS)");
      }
    } catch (e) {
      print("❌ NavigationScreen: Erro ao abrir configurações: $e");
      // Fallback: mostrar modal com instruções específicas para iOS
      if (Platform.isIOS) {
        _showModalAlertError('Para ativar a localização no iOS:\n\n1. Vá em Configurações\n2. Privacidade e Segurança\n3. Serviços de Localização\n4. Ative para este app');
      } else {
        _showModalAlertError('Não foi possível abrir as configurações automaticamente. Acesse manualmente as configurações do seu dispositivo.');
      }
    }
  }
}
