import 'package:aondeir_motorista/styles/app_colors.dart';
import 'dart:async';
import 'dart:io';
import 'package:aondeir_motorista/screens/Permissao/PermissaoBateriaScreen.dart';
import 'package:aondeir_motorista/screens/Permissao/PermissaoGeolocatorScreen.dart';
import 'package:aondeir_motorista/screens/Permissao/PermissaoOverlayScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Home/Corrida/DetalhesCorridaScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Home/Corrida/CorridaDetalheMapaScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/Cadastro/contaBancaria/CadastroContaBancariaScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/Mensagens/ConversasScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/MenuScreen.dart';
import 'package:aondeir_motorista/service/corrida/MotoristaAtualizaLocalizacaoService.dart';
import 'package:aondeir_motorista/service/helper/CheckConexaoService.dart';
import 'package:aondeir_motorista/service/helper/VariavelControleService.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:geolocator/geolocator.dart';

import '../../../service/CorridaService.dart';
import '../../../service/RecargaService.dart';
import '../../../service/SocketService.dart';
import '../../../service/UsuarioService.dart';
import '../../../service/EnderecoService.dart';
import '../../../service/localizacao/LocalizacaoGetPlaceMarkFromCoordinatesService.dart';
import '../../../service/mensagem/PegarMensagensNaoLidaService.dart';
import '../../../service/middleware/CurrentScreenService.dart';
import '../../../service/toque/ToqueService.dart';
import '../../../service/corrida/CorridaBuscarService.dart';

import '../../Modal/RecargaAlertSaldoBaixo.dart';

import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart' as overlay;
import 'package:android_intent_plus/android_intent.dart';

import '../../../service/firebase/FirebaseRealtimeService.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  late TabController _tabController;

  var alert = false;
  var alertMsg = "";
  var idUsuarioLogado = "";
  var alertContaBancaria = false;
  var alertContaBancariaMsg = "Conta bancária não cadastrada";
  bool isLoading = false;
  bool conectarSocketCorrida = true;
  bool alertaNovaCorrida = true;
  bool alertLocalizacaoDesligada = false;
  bool _modalLocalizacaoJaMostrada = false;

  var accuracy = LocationAccuracy.bestForNavigation;
  int distanceFilter = 100;
  StreamSubscription<Position>? _positionStreamSubscription;

  // --- ADDED: Track refused corridas in memory (frontend-only) ---
  Set<int> refusedCorridaIds = {};

  // --- ADDED: Control if corrida search was already executed ---
  bool _hasExecutedCorridaSearch = false;

  // --- ADDED: Execute corrida search once ---
  Future<void> _executarBuscaCorridas() async {
    if (_hasExecutedCorridaSearch) return;
    
    try {
      var corridaBuscarService = Provider.of<CorridaBuscarService>(context, listen: false);
      var usuarioService = Provider.of<UsuarioService>(context, listen: false);
      
      // Verifica se o usuário está logado e conectado
      if (usuarioService.usuario.id != null && 
          usuarioService.usuario.id > 0 && 
          usuarioService.usuario.motorista != null && 
          usuarioService.usuario.motorista['logado'] == "CONECTADO") {
        
        await corridaBuscarService.execute('', '');
        _hasExecutedCorridaSearch = true;
      }
    } catch (e) {
      print("❌ HomeScreen: Erro ao executar busca de corridas: $e");
    }
  }

  // Adicione esta variável
  FirebaseRealtimeService? _firebaseRealtimeService;

  @override
  void initState() {
    super.initState();
    
    // Adicionar observer para detectar mudanças no ciclo de vida do app
    WidgetsBinding.instance.addObserver(this);

    _tabController = TabController(length: 1, vsync: this);

    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      verificarSaldoRecarga();
      await requestPermissions();
      await initializeForegroundTask();
      _startTimer();
      await pegarDadosBancarios();
      await getLocalizacaoAtual();
      
      // Aguarda um pouco para garantir que o usuário foi carregado
      await Future.delayed(Duration(seconds: 2));
      
      // Executa busca de corridas apenas uma vez
      await _executarBuscaCorridas();
      
      // Substitua a chamada do socket() por:
      await initializeFirebaseRealtime();
      await pegarMensagensNaoLida();
      // Verificar conexão com internet
      await verificarConexaoInternet();
      // Verificar status da localização inicialmente
      await verificarStatusLocalizacao();
      // await redirecionarMensagem();
    });
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // Verificar localização apenas se ainda não foi verificada nesta sessão
    // e se o widget está montado
    if (mounted && !_modalLocalizacaoJaMostrada) {
      Future.delayed(Duration(milliseconds: 500), () {
        if (mounted) {
          verificarStatusLocalizacao();
        }
      });
    }
  }

  Timer? _updateTimer;
  Timer? _connectionCheckTimer; // Timer para verificar conexão
  Timer? _locationCheckTimer; // Timer para verificar localização

  void _startTimer() {
    _updateTimer?.cancel(); // Cancela timer anterior se existir
    _updateTimer = Timer.periodic(Duration(seconds: 30), (timer) async {
      if (!mounted) {
        timer.cancel();
        return;
      }
      if (conectarSocketCorrida) {
        await buscarAtualizacoes();
      }
    });

    // Timer para verificar conexão a cada 10 segundos
    _connectionCheckTimer?.cancel();
    _connectionCheckTimer = Timer.periodic(Duration(seconds: 10), (timer) async {
      if (!mounted) {
        timer.cancel();
        return;
      }
      await verificarConexaoInternet();
    });

    // Timer para verificar localização a cada 15 segundos
    _locationCheckTimer?.cancel();
    _locationCheckTimer = Timer.periodic(Duration(seconds: 15), (timer) async {
      if (!mounted) {
        timer.cancel();
        return;
      }
      await verificarStatusLocalizacao();
    });
  }

  // Função para verificar conexão com internet
  Future<void> verificarConexaoInternet() async {
    try {
      var checkConexaoService = Provider.of<CheckConexaoService>(context, listen: false);
      await checkConexaoService.execute();
    } catch (e) {
      print("❌ HomeScreen: Erro ao verificar conexão: $e");
    }
  }

  // Função para verificar status da localização
  Future<void> verificarStatusLocalizacao() async {
    try {
      
      // No iOS, primeiro verificar permissão
      LocationPermission permission = await Geolocator.checkPermission();
      
      bool serviceEnabled = false;
      
      if (Platform.isIOS) {
        // No iOS, verificar se tem permissão primeiro
        if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) {
          serviceEnabled = false;
        } else {
          // Se tem permissão, verificar se o serviço está ativo
          serviceEnabled = await Geolocator.isLocationServiceEnabled();
        }
      } else {
        // Android - verificar serviço diretamente
        serviceEnabled = await Geolocator.isLocationServiceEnabled();
      }
      
      if (mounted) {
        setState(() {
          alertLocalizacaoDesligada = !serviceEnabled;
        });
        
        // Mostrar alerta se localização estiver desligada
        if (!serviceEnabled && !_modalLocalizacaoJaMostrada) {
          print("🔍 HomeScreen: Mostrando modal de localização...");
          _modalLocalizacaoJaMostrada = true;
          showModalAlertLocalizacao();
        }
        
        // Resetar flag quando localização voltar a funcionar
        if (serviceEnabled && _modalLocalizacaoJaMostrada) {
          _modalLocalizacaoJaMostrada = false;
        }
      }

    } catch (e) {
      print("❌ HomeScreen: Erro ao verificar status da localização: $e");
      // Em caso de erro, assumir que está desligada
      if (mounted) {
        setState(() {
          alertLocalizacaoDesligada = true;
        });
      }
    }
  }

  // Função para verificar status da localização SEM resetar a flag
  Future<void> _verificarStatusLocalizacaoSemReset() async {
    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      
      if (mounted) {
        setState(() {
          alertLocalizacaoDesligada = !serviceEnabled;
        });
        
        // Mostrar alerta se a localização estiver desligada
        // (mesmo que a flag já esteja true, mostrar novamente ao voltar do background)
        if (!serviceEnabled) {
          if (!_modalLocalizacaoJaMostrada) {
            _modalLocalizacaoJaMostrada = true;
          }
          // Mostrar modal novamente ao voltar do background se localização ainda estiver desligada
          showModalAlertLocalizacao();
        }
        
        // Resetar flag APENAS quando a localização voltar a funcionar
        if (serviceEnabled && _modalLocalizacaoJaMostrada) {
          _modalLocalizacaoJaMostrada = false;
          print("✅ HomeScreen: Localização ativada, flag resetada");
        }
      }
      
      if (!serviceEnabled) {
        print("⚠️ HomeScreen: Serviço de localização desligado (sem reset)");
      } else {
        print("✅ HomeScreen: Serviço de localização ativo (sem reset)");
      }
    } catch (e) {
      print("❌ HomeScreen: Erro ao verificar status da localização (sem reset): $e");
    }
  }


  // Novo método para inicializar o Firebase Realtime
  Future<void> initializeFirebaseRealtime() async {
    try {
      var usuarioService = Provider.of<UsuarioService>(context, listen: false);
      if (usuarioService.usuario.id != null && usuarioService.usuario.id > 0) {
        _firebaseRealtimeService = FirebaseRealtimeService(context);
        
        _firebaseRealtimeService!.startListeningForNewCorridas(
          usuarioService.usuario.id.toString()
        );
        
        // Inicializar listener para atualizações silenciosas de lista
        _firebaseRealtimeService!.startListeningForAtualizarListaCorridas(
          usuarioService.usuario.id.toString()
        );
      } else {
        
        // Aguarda um pouco e tenta novamente
        await Future.delayed(Duration(seconds: 3));
        
        if (usuarioService.usuario.id != null && usuarioService.usuario.id > 0) {
          _firebaseRealtimeService = FirebaseRealtimeService(context);
          _firebaseRealtimeService!.startListeningForNewCorridas(
            usuarioService.usuario.id.toString()
          );
          
          // Inicializar listener para atualizações silenciosas de lista
          _firebaseRealtimeService!.startListeningForAtualizarListaCorridas(
            usuarioService.usuario.id.toString()
          );
        }
      }
    } catch (e) {
      print("❌ HomeScreen: Erro ao inicializar Firebase Realtime: $e");
      print("🔍 HomeScreen: Stack trace: ${e.toString()}");
    }
  }

  buscarAtualizacoes() async {
    var variavelControleService = Provider.of<VariavelControleService>(
      context,
      listen: false,
    );
    var checkConexaoService = Provider.of<CheckConexaoService>(
      context,
      listen: false,
    );

    await checkConexaoService.execute();
    if (variavelControleService.checkIsLogged == false) {
      return;
    }

    // A lógica de busca de corridas agora é gerenciada pelo FirebaseRealtimeService
    // Você pode manter a busca periódica se necessário
  }
  
  Future<void> openOverlay() async {
    print("🚀 Tentando reabrir o app...");
    if (Platform.isAndroid) {
      // Verifica permissão de sobreposição usando flutter_overlay_window
      bool? hasPermission = await overlay.FlutterOverlayWindow.isPermissionGranted();
      if (hasPermission != true) {
        print("⚠️ Solicitando permissão para sobrepor apps...");
        await overlay.FlutterOverlayWindow.requestPermission();
      }

      // 🔥 NOVA IMPLEMENTAÇÃO: Android Intent direto (compatível com Samsung S23 FE)
      try {
        print("🚀 Tentando abrir app via Android Intent...");
        AndroidIntent intent = AndroidIntent(
          action: 'android.intent.action.MAIN',
          category: 'android.intent.category.LAUNCHER',
          package: 'com.appaondeir.usuario', // Package name do app
          flags: [0x10000000], // FLAG_ACTIVITY_NEW_TASK
        );
        await intent.launch();
        print("✅ App aberto via Android Intent com sucesso!");
        return;
      } catch (e) {
        print("❌ Erro ao abrir via Android Intent: $e");
        print("🔄 Tentando método alternativo...");
      }

      // 🔥 MÉTODO ORIGINAL (comentado para fallback)
      // bool canLaunch = await FlutterForegroundTask.isRunningService;
      // print("🔍 O serviço está rodando? $canLaunch");
      // 
      // if (canLaunch) {
      //   FlutterForegroundTask.launchApp("/");
      //   print("🚀 Abrindo app via Intent...");
      // } else {
      //   print("⚠️ O serviço não está ativo. Tentando iniciar...");
      //   await FlutterForegroundTask.startService(
      //     notificationTitle: 'Serviço Ativo',
      //     notificationText: 'Aguardando evento...',
      //   );
      // }

      // 🔥 FALLBACK: Método original se Android Intent falhar
      bool canLaunch = await FlutterForegroundTask.isRunningService;
      print("🔍 O serviço está rodando? $canLaunch");

      if (canLaunch) {
        FlutterForegroundTask.launchApp("/");
        print("🚀 Abrindo app via FlutterForegroundTask (fallback)...");
      } else {
        print("⚠️ O serviço não está ativo. Tentando iniciar...");
        await FlutterForegroundTask.startService(
          notificationTitle: 'Serviço Ativo',
          notificationText: 'Aguardando evento...',
        );
      }
    }
    print("✅ O app foi reaberto com sucesso!");
  }


  verificarSaldoRecarga() async {
    try {
      var recargaService = Provider.of<RecargaService>(context, listen: false);
      await recargaService.pegarSaldoInvestido();
      if (recargaService.saldo_atual < 1) {
        showModalRecarga();
      }
    } catch (e) {
      throw Exception('Failed to load data pegarSaldoInvestido');
    }
  }

  Future<void> initializeForegroundTask() async {
    FlutterForegroundTask.init(
      androidNotificationOptions: AndroidNotificationOptions(
        channelId: 'foreground_service',
        channelName: 'Foreground Service Notification',
        channelDescription:
            'This notification appears when the foreground service is running.',
        onlyAlertOnce: true,
      ),
      iosNotificationOptions: const IOSNotificationOptions(
        showNotification: false,
        playSound: false,
      ),
      foregroundTaskOptions: ForegroundTaskOptions(
        eventAction: ForegroundTaskEventAction.repeat(15000), // Aumenta para 15 segundos
        autoRunOnBoot: true,
        autoRunOnMyPackageReplaced: true,
        allowWakeLock: true,
        allowWifiLock: true,
      ),
    );

    startForegroundService();
  }

  Future<void> startForegroundService() async {
    // Solicita as permissões necessárias
    if (!(await Permission.location.isGranted)) {
      await Permission.location.request();
    }
    if (!(await Permission.locationAlways.isGranted)) {
      await Permission.locationAlways.request();
    }

    // Verifica novamente após a solicitação
    if (!(await Permission.location.isGranted)) {
      print("❌ Permissão de localização não concedida.");
      return;
    }

    bool isRunning = await FlutterForegroundTask.isRunningService;

    if (!isRunning) {
      print("🚀 Iniciando serviço de foreground...");

      try {
        await FlutterForegroundTask.startService(
          notificationTitle: 'Serviço Ativo',
          notificationText: 'Monitorando eventos...',
        );
      } catch (e) {
        print("❌ Erro ao iniciar serviço: $e");
      }
      
      print("✅ Serviço iniciado com sucesso!");
    } else {
      print("🔄 O serviço já está rodando.");
    }
  }

  Future<void> requestPermissions() async {
    if (!await FlutterForegroundTask.isIgnoringBatteryOptimizations) {
      await FlutterForegroundTask.requestIgnoreBatteryOptimization();
    }

    // Permissão de overlay já foi solicitada no login se necessário
    // Não precisa verificar novamente aqui

    // Solicita permissão de localização
    if (!Platform.isIOS && await Permission.location.isDenied) {
      Navigator.of(
        context,
      ).push(MaterialPageRoute(builder: (_) => PermissaoGeolocatorScreen()));
    }

    // Solicita permissão para ignorar otimizações de bateria
    if (!Platform.isIOS &&
        await Permission.ignoreBatteryOptimizations.isDenied) {
      Navigator.of(
        context,
      ).push(MaterialPageRoute(builder: (_) => PermissaoBateriaScreen()));
    }
  }

  showModalRecarga() async {
    showDialog<String>(
      context: context,
      builder: (BuildContext context) => RecargaAlertSaldoBaixo(),
    );
  }

  // redirecionarMensagem() {
  //   Provider.of<UsuarioService>(context, listen: false);

  //   AndroidInitializationSettings initializationSettingsAndroid =
  //       const AndroidInitializationSettings('launch_background');

  //   var initializationSettings = InitializationSettings(
  //     android: initializationSettingsAndroid,
  //   );
  // }

  socket() async {
    try {
      var socketService = Provider.of<SocketService>(context, listen: false);
      var usuarioService = Provider.of<UsuarioService>(context, listen: false);
      Provider.of<CorridaService>(context, listen: false);
      socketService.socket?.on(
        "enviarMensagemChatUsuario" + usuarioService.usuario.id.toString(),
        (data) async => {pegarMensagensNaoLida()},
      );
    } catch (e) {
      throw e;
    }
  }

  void cancelarCorridaPendente(idCorrida, BuildContext context) async {
    try {
      final corridaService = Provider.of<CorridaService>(
        context,
        listen: false,
      );
      await corridaService.cancelarCorridaPendente(idCorrida);
    } catch (e) {
      throw Exception('Failed to load data');
    }
  }

  showLoader(texto) {
    if (isLoading == true) {
      showDialog<String>(
        barrierDismissible: false,
        context: context,
        builder:
            (BuildContext context) => AlertDialog(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(12.0)),
              ),
              title: Container(
                child: Text(
                  texto,
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 13, color: Colors.grey[700]),
                ),
              ),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 16),
                  Text('Carregando...'),
                ],
              ),
            ),
      );
    }
  }

  Future<void> aceitarCorrida(idCorrida, BuildContext context) async {
    try {
      // Check if widget is still mounted before accessing context
      if (!mounted) {
        print('⚠️ HomeScreen - Widget not mounted, skipping aceitarCorrida');
        Navigator.of(context).pop();
        return;
      }

      final corridaService = Provider.of<CorridaService>(
        context,
        listen: false,
      );
      final toqueService = Provider.of<ToqueService>(context, listen: false);
      var currentScreenService = Provider.of<CurrentScreenService>(
        context,
        listen: false,
      );
      setState(() {
        isLoading = true;
      });

      await showLoader("Aceitando corrida...");
      await Future.delayed(Duration(seconds: 1));

      var resp = await corridaService.aceitarCorrida(idCorrida);

      if (resp == true) {
        Navigator.of(context).pop();
        corridaService.corridas.clear();

        if (corridaService.corridasPendentes.isNotEmpty) {
          corridaService.corridasPendentes.clear();
        }

        await corridaService.save();

        // Check if widget is still mounted before calling setState
        if (mounted) {
          setState(() {
            alert = false;
          });
        }
        
        await corridaService.pegarCorridaAndamento();
        currentScreenService.setCurrentScreen("DetalhesCorridaScreen");
        
        // Check if widget is still mounted before calling setState
        if (mounted) {
          setState(() {
            isLoading = false;
          });
        }

        var usuarioService = Provider.of<UsuarioService>(
          context,
          listen: false,
        );
        usuarioService.usuario.motorista['situacao'] = 'OCUPADO';
        await usuarioService.save();

        toqueService.execute('toques/toque_motorista_corrida_aceita.mp3');
   
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => DetalhesCorridaScreen()),
        );
      }
    } catch (e) {
      if (e is HttpException) {
        // Check if widget is still mounted before calling setState
        if (mounted) {
          setState(() {
            isLoading = false;
          });
        }
        Navigator.of(context).pop();
        print('🏆🏆Passageiro cancelou a viagem');
        print(e);
        print('🏆🏆Passageiro cancelou a viagem');

        showModalAlertError('Passageiro cancelou a viagem, clique em "recusar" para fechar a tela !');
      } else {
        // Check if widget is still mounted before calling setState
        if (mounted) {
          setState(() {
            isLoading = false;
          });
        }
        Navigator.of(context).pop();
        showModalAlertError(
          'Passageiro cancelou a viagem, clique em "recusar" para fechar a tela!',
        );
      }
    }
  }

  showModalAlertError(String message) async {
    // Check if widget is still mounted before showing dialog
    if (!mounted) {
      print('⚠️ HomeScreen - Widget not mounted, skipping showModalAlertError');
      return;
    }

    showDialog<String>(
      context: context,
      builder:
          (BuildContext context) => MediaQuery(
            data: MediaQuery.of(
              context,
            ).copyWith(textScaler: TextScaler.linear(1.0)),
            child: AlertDialog(
              title: Text('Ops!', textAlign: TextAlign.center),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.error, color: Colors.red, size: 50),
                  SizedBox(height: 10),
                  Text(
                    message,
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.black),
                  ),
                ],
              ),
              actions: <Widget>[
                InkWell(
                  onTap: () {
                    Navigator.pop(context, "Fechar");
                  },
                  child: Padding(
                    padding: EdgeInsets.only(bottom: 10, left: 15, right: 15),
                    child: Text(
                      'Fechar',
                      style: TextStyle(color: Colors.orange),
                    ),
                  ),
                ),
              ],
            ),
          ),
    );
  }

  // Método específico para mostrar alerta de localização com botão de configurações
  void showModalAlertLocalizacao() async {
    // Check if widget is still mounted before showing dialog
    if (!mounted) {
      print('⚠️ HomeScreen - Widget not mounted, skipping showModalAlertLocalizacao');
      return;
    }

    print("🔍 HomeScreen: Exibindo modal de localização...");
    
    showDialog<String>(
      context: context,
      builder:
          (BuildContext context) => MediaQuery(
            data: MediaQuery.of(
              context,
            ).copyWith(textScaler: TextScaler.linear(1.0)),
            child: AlertDialog(
              title: Text('Localização Desligada', textAlign: TextAlign.center),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.location_off, color: Colors.red, size: 50),
                  SizedBox(height: 10),
                  Text(
                    'O serviço de localização está desligado. Para continuar recebendo corridas, ative a localização nas configurações do seu dispositivo.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.black),
                  ),
                ],
              ),
              actions: <Widget>[
                InkWell(
                  onTap: () {
                    Navigator.pop(context, "Fechar");
                  },
                  child: Padding(
                    padding: EdgeInsets.only(bottom: 10, left: 15, right: 15),
                    child: Text(
                      'Fechar',
                      style: TextStyle(color: Colors.grey),
                    ),
                  ),
                ),
                InkWell(
                  onTap: () {
                    Navigator.pop(context, "Configurações");
                    _abrirConfiguracoesLocalizacao();
                  },
                  child: Padding(
                    padding: EdgeInsets.only(bottom: 10, left: 15, right: 15),
                    child: Text(
                      'Abrir Configurações',
                      style: TextStyle(color: Colors.orange, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
              ],
            ),
          ),
    );
  }

  // Método para abrir configurações de localização
  void _abrirConfiguracoesLocalizacao() async {
    try {
      print("🔍 HomeScreen: Tentando abrir configurações...");
      
      // Para Android
      if (Platform.isAndroid) {
        await Geolocator.openLocationSettings();
        print("✅ HomeScreen: Configurações de localização abertas (Android)");
      }
      // Para iOS
      else if (Platform.isIOS) {
        // No iOS, tentar abrir configurações gerais do app primeiro
        await Geolocator.openAppSettings();
        print("✅ HomeScreen: Configurações do app abertas (iOS)");
      }
    } catch (e) {
      print("❌ HomeScreen: Erro ao abrir configurações: $e");
      
      // Fallback específico para iOS
      if (Platform.isIOS) {
        showModalAlertError('Para ativar a localização no iOS:\n\n1. Vá em Configurações\n2. Privacidade e Segurança\n3. Serviços de Localização\n4. Encontre este app\n5. Selecione "Sempre" ou "Ao usar o app"\n\nOu acesse: Configurações > Privacidade e Segurança > Serviços de Localização');
      } else {
        showModalAlertError('Não foi possível abrir as configurações automaticamente. Acesse manualmente as configurações do seu dispositivo.');
      }
    }
  }

  pegarDadosBancarios() async {
    try {
      // Check if widget is still mounted before accessing context
      if (!mounted) {
        print('⚠️ HomeScreen - Widget not mounted, skipping pegarDadosBancarios');
        return;
      }

      final usuarioService = Provider.of<UsuarioService>(
        context,
        listen: false,
      );

      await usuarioService.pegarDadosBancarios();

      if (usuarioService.usuario.dados_bancarios == null) {
        // Check if widget is still mounted before calling setState
        if (mounted) {
          setState(() {
            alertContaBancaria = false;
            alertContaBancariaMsg = "Conta bancária não cadastrada!";
          });
        }
      }
    } catch (e) {}
  }

  pegarMensagensNaoLida() async {
    // Check if widget is still mounted before accessing context
    if (!mounted) {
      print('⚠️ HomeScreen - Widget not mounted, skipping pegarMensagensNaoLida');
      return;
    }

    var pegarMensagensNaoLidaService =
        Provider.of<PegarMensagensNaoLidaService>(context, listen: false);

    await pegarMensagensNaoLidaService.execute();
  }

  Future<void> recusarCorridaDisponivel(corridaId, BuildContext detailsContext) async {
    try {
      // Check if widget is still mounted before accessing context
      if (!mounted) {
        print('⚠️ HomeScreen - Widget not mounted, skipping recusarCorridaDisponivel');
        Navigator.of(detailsContext).pop();
        return;
      }

      final corridaService = Provider.of<CorridaService>(context, listen: false);
      // Remove backend API call and loading state
      final parsedId = int.tryParse(corridaId.toString());
      if (parsedId != null) {
        setState(() {
          refusedCorridaIds.add(parsedId);
        });
        await corridaService.removerCorridaListaById(corridaId);
        await corridaService.save();
      }
      Navigator.of(detailsContext).pop();
    } catch (e) {
      Navigator.of(detailsContext).pop();
      _showModalAlertErrorWithContext(
        "Ops! Ocorreu um erro ao recusar a corrida. tente novamente mais tarde!",
        detailsContext,
      );
    }
  }



  // Helper method to show modal alert error with specific context
  _showModalAlertErrorWithContext(String message, BuildContext context) {
    showDialog<String>(
      context: context,
      builder:
          (BuildContext context) => MediaQuery(
            data: MediaQuery.of(
              context,
            ).copyWith(textScaler: TextScaler.linear(1.0)),
            child: AlertDialog(
              title: Text('Ops!', textAlign: TextAlign.center),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.error, color: Colors.red, size: 50),
                  SizedBox(height: 10),
                  Text(
                    message,
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.black),
                  ),
                ],
              ),
              actions: <Widget>[
                InkWell(
                  onTap: () {
                    Navigator.pop(context, "Fechar");
                  },
                  child: Padding(
                    padding: EdgeInsets.only(bottom: 10, left: 15, right: 15),
                    child: Text(
                      'Fechar',
                      style: TextStyle(color: Colors.orange),
                    ),
                  ),
                ),
              ],
            ),
          ),
    );
  }

  String getGreeting() {
    DateTime now = DateTime.now();
    int hour = now.hour;

    if (hour >= 6 && hour < 12) {
      return 'Bom dia';
    } else if (hour >= 12 && hour < 18) {
      return 'Boa tarde';
    } else {
      return 'Boa noite';
    }
  }

  Future<Position> _getCurrentLocation() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      return Future.error("Location services are disabled.");
    }

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return Future.error("Location permission are denied.");
      }
    }

    if (permission == LocationPermission.deniedForever) {
      return Future.error("Location Permission are permetly......");
    }

    return await Geolocator.getCurrentPosition();
  }

  Future _getAddreesToCoordinateCidade(
    latitude,
    longitude,
    usuarioMtoristaId,
  ) async {
    // Check if widget is still mounted before accessing context
    if (!mounted) {
      print('⚠️ HomeScreen - Widget not mounted, skipping _getAddreesToCoordinateCidade');
      return;
    }

    var enderecoService = Provider.of<EnderecoService>(context, listen: false);
    var socketService = Provider.of<SocketService>(this.context, listen: false);
    var localizacaoGetPlaceMarkFromCoordinatesService =
        Provider.of<LocalizacaoGetPlaceMarkFromCoordinatesService>(
          context,
          listen: false,
        );

    var endereco = await localizacaoGetPlaceMarkFromCoordinatesService.execute(
      latitude,
      longitude,
    );

    enderecoService.enderecoAtualCompletoTexto = endereco['enderecoCompleto'];
    enderecoService.enderecoAtualNumeroTexto = endereco['numero'];
    enderecoService.cidadeAtual = endereco['cidade'];
    
    // ⚡ MIGRAÇÃO: Usar Firebase Realtime Database em vez de WebSocket
    try {
      var firebaseService = Provider.of<FirebaseRealtimeService>(context, listen: false);
      await firebaseService.enviarCoordenadasFirebase(
        latitude.toString(),
        longitude.toString(),
        usuarioMtoristaId,
      );
    } catch (error) {
      print('❌ [HomeScreen] Erro ao enviar coordenadas via Firebase: $error');
      // Fallback para WebSocket em caso de erro
      socketService.socket?.emit("cordenadas", {
        "latitude": latitude.toString(),
        "longitude": longitude.toString(),
        "usuarioId": usuarioMtoristaId,
      });
    }
    
    await enderecoService.save();
  }

  getLocalizacaoAtual() async {
    var enderecoService = Provider.of<EnderecoService>(context, listen: false);
    var usuarioService = Provider.of<UsuarioService>(context, listen: false);
    var localizacaoGetPlaceMarkFromCoordinatesService =
        Provider.of<LocalizacaoGetPlaceMarkFromCoordinatesService>(
          context,
          listen: false,
        );

    var cordenadas = await _getCurrentLocation();
    enderecoService.enderecoAtual.latitude = cordenadas.latitude;
    enderecoService.enderecoAtual.longitude = cordenadas.longitude;

    var endereco = await localizacaoGetPlaceMarkFromCoordinatesService.execute(
      cordenadas.latitude,
      cordenadas.longitude,
    );

    enderecoService.enderecoPartida.latitude = cordenadas.latitude;
    enderecoService.enderecoPartida.longitude = cordenadas.longitude;
    enderecoService.enderecoPartida.texto = endereco['enderecoCompleto'];

    await enderecoService.save();

    await _getAddreesToCoordinateCidade(
      cordenadas.latitude,
      cordenadas.longitude,
      usuarioService.usuario.id,
    );
    _toggleListening();
  }

  Future<void> _toggleListening() async {
    var usuarioService = Provider.of<UsuarioService>(context, listen: false);
    var motoristaAtualizaLocalizacaoService =
        Provider.of<MotoristaAtualizaLocalizacaoService>(
          context,
          listen: false,
        );
    var locationSettings;

    if (!Platform.isIOS) {
      locationSettings = await AndroidSettings(
        accuracy: this.accuracy,
        distanceFilter: this.distanceFilter,
        foregroundNotificationConfig: const ForegroundNotificationConfig(
          notificationText:
              "O aplicativo continuará recebendo sua localização mesmo quando você estiver com ele em segundo plano",
          notificationTitle: "Executando em segundo plano",
          enableWakeLock: true,
        ),
      );
    } else if (Platform.isIOS) {
      locationSettings = await AppleSettings(
        accuracy: this.accuracy,
        // accuracy: LocationAccuracy.low,
        activityType: ActivityType.fitness,
        distanceFilter: this.distanceFilter,
        pauseLocationUpdatesAutomatically: true,
        showBackgroundLocationIndicator: false,
      );
    } else {
      locationSettings = await LocationSettings(
        accuracy: this.accuracy,
        // accuracy: LocationAccuracy.low,
        distanceFilter: this.distanceFilter,
      );
    }

    final positionStream = await Geolocator.getPositionStream(
      locationSettings: locationSettings,
    );

    _positionStreamSubscription = positionStream
        .handleError((error) {
          _positionStreamSubscription?.cancel();
          _positionStreamSubscription = null;
        })
        .listen((Position position) async {
          // Check if widget is still mounted before processing location updates
          if (!mounted) {
            print('⚠️ HomeScreen - Widget not mounted, skipping location update');
            return;
          }
          
          motoristaAtualizaLocalizacaoService.execute(
            usuarioService.usuario.id,
            position,
          );
          await _getAddreesToCoordinateCidade(
            position.latitude,
            position.longitude,
            usuarioService.usuario.id,
          );
        });
  }

  @override
  void dispose() {
    // Cancel the location stream subscription to prevent context errors
    _updateTimer?.cancel();
    _connectionCheckTimer?.cancel(); // Cancelar o novo timer
    _locationCheckTimer?.cancel(); // Cancelar o timer de verificação de localização
    _positionStreamSubscription?.cancel();
    _positionStreamSubscription = null;
    _tabController.dispose();
    
    // Remover observer
    WidgetsBinding.instance.removeObserver(this);
    
    // Para o listener do Firebase Realtime
    try {
      _firebaseRealtimeService?.stopListening();
    } catch (e) {
      print("❌ HomeScreen: Erro ao parar Firebase listener no dispose: $e");
    }
    
    super.dispose();
  }

  // Método para detectar mudanças no ciclo de vida do app
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    
    if (state == AppLifecycleState.resumed && mounted) {
      // Quando o app voltar ao foco, verificar localização com delay
      // Mas NÃO resetar a flag automaticamente
      print("🔄 HomeScreen: App voltou ao foco, verificando localização...");
      Future.delayed(Duration(milliseconds: 1000), () {
        if (mounted) {
          // Verificar status sem resetar flag automaticamente
          _verificarStatusLocalizacaoSemReset();
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    var corridaService = Provider.of<CorridaService>(context);
    var usuarioService = Provider.of<UsuarioService>(context);
    var pegarMensagensNaoLidaService =
        Provider.of<PegarMensagensNaoLidaService>(this.context, listen: true);
    var enderecoService = Provider.of<EnderecoService>(context, listen: true);
    var recargaService = Provider.of<RecargaService>(context, listen: false);
    var checkConexaoService = Provider.of<CheckConexaoService>(context, listen: false);

    var qtd = corridaService.corridas.length.toString();
    corridaService.corridasPendentes.length.toString();

    setState(() {
      idUsuarioLogado = usuarioService.usuario.id.toString();
    });

    // --- AUTO-SHOW NEXT CORRIDA LOGIC ---
    // (Removed: No longer auto-show CorridaDetalheMapaScreen here)

    // Render the list of corrida cards, each tappable to open CorridaDetalheMapaScreen
    var filteredCorridas = corridaService.corridas
        .where((corrida) => !refusedCorridaIds.contains(corrida.id))
        .toList();

    return MediaQuery(
      data: MediaQuery.of(context).copyWith(textScaler: TextScaler.linear(1.0)),
      child: MaterialApp(
        home: Scaffold(
          appBar: AppBar(
            backgroundColor: Color.fromARGB(255, 49, 49, 49),
            leading: IconButton(
              icon: Icon(Icons.list, color: Colors.white, size: 30),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => MenuScreen()),
                );
              },
            ),
            title: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.directions_car, size: 30, color: Colors.white),
              ],
            ),
            centerTitle: true,
            actions: [
              Stack(
                children: [
                  IconButton(
                    icon: Icon(
                      Icons.notifications,
                      size: 30,
                      color: Colors.white,
                    ),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => ConversasScreen()),
                      );
                    },
                  ),
                  if (pegarMensagensNaoLidaService.qtdMensagemNaoLida > 0)
                    Positioned(
                      right: 8,
                      top: 8,
                      child: Container(
                        padding: EdgeInsets.all(4),
                        decoration: BoxDecoration(
                          color: Colors.red,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          pegarMensagensNaoLidaService.qtdMensagemNaoLida > 0
                              ? pegarMensagensNaoLidaService.qtdMensagemNaoLida
                                  .toString()
                              : "0",
                          style: TextStyle(color: Colors.white, fontSize: 12),
                        ),
                      ),
                    ),
                ],
              ),
            ],
            bottom: TabBar(
              labelColor: Colors.white,
              indicatorColor: Colors.orange,
              controller: _tabController,
              tabs: [Tab(text: "Disp. (" + qtd + ")")],
            ),
          ),
          body: WillPopScope(
            onWillPop: () async {
              return false;
            },
            child: TabBarView(
              controller: _tabController,
              physics: NeverScrollableScrollPhysics(),
              children: <Widget>[
                Stack(
                  children: [
                    Column(
                      children: [
                        Expanded(
                          child: SingleChildScrollView(
                            child: Container(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  if (recargaService.saldo_atual < 1)
                                    Column(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: <Widget>[
                                        Container(
                                          width: double.infinity,
                                          margin: EdgeInsets.only(left: 20, right: 20, top: 20),
                                          decoration: BoxDecoration(
                                            border: Border.all(
                                              color: const Color.fromARGB(150, 255, 153, 0),
                                              width: 1,
                                            ),
                                            borderRadius: BorderRadius.circular(7),
                                            color: const Color.fromARGB(150, 255, 153, 0),
                                          ),
                                          child: Padding(
                                            padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                                            child: Text(
                                              "Você está sem saldo, faça uma recarga para continuar recebendo corridas!",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Colors.black54),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  if (usuarioService.usuario.motorista != null && usuarioService.usuario.motorista['logado'] != "CONECTADO")
                                    Column(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: <Widget>[
                                        Container(
                                          width: double.infinity,
                                          margin: EdgeInsets.only(left: 20, right: 20, top: 20),
                                          decoration: BoxDecoration(
                                            border: Border.all(
                                              color: const Color.fromARGB(150, 255, 153, 0),
                                              width: 1,
                                            ),
                                            borderRadius: BorderRadius.circular(7),
                                            color: const Color.fromARGB(150, 255, 153, 0),
                                          ),
                                          child: Padding(
                                            padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                                            child: Text(
                                              "Você está desconectado, conecte-se para receber corridas",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Colors.black54),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  // Alerta de sem internet
                                  if (checkConexaoService.connectionStatus == false)
                                    Column(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: <Widget>[
                                        Container(
                                          width: double.infinity,
                                          margin: EdgeInsets.only(left: 20, right: 20, top: 20),
                                          decoration: BoxDecoration(
                                            border: Border.all(
                                              color: const Color.fromARGB(150, 244, 67, 54), // Vermelho para indicar erro
                                              width: 1,
                                            ),
                                            borderRadius: BorderRadius.circular(7),
                                            color: const Color.fromARGB(150, 244, 67, 54),
                                          ),
                                          child: Padding(
                                            padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                                            child: Text(
                                              "Você está sem conexão com a internet, confira seus dados móveis ou wifi para continuar recebendo viagens!",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Colors.white),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  // Alerta de localização desligada
                                  if (alertLocalizacaoDesligada)
                                    Column(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: <Widget>[
                                        Container(
                                          width: double.infinity,
                                          margin: EdgeInsets.only(left: 20, right: 20, top: 20),
                                          decoration: BoxDecoration(
                                            border: Border.all(
                                              color: const Color.fromARGB(150, 244, 67, 54), // Vermelho para indicar erro
                                              width: 1,
                                            ),
                                            borderRadius: BorderRadius.circular(7),
                                            color: const Color.fromARGB(150, 244, 67, 54),
                                          ),
                                          child: Padding(
                                            padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                                            child: Text(
                                              "O serviço de localização está desligado. Ative a localização nas configurações do seu dispositivo para continuar recebendo corridas!",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Colors.white),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  Container(
                                    child: Column(
                                      children: <Widget>[
                                        Container(
                                          padding: EdgeInsets.symmetric(horizontal: 15),
                                          child: Text.rich(
                                            TextSpan(
                                              text: getGreeting() + ", ",
                                              style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
                                              children: <TextSpan>[
                                                TextSpan(
                                                  text: usuarioService.usuario.name,
                                                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.black),
                                                ),
                                              ],
                                            ),
                                            textAlign: TextAlign.start,
                                          ),
                                        ),
                                        Container(
                                          padding: EdgeInsets.symmetric(horizontal: 15),
                                          child: Text(
                                            "Você esta em " +
                                                enderecoService.cidadeAtual +
                                                ", " +
                                                enderecoService.enderecoAtualCompletoTexto.split(',')[0].trim() +
                                                " nº" +
                                                enderecoService.enderecoAtualNumeroTexto +
                                                " ...",
                                            textAlign: TextAlign.start,
                                            style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  alert == true
                                      ? InkWell(
                                          onTap: () {
                                            setState(() {
                                              alert = false;
                                              alertMsg = "";
                                            });
                                          },
                                          child: Container(
                                            margin: EdgeInsets.all(15),
                                            padding: EdgeInsets.all(15),
                                            width: double.infinity,
                                            decoration: BoxDecoration(
                                              border: Border.all(color: Colors.orange, width: 1),
                                              borderRadius: BorderRadius.circular(12),
                                              color: Colors.white,
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Colors.grey.withOpacity(0.5),
                                                  spreadRadius: 2,
                                                  blurRadius: 10,
                                                  offset: Offset(0, 3),
                                                ),
                                              ],
                                            ),
                                            child: Column(
                                              children: <Widget>[
                                                Row(
                                                  children: <Widget>[
                                                    Container(
                                                      width: 274,
                                                      child: Text(
                                                        alertMsg,
                                                        style: TextStyle(color: Colors.orange, fontWeight: FontWeight.bold, fontSize: 16),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ],
                                            ),
                                          ),
                                        )
                                      : SizedBox(),
                                  alertContaBancaria == true
                                      ? InkWell(
                                          onTap: () {
                                            Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                builder: (_) => CadastroContaBancariaScreen(),
                                              ),
                                            );
                                          },
                                          child: Container(
                                            margin: EdgeInsets.all(15),
                                            padding: EdgeInsets.all(15),
                                            width: double.infinity,
                                            decoration: BoxDecoration(
                                              border: Border.all(color: Colors.orange, width: 1),
                                              borderRadius: BorderRadius.circular(12),
                                              color: Colors.white,
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Colors.grey.withOpacity(0.5),
                                                  spreadRadius: 2,
                                                  blurRadius: 10,
                                                  offset: Offset(0, 3),
                                                ),
                                              ],
                                            ),
                                            child: Column(
                                              children: <Widget>[
                                                Row(
                                                  children: <Widget>[
                                                    Container(
                                                      width: 274,
                                                      child: Text(
                                                        alertContaBancariaMsg,
                                                        style: TextStyle(color: Colors.orange, fontWeight: FontWeight.bold, fontSize: 16),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ],
                                            ),
                                          ),
                                        )
                                      : SizedBox(),
                                  for (var corrida in filteredCorridas)
                                    InkWell(
                                      child: Container(
                                        margin: EdgeInsets.all(15),
                                        padding: EdgeInsets.all(15),
                                        width: double.infinity,
                                        decoration: BoxDecoration(
                                          border: Border.all(
                                            color: corrida.status['id'] == 8 ? const Color.fromRGBO(244, 67, 54, 1) : Colors.orange,
                                            width: 1,
                                          ),
                                          borderRadius: BorderRadius.circular(12),
                                          color: corrida.status['id'] == 8 ? Color.fromARGB(148, 255, 17, 0) : Colors.white,
                                          boxShadow: [
                                            BoxShadow(
                                              color: Colors.grey.withOpacity(0.5),
                                              spreadRadius: 2,
                                              blurRadius: 10,
                                              offset: Offset(0, 3),
                                            ),
                                          ],
                                        ),
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: <Widget>[
                                            // Address
                                            Text(
                                              corrida.endereco_partida ?? '',
                                              style: TextStyle(color: Colors.grey[800], fontWeight: FontWeight.bold, fontSize: 16),
                                            ),
                                            SizedBox(height: 4), // reduced spacing
                                            // Payment and Category
                                            Row(
                                              children: <Widget>[
                                                Icon(
                                                  Icons.attach_money,
                                                  color: corrida.status['id'] == 8 ? Colors.red : Colors.orange,
                                                  size: 18,
                                                ),
                                                SizedBox(width: 4),
                                                Text(
                                                  corrida.metodo_pagamento ?? '',
                                                  style: TextStyle(color: Colors.grey[800], fontWeight: FontWeight.w500),
                                                ),
                                                SizedBox(width: 10),
                                              ],
                                            ),
                                            // SizedBox(height: 4), // reduced spacing
                                            // Row(
                                            //   children: <Widget>[
                                            //     Icon(
                                            //       Icons.directions_car,
                                            //       color: corrida.status['id'] == 8 ? Colors.red : Colors.orange,
                                            //       size: 18,
                                            //     ),
                                            //     SizedBox(width: 4),
                                            //     Text(
                                            //       corrida.categoria['name'] ?? '',
                                            //       style: TextStyle(color: Colors.grey[800], fontWeight: FontWeight.w500),
                                            //     ),
                                            //   ],
                                            // ),
                                            SizedBox(height: 4), // reduced spacing
                                            // Passenger name and total
                                            Row(
                                              children: <Widget>[
                                                Icon(
                                                  Icons.person,
                                                  color: Colors.orange,
                                                  size: 18,
                                                ),
                                                SizedBox(width: 4),
                                                Expanded(
                                                  child: Text(
                                                    corrida.nome ?? '',
                                                    style: TextStyle(color: Colors.grey[800], fontWeight: FontWeight.w500),
                                                    overflow: TextOverflow.ellipsis,
                                                  ),
                                                ),
                                              ],
                                            ),
                                            SizedBox(height: 2), // reduced spacing
                                            Row(
                                              children: <Widget>[
                                                Icon(
                                                  Icons.edit,
                                                  color: Colors.transparent, // hidden, just for spacing
                                                  size: 0,
                                                ),
                                                SizedBox(width: 0),
                                                Text(
                                                  "Total: ",
                                                  style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 24),
                                                ),
                                                Text(
                                                  "R\$" + ((double.parse(corrida.valor_corrida ?? '0') + double.parse(corrida.chamadaTarifaValorBase['valor_pedagio'] ?? '0')).toStringAsFixed(2)),
                                                  style: TextStyle(color: Colors.grey[800], fontWeight: FontWeight.bold, fontSize: 24),
                                                ),
                                                if (double.parse(corrida.chamadaTarifaValorBase['valor_pedagio'] ?? '0') > 0) ...[
                                                  SizedBox(width: 6),
                                                  Text(
                                                    "Pedágio incluso: R\$" + (corrida.chamadaTarifaValorBase['valor_pedagio'] ?? '0.00'),
                                                    style: TextStyle(color: Color.fromARGB(255, 249, 14, 14), fontWeight: FontWeight.w500, fontSize: 14),
                                                  ),
                                                ],
                                              ],
                                            ),
                                            SizedBox(height: 4), // reduced spacing
                                            // Add distance and time row above the button
                                            if (corrida.distancia_viagem_metros != null || corrida.tempo_estimado_segundos != null)
                                              Row(
                                                children: [
                                                  if (corrida.distancia_viagem_metros != null) ...[
                                                    // Icon(Icons.place, color: Colors.orange, size: 18),
                                                    SizedBox(width: 4),
                                                    Text(
                                                      "${(corrida.distancia_viagem_metros! / 1000).toStringAsFixed(1)} ",
                                                      style: TextStyle(color: Colors.orange, fontWeight: FontWeight.bold, fontSize: 24),
                                                    ),
                                                    Text(
                                                      "km",
                                                      style: TextStyle(color: Colors.orange, fontWeight: FontWeight.w500, fontSize: 14),
                                                    ),
                                                    SizedBox(width: 8),
                                                  ],
                                                  if (corrida.tempo_estimado_segundos != null) ...[
                                                    // Icon(Icons.access_time, color: Colors.orange, size: 18),
                                                    SizedBox(width: 4),
                                                    Text(
                                                      "${(corrida.tempo_estimado_segundos! / 60).toStringAsFixed(0)} ",
                                                      style: TextStyle(color: Colors.orange, fontWeight: FontWeight.bold, fontSize: 24),
                                                    ),
                                                    Text(
                                                      "min",
                                                      style: TextStyle(color: Colors.orange, fontWeight: FontWeight.w500, fontSize: 14),
                                                    ),
                                                  ],
                                                ],
                                              ),
                                            SizedBox(height: 4), // reduced spacing
                                            // Button now left-aligned and always says 'Aceitar Corrida'
                                            Row(
                                              children: [
                                                AbsorbPointer(
                                                  absorbing: true,
                                                  child: ElevatedButton(
                                                    onPressed: () {}, // Not null, so uses your color, but not clickable
                                                    style: ElevatedButton.styleFrom(
                                                      backgroundColor: AppColors.buttonSecondary, // app theme color
                                                      shape: RoundedRectangleBorder(
                                                        borderRadius: BorderRadius.circular(20),
                                                      ),
                                                      padding: EdgeInsets.symmetric(horizontal: 18, vertical: 8),
                                                      elevation: 0,
                                                    ),
                                                    child: Row(
                                                      children: [
                                                        // Icon(Icons.directions_car, color: Colors.white, size: 18),
                                                        SizedBox(width: 5),
                                                        Text(
                                                          'Analisar Ofertar',
                                                          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                            SizedBox(height: 6),
                                            Text(
                                              'Visualize a viagem antes de aceitar',
                                              style: TextStyle(color: Colors.grey[600], fontSize: 15, fontStyle: FontStyle.italic),
                                            ),
                                          ],
                                        ),
                                      ),
                                      onTap: () {
                                        if (corrida.status['id'] == 8) {
                                          showModalAlertError("Ops! Essa corrida foi cancelada..");
                                        } else {
                                          Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                              builder: (_) => CorridaDetalheMapaScreen(
                                                corrida: corrida,
                                                onAceitar: (idCorrida) => aceitarCorrida(idCorrida, context),
                                                onRecusar: (idCorrida, detailsContext) => recusarCorridaDisponivel(idCorrida, detailsContext),
                                              ),
                                            ),
                                          );
                                        }
                                      },
                                    ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ], // <-- Close Column's children here
                    ), // <-- Close Column here
                    if (corridaService.corridas.isEmpty && usuarioService.usuario.motorista != null &&
            usuarioService.usuario.motorista['logado'] == "CONECTADO")
                      Positioned(
                        left: 0,
                        right: 0,
                        bottom: 24, // Add space from the bottom
                        child: Container(
                          margin: EdgeInsets.symmetric(horizontal: 16),
                          padding: EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(12),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black12,
                                blurRadius: 4,
                                offset: Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                'Procurando viagens',
                                style: TextStyle(
                                  color: Color(0xFFF9AD1E),
                                  fontWeight: FontWeight.normal,
                                  fontSize: 16,
                                ),
                              ),
                              SizedBox(height: 8),
                              LinearProgressIndicator(
                                backgroundColor: Colors.transparent,
                                valueColor: AlwaysStoppedAnimation<Color>(Color(0xFFF9AD1E)),
                              ),
                            ],
                          ),
                        ),
                      ),
                  ], // <-- Close Stack's children here
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

}
