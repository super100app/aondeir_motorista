import 'dart:async';
import 'dart:io';
import 'dart:math';
import 'dart:convert';
import 'dart:ui' as ui;
import 'dart:typed_data';

import 'package:aondeir_motorista/service/UsuarioService.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:provider/provider.dart';

import '../../../../service/CorridaService.dart';
import '../../../../service/corrida/CorridaBuscarService.dart';
import '../Corrida/CorridaDetalheMapaScreenMapa.dart';
import '../Corrida/DetalhesCorridaScreen.dart';

const String _nightMapStyle = '''[
  {"elementType": "geometry", "stylers": [{"color": "#242f3e"}]},
  {"elementType": "labels.text.stroke", "stylers": [{"color": "#242f3e"}]},
  {"elementType": "labels.text.fill", "stylers": [{"color": "#746855"}]},
  {"featureType": "administrative.locality", "elementType": "labels.text.fill", "stylers": [{"color": "#d59563"}]},
  {"featureType": "poi", "elementType": "labels.text.fill", "stylers": [{"color": "#d59563"}]},
  {"featureType": "poi.park", "elementType": "geometry", "stylers": [{"color": "#263c3f"}]},
  {"featureType": "poi.park", "elementType": "labels.text.fill", "stylers": [{"color": "#6b9a76"}]},
  {"featureType": "road", "elementType": "geometry", "stylers": [{"color": "#38414e"}]},
  {"featureType": "road", "elementType": "geometry.stroke", "stylers": [{"color": "#212a37"}]},
  {"featureType": "road", "elementType": "labels.text.fill", "stylers": [{"color": "#9ca5b3"}]},
  {"featureType": "road.highway", "elementType": "geometry", "stylers": [{"color": "#746855"}]},
  {"featureType": "road.highway", "elementType": "geometry.stroke", "stylers": [{"color": "#1f2835"}]},
  {"featureType": "road.highway", "elementType": "labels.text.fill", "stylers": [{"color": "#f3d19c"}]},
  {"featureType": "transit", "elementType": "geometry", "stylers": [{"color": "#2f3948"}]},
  {"featureType": "transit.station", "elementType": "labels.text.fill", "stylers": [{"color": "#d59563"}]},
  {"featureType": "water", "elementType": "geometry", "stylers": [{"color": "#17263c"}]},
  {"featureType": "water", "elementType": "labels.text.fill", "stylers": [{"color": "#515c6d"}]},
  {"featureType": "water", "elementType": "labels.text.stroke", "stylers": [{"color": "#17263c"}]}
]''';

class MapaScreen extends StatefulWidget {
  final String tipo;
  final String? favorito;

  const MapaScreen({Key? key, required this.tipo, this.favorito}) : super(key: key);

  @override
  _MapaScreenState createState() => _MapaScreenState();
}

class _MapaScreenState extends State<MapaScreen> {
  GoogleMapController? mapController;
  Set<Marker> _markers = {};
  StreamSubscription<Position>? positionStream;
  bool _nightMode = false;
  bool _isDisposed = false;
  final Key _mapKey = UniqueKey(); // Key única para o GoogleMap

  // --- ADDED: Control auto-show of CorridaDetalheMapaScreen ---
  bool _isShowingCorridaDetalhe = false;
  bool _hasShownCorridaThisFrame = false;

  // --- ADDED: Track refused corridas in memory (frontend-only) ---
  Set<int> refusedCorridaIds = {};

  // --- ADDED: Control if corrida search was already executed ---
  bool _hasExecutedCorridaSearch = false;

  // --- ADDED: Execute corrida search once ---
  Future<void> _executarBuscaCorridas() async {
    if (_hasExecutedCorridaSearch) return;
    
    try {
      print("🔍 MapaScreen: Executando busca de corridas...");
      var corridaBuscarService = Provider.of<CorridaBuscarService>(context, listen: false);
      var usuarioService = Provider.of<UsuarioService>(context, listen: false);
      
      // Verifica se o usuário está logado e conectado
      if (usuarioService.usuario.id != null && 
          usuarioService.usuario.id > 0 && 
          usuarioService.usuario.motorista != null && 
          usuarioService.usuario.motorista['logado'] == "CONECTADO") {
        
        await corridaBuscarService.execute('', '');
        _hasExecutedCorridaSearch = true;
        print("✅ MapaScreen: Busca de corridas executada com sucesso!");
      } else {
        print("⚠️ MapaScreen: Usuário não conectado, pulando busca de corridas");
      }
    } catch (e) {
      print("❌ MapaScreen: Erro ao executar busca de corridas: $e");
    }
  }

  // --- ADDED: Auto-show next corrida logic ---
  void _showNextCorridaDetalheIfNeeded() {
    if (!mounted || _isDisposed) return;
    
    try {
      var corridaService = Provider.of<CorridaService>(context, listen: false);
      var filteredCorridas = corridaService.corridas
          .where((corrida) => !refusedCorridaIds.contains(corrida.id))
          .toList();
      
      if (filteredCorridas.isNotEmpty && !_isShowingCorridaDetalhe && !_hasShownCorridaThisFrame && mounted) {
        print('🚀 MapaScreen - Showing CorridaDetalheMapaScreen for corrida: ${filteredCorridas.first.id}');
        
        if (mounted) {
          setState(() {
            _hasShownCorridaThisFrame = true;
            _isShowingCorridaDetalhe = true;
          });
        }
        
        if (mounted) {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => CorridaDetalheMapaScreenMapa(
                corrida: filteredCorridas.first,
              ),
            ),
          ).then((result) {
            if (!mounted || _isDisposed) return;
            
            if (result == 'recusar') {
              final parsedId = int.tryParse(filteredCorridas.first.id.toString());
              if (parsedId != null && mounted) {
                setState(() {
                  refusedCorridaIds.add(parsedId);
                  _isShowingCorridaDetalhe = false;
                  _hasShownCorridaThisFrame = false;
                });
              } else if (mounted) {
                setState(() {
                  _isShowingCorridaDetalhe = false;
                  _hasShownCorridaThisFrame = false;
                });
              }
              if (mounted) {
                WidgetsBinding.instance.addPostFrameCallback((_) {
                  if (mounted && !_isDisposed) {
                    _showNextCorridaDetalheIfNeeded();
                  }
                });
              }
            } else if (result == 'aceitar') {
              if (!mounted || _isDisposed) return;
              
              // Set the selected corrida in CorridaService before navigating
              try {
                var corridaService = Provider.of<CorridaService>(context, listen: false);
                corridaService.corrida = filteredCorridas.first.toJson();
                if (filteredCorridas.first.status != null && filteredCorridas.first.status['id'] != null) {
                  corridaService.status = filteredCorridas.first.status['id'].toString();
                }
                corridaService.notifyListeners();
              } catch (e) {
                print('Error setting corrida: $e');
              }
              
              if (mounted) {
                setState(() {
                  _isShowingCorridaDetalhe = false;
                  _hasShownCorridaThisFrame = false;
                });
              }
              
              if (mounted) {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => DetalhesCorridaScreen()),
                );
              }
            } else {
              if (mounted) {
                setState(() {
                  _isShowingCorridaDetalhe = false;
                  _hasShownCorridaThisFrame = false;
                });
              }
            }
          }).catchError((error) {
            print('Error in navigation: $error');
            if (mounted) {
              setState(() {
                _isShowingCorridaDetalhe = false;
                _hasShownCorridaThisFrame = false;
              });
            }
          });
        }
      } else {
        print('❌ MapaScreen - Not showing popup. Conditions not met.');
      }
    } catch (e) {
      print('Error in _showNextCorridaDetalheIfNeeded: $e');
      if (mounted) {
        setState(() {
          _isShowingCorridaDetalhe = false;
          _hasShownCorridaThisFrame = false;
        });
      }
    }
  }

  @override
  void initState() {
    super.initState();
    print('🚀 MapaScreen - initState called');
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (!mounted || _isDisposed) return;
      print('🚀 MapaScreen - Post frame callback in initState');
      await _getCurrentLocation();
      
      // Executa busca de corridas apenas uma vez
      await _executarBuscaCorridas();
      
      // Add auto-popup logic here as well
      if (mounted && !_isDisposed) {
        _showNextCorridaDetalheIfNeeded();
      }
    });
    _startLiveLocationUpdates();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_isDisposed || !mounted) return;
    
    try {
      var corridaService = Provider.of<CorridaService>(context, listen: true);
      if (corridaService.corridas.isEmpty) {
        if (mounted) {
          setState(() {
            _isShowingCorridaDetalhe = false;
            _hasShownCorridaThisFrame = false;
          });
        }
      } else {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted && !_isDisposed) {
            _showNextCorridaDetalheIfNeeded();
          }
        });
      }
    } catch (e) {
      print('Error in didChangeDependencies: $e');
    }
  }

  void _toggleNightMode() {
    if (!mounted || _isDisposed) return;
    
    setState(() {
      _nightMode = !_nightMode;
    });
    
    try {
      mapController?.setMapStyle(_nightMode ? _nightMapStyle : null);
    } catch (e) {
      print('Error setting map style: $e');
    }
  }

  Future<void> _getCurrentLocation() async {
    if (!mounted || _isDisposed) return;
    
    try {
      LocationPermission permission = await Geolocator.checkPermission();
      
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          return;
        }
      }
      if (permission == LocationPermission.deniedForever) {
        return;
      }
      
      Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );
      
      if (!mounted || _isDisposed) return;
      
      LatLng currentPosition = LatLng(position.latitude, position.longitude);
      
      if (mounted) {
        setState(() {
          _markers.add(
            Marker(
              markerId: MarkerId("current_location"),
              position: currentPosition,
              infoWindow: InfoWindow(title: "Você está aqui"),
            ),
          );
        });
      }
      
      if (mapController != null && mounted) {
        try {
          await mapController!.animateCamera(
            CameraUpdate.newLatLngZoom(currentPosition, 15),
          );
        } catch (e) {
          print("❌ Erro ao animar câmera: $e");
        }
      } else {
        print('⚠️ MapaScreen - Map controller is null or widget not mounted');
      }
    } catch (e) {
      print("❌ Erro ao obter localização atual: $e");
    }
  }

  void _startLiveLocationUpdates() {
    if (_isDisposed) return;
    
    try {
      positionStream = Geolocator.getPositionStream(
        locationSettings: LocationSettings(
          accuracy: LocationAccuracy.high,
          distanceFilter: 50, // Aumenta o filtro de distância para reduzir atualizações
          timeLimit: Duration(seconds: 5), // Limita frequência de atualizações
        ),
      ).listen((Position position) {
        if (!mounted || _isDisposed) return;
        
        LatLng currentPosition = LatLng(position.latitude, position.longitude);
        
        if (mounted) {
          setState(() {
            _markers.add(
              Marker(
                markerId: MarkerId("current_location"),
                position: currentPosition,
                infoWindow: InfoWindow(title: "Você está aqui"),
              ),
            );
          });
        }
        
        if (mapController != null && mounted) {
          try {
            mapController!.animateCamera(
              CameraUpdate.newLatLng(currentPosition),
            );
          } catch (e) {
            print("Erro ao animar câmera: $e");
          }
        }
      }, onError: (error) {
        print("Erro no stream de localização: $error");
      });
    } catch (e) {
      print("Erro ao iniciar stream de localização: $e");
    }
  }

  @override
  void dispose() {
    _isDisposed = true;
    positionStream?.cancel();
    // Limpar o controller antes de descartar
    if (mapController != null) {
      try {
        mapController!.dispose();
      } catch (e) {
        print('⚠️ Erro ao descartar mapController: $e');
      }
      mapController = null;
    }
    super.dispose();
  }

  void _onMapCreated(GoogleMapController controller) {
    if (_isDisposed || !mounted) {
      // Se o widget foi descartado, descartar o controller imediatamente
      try {
        controller.dispose();
      } catch (e) {
        print('⚠️ Erro ao descartar controller recém-criado: $e');
      }
      return;
    }
    
    try {
      // Descartar controller anterior se existir
      if (mapController != null) {
        try {
          mapController!.dispose();
        } catch (e) {
          print('⚠️ Erro ao descartar controller anterior: $e');
        }
      }
      
      mapController = controller;
      mapController?.setMapStyle(_nightMode ? _nightMapStyle : null);
    } catch (e) {
      print('❌ Error in _onMapCreated: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isDisposed || !mounted) {
      return Container(); // Return empty container if disposed
    }
    
    try {
      // --- AUTO-SHOW NEXT CORRIDA LOGIC ---
      // Removed addPostFrameCallback from build method for stability
      var corridaService = Provider.of<CorridaService>(context);
      var usuarioService = Provider.of<UsuarioService>(context);

      var filteredCorridas = corridaService.corridas
          .where((corrida) => !refusedCorridaIds.contains(corrida.id))
          .toList();
      return Scaffold(
        appBar: AppBar(
          title: Text('Mapa'),
          actions: [
            IconButton(
              icon: Icon(_nightMode ? Icons.nightlight_round : Icons.wb_sunny),
              onPressed: _toggleNightMode,
            ),
          ],
        ),
        body: Stack(
          children: [
            GoogleMap(
              key: _mapKey, // Key única para evitar recriação de view
              onMapCreated: (GoogleMapController controller) {
                if (_isDisposed || !mounted) {
                  try {
                    controller.dispose();
                  } catch (e) {
                    print('⚠️ Erro ao descartar controller: $e');
                  }
                  return;
                }
                
                print('📍 GoogleMap widget onMapCreated callback');
                _onMapCreated(controller);
                
                // Test map functionality after creation
                if (mounted) {
                  WidgetsBinding.instance.addPostFrameCallback((_) {
                    if (mounted && !_isDisposed) {
                      _testMapFunctionality();
                    }
                  });
                }
              },
              markers: _markers,
              initialCameraPosition: CameraPosition(
                target: LatLng(-23.550520, -46.633308), // São Paulo coordinates as fallback
                zoom: 15,
              ),
              myLocationEnabled: true,
              myLocationButtonEnabled: true,
              mapType: MapType.normal,
              zoomControlsEnabled: false,
              zoomGesturesEnabled: true,
              scrollGesturesEnabled: true,
              tiltGesturesEnabled: true,
              rotateGesturesEnabled: true,
              onCameraMove: (CameraPosition position) {
                if (mounted && !_isDisposed) {
                  print('📍 Camera moved to: ${position.target}');
                }
              },
            ),
            // Add API key error detection overlay
            if (filteredCorridas.isEmpty && usuarioService.usuario.motorista != null &&
            usuarioService.usuario.motorista['logado'] == "CONECTADO" )
              Positioned(
                left: 0,
                right: 0,
                bottom: 24,
                child: Container(
                  margin: EdgeInsets.symmetric(horizontal: 16),
                  padding: EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black12,
                        blurRadius: 4,
                        offset: Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        'Procurando viagens',
                        style: TextStyle(
                          color: Color(0xFFF9AD1E),
                          fontWeight: FontWeight.normal,
                          fontSize: 16,
                        ),
                      ),
                      SizedBox(height: 8),
                      LinearProgressIndicator(
                        backgroundColor: Colors.transparent,
                        valueColor: AlwaysStoppedAnimation<Color>(Color(0xFFF9AD1E)),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      );
    } catch (e) {
      print('❌ Error in build: $e');
      return Scaffold(
        appBar: AppBar(title: Text('Mapa')),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.error, size: 64, color: Colors.red),
              SizedBox(height: 16),
              Text('Erro ao carregar o mapa'),
              SizedBox(height: 8),
              Text('$e', style: TextStyle(fontSize: 12, color: Colors.grey)),
              SizedBox(height: 16),
              ElevatedButton(
                onPressed: () {
                  setState(() {
                    // Force rebuild
                  });
                },
                child: Text('Tentar novamente'),
              ),
            ],
          ),
        ),
      );
    }
  }

  // Test map functionality to detect API key issues
  void _testMapFunctionality() async {
    if (mapController == null || !mounted) return;
    
    try {
      // Try to get map bounds - this will fail if API key is invalid
      await Future.delayed(Duration(seconds: 2));
      if (mounted && mapController != null) {
        final bounds = await mapController!.getVisibleRegion();
        print('📍 Map bounds loaded successfully: $bounds');
      }
    } catch (e) {
      print('❌ Map functionality test failed: $e');
      if (mounted) {
        setState(() {
          // This will trigger the error overlay
        });
      }
    }
  }

}