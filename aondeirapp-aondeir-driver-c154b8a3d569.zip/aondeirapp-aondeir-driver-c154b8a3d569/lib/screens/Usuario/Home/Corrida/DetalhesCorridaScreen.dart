import 'dart:async';
import 'package:aondeir_motorista/screens/Modal/ModalPadraoGeral.dart';
import 'package:aondeir_motorista/screens/Usuario/BottomNavigationBar/NavigationScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/AberturaCorrida/ChatMensagem/MensagemScreen.dart';
import 'package:aondeir_motorista/service/LocalizacaoService.dart';
import 'package:aondeir_motorista/service/corrida/MotoristaAtualizaLocalizacaoService.dart';
import 'package:aondeir_motorista/service/FirebasePresenceService.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:geolocator/geolocator.dart';
import 'package:provider/provider.dart';
import 'package:slidable_button/slidable_button.dart';
import 'package:map_launcher/map_launcher.dart';
import 'package:sliding_up_panel/sliding_up_panel.dart';
import '../../../../service/CorridaService.dart';
import '../../../../service/UsuarioService.dart';
import '../../../../service/firebase/FirebaseRealtimeService.dart';
import '../../../../service/corrida/CorridaGuardarCoordenadasOfflineService.dart';
import '../../../../service/corrida/CorridaSalvarCoordenadaRotaService.dart';
import '../../../../service/corrida/parada/CorridaAdicionarParadaService.dart';
import '../../../../service/corrida/CorridaBuscarDuracaoParadaService.dart';
import '../../../../service/corrida/parada/CorridaFinalizarParadaService.dart';
import '../../../../service/corrida/parada/CorridaPegarDuracaoParadaService.dart';
import '../../../../service/corrida/proximo-destino/CorridaAdicionarProximoDestinoService.dart';
import '../../../../service/helper/CheckConexaoService.dart';
import '../../../../service/ligacao/FazerLigacaoService.dart';
import '../../../../service/localizacao/PesquisaEnderecoGeocodificacaoPorCoordenadaService.dart';
import '../../../../service/toque/ToqueService.dart';
import '../../Menu/AberturaCorrida/FichaTecnica/FichaTecnicaScreen.dart';
import 'OpcionalCancelamentoScreen.dart';
import 'CheckoutScreen.dart';

class DetalhesCorridaScreen extends StatefulWidget {
  const DetalhesCorridaScreen({super.key});

  @override
  State<DetalhesCorridaScreen> createState() => _DetalhesCorridaScreenState();
}

class _DetalhesCorridaScreenState extends State<DetalhesCorridaScreen> {
  PanelController panelController = PanelController();
  final storage = new FlutterSecureStorage();

  String etapas = "Cheguei ao local";
  String tempoParadoTexto = "00:00";
  var latitude = "";
  var numero = "";
  var statusCorrida = "4";
  var motivoDescricao = "";
  bool showDiaLog = false;
  bool startContarParada = false;
  bool isLoading = false;
  bool status = false;
  bool isBotaoProximoDestinoHabilitado = true;
  bool startProximoDestino = false;
  bool isProximoDestino = false;
  bool isCalculando = false;
  bool isSaving = false;
  var parte = 0;
  late CorridaService corridaService;
  var localizacaoAtual;
  var motivoId = null;

  var isOptionSelected = false;
  var positionStreamState;
  Timer? meuTimer;
  var dataInicioParada = null;
  var duracaoEmSegundos = 0;
  var tempoTotalParadaSegundos = 0;
  var distanciaEntreOsPontos = 0.0;
  var totalPercorridoEntrePontos = 0.0;
  var totalPercorridoRota = 0.0;
  var totalPercorridoRotaParaSalvar = 0.0;
  late Position _startPosition = Position(
    longitude: 0,
    latitude: 0,
    timestamp: DateTime.now(),
    altitudeAccuracy: 0,
    accuracy: 0,
    altitude: 0,
    heading: 0,
    speed: 0,
    headingAccuracy: 0,
    speedAccuracy: 0,
  );
  final GeolocatorPlatform _geolocatorPlatform = GeolocatorPlatform.instance;
  StreamSubscription<Position>? _positionStreamSubscription;
  StreamSubscription<ServiceStatus>? _serviceStatusStreamSubscription;

  bool positionStreamStarted = false;

  int distanceFilter = 20;
  int limiteMetrosAtualizacao = 20;
  var accuracy = LocationAccuracy.bestForNavigation;
  bool modalAlerta = false;

  openMap() async {
    try {
      setState(() {
        isLoading = true;
      });

      await showLoader("Abrindo mapa com a rota...");
      await Future.delayed(Duration(seconds: 1));

      Position position = await Geolocator.getCurrentPosition();
      var corridaService = Provider.of<CorridaService>(context, listen: false);

      setState(() {
        isLoading = false;
      });

      Navigator.of(context).pop();

      Coords destino;

      if (statusCorrida == "6") {
        destino = Coords(
          double.parse(corridaService.corrida["latitude_destino"]),
          double.parse(corridaService.corrida["longitude_destino"]),
        );
      } else if (statusCorrida == "4" || statusCorrida == "5") {
        destino = Coords(
          double.parse(corridaService.corrida["latitude_partida"]),
          double.parse(corridaService.corrida["longitude_partida"]),
        );
      } else {
        throw Exception("Status da corrida inválido.");
      }

      // Obtém a lista de aplicativos de mapas instalados
      final availableMaps = await MapLauncher.installedMaps;

      if (availableMaps.isNotEmpty) {
        showModalBottomSheet(
          context: context,
          builder: (context) {
            return SafeArea(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children:
                    availableMaps.map((map) {
                      return ListTile(
                        onTap: () async {
                          Navigator.pop(context);

                          await map.showDirections(
                            origin: Coords(
                              position.latitude,
                              position.longitude,
                            ),
                            destination: destino,
                            directionsMode: DirectionsMode.driving,
                          );
                        },
                        title: Text(map.mapName),
                      );
                    }).toList(),
              ),
            );
          },
        );
      } else {
        throw Exception("Nenhum aplicativo de mapas encontrado.");
      }
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      Navigator.of(context).pop();
      showModalAlertError(e.toString());
    }
  }

  showModalAlertError(String message) async {
    showDialog<String>(
      context: context,
      builder:
          (BuildContext context) => AlertDialog(
            title: Text('Ops!', textAlign: TextAlign.center),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.error, color: Colors.red, size: 50),
                SizedBox(height: 10),
                Text(
                  message,
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.black),
                ),
              ],
            ),
            actions: <Widget>[
              InkWell(
                onTap: () {
                  Navigator.pop(context, "Fechar");
                },
                child: Padding(
                  padding: EdgeInsets.only(bottom: 10, left: 15, right: 15),
                  child: Text('Fechar', style: TextStyle(color: Colors.orange)),
                ),
              ),
            ],
          ),
    );
  }

  showLoader(texto) {
    if (isLoading == true) {
      showDialog<String>(
        barrierDismissible: false,
        context: context,
        builder:
            (BuildContext context) => AlertDialog(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(12.0)),
              ),
              title: Container(
                child: Text(
                  texto,
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 13, color: Colors.grey[700]),
                ),
              ),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 16),
                  Text('Carregando...'),
                ],
              ),
            ),
      );
    }
  }

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      // ⚡ CORREÇÃO: Verificar se o widget ainda está montado
      if (!mounted) return;
      
      // 🔥 Inicializar Firebase Presence quando DetalhesCorridaScreen é aberta
      try {
        var usuarioService = Provider.of<UsuarioService>(context, listen: false);
        var corridaService = Provider.of<CorridaService>(context, listen: false);
        
        int? corridaId;
        if (corridaService.corrida.isNotEmpty && corridaService.corrida['id'] != null) {
          corridaId = corridaService.corrida['id'] is int 
              ? corridaService.corrida['id'] 
              : int.tryParse(corridaService.corrida['id'].toString());
        }
        await FirebasePresenceService().initialize(usuarioService.usuario.id, corridaId: corridaId);
        
      } catch (e) {
        print('❌ [DetalhesCorrida] Erro Firebase Presence: $e');
      }
      
      await buscarDuaracaoParadaCorrida();
      
      if (!mounted) return;
      await setParte();
      
      if (!mounted) return;
      print('📍_getLocation');
      await _getLocation();
      
      if (!mounted) return;
      // ⚡ CORREÇÃO: Adicionar delay antes de ativar o listener Firebase
      // para evitar processamento de dados antigos
      await Future.delayed(Duration(seconds: 2));
      
      if (!mounted) return;
      await firebaseListener();
    });
  }
  firebaseListener() async {
    try {
      // ⚡ CORREÇÃO: Verificar se o widget ainda está montado
      if (!mounted) {
        print("⚠️ [DetalhesCorrida] Widget não está montado, cancelando firebaseListener");
        return;
      }
      
      var firebaseService = Provider.of<FirebaseRealtimeService>(context, listen: false);
      var usuarioService = Provider.of<UsuarioService>(context, listen: false);
      var corridaService = Provider.of<CorridaService>(context, listen: false);
      
      print("🔥 [DetalhesCorrida] Iniciando listener Firebase para cancelamento");
      print("🔥 [DetalhesCorrida] User ID: ${usuarioService.usuario.id}");
      
      // Inicializar Firebase para conexão rápida
      await firebaseService.initializeForFastConnection();
      
      if (!mounted) return;
      await corridaService.pegarCorridaAndamento();
      corridaService.modalAlerta = false;
      corridaService.save();
      
      // Configurar listener Firebase com callback personalizado
      firebaseService.startListeningForCorridaCanceladaWithCallback(
        usuarioService.usuario.id.toString(),
        (data) async {
          // ⚡ CORREÇÃO: Verificar se o widget ainda está montado
          if (!mounted) {
            print("⚠️ [DetalhesCorrida] Widget não está montado, ignorando cancelamento");
            return;
          }
          
          print("🔥 [DetalhesCorrida] Cancelamento recebido via Firebase: $data");
          
          // Processar cancelamento localmente
          await _processarCancelamentoLocal(data);
        }
      );
      
      // 🔥 FIREBASE: Listener de mensagens via Firebase
      firebaseService.iniciarListenerMensagemChat(
        usuarioService.usuario.id.toString(),
        corridaService.corrida['id'],
       (data) async {
          print("💬 [DetalhesCorrida] Mensagem recebida via Firebase");
          print("💬 [DetalhesCorrida] Dados completos: ${data.toString()}");
          
          var mensagem = data['mensagem'];
          var remetenteTipoId = mensagem?['remetente']?['tipoId'];
          var remetenteId = mensagem?['remetente']?['id'];
          
          print("💬 [DetalhesCorrida] remetenteTipoId: $remetenteTipoId, remetenteId: $remetenteId");
          print("💬 [DetalhesCorrida] Estrutura completa remetente: ${mensagem?['remetente']}");
          
          // Capturar modalAlerta ANTES de adicionar mensagem
          var modalAlertaAntes = corridaService.modalAlerta;
          print("💬 [DetalhesCorrida] modalAlerta antes de addNovaMensagemLista: $modalAlertaAntes");
          
          await corridaService.addNovaMensagemLista(mensagem);
          
          // Verificar modalAlerta novamente após adicionar mensagem
          var modalAlertaDepois = corridaService.modalAlerta;
          print("💬 [DetalhesCorrida] modalAlerta depois de addNovaMensagemLista: $modalAlertaDepois");
          
          // Mostrar modal se: mensagem é do passageiro (tipoId == 3) e modalAlerta ainda não foi mostrado
          // Usar o valor ANTES de adicionar mensagem para evitar race condition
          print("💬 [DetalhesCorrida] Verificando condições - remetenteTipoId: $remetenteTipoId (esperado: 3), modalAlerta: $modalAlertaAntes (esperado: false)");
          
          if (remetenteTipoId == 3 && modalAlertaAntes == false) {
            // Definir modalAlerta como true para evitar mostrar múltiplas vezes
            corridaService.modalAlerta = true;
            corridaService.save();

            print("💬 [DetalhesCorrida] ✅ Condições atendidas - Mostrando modal de alerta");
            print("💬 [DetalhesCorrida] mounted: $mounted, context: ${context.toString()}");

            // Usar SchedulerBinding para garantir que o contexto está pronto
            SchedulerBinding.instance.addPostFrameCallback((_) {
              if (mounted) {
                print("💬 [DetalhesCorrida] 🎯 Chamando showDialog");
            showDialog<String>(
              context: context,
                  barrierDismissible: false,
                  builder: (BuildContext context) {
                    print("💬 [DetalhesCorrida] 🎯 Builder chamado");
                    return ModalPadraoGeral(
                titulo: 'Atenção!',
                message: 'Você tem uma nova mensagem do passageiro',
                btnAcao: true,
                      btnAcaoTexto: 'Abrir mensagem',
                btnAcaoClick: () {
                  corridaService.modalAlerta = false;
                  corridaService.save();
                  Navigator.pop(context);
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => MensagemScreen(),
              ),
            );
                      },
                    );
                  },
                );
              } else {
                print("💬 [DetalhesCorrida] ⚠️ Widget não está mounted após postFrameCallback");
              }
            });
          } else {
            print("💬 [DetalhesCorrida] ❌ Modal não será mostrado - remetenteTipoId: $remetenteTipoId (esperado: 3), modalAlerta: ${corridaService.modalAlerta} (esperado: false)");
        }
        },
      );
      
    } catch (e) {
      print("❌ [DetalhesCorrida] Erro ao iniciar listener Firebase: $e");
      throw e;
    }
  }

  // Processa cancelamento localmente
  Future<void> _processarCancelamentoLocal(Map<dynamic, dynamic> data) async {
    try {
      // ⚡ CORREÇÃO: Verificar se o widget ainda está montado
      if (!mounted) {
        print("⚠️ [DetalhesCorrida] Widget não está montado, cancelando processamento de cancelamento");
        return;
      }
      
      var corridaService = Provider.of<CorridaService>(context, listen: false);
      
      print("🚫 [DetalhesCorrida] Processando cancelamento local");
      print("🚫 [DetalhesCorrida] Dados: $data");
      
      // Verificar se é um cancelamento
      String? status = data['status']?.toString();
      if (status == 'CANCELADA' && data['msg']?.toString().contains('cancelada pelo passageiro') == true) {
        
        var corridaData = data['corrida'];
        if (corridaData != null) {
          print("📋 [DetalhesCorrida] ID da corrida cancelada: ${corridaData['id']}");
          
          // ⚡ CORREÇÃO: Verificar se o cancelamento é da corrida atual
          if (corridaService.corrida.isNotEmpty && 
              corridaService.corrida['id'].toString() == corridaData['id'].toString()) {
            print("✅ [DetalhesCorrida] Cancelamento confirmado para corrida atual");
            
            // Executar ações de cancelamento
            cancelarListenCorrida();
            liberarMotorista();
            resetarServiceCorrida();
            
            // Atualizar CorridaService com dados do cancelamento
            print("🔄 [DetalhesCorrida] Atualizando CorridaService com dados do cancelamento");
            corridaService.corrida = corridaData;
            await corridaService.save();
            
            // Navegar para home
            if (mounted) {
              await redirecionarHome();
            }
          } else {
            print("⚠️ [DetalhesCorrida] Cancelamento ignorado - não é da corrida atual");
            print("⚠️ [DetalhesCorrida] Corrida atual: ${corridaService.corrida['id']}");
            print("⚠️ [DetalhesCorrida] Corrida cancelada: ${corridaData['id']}");
            return;
          }
          
          // Mostrar modal de cancelamento
          if (corridaData['id'] != null) {
            showDialog<String>(
              context: context,
              builder: (BuildContext context) => ModalPadraoGeral(
                titulo: 'Corrida Cancelada',
                message: "Corrida cancelada Motivo: ${corridaData['motivo_descricao_cancelamento'] ?? 'Não informado'}",
                btnAcao: true,
                btnAcaoTexto: 'Fechar',
                btnAcaoClick: () {
                  Navigator.pop(context);
                },
              ),
            );
          }
        }
      }
    } catch (e) {
      print("❌ [DetalhesCorrida] Erro ao processar cancelamento local: $e");
    }
  }
  @override
  void dispose() {
    _positionStreamSubscription?.cancel();
    _positionStreamSubscription = null;
    
    final firebaseService = Provider.of<FirebaseRealtimeService>(context, listen: false);
    
    print("🔥 [DetalhesCorrida] Dispose - parando listeners Firebase");
    firebaseService.stopListeningForCorridaCancelada();
    firebaseService.pararListenerMensagemChat();
    
    super.dispose();
  }

  buscarDuaracaoParadaCorrida() async {
    var corridaService = Provider.of<CorridaService>(context, listen: false);
    var corridaBuscarDuracaoParadaService =
        Provider.of<CorridaBuscarDuracaoParadaService>(context, listen: false);

    if (corridaService.corrida.isNotEmpty) {
      if (corridaService.corrida['status']['id'] == 6) {
        await corridaBuscarDuracaoParadaService.execute();
        if (corridaBuscarDuracaoParadaService.dataInicioParada != null) {
          setState(() {
            startContarParada = true;
            dataInicioParada =
                corridaBuscarDuracaoParadaService.dataInicioParada;
            tempoTotalParadaSegundos =
                corridaBuscarDuracaoParadaService.tempoTotalParadaSegundos;
          });
          await pegarDurancaoParaCorrida();
          iniciarTimer();
        } else {
          setState(() {
            tempoTotalParadaSegundos =
                corridaBuscarDuracaoParadaService.tempoTotalParadaSegundos;
          });
          await pegarDurancaoParaCorrida();
        }
      }
    }
  }

  pegarDuracaoEmSegundos() async {
    if (dataInicioParada == null) {
      return;
    }

    var corridaPegarDuracaoParadaService =
        Provider.of<CorridaPegarDuracaoParadaService>(context, listen: false);
    await corridaPegarDuracaoParadaService.execute(dataInicioParada);

    setState(() {
      duracaoEmSegundos = corridaPegarDuracaoParadaService.duracaoEmSegundos;
    });
  }

  pegarDurancaoParaCorrida() async {
    print('🟨🟨🟨 - pegarDurancaoParaCorrida');
    await pegarDuracaoEmSegundos();
    print('🟨🟨🟨 - duracaoEmSegundos');
    print(duracaoEmSegundos);
    var totalSegundos = duracaoEmSegundos + tempoTotalParadaSegundos;
    print('🟨🟨🟨 - totalSegundos');
    print(totalSegundos);
    var horas = totalSegundos ~/ 3600;
    var minutos = (totalSegundos % 3600) ~/ 60;
    var segundosRestantes = totalSegundos % 60;

    if (totalSegundos > 0) {
      var texto =
          horas > 0
              ? horas.toString().padLeft(2, '0') +
                  ":" +
                  minutos.toString().padLeft(2, '0') +
                  ":" +
                  segundosRestantes.toString().padLeft(2, '0')
              : minutos.toString() +
                  ":" +
                  segundosRestantes.toString().padLeft(2, '0');

      setState(() {
        tempoParadoTexto = texto;
      });
    }
  }

  mensagemSemInternet() async {
    final snackBar = SnackBar(
      content: Text(
        'Sem internet Conecte-se á rede Wi-Fi ou aos dados móveis!',
        selectionColor: Colors.white,
      ),
      duration: Duration(days: 365),
      backgroundColor: const Color.fromARGB(255, 233, 43, 29),
    );
    ScaffoldMessenger.of(context).showSnackBar(snackBar);
  }

  void fecharSnackBar() {
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
  }

  cancelarListenCorrida() async {
    _positionStreamSubscription?.cancel();
    _positionStreamSubscription = null;
    setState(() {
      _positionStreamSubscription = _positionStreamSubscription;
    });
  }

  resetarServiceCorrida() {
    var corridaService = Provider.of<CorridaService>(context, listen: false);
    corridaService.resetarStateService();
  }

  liberarMotorista() async {
    final usuarioService = Provider.of<UsuarioService>(context, listen: false);
    usuarioService.usuario.motorista['situacao'] = 'LIVRE';
    usuarioService.save();
  }

  redirecionarHome() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => NavigationScreen()),
    );
  }

  setParte() async {
    var corridaService = Provider.of<CorridaService>(context, listen: false);

    if (corridaService.status == "4") {
      setState(() {
        parte = 0;
        statusCorrida = corridaService.status;
      });
    }

    if (corridaService.status == "5") {
      setState(() {
        parte = 1;
        etapas = "Iniciar corrida";
        statusCorrida = corridaService.status;
      });
    }

    if (corridaService.status == "6") {
      setState(() {
        parte = 2;
        etapas = 'Finalizar corrida';
        statusCorrida = corridaService.status;
      });
    }

    if (corridaService.status == "7") {
      await Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => CheckoutScreen()),
      );
    }
  }

  void alterarStatusCorrida(idStatus, nomeStatus, idCorrida) async {
    try {
      var corridaService = Provider.of<CorridaService>(context, listen: false);
      var textoLoader = "Avisando o passageiro...";

      print('aqui');

      setState(() {
        isLoading = true;
      });

      if (parte == 1) {
        textoLoader = "Iniciando corrida";
      }

      await showLoader(textoLoader);
      await Future.delayed(Duration(seconds: 1));

      var resp = await corridaService.alterarStatusCorrida(
        idStatus,
        nomeStatus,
        idCorrida,
      );

      if (resp == true) {
        if (parte == 0) {
          setState(() {
            etapas = "Iniciar corrida";
          });
        }

        if (parte == 1 && idStatus == "6") {
          setState(() {
            etapas = 'Finalizar corrida';
          });
        }

        setState(() {
          parte++;
        });

        print('if parte');

        print('📍📍_getLocation');
        _getLocation();

        setState(() {
          statusCorrida = corridaService.status;
        });

        Navigator.of(context).pop();
        setState(() {
          isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      Navigator.of(context).pop();
      showModalAlertError(e.toString());
    }
  }

  void finalizar(idCorrida) async {
    try {
      var corridaService = Provider.of<CorridaService>(context, listen: false);
      var toqueService = Provider.of<ToqueService>(context, listen: false);
      var pesquisaEnderecoGeocodificacaoPorCoordenadaService =
          Provider.of<PesquisaEnderecoGeocodificacaoPorCoordenadaService>(
            context,
            listen: false,
          );

      setState(() {
        isLoading = true;
      });

      await showLoader("Finalizando corrida");
      await Future.delayed(Duration(seconds: 1));

      LocationPermission permission = await Geolocator.checkPermission();

      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied ||
            permission == LocationPermission.deniedForever) {
          Navigator.of(context).pop();
          setState(() {
            isLoading = false;
          });
          return;
        }
      }

      Position enderecoDestino = await Geolocator.getCurrentPosition()
          .then((value) {
            return value;
          })
          .catchError((e) {
            Navigator.of(context).pop();
            setState(() {
              isLoading = false;
            });
            // showModalAlertError(
            //     "Ops! nao foi possivel pegar sua localização atual!");
          });

      _positionStreamSubscription!.pause();

      String localAtual =
          await pesquisaEnderecoGeocodificacaoPorCoordenadaService.execute(
            enderecoDestino.latitude,
            enderecoDestino.longitude,
          );

      var coordenadas = await storage.read(key: 'coordenadas');

      if (coordenadas != null) {
        var corridaSalvarCoordenadaRotaService =
            Provider.of<CorridaSalvarCoordenadaRotaService>(
              context,
              listen: false,
            );
        await corridaSalvarCoordenadaRotaService.execute(coordenadas);

        setState(() {
          totalPercorridoEntrePontos = 0.0;
        });

        var corridaGuardarCoordenadasOfflineService =
            Provider.of<CorridaGuardarCoordenadasOfflineService>(
              context,
              listen: false,
            );

        corridaGuardarCoordenadasOfflineService.coordenadas.clear();
        await corridaGuardarCoordenadasOfflineService.save();

        await storage.delete(key: 'coordenadas');
      }

      corridaService.enderecoDestinoTexto = localAtual;
      corridaService.enderecoDestinoLatitude = enderecoDestino.latitude;
      corridaService.enderecoDestinoLongitude = enderecoDestino.longitude;
      await corridaService.save();

      var resp = await corridaService.finalizarCorrida(idCorrida);
      if (resp == true) {
        setState(() {
          statusCorrida = corridaService.status;
          totalPercorridoRota = 0.0;
          distanciaEntreOsPontos = 0.0;
          totalPercorridoEntrePontos = 0.0;
        });

        _positionStreamSubscription!.cancel();
        var corridaGuardarCoordenadasOfflineService =
            Provider.of<CorridaGuardarCoordenadasOfflineService>(
              context,
              listen: false,
            );

        corridaGuardarCoordenadasOfflineService.coordenadas.clear();
        await corridaGuardarCoordenadasOfflineService.save();

        await storage.delete(key: 'coordenadas');

        if (corridaService.corrida.isNotEmpty) {
          if (statusCorrida == "7") {
            Navigator.of(context).pop();
            setState(() {
              isLoading = false;
            });
            toqueService.execute(
              'toques/toque_motorista_corrida_finalizada.mp3',
            );
            await Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => CheckoutScreen()),
            );
          }
        }
      }
    } catch (e) {
      setState(() {
        isLoading = false;
      });

      _positionStreamSubscription!.resume();

      Navigator.of(context).pop();
      showModalAlertError(e.toString());
    }
  }

  ligar() async {
    var fazerLigacaoService = Provider.of<FazerLigacaoService>(
      context,
      listen: false,
    );
    var corridaService = Provider.of<CorridaService>(context, listen: false);
    await fazerLigacaoService.execute(
      corridaService.corrida['telefone_contato'],
    );
  }

  iniciarParada() async {
    try {
      if (isLoading) {
        return;
      }

      if (startContarParada) {
        return;
      }

      setState(() {
        startContarParada = true;
        isLoading = true;
      });

      await showLoader("Obtendo localização da parada...");
      await Future.delayed(Duration(seconds: 1));

      var localizacaoService = Provider.of<LocalizacaoService>(
        context,
        listen: false,
      );

      Position position =
          await localizacaoService.getCurrentLocationAberturaCorrida();

      var pesquisaEnderecoGeocodificacaoPorCoordenadaService =
          Provider.of<PesquisaEnderecoGeocodificacaoPorCoordenadaService>(
            context,
            listen: false,
          );

      var localAtual = await pesquisaEnderecoGeocodificacaoPorCoordenadaService
          .execute(position.latitude, position.longitude);

      Navigator.of(context).pop();

      await showLoader("Iniciando parada...");
      await Future.delayed(Duration(seconds: 1));

      var coordenadas = await storage.read(key: 'coordenadas');

      if (coordenadas != null) {
        var corridaSalvarCoordenadaRotaService =
            Provider.of<CorridaSalvarCoordenadaRotaService>(
              context,
              listen: false,
            );
        await corridaSalvarCoordenadaRotaService.execute(coordenadas);

        setState(() {
          totalPercorridoEntrePontos = 0.0;
        });

        var corridaGuardarCoordenadasOfflineService =
            Provider.of<CorridaGuardarCoordenadasOfflineService>(
              context,
              listen: false,
            );

        corridaGuardarCoordenadasOfflineService.coordenadas.clear();
        await corridaGuardarCoordenadasOfflineService.save();

        await storage.delete(key: 'coordenadas');
      }

      var latitude = position.latitude.toString();
      var longitude = position.longitude.toString();
      var endereco = localAtual;

      var corridaAdicionarParadaService =
          Provider.of<CorridaAdicionarParadaService>(context, listen: false);

      await corridaAdicionarParadaService.execute(
        latitude,
        longitude,
        endereco,
      );

      setState(() {
        dataInicioParada = corridaAdicionarParadaService.dataInicioParada;
        tempoTotalParadaSegundos =
            corridaAdicionarParadaService.tempoTotalParadaSegundos;
      });

      await Future.delayed(Duration(seconds: 3));

      await pegarDurancaoParaCorrida();

      iniciarTimer();

      setState(() {
        isLoading = false;
      });
      Navigator.of(context).pop();
    } catch (e) {
      setState(() {
        isLoading = false;
        startContarParada = false;
      });
      Navigator.of(context).pop();
      showModalAlertError(e.toString());
    }
  }

  finalizarParada() async {
    try {
      if (isLoading) {
        return;
      }

      setState(() {
        isLoading = true;
      });

      await showLoader("finalizando parada...");
      await Future.delayed(Duration(seconds: 1));
      var corridaFinalizarParadaService =
          Provider.of<CorridaFinalizarParadaService>(context, listen: false);

      await corridaFinalizarParadaService.execute();

      setState(() {
        dataInicioParada = null;
        duracaoEmSegundos = 0;
        tempoTotalParadaSegundos =
            corridaFinalizarParadaService.tempoTotalParadaSegundos;
      });

      await Future.delayed(Duration(seconds: 3));

      await pegarDurancaoParaCorrida();

      await cancelarTimer();

      setState(() {
        isLoading = false;
        startContarParada = false;
      });
      Navigator.of(context).pop();

      if (corridaFinalizarParadaService.semDestino == false) {
        showModalProximoDestino();
      }
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      Navigator.of(context).pop();
      showModalAlertError(e.toString());
    }
  }

  showModalProximoDestino() async {
    showDialog<String>(
      barrierDismissible: false,
      context: context,
      builder:
          (BuildContext context) => AlertDialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(12.0)),
            ),
            title: Text(
              'Atenção',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold),
            ),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.location_on, color: Colors.orange, size: 50),
                SizedBox(height: 10),
                Text(
                  'Esse "Próximo Destino" é um endereço não planejado pelo passageiro onde o mesmo pede ao motorista para ir a um destino adicional diferente do inserido no app!',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.black),
                ),
                SizedBox(height: 10),
                Text(
                  'Você tem certeza que deseja continuar?',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.black),
                ),
              ],
            ),
            actions: <Widget>[
              InkWell(
                onTap: () {
                  Navigator.pop(context);
                },
                child: Padding(
                  padding: EdgeInsets.only(bottom: 10, left: 15, right: 15),
                  child: Text(
                    'Não',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              InkWell(
                onTap: () {
                  Navigator.pop(context, "Sim");
                  irParaProximoDestino();
                },
                child: Padding(
                  padding: EdgeInsets.only(bottom: 10, right: 15),
                  child: Text(
                    'Sim',
                    style: TextStyle(
                      color: Colors.orange,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ],
          ),
    );
  }

  void iniciarTimer() {
    meuTimer = Timer.periodic(Duration(seconds: 1), (timer) {
      pegarDurancaoParaCorrida();
    });
  }

  cancelarTimer() {
    meuTimer?.cancel();
  }

  void pagarCorrida(idCorrida, BuildContext context) async {
    try {
      final corridaService = Provider.of<CorridaService>(
        context,
        listen: false,
      );
      setState(() {
        isLoading = true;
      });

      await showLoader("Pagando corrida...");
      await Future.delayed(Duration(seconds: 1));

      await corridaService.pagarCorrida(idCorrida);

      setState(() {
        isLoading = false;
      });
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      Navigator.of(context).pop();
      showModalAlertError(e.toString());
    }
  }

  Future<bool> longeDoEmbarque() async {
    var localizacaoService = Provider.of<LocalizacaoService>(
      context,
      listen: false,
    );
    var usuarioService = Provider.of<UsuarioService>(context, listen: false);
    localizacaoService.getCurrentLocation(usuarioService.usuario.id);

    if (localizacaoService.numeroFormatado != null &&
        localizacaoService.isKm == false) {
      if (double.parse(localizacaoService.numeroFormatado) <=
          localizacaoService.distanciaMinima) {
        return false;
      }
    }

    return true;
  }

  irParaProximoDestino() async {
    try {
      if (isLoading) {
        return;
      }

      setState(() {
        startProximoDestino = true;
        isLoading = true;
        isBotaoProximoDestinoHabilitado = false;
        isProximoDestino = true;
      });
      await showLoader("Iniciando próximo destino...");
      await Future.delayed(Duration(seconds: 1));
      var corridaIniciarProximoDestinoService =
          Provider.of<CorridaIniciarProximoDestinoService>(
            context,
            listen: false,
          );

      await corridaIniciarProximoDestinoService.execute();

      setState(() {
        isLoading = false;
      });
      Navigator.of(context).pop();
    } catch (e) {
      setState(() {
        isLoading = false;
        startContarParada = false;
        startProximoDestino = false;
        isBotaoProximoDestinoHabilitado = true;
      });
      Navigator.of(context).pop();
      showModalAlertError(e.toString());
    }
  }

  Future<void> _getLocation() async {
    print('getLocation parte');

    print(parte);

    print('getLocation parte');
    // if (parte != 2) {
    //   return;
    // }
    _toggleServiceStatusStream();
    _toggleListening();
  }

  Future<void> _toggleListening() async {
    var usuarioService = Provider.of<UsuarioService>(context, listen: false);
    var motoristaAtualizaLocalizacaoService =
        Provider.of<MotoristaAtualizaLocalizacaoService>(
          context,
          listen: false,
        );

    // if (parte == 2 && _positionStreamSubscription == null) {
    if (_positionStreamSubscription == null) {
      setState(() {
        totalPercorridoRota = 0.0;
        distanciaEntreOsPontos = 0.0;
        totalPercorridoEntrePontos = 0.0;
      });

      var locationSettings;

      if (defaultTargetPlatform == TargetPlatform.android) {
        locationSettings = await AndroidSettings(
          accuracy: this.accuracy,
          // accuracy: LocationAccuracy.low,
          distanceFilter: this.distanceFilter,
          foregroundNotificationConfig: const ForegroundNotificationConfig(
            notificationText:
                "O aplicativo continuará recebendo sua localização mesmo quando você estiver com ele em segundo plano",
            notificationTitle: "Executando em segundo plano",
            enableWakeLock: true,
          ),
        );
      } else if (defaultTargetPlatform == TargetPlatform.iOS ||
          defaultTargetPlatform == TargetPlatform.macOS) {
        locationSettings = await AppleSettings(
          accuracy: this.accuracy,
          // accuracy: LocationAccuracy.low,
          activityType: ActivityType.fitness,
          distanceFilter: this.distanceFilter,
          pauseLocationUpdatesAutomatically: true,
          showBackgroundLocationIndicator: false,
        );
      } else {
        locationSettings = await LocationSettings(
          accuracy: this.accuracy,
          // accuracy: LocationAccuracy.low,
          distanceFilter: this.distanceFilter,
        );
      }

      final positionStream = await Geolocator.getPositionStream(
        locationSettings: locationSettings,
      );

      _positionStreamSubscription = positionStream
          .handleError((error) {
            _positionStreamSubscription?.cancel();
            _positionStreamSubscription = null;
          })
          .listen((Position position) async {
            if (parte != 2 && parte != 0 && parte != 1) {
              return;
            }

            if (position == null) {
              return;
            }

            motoristaAtualizaLocalizacaoService.execute(
              usuarioService.usuario.id,
              position,
            );

            if (isCalculando) {
              return;
            }

            if (_startPosition.latitude == position.latitude &&
                _startPosition.longitude == position.longitude) {
              return;
            }

            setState(() {
              isCalculando = true;
            });

            if (_startPosition.latitude == 0) {
              await setStartPosition(position);
            }

            await pegarDistanciaEntrePontos(_startPosition, position);

            setState(() {
              _startPosition = position;
            });

            await somarDistaciaPercorridaEntrePontos();
            await somarTotalPercorridoRota();
            await somarTotalPercorridoRotaParaSalvar();

            await guardarCoordenada(position);

            setState(() {
              isCalculando = false;
            });
          });

      if (isLoading == true) {
        Navigator.of(context).pop();
      }

      setState(() {
        positionStreamState = _positionStreamSubscription;
        _positionStreamSubscription = _positionStreamSubscription;
        isLoading = false;
      });
    }
  }

  void _toggleServiceStatusStream() {
    if (_serviceStatusStreamSubscription == null) {
      final serviceStatusStream = _geolocatorPlatform.getServiceStatusStream();
      serviceStatusStream
          .handleError((error) {
            _serviceStatusStreamSubscription?.cancel();
            _serviceStatusStreamSubscription = null;
          })
          .listen((serviceStatus) {
            if (serviceStatus == ServiceStatus.enabled) {
              _toggleListening();
            } else {
              if (_positionStreamSubscription != null) {
                setState(() {
                  _positionStreamSubscription?.cancel();
                  _positionStreamSubscription = null;
                });
              }
            }
          });
    }
  }

  pegarDistanciaEntrePontos(Position _startPosition, Position position) async {
    var distanciaEntreOsPontosResp = await Geolocator.distanceBetween(
      _startPosition.latitude,
      _startPosition.longitude,
      position.latitude,
      position.longitude,
    );

    setState(() {
      distanciaEntreOsPontos = distanciaEntreOsPontosResp;
    });
  }

  somarDistaciaPercorridaEntrePontos() async {
    var total = totalPercorridoEntrePontos + distanciaEntreOsPontos;

    setState(() {
      totalPercorridoEntrePontos = total;
    });
  }

  somarTotalPercorridoRota() async {
    var total = 0.0;
    total = totalPercorridoRota + distanciaEntreOsPontos;

    setState(() {
      totalPercorridoRota = total;
    });
  }

  somarTotalPercorridoRotaParaSalvar() async {
    var total = 0.0;
    total = totalPercorridoRotaParaSalvar + distanciaEntreOsPontos;

    setState(() {
      totalPercorridoRotaParaSalvar = total;
    });
  }

  guardarCoordenada(Position position) async {
    var limiteMetrosAtualizacao = this.limiteMetrosAtualizacao;

    try {
      var checkConexaoService = Provider.of<CheckConexaoService>(
        context,
        listen: false,
      );

      var corridaGuardarCoordenadasOfflineService =
          Provider.of<CorridaGuardarCoordenadasOfflineService>(
            context,
            listen: false,
          );

      if (distanciaEntreOsPontos > 10) {
        await corridaGuardarCoordenadasOfflineService.execute(
          position,
          distanciaEntreOsPontos,
        );
      }

      if (isSaving) {
        return;
      }

      await checkConexaoService.execute();

      if (checkConexaoService.connectionStatus == true &&
          totalPercorridoEntrePontos >= limiteMetrosAtualizacao) {
        setState(() {
          isSaving = true;
          totalPercorridoEntrePontos = 0.0;
          totalPercorridoRotaParaSalvar = 0.0;
        });

        var coordenadas = await storage.read(key: 'coordenadas');

        var corridaSalvarCoordenadaRotaService =
            Provider.of<CorridaSalvarCoordenadaRotaService>(
              context,
              listen: false,
            );

        await corridaSalvarCoordenadaRotaService.execute(coordenadas);

        setState(() {
          totalPercorridoEntrePontos = 0.0;
        });

        corridaGuardarCoordenadasOfflineService.coordenadas.clear();
        await corridaGuardarCoordenadasOfflineService.save();

        await storage.delete(key: 'coordenadas');

        setState(() {
          isSaving = false;
        });
      } else if (checkConexaoService.connectionStatus == false) {
        setState(() {
          isSaving = false;
        });
      }
    } catch (e) {
      setState(() {
        isSaving = false;
        isCalculando = false;
      });
      throw e;
    }
  }

  setStartPosition(position) async {
    if (_startPosition.latitude == 0) {
      setState(() {
        _startPosition = position;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    var corridaService = Provider.of<CorridaService>(context, listen: true);

    var enderecoDestinoTexto = "";

    if (corridaService.corrida.isNotEmpty && isProximoDestino == false) {
      enderecoDestinoTexto =
          corridaService.corrida["endereco_destino"].toString();
    } else if (isProximoDestino == true) {
      enderecoDestinoTexto = "Viagem sem destino";
    }

    return MediaQuery(
      data: MediaQuery.of(context).copyWith(textScaler: TextScaler.linear(1.0)),
      child: Scaffold(
        backgroundColor: Color.fromARGB(255, 58, 58, 58),
        appBar: AppBar(
          leading: null,
          title: Text(
            "Detalhes",
            style: TextStyle(fontSize: 17, color: Colors.white),
          ),
          centerTitle: true,
          backgroundColor: Color.fromARGB(255, 49, 49, 49),
        ),
        body: WillPopScope(
          onWillPop: () async {
            return false;
          },
          child: Material(
            type: MaterialType.transparency,
            child: new SingleChildScrollView(
              child: Container(
                color: Color.fromARGB(255, 58, 58, 58),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    SizedBox(height: 15),
                    Padding(
                      padding: EdgeInsets.only(left: 15, right: 15),
                      child: Column(
                        children: <Widget>[
                          SizedBox(height: 25),
                          HorizontalSlidableButton(
                            width: double.infinity,
                            height: 70,
                            buttonWidth: 80.0,
                            color: Colors.grey.withOpacity(0.2),
                            buttonColor: Colors.orange,
                            dismissible: false,
                            borderRadius: BorderRadius.circular(6),
                            isRestart: true,
                            label: Center(
                              child: Icon(
                                Icons.arrow_forward_ios,
                                color: Colors.grey[800],
                                size: 30,
                              ),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(''),
                                  Text(
                                    etapas,
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 16,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            onChanged: (position) async {
                              if (position == SlidableButtonPosition.end) {
                                if (parte == 0) {
                                  alterarStatusCorrida(
                                    "5",
                                    "AGUARDANDO O PASSAGEIRO",
                                    corridaService.corrida["id"].toString(),
                                  );
                                }

                                if (parte == 1) {
                                  if (await longeDoEmbarque() == true) {
                                    showDialog<String>(
                                      context: context,
                                      builder:
                                          (BuildContext context) => AlertDialog(
                                            title: const Text('Confirmar'),
                                            content: const Text(
                                              'Você esta longe do local de embarque, tem certeza que deseja iniciar a corrida?',
                                            ),
                                            actions: <Widget>[
                                              InkWell(
                                                onTap: () {
                                                  Navigator.pop(context, "Nao");
                                                },
                                                child: Padding(
                                                  padding: EdgeInsets.all(15),
                                                  child: Text(
                                                    'Não',
                                                    style: TextStyle(
                                                      color: Colors.orange,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              InkWell(
                                                onTap: () {
                                                  Navigator.pop(context, "Sim");
                                                  alterarStatusCorrida(
                                                    "6",
                                                    "A CAMINHO DO ENDERECO DE DESTINO",
                                                    corridaService.corrida["id"]
                                                        .toString(),
                                                  );
                                                  if (panelController
                                                          .isAttached &&
                                                      panelController
                                                          .isPanelOpen) {
                                                    panelController.close();
                                                  }
                                                },
                                                child: Padding(
                                                  padding: EdgeInsets.all(15),
                                                  child: Text(
                                                    'Sim',
                                                    style: TextStyle(
                                                      color: Colors.orange,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                    );
                                  } else {
                                    alterarStatusCorrida(
                                      "6",
                                      "A CAMINHO DO ENDERECO DE DESTINO",
                                      corridaService.corrida["id"].toString(),
                                    );
                                  }
                                }

                                if (parte == 2) {
                                  if (statusCorrida == "6") {
                                    finalizar(
                                      corridaService.corrida["id"].toString(),
                                    );
                                  }
                                }
                              }
                            },
                          ),
                          SizedBox(height: 25),
                          Row(
                            children: <Widget>[
                              Icon(
                                Icons.phone_android,
                                color:
                                    parte == 2 || parte == 3
                                        ? Colors.orange
                                        : Colors.white,
                                size: 20,
                              ),
                              SizedBox(width: 10),
                              Text(
                                corridaService.corrida.isNotEmpty
                                    ? corridaService.corrida['nome'].toString()
                                    : "",
                                style: TextStyle(
                                  color:
                                      parte == 2 || parte == 3
                                          ? Colors.orange
                                          : Colors.white,
                                  fontWeight: FontWeight.w500,
                                  fontSize: 14,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 8),
                          SizedBox(height: 15),
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              if (parte != 2 && parte != 3)
                                Icon(
                                  Icons.person,
                                  color: Colors.orange,
                                  size: 24,
                                ),
                              if (parte != 2 && parte != 3) SizedBox(width: 10),
                              if (parte != 2 && parte != 3)
                                Container(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: <Widget>[
                                      if (parte != 2 && parte != 3)
                                        Container(
                                          child: Text(
                                            "Embarque: ",
                                            style: TextStyle(
                                              fontWeight: FontWeight.w600,
                                              color: Colors.orange,
                                              fontSize: 15,
                                            ),
                                          ),
                                        ),
                                      Container(
                                        width: 290,
                                        child: Text(
                                          corridaService.corrida.isNotEmpty
                                              ? corridaService
                                                  .corrida["endereco_partida"]
                                                  .toString()
                                              : "",
                                          style: TextStyle(
                                            fontWeight: FontWeight.w500,
                                            color: Colors.orange,
                                            fontSize: 16,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                            ],
                          ),
                          if (parte != 2 && parte != 3) SizedBox(height: 15),
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              if (parte != 2 && parte != 3)
                                Icon(Icons.flag, color: Colors.white, size: 24),
                              if (parte != 2 && parte != 3) SizedBox(width: 10),
                              Container(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    Container(
                                      child: Text(
                                        "Destino: ",
                                        style: TextStyle(
                                          fontWeight: FontWeight.w600,
                                          color: Colors.white,
                                          fontSize: 15,
                                        ),
                                      ),
                                    ),
                                    Container(
                                      width:
                                          parte == 2 || parte == 3 ? 350 : 290,
                                      child: Text(
                                        enderecoDestinoTexto,
                                        style: TextStyle(
                                          fontWeight:
                                              parte == 2 || parte == 3
                                                  ? FontWeight.bold
                                                  : FontWeight.w400,
                                          color:
                                              parte == 2 || parte == 3
                                                  ? Colors.orange
                                                  : Colors.white,
                                          fontSize:
                                              parte == 2 || parte == 3
                                                  ? 24
                                                  : 16,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          parte != 2 && parte != 3
                              ? SizedBox(height: 25)
                              : SizedBox(height: 15),
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Icon(
                                Icons.messenger,
                                color: Colors.white,
                                size: 18,
                              ),
                              SizedBox(width: 10),
                              Container(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    Container(
                                      child: Text(
                                        "Observação: ",
                                        style: TextStyle(
                                          fontWeight: FontWeight.w600,
                                          color: Colors.white,
                                          fontSize: 15,
                                        ),
                                      ),
                                    ),
                                    Container(
                                      width:
                                          parte == 2 || parte == 3 ? 350 : 290,
                                      child: Text(
                                        corridaService.corrida.isNotEmpty
                                            ? corridaService
                                                .corrida["complemento_partida"]
                                                .toString()
                                            : "",
                                        style: TextStyle(
                                          fontWeight: FontWeight.w400,
                                          color: Colors.white,
                                          fontSize: 16,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 10),
                          Row(
                            children: <Widget>[
                              Icon(Icons.send, color: Colors.white, size: 18),
                              SizedBox(width: 10),
                              Text(
                                corridaService.corrida.isNotEmpty
                                    ? (corridaService
                                                    .corrida['tempo_estimado_segundos'] /
                                                60)
                                            .round()
                                            .toString() +
                                        " Min"
                                    : "",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w500,
                                  fontSize: 14,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 10),
                          Row(
                            children: <Widget>[
                              Icon(
                                Icons.messenger,
                                color: Colors.white,
                                size: 18,
                              ),
                              SizedBox(width: 10),
                              Text(
                                corridaService.corrida.isNotEmpty
                                    ? "Total: R\$" +
                                        corridaService.corrida["valor_corrida"]
                                            .toString()
                                    : "",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w500,
                                  fontSize: 14,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 25),
                          Row(
                            children: <Widget>[
                              Icon(
                                Icons.directions_car,
                                color: Colors.white,
                                size: 19,
                              ),
                              SizedBox(width: 10),
                              Text(
                                corridaService.corrida.isNotEmpty
                                    ? corridaService
                                        .corrida["categoria"]['name']
                                        .toString()
                                    : "",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w500,
                                  fontSize: 14,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 10),
                          Row(
                            children: <Widget>[
                              Icon(
                                Icons.attach_money,
                                color: Colors.white,
                                size: 19,
                              ),
                              SizedBox(width: 10),
                              Text(
                                corridaService.corrida.isNotEmpty
                                    ? corridaService.corrida["metodo_pagamento"]
                                        .toString()
                                    : "",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w500,
                                  fontSize: 14,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 15),
                          // ✅ Botão de Mensagens disponível em todos os status
                          if (corridaService.corrida['usuario'] != null)
                            Container(
                              child: SizedBox(
                              width: double.infinity,
                              height: 50,
                              child: ElevatedButton(
                                style: ButtonStyle(
                                  backgroundColor:
                                      MaterialStateProperty.all<Color>(
                                        Colors.grey.shade700,
                                      ),
                                  overlayColor:
                                        MaterialStateProperty.resolveWith<
                                          Color?
                                        >((Set<MaterialState> states) {
                                          if (states.contains(
                                            MaterialState.pressed,
                                          ))
                                            return Colors.orange;
                                          return null;
                                        }),
                                ),
                                onPressed: () {
                                  corridaService.mensagens.clear();
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) => MensagemScreen(),
                                    ),
                                  );
                                },
                                child: Text(
                                  "Mensagens",
                                  style: TextStyle(
                                    fontSize: 18,
                                    color: Colors.white,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          SizedBox(height: 15),
                          if (this.statusCorrida == "4" ||
                              this.statusCorrida == "5")
                            Container(
                              child: SizedBox(
                                width: double.infinity,
                                height: 50,
                                child: ElevatedButton(
                                  style: ButtonStyle(
                                    backgroundColor:
                                        MaterialStateProperty.all<Color>(
                                          Colors.grey.shade700,
                                        ),
                                    overlayColor:
                                        MaterialStateProperty.resolveWith<
                                          Color?
                                        >((Set<MaterialState> states) {
                                          if (states.contains(
                                            MaterialState.pressed,
                                          ))
                                            return Colors.orange;
                                          return null;
                                        }),
                                  ),
                                  onPressed: () {
                                    ligar();
                                  },
                                  child: Text(
                                    "Ligar para passageiro",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      fontSize: 18,
                                      color: Colors.white,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          SizedBox(height: 15),
                          SizedBox(
                            width: double.infinity,
                            height: 50,
                            child: ElevatedButton(
                              style: ButtonStyle(
                                backgroundColor:
                                    MaterialStateProperty.all<Color>(
                                      Colors.grey.shade700,
                                    ),
                                overlayColor: MaterialStateProperty.resolveWith<
                                  Color?
                                >((Set<MaterialState> states) {
                                  if (states.contains(MaterialState.pressed))
                                    return Colors.orange;
                                  return null;
                                }),
                              ),
                              onPressed: () {
                                openMap();
                              },
                              child: Text(
                                "Mapa com a rota",
                                style: TextStyle(
                                  fontSize: 18,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ),
                          SizedBox(height: 15),
                          SizedBox(
                            width: double.infinity,
                            height: 50,
                            child: ElevatedButton(
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => FichaTecnicaScreen(),
                                  ),
                                );
                              },
                              style: ButtonStyle(
                                backgroundColor:
                                    MaterialStateProperty.all<Color>(
                                      Colors.grey.shade700,
                                    ),
                                overlayColor: MaterialStateProperty.resolveWith<
                                  Color?
                                >((Set<MaterialState> states) {
                                  if (states.contains(MaterialState.pressed))
                                    return Colors.orange;
                                  return null;
                                }),
                              ),
                              child: Text(
                                "Abrir ficha técnica",
                                style: TextStyle(
                                  fontSize: 18,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ),
                          SizedBox(height: 15),
                          this.statusCorrida == "4" || this.statusCorrida == "5"
                              ? SizedBox(
                                width: double.infinity,
                                height: 50,
                                child: ElevatedButton(
                                  style: ButtonStyle(
                                    backgroundColor:
                                        MaterialStateProperty.all<Color>(
                                          Colors.grey.shade700,
                                        ),
                                    overlayColor:
                                        MaterialStateProperty.resolveWith<
                                          Color?
                                        >((Set<MaterialState> states) {
                                          if (states.contains(
                                            MaterialState.pressed,
                                          ))
                                            return Colors.orange;
                                          return null;
                                        }),
                                  ),
                                  onPressed: () {
                                    Navigator.of(context).push(
                                      MaterialPageRoute(
                                        builder:
                                            (_) => OpcionalCancelamentoScreen(),
                                      ),
                                    );
                                  },
                                  child: Text(
                                    "Cancelar corrida",
                                    style: TextStyle(
                                      fontSize: 18,
                                      color: Colors.white,
                                    ),
                                  ),
                                ),
                              )
                              : SizedBox(),
                          if (this.statusCorrida == "6")
                            Container(
                              child: SizedBox(
                                width: double.infinity,
                                height: 50,
                                child: ElevatedButton(
                                  style: ButtonStyle(
                                    backgroundColor:
                                        MaterialStateProperty.all<Color>(
                                          startContarParada
                                              ? Colors.red
                                              : Colors.grey.shade700,
                                        ),
                                    overlayColor:
                                        MaterialStateProperty.resolveWith<
                                          Color?
                                        >((Set<MaterialState> states) {
                                          if (states.contains(
                                            MaterialState.pressed,
                                          ))
                                            return Colors.orange;
                                          return null;
                                        }),
                                  ),
                                  onPressed: () {
                                    if (startContarParada == true) {
                                      finalizarParada();
                                    } else {
                                      iniciarParada();
                                    }
                                  },
                                  child: Text(
                                    startContarParada
                                        ? "Finalizar parada: " +
                                            tempoParadoTexto
                                        : "adicionar parada: " +
                                            tempoParadoTexto,
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      fontSize: 18,
                                      color: Colors.white,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
