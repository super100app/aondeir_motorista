import 'package:aondeir_motorista/styles/app_colors.dart';
import 'dart:async';
import 'package:aondeir_motorista/service/UsuarioService.dart';
import 'package:aondeir_motorista/service/firebase/FirebaseRealtimeService.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:provider/provider.dart';
import '../../../../service/CorridaService.dart';
import 'package:aondeir_motorista/service/toque/ToqueService.dart';
import '../Corrida/DetalhesCorridaScreen.dart';

const String _nightMapStyle = '''[
  {"elementType": "geometry", "stylers": [{"color": "#242f3e"}]},
  {"elementType": "labels.text.stroke", "stylers": [{"color": "#242f3e"}]},
  {"elementType": "labels.text.fill", "stylers": [{"color": "#746855"}]},
  {"featureType": "administrative.locality", "elementType": "labels.text.fill", "stylers": [{"color": "#d59563"}]},
  {"featureType": "poi", "elementType": "labels.text.fill", "stylers": [{"color": "#d59563"}]},
  {"featureType": "poi.park", "elementType": "geometry", "stylers": [{"color": "#263c3f"}]},
  {"featureType": "poi.park", "elementType": "labels.text.fill", "stylers": [{"color": "#6b9a76"}]},
  {"featureType": "road", "elementType": "geometry", "stylers": [{"color": "#38414e"}]},
  {"featureType": "road", "elementType": "geometry.stroke", "stylers": [{"color": "#212a37"}]},
  {"featureType": "road", "elementType": "labels.text.fill", "stylers": [{"color": "#9ca5b3"}]},
  {"featureType": "road.highway", "elementType": "geometry", "stylers": [{"color": "#746855"}]},
  {"featureType": "road.highway", "elementType": "geometry.stroke", "stylers": [{"color": "#1f2835"}]},
  {"featureType": "road.highway", "elementType": "labels.text.fill", "stylers": [{"color": "#f3d19c"}]},
  {"featureType": "transit", "elementType": "geometry", "stylers": [{"color": "#2f3948"}]},
  {"featureType": "transit.station", "elementType": "labels.text.fill", "stylers": [{"color": "#d59563"}]},
  {"featureType": "water", "elementType": "geometry", "stylers": [{"color": "#17263c"}]},
  {"featureType": "water", "elementType": "labels.text.fill", "stylers": [{"color": "#515c6d"}]},
  {"featureType": "water", "elementType": "labels.text.stroke", "stylers": [{"color": "#17263c"}]}
]''';

class CorridaDetalheMapaScreenMapa extends StatefulWidget {
  final dynamic corrida; // Pass the corrida object

  CorridaDetalheMapaScreenMapa({required this.corrida});

  @override
  _CorridaDetalheMapaScreenMapaState createState() => _CorridaDetalheMapaScreenMapaState();
}

class _CorridaDetalheMapaScreenMapaState extends State<CorridaDetalheMapaScreenMapa> {
  GoogleMapController? mapController;
  Set<Marker> _markers = {};
  Set<Polyline> _polylines = {};
  LatLng? _start;
  LatLng? _end;
  bool _nightMode = false;
  bool _isLoading = false;
  bool _isDisposed = false;
  final Key _mapKey = UniqueKey();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await _setupMarkersAndRoute();
      await firebaseListener();
    });
  }

  firebaseListener() async {
    try {
      var firebaseService = Provider.of<FirebaseRealtimeService>(context, listen: false);
      var usuarioService = Provider.of<UsuarioService>(context, listen: false);
      
      print("🔥 [CorridaDetalheMapa] Iniciando listener Firebase para cancelamento");
      print("🔥 [CorridaDetalheMapa] User ID: ${usuarioService.usuario.id}");
      
      // Iniciar listener para cancelamentos
      firebaseService.startListeningForCorridaCancelada(usuarioService.usuario.id.toString());
      
    } catch (e) {
      print("❌ [CorridaDetalheMapa] Erro ao iniciar listener Firebase: $e");
      throw e;
    }
  }

  
  @override
  void dispose() {
    _isDisposed = true;
    final firebaseService = Provider.of<FirebaseRealtimeService>(context, listen: false);
    
    print("🔥 [CorridaDetalheMapa] Dispose - parando listener Firebase");
    firebaseService.stopListeningForCorridaCancelada();
    
    // Limpar o controller antes de descartar
    if (mapController != null) {
      try {
        mapController!.dispose();
      } catch (e) {
        print('⚠️ Erro ao descartar mapController: $e');
      }
      mapController = null;
    }
    
    super.dispose();
  }

  Future<void> _setupMarkersAndRoute() async {
    // Parse coordinates from Corrida object (fields are String)
    _start = LatLng(
      double.parse(widget.corrida.latitude_partida ?? '0'),
      double.parse(widget.corrida.longitude_partida ?? '0'),
    );
    _end = LatLng(
      double.parse(widget.corrida.latitude_destino ?? '0'),
      double.parse(widget.corrida.longitude_destino ?? '0'),
    );
    if (!mounted) return;
    setState(() {
      _markers = {
        Marker(
          markerId: MarkerId('start'),
          position: _start!,
          infoWindow: InfoWindow(title: 'Embarque'),
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen),
        ),
        Marker(
          markerId: MarkerId('end'),
          position: _end!,
          infoWindow: InfoWindow(title: 'Destino'),
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
        ),
      };
    });

    await _drawRoute();
    _fitCameraToBounds();
  }

  Future<void> _drawRoute() async {
    // Create an arch (curved line) between start and end using a quadratic Bezier curve
    List<LatLng> polylineCoordinates = [];
    if (_start != null && _end != null) {
      int numPoints = 60;
      // Calculate a control point above the midpoint for the arch
      double midLat = (_start!.latitude + _end!.latitude) / 2;
      double midLng = (_start!.longitude + _end!.longitude) / 2;
      // Offset control point perpendicular to the line for arch effect
      double dx = _end!.longitude - _start!.longitude;
      double dy = _end!.latitude - _start!.latitude;
      double controlLat = midLat + 0.15 * dx; // 0.15 is the arch height factor
      double controlLng = midLng - 0.15 * dy;
      for (int i = 0; i <= numPoints; i++) {
        double t = i / numPoints;
        double lat = (1 - t) * (1 - t) * _start!.latitude + 2 * (1 - t) * t * controlLat + t * t * _end!.latitude;
        double lng = (1 - t) * (1 - t) * _start!.longitude + 2 * (1 - t) * t * controlLng + t * t * _end!.longitude;
        polylineCoordinates.add(LatLng(lat, lng));
      }
    }
    if (!mounted) return;
    setState(() {
      _polylines = {
        Polyline(
          polylineId: PolylineId('route'),
          color: Colors.black, // Changed from Colors.blue to Colors.black
          width: 5,
          points: polylineCoordinates,
        ),
      };
    });
  }



  void _fitCameraToBounds() {
    if (_start == null || _end == null || mapController == null) return;
    try {
      LatLngBounds bounds = LatLngBounds(
        southwest: LatLng(
          (_start!.latitude < _end!.latitude) ? _start!.latitude : _end!.latitude,
          (_start!.longitude < _end!.longitude) ? _start!.longitude : _end!.longitude,
        ),
        northeast: LatLng(
          (_start!.latitude > _end!.latitude) ? _start!.latitude : _end!.latitude,
          (_start!.longitude > _end!.longitude) ? _start!.longitude : _end!.longitude,
        ),
      );
      mapController!.animateCamera(CameraUpdate.newLatLngBounds(bounds, 80));
    } catch (e) {
      print("Erro ao ajustar câmera: $e");
    }
  }

  void _onMapCreated(GoogleMapController controller) {
    if (_isDisposed || !mounted) {
      // Se o widget foi descartado, descartar o controller imediatamente
      try {
        controller.dispose();
      } catch (e) {
        print('⚠️ Erro ao descartar controller recém-criado: $e');
      }
      return;
    }
    
    try {
      // Descartar controller anterior se existir
      if (mapController != null) {
        try {
          mapController!.dispose();
        } catch (e) {
          print('⚠️ Erro ao descartar controller anterior: $e');
        }
      }
      
      mapController = controller;
      _fitCameraToBounds();
      mapController?.setMapStyle(_nightMode ? _nightMapStyle : null);
    } catch (e) {
      print('❌ Error in _onMapCreated: $e');
    }
  }

  void _toggleNightMode() {
    setState(() {
      _nightMode = !_nightMode;
    });
    try {
      mapController?.setMapStyle(_nightMode ? _nightMapStyle : null);
    } catch (e) {
      print("Erro ao alternar modo noturno: $e");
    }
  }

  Future<void> _aceitarCorrida(BuildContext context) async {
    setState(() {
      _isLoading = true;
    });
    try {
      final corridaService = Provider.of<CorridaService>(context, listen: false);
      final toqueService = Provider.of<ToqueService>(context, listen: false);
      var resp = await corridaService.aceitarCorrida(widget.corrida.id.toString());
      if (resp == true) {
        corridaService.corridas.clear();
        if (corridaService.corridasPendentes.isNotEmpty) {
          corridaService.corridasPendentes.clear();
        }
        await corridaService.save();
        await corridaService.pegarCorridaAndamento();
        setState(() {
          _isLoading = false;
        });
        toqueService.execute('toques/toque_motorista_corrida_aceita.mp3');
        if (mounted) {
          // Navigator.of(context).pop();
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => DetalhesCorridaScreen()),
          );
        }
      } else {
        setState(() {
          _isLoading = false;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erro ao aceitar corrida. Tente novamente.')),
        );
      }
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erro ao aceitar corrida: ' + e.toString())),
      );
    }
  }

  Future<void> recusarCorridaDisponivel(corridaId, BuildContext context) async {
    try {
      print("CAIU NO RECUSAR CORRIDA");
      print(corridaId);
      final corridaService = Provider.of<CorridaService>(context, listen: false);
      if (corridaId != null) {
        await corridaService.removerCorridaListaById(corridaId.toString());
        await corridaService.save();
      }
      Navigator.of(context).pop();
    } catch (e) {
      print("🚨🚨🚨 ERROOO CAIU NO RECUSAR CORRIDA");
      print(e);
      Navigator.of(context).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    final corrida = widget.corrida;
    return Scaffold(
      appBar: AppBar(
        title: Text('Detalhes da Corrida'),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
        actions: [
          IconButton(
            icon: Icon(_nightMode ? Icons.nightlight_round : Icons.wb_sunny),
            onPressed: _toggleNightMode,
          ),
        ],
      ),
      body: Stack(
        children: [
          GoogleMap(
            key: _mapKey, // Key única para evitar recriação de view
            onMapCreated: _onMapCreated,
            markers: _markers,
            polylines: _polylines,
            initialCameraPosition: CameraPosition(
              target: _start ?? LatLng(0, 0),
              zoom: 14,
            ),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                  elevation: 8,
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            Row(
                              children: <Widget>[
                                Icon(
                                  Icons.person,
                                  color: Colors.orange,
                                  size: 30,
                                ),
                                Text(
                                  '${(corrida.tempo_estimado_segundos! / 60).toStringAsFixed(0)} Min',
                                  style: TextStyle(
                                    fontSize: 22,
                                    fontWeight: FontWeight.w500,
                                    color: Colors.grey[800],
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(
                              width: 130.0,
                              height: 30.0,
                              child: ElevatedButton(
                                style: ButtonStyle(
                                  shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                                    RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(80.0),
                                      side: BorderSide(color: AppColors.buttonBorderSecondary),
                                    ),
                                  ),
                                  backgroundColor: MaterialStateProperty.all(Colors.transparent),
                                  shadowColor: MaterialStateProperty.all(Colors.transparent),
                                ),
                                onPressed: () async {
                                  recusarCorridaDisponivel(corrida.id, context);
                                },
                                child: Text(
                                  'Recusar',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w500,
                                    fontSize: 16,
                                    color: Colors.orange,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                        Text(
                          'R\$' +
                              ((double.parse(corrida.valor_corrida!) + double.parse(corrida.chamadaTarifaValorBase['valor_pedagio']!)).toStringAsFixed(2)),
                          style: TextStyle(
                            fontSize: 30,
                            fontWeight: FontWeight.w500,
                            color: Colors.orange,
                          ),
                        ),
                        Text(
                          "R\$ ${(double.parse(corrida.valor_corrida!) / (((corrida.chamadaDisparo['distancia'] ?? 0) * 1.35 + (corrida.distancia_viagem_metros ?? 0)) / 1000)).toStringAsFixed(2)} por Km estimado",
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w500,
                            color: Colors.grey[800],
                          ),
                        ),
                        if (((corrida.chamadaDisparo['distancia'] * 1.35) / 1000) > 1.5)
                          Text(
                            "Taxa de R\$" +
                                ((double.parse(corrida.valor_corrida!) * 0.10)).toStringAsFixed(2) +
                                " (10%) deslocamento inclusa no valor",
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w500,
                              color: Colors.orange,
                            ),
                          ),
                        SizedBox(height: 10),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            Expanded(
                              child: Row(
                                children: [
                                  Icon(
                                    Icons.accessibility_new,
                                    size: 20,
                                    color: Colors.grey[700],
                                  ),
                                  SizedBox(width: 4),
                                  Text(
                                    "${(((corrida.chamadaDisparo['distancia'] * 1.35) + corrida.distancia_viagem_metros!) / 1000).toStringAsFixed(2)} km estimado",
                                    style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.w500,
                                      color: Colors.grey[800],
                                    ),
                                  ),
                                  SizedBox(width: 10),
                                  Icon(
                                    Icons.person,
                                    size: 20,
                                    color: Colors.grey[700],
                                  ),
                                  SizedBox(width: 4),
                                  Expanded(
                                    child: Text(
                                      "${corrida.nome}",
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.w500,
                                        color: Colors.grey[800],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Row(
                              children: <Widget>[
                                Icon(
                                  Icons.star,
                                  color: Colors.orange,
                                  size: 20,
                                ),
                                SizedBox(width: 4),
                                Text(
                                  "5",
                                  style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.w500,
                                    color: Colors.grey[800],
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                        Divider(),
                        Row(
                          children: <Widget>[
                            Container(
                              alignment: Alignment.topLeft,
                              child: Icon(
                                Icons.person,
                                color: Colors.grey[800],
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.all(5),
                            ),
                            Container(
                              width: 299,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Text(
                                    "Embarque (" +
                                        "${((corrida.chamadaDisparo['distancia'] * 1.35) / 1000).toStringAsFixed(2)} km)",
                                    style: TextStyle(
                                      color: Colors.grey[800],
                                      fontSize: 13,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                  SizedBox(height: 4),
                                  Text(
                                    corrida.endereco_partida!,
                                    style: TextStyle(
                                      color: Colors.grey[700],
                                      fontSize: 14,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 5),
                        Row(
                          children: <Widget>[
                            Container(
                              alignment: Alignment.topLeft,
                              child: Icon(
                                Icons.flag,
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.all(5),
                            ),
                            Container(
                              width: 299,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  corrida.distancia_viagem_metros! >= 1000
                                      ? Text(
                                          "Destino (" +
                                              '${(corrida.distancia_viagem_metros! / 1000).toStringAsFixed(2)}' +
                                              " km)",
                                          style: TextStyle(
                                            color: Colors.grey[800],
                                            fontSize: 13,
                                            fontWeight: FontWeight.w500,
                                          ),
                                        )
                                      : Text(
                                          "Destino (" +
                                              '${corrida.distancia_viagem_metros!}' +
                                              " mestros)",
                                          style: TextStyle(
                                            color: Colors.grey[800],
                                            fontSize: 13,
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                  SizedBox(height: 4),
                                  Text(
                                    corrida.endereco_destino!,
                                    style: TextStyle(
                                      color: Colors.grey[700],
                                      fontSize: 14,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 10),
                        Row(
                          children: <Widget>[
                            Container(
                              padding: EdgeInsets.all(5),
                              decoration: BoxDecoration(
                                border: Border.all(
                                  color: Colors.grey.shade300,
                                ),
                                borderRadius: BorderRadius.circular(20),
                                color: Colors.grey[100],
                              ),
                              child: Text(
                                corrida.categoria['name'],
                                style: TextStyle(
                                  color: Colors.grey[800],
                                ),
                              ),
                            ),
                            SizedBox(width: 8),
                            Container(
                              padding: EdgeInsets.all(5),
                              decoration: BoxDecoration(
                                border: Border.all(
                                  color: Colors.grey.shade300,
                                ),
                                borderRadius: BorderRadius.circular(20),
                                color: Colors.grey[100],
                              ),
                              child: Text(
                                corrida.metodo_pagamento!,
                                style: TextStyle(
                                  color: Colors.grey[800],
                                ),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 20),
                        SizedBox(
                          width: double.infinity,
                          height: 50,
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              elevation: 0,
                              backgroundColor: AppColors.buttonSecondary,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(6),
                                side: BorderSide(
                                  color: Colors.orange,
                                ),
                              ),
                              minimumSize: Size(100, 40),
                            ),
                            onPressed: _isLoading
                                ? null
                                : () async {
                                    await _aceitarCorrida(context);
                                  },
                            child: _isLoading
                                ? SizedBox(
                                    width: 24,
                                    height: 24,
                                    child: CircularProgressIndicator(
                                      valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                                      strokeWidth: 2,
                                    ),
                                  )
                                : Text(
                                    "Aceitar corrida",
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 18,
                                    ),
                                  ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
} 