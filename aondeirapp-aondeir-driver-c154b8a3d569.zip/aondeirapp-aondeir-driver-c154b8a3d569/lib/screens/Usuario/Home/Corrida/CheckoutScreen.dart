import 'package:aondeir_motorista/styles/app_colors.dart';
import 'package:aondeir_motorista/screens/Modal/ModalPadraoClick.dart';
import 'package:aondeir_motorista/screens/Usuario/BottomNavigationBar/NavigationScreen.dart';
import 'package:aondeir_motorista/service/UsuarioService.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_masked_text2/flutter_masked_text2.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../../../../models/Transaca.dart';
import '../../../../service/CorridaService.dart';
import '../../../../service/SocketService.dart';
import '../../../../service/corrida/CorridaBuscarDuracaoParadaService.dart';

class CheckoutScreen extends StatefulWidget {
  const CheckoutScreen({super.key});

  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  String qrCodeData = '';
  String qrCode = '';
  String valorRecarga = '';
  String tempoParadoTexto = '00:00';
  String formaPagamentoTexto = '';
  String formaPagamentoSelecionado = 'DINHEIRO';
  String textoPagamento =
      "Aguarde o pagamento do passageiro para encerrar a viagem!";

  var controller = MoneyMaskedTextController(thousandSeparator: '.');
  bool isLoading = false;

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      await fillFormaPagamento();
      await pagarViaCartao();
      await socket();
      await pegarDuracaoParada();
      gerarCodigo();
    });


  }

  socket() async {
    try {
      print("⏳⏳⏳ Iniciou o metodo ⏳⏳⏳");
      var corridaService = Provider.of<CorridaService>(context, listen: false);
      var socketService = Provider.of<SocketService>(context, listen: false);

      socketService.socket?.on("corridaAndamento" + corridaService.corrida['id'].toString(),
        (data) async => {
            print("⏳⏳⏳ corridaAndamento ⏳⏳⏳"),
            corridaService.corrida = data['corrida'],
            await corridaService.save(),

            await limparQrCode(),
            await fillFormaPagamento(),
            if(corridaService.corrida['metodo_pagamento'] == "PIX") {
              gerarCodigo()
            },
            print(corridaService.corrida['status']['id'].toString()),
            print(data['statusPedido']),
            if(corridaService.corrida['status']['id'].toString() == '7' && data['statusPedido'] == 'PAGO') {
              pagarCorrida()
            }
      });
    } catch (e) {
      print("❌ Erro ao configurar socket: $e");
    }
  }
  
  alterarMetodoEpagar() async {
     var corridaService = Provider.of<CorridaService>(context, listen: false);
      corridaService.trocarFormaPagamentoPagar();
      await setFormaPagamenCorrida('DINHEIRO');
      pagarCorrida();
  }

  fillFormaPagamento() async {
    var corridaService = Provider.of<CorridaService>(context, listen: false);
    if (corridaService.corrida.isEmpty) {
      return;
    }

    if (corridaService.corrida['metodo_pagamento'] == "PIX") {
      formaPagamentoTexto = "Pagamento via Pix";
      formaPagamentoSelecionado = corridaService.corrida['metodo_pagamento'];
    } else if (corridaService.corrida['metodo_pagamento'] == "DINHEIRO") {
      formaPagamentoTexto = "Pagamento em DINHEIRO";
      formaPagamentoSelecionado = corridaService.corrida['metodo_pagamento'];
    } else if (corridaService.corrida['metodo_pagamento'] == "MAQUININHA") {
      formaPagamentoTexto = "Pagamento via MAQUININHA";
      formaPagamentoSelecionado = corridaService.corrida['metodo_pagamento'];
    } else if (corridaService.corrida['metodo_pagamento'] == "CREDITO") {
      formaPagamentoTexto = "Pagamento via CARTÃO DE CRÉDITO";
      formaPagamentoSelecionado = corridaService.corrida['metodo_pagamento'];
      textoPagamento = "Aguarde, estamos processando o pagamento...";
    }

    setState(() {
      formaPagamentoTexto = formaPagamentoTexto;
      formaPagamentoSelecionado = formaPagamentoSelecionado;
    });
  }

  setFormaPagamenCorrida(formaPagamento) async {
    var corridaService = Provider.of<CorridaService>(context, listen: false);
    corridaService.corrida['metodo_pagamento'] = formaPagamento;
    await corridaService.save();
  }

  setFormaPagamentoTexto(formaPagamento) async {
    var texto = "";

    if (formaPagamento == "CREDITO") {
      texto = "Aguarde, estamos processando o pagamento...";
    } else {
      texto = "Aguarde o pagamento do passageiro para encerrar a viagem!";
    }

    setState(() {
      formaPagamentoTexto = "Pagamento via " + formaPagamento;
      formaPagamentoSelecionado = formaPagamento;
      textoPagamento = texto;
    });
  }

  showModalLoaderPagamento(String message) async {
    showDialog<String>(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        title: Text(
          'Carregando!',
          textAlign: TextAlign.center, // Centraliza o texto
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircularProgressIndicator(
              color: Color(0xFFEF8F19),
            ),
            SizedBox(
                height: 10), // Espaçamento entre o ícone e o Widget adicional
            Text(
              message,
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.black),
            ),
          ],
        ),
        actions: <Widget>[
          InkWell(
            onTap: () {
              Navigator.pop(context, "Fechar");
            },
            child: Padding(
              padding: EdgeInsets.only(bottom: 10, left: 15, right: 15),
              child: Text(
                'Fechar',
                style: TextStyle(color: Colors.orange),
              ),
            ),
          ),
        ],
      ),
    );
  }

  limparQrCode() async {
    setState(() {
      qrCodeData = '';
      qrCode = '';
    });
  }

  showLoader(texto) {
    if (isLoading == true) {
      showDialog<String>(
        barrierDismissible: false,
        context: context,
        builder: (BuildContext context) => AlertDialog(
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(12.0))),
          title: Container(
            child: Text(
              texto,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 13,
                color: Colors.grey[700],
              ),
            ),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(), // Indicador de progresso circular
              SizedBox(
                  height:
                      16), // Espaçamento entre o indicador de progresso e o texto
              Text('Carregando...'), // Texto "Carregando"
            ],
          ),
        ),
      );
    }
  }

  gerarCodigo() async {
    try {
      var corridaService = Provider.of<CorridaService>(context, listen: false);

      if (corridaService.corrida['metodo_pagamento'] == "PIX") {
        final transacao = await corridaService.gerarQrCode();
        await fetchQrCodeData(transacao);
      }
    } catch (e) {
      throw e;
    }
  }

  copiarCodigo() async {
    await Clipboard.setData(ClipboardData(text: qrCode));
    final snackBar = SnackBar(
      content: Text('Código QR copiado para a área de transferência!'),
    );
    ScaffoldMessenger.of(context).showSnackBar(snackBar);
  }

  Widget renderQrCodeCopiaCola() {
  return Column(
    children: [
      SizedBox(height: 25),
      SizedBox(
        width: double.infinity,
        height: 60,
        child: TextField(
          readOnly: true, 
          toolbarOptions: const ToolbarOptions(
            copy: true,
            paste: true,
            cut: true,
            selectAll: true,
          ),
          controller: TextEditingController(
            text: qrCode,
          ),
          decoration: InputDecoration(
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(
                color: Color(0xFFF2F2F2),
              ),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(
                color: Color(0xFFF2F2F2),
              ),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(
                color: Color(0xFFF2F2F2),
              ),
            ),
            filled: true,
            fillColor: const Color(0xFFF2F2F2),
          ),
        ),
      ),
      const SizedBox(height: 15),
      InkWell(
          onTap: () {
            copiarCodigo();
          },
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: const <Widget>[
              Text(
                "Copiar Código",
                style: TextStyle(
                  fontSize: 20,
                  color: Colors.orange,
                  fontWeight: FontWeight.w600,
                ),
              ),
              SizedBox(width: 8),
              Icon(
                Icons.content_copy,
                color: Colors.orange,
                size: 30,
              ),
            ],
          ),
        ),
      const SizedBox(height: 15),
    ],
  );
}

  Future<void> fetchQrCodeData(Transacao transacao) async {
    try {
      setState(() {
        qrCode = transacao.qr_code;
        qrCodeData = transacao.qr_code_url;
      });
    } catch (e) {
      throw e;
    }
  }

  pagarViaCartao() async {
    try {
      await Future.delayed(Duration(seconds: 3));
      final corridaService =
          Provider.of<CorridaService>(context, listen: false);

      if (corridaService.corrida['metodo_pagamento'] == "CREDITO") {
        await corridaService.pagarViaCartao();
        setState(() {
          textoPagamento =
              "Pagamento efetuado. Para encerrar a viagem clique no botão abaixo!";
        });
        showDialog<String>(
            context: context,
            builder: (BuildContext context) => ModalPadraoClick(
                  message: textoPagamento,
                  isicon: true,
                  btnAcao: true,
                  btnAcaoTexto: "Confirmar!",
                  btnAcaoClick: () {
                    pagarCorrida();
                  },
                ));
      }
    } catch (e) {
      setState(() {
        textoPagamento = e.toString();
      });
      showDialog<String>(
          context: context,
          builder: (BuildContext context) => ModalPadraoClick(
                message: e.toString(),
                btnFechar: true,
              ));
    }
  }

  void pagarCorrida() async {
    try {
      final corridaService =
          Provider.of<CorridaService>(context, listen: false);

      setState(() {
        isLoading = true;
      });

      await showLoader("Confirmando pagamento...");
      await Future.delayed(Duration(seconds: 1));

      if (corridaService.corrida['metodo_pagamento'] == "DINHEIRO" ||
          corridaService.corrida['metodo_pagamento'] == "MAQUININHA") {
        await corridaService
            .pagarCorrida(corridaService.corrida['id'].toString());
      }

      Navigator.of(context).pop();
      setState(() {
        isLoading = false;
      });

      final usuarioService =
          Provider.of<UsuarioService>(context, listen: false);
      usuarioService.usuario.motorista['situacao'] = 'LIVRE';
      await usuarioService.save();

      await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => NavigationScreen(),
        ),
      );
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      Navigator.of(context).pop();
      showModalAlertError(
          "Ops! Ocorreu um erro ao confirmar o pagamento da corrida.");
    }
  }

  showModalAlertError(String message) async {
    showDialog<String>(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        title: Text(
          'Ops!',
          textAlign: TextAlign.center, // Centraliza o texto
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.error,
              color: Colors.red,
              size: 50,
            ),
            SizedBox(
                height: 10), // Espaçamento entre o ícone e o Widget adicional
            Text(
              message,
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.black),
            ),
          ],
        ),
        actions: <Widget>[
          InkWell(
            onTap: () {
              Navigator.pop(context, "Fechar");
            },
            child: Padding(
              padding: EdgeInsets.only(bottom: 10, left: 15, right: 15),
              child: Text(
                'Fechar',
                style: TextStyle(color: Colors.orange),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void voltarHome() async {
    try {
      setState(() {
        isLoading = true;
      });

      await showLoader("Carregando a home...");
      await Future.delayed(Duration(seconds: 1));

      Navigator.of(context).pop();
      setState(() {
        isLoading = false;
      });

      await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => NavigationScreen(),
        ),
      );
    } catch (e) {
      throw Exception('Failed to load data');
    }
  }

  pegarDuracaoParada() async {
    var corridaBuscarDuracaoParadaService =
        Provider.of<CorridaBuscarDuracaoParadaService>(context, listen: false);

    await corridaBuscarDuracaoParadaService.execute();

    var totalSegundos =
        corridaBuscarDuracaoParadaService.tempoTotalParadaSegundos;

    if (totalSegundos > 0) {
      var horas = totalSegundos ~/ 3600;
      var minutos = (totalSegundos % 3600) ~/ 60;
      var segundosRestantes = totalSegundos % 60;

      var texto = horas > 0
          ? horas.toString().padLeft(2, '0') +
              ":" +
              minutos.toString().padLeft(2, '0') +
              ":" +
              segundosRestantes.toString().padLeft(2, '0')
          : minutos.toString().padLeft(2, '0') + // Adicione padLeft aqui
              ":" +
              segundosRestantes.toString().padLeft(2, '0');

      setState(() {
        tempoParadoTexto = texto;
      });
    }
  }


  @override
  Widget build(BuildContext context) {
    var corridaService = Provider.of<CorridaService>(context, listen: true);
    var formatador = NumberFormat.currency(locale: 'pt_BR', symbol: 'R\$');
    var valorTotalPorParada = 0.0;
    var valorTotalMinutoParada = 0.0;
    var totalParadaAdicional = 0.0;
    var totalParadaAdicionalTexto = 'R\$ 0.00';
    var valorPedagioTexto = '0';
    var totalTarifaTexto = 'R\$ 0.00';
    var totalDescontoTexto = 'R\$ 0.00';
    var totalAlteracaoTrajetoTexto = 'R\$ 0.00';
    var totalPrevistoTexto = 'R\$ 0.00';
    var totalCorridaTexto = 'R\$ 0.00';
    var totalValorKmRodadoMaisTexto = 'R\$ 0.00';
    var totalTaxaCancelamentoValorTexto = 'R\$ 0.00';
    var temTaxaCancelamento = false;

    if (corridaService.corrida.isNotEmpty) {
      valorTotalPorParada = double.parse(
          corridaService.corrida['valor_total_por_parada'].toString());
      valorTotalMinutoParada = double.parse(
          corridaService.corrida['valor_total_minuto_parada'].toString());
      totalParadaAdicional = valorTotalPorParada + valorTotalMinutoParada;

      totalParadaAdicionalTexto = formatador.format(totalParadaAdicional);
      totalTarifaTexto = formatador.format(
          double.parse(corridaService.corrida['valor_taxa'].toString()));
      totalDescontoTexto = formatador.format(double.parse(
          corridaService.corrida['valor_desconto_aplicado'].toString()));
      totalAlteracaoTrajetoTexto = formatador.format(double.parse(
          corridaService.corrida['valor_alteracao_trajeto'].toString()));
      totalValorKmRodadoMaisTexto = formatador.format(double.parse(
          corridaService.corrida['valor_km_adicional'].toString()));
      totalPrevistoTexto = formatador.format(
          double.parse(corridaService.corrida['valor_estimado'].toString()));

   if (double.parse(corridaService.corrida['chamadaTarifaValorBase']['valor_pedagio'].toString()) != "0.00") {
      valorPedagioTexto = formatador.format(
        double.parse(corridaService.corrida['chamadaTarifaValorBase']['valor_pedagio'].toString()));
    } else {
      valorPedagioTexto = '0'; 
    }

      if (corridaService.corrida['taxa_cancelamento_valor'] != null) {
        temTaxaCancelamento = true;
        totalTaxaCancelamentoValorTexto = formatador.format(double.parse(
            corridaService.corrida['taxa_cancelamento_valor'].toString()));
        var valorCorridaDouble =
            double.parse(corridaService.corrida['valor_corrida'].toString());

        totalCorridaTexto =
            formatador.format((valorCorridaDouble));
      } else {
        totalCorridaTexto = formatador.format(
            double.parse(corridaService.corrida['valor_corrida'].toString()));
      }
    }

    return MediaQuery(
      data: MediaQuery.of(context).copyWith(textScaler: TextScaler.linear(1.0)),
      child:Scaffold(
      backgroundColor: Color.fromARGB(255, 58, 58, 58),
      appBar: AppBar(
        title: Text(
          "Pagamento da corrida",
          style: TextStyle(fontSize: 17),
        ),
        centerTitle: true,
        backgroundColor: Color.fromARGB(255, 49, 49, 49),
        automaticallyImplyLeading: false,
      ),
      body: WillPopScope(
        onWillPop: () async {
          // Navigator.popUntil(context, ModalRoute.withName('/'));
          return false;
        },
        child: Padding(
          padding: EdgeInsets.only(left: 15, top: 35, right: 15),
          child: Material(
            type: MaterialType.transparency,
            child: new SingleChildScrollView(
              child: Container(
                // alignment: Alignment.center,
                color: Color.fromARGB(255, 58, 58, 58),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    Container(
                      child: Text(
                        "Dados de pagamento ",
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 17,
                        ),
                      ),
                    ),
                    qrCodeData.isNotEmpty
                        ? SizedBox(height: 15)
                        : SizedBox(height: 15),
                    Container(
                      child: Text(
                        formaPagamentoTexto,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w400,
                          fontSize: 16,
                        ),
                      ),
                    ),
                    qrCodeData.isNotEmpty
                        ? SizedBox(height: 15)
                        : SizedBox(height: 15),
                    if (corridaService.corrida['metodo_pagamento'] == "PIX")
                      qrCodeData.isNotEmpty
                          ? Container(
                            child: Image.network(
                              qrCodeData,
                              width: 200,
                              height: 200,
                              fit: BoxFit.contain,
                            ),
                          )
                          : SizedBox(),
                    qrCode.isNotEmpty ? renderQrCodeCopiaCola() : SizedBox(),
                    Container(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: <Widget>[
                          Text(
                            "Valor previsto: " + totalPrevistoTexto,
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w400,
                              color: Colors.white,
                            ),
                          ),
                          Text(
                            "Alteração de Trajeto: " +
                                totalAlteracaoTrajetoTexto,
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w400,
                              color: Colors.white,
                            ),
                          ),
                          Text(
                            "Desconto aplicado: " + totalDescontoTexto,
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w400,
                              color: Colors.white,
                            ),
                          ),
                          Text(
                            "Taxas do aplicativo (%): " + totalTarifaTexto,
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w400,
                              color: Colors.white,
                            ),
                          ),
                          Text(
                            "Km adicional: " + totalValorKmRodadoMaisTexto,
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w400,
                              color: Colors.white,
                            ),
                          ),
                          Text(
                            "Parada adicional " +
                                tempoParadoTexto +
                                " : " +
                                totalParadaAdicionalTexto,
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w400,
                              color: Colors.white,
                            ),
                          ),
                          if (valorPedagioTexto != '0')
                            Text(
                              "Valor Pedagio: " + valorPedagioTexto,
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w400,
                                color: Colors.white,
                              ),
                            ),
                          if (formaPagamentoSelecionado == "PIX" || formaPagamentoSelecionado == "CREDITO")
                            GestureDetector(
                              onTap: () async {
                                await alterarMetodoEpagar();
                              },
                              child: Container(
                                padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                margin: EdgeInsets.only(top: 10),
                                decoration: BoxDecoration(
                                  color: Color(0xFFFFF4E5), // um tom claro do laranja para dar leve fundo
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(color: Color(0xFFEF8F19), width: 0.5), // borda discreta
                                ),
                                child: Text(
                                  'Recebi em dinheiro',
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w400,
                                    color: Color(0xFFEF8F19),
                                  ),
                                ),
                              ),
                            ),
                          if (temTaxaCancelamento)
                            Text(
                              "Taxa de cancelamento: " +
                                  totalTaxaCancelamentoValorTexto,
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w400,
                                color: Colors.white,
                              ),
                            ),
                          Text(
                            "",
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w400,
                              color: Colors.white,
                            ),
                          ),
                          Text(
                            "",
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w400,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      child: Text(
                        "Valor da Viagem",
                        style: TextStyle(
                          fontSize: 15,
                          color: Colors.white,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ),
                    Container(
                        child: Text(
                      totalCorridaTexto,
                      style: TextStyle(
                        fontSize: 45,
                        color: Colors.orange,
                        fontWeight: FontWeight.w700,
                      ),
                    )),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Flexible(
                          child: CircularProgressIndicator(
                            color: Color(0xFFEF8F19),
                          ),
                        ),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Container(
                          margin: EdgeInsets.only(top: 10),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: <Widget>[
                              Text(
                                textoPagamento,
                                style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w400,
                                    color: Color(0xFFEF8F19)),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 10),
                    if (formaPagamentoSelecionado == "DINHEIRO" ||
                        formaPagamentoSelecionado == "MAQUININHA")
                      SizedBox(
                        width: double.infinity, // <-- Your width
                        height: 50, // <-- Your height
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            elevation: 0,
                            backgroundColor: AppColors.buttonSecondary,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(6),
                              side: BorderSide(color: AppColors.buttonBorderSecondary),
                            ),
                            minimumSize: Size(100, 40), //////// HERE
                          ),
                          onPressed: () {
                            pagarCorrida();
                          },
                          child: Text(
                            "Confirmar",
                            style: TextStyle(fontSize: 18, color: Colors.white,),
                          ),
                        ),
                      ),
                    

                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    ));
  }
}
