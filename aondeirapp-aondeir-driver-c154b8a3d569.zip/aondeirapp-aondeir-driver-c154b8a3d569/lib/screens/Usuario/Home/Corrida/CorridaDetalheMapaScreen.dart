import 'package:aondeir_motorista/styles/app_colors.dart';
import 'dart:async';
import 'package:aondeir_motorista/service/UsuarioService.dart';
import 'package:aondeir_motorista/service/firebase/FirebaseRealtimeService.dart';
import 'package:aondeir_motorista/service/CorridaService.dart';
import 'package:aondeir_motorista/screens/Usuario/BottomNavigationBar/NavigationScreen.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import 'package:provider/provider.dart';

const String _nightMapStyle = '''[
  {"elementType": "geometry", "stylers": [{"color": "#242f3e"}]},
  {"elementType": "labels.text.stroke", "stylers": [{"color": "#242f3e"}]},
  {"elementType": "labels.text.fill", "stylers": [{"color": "#746855"}]},
  {"featureType": "administrative.locality", "elementType": "labels.text.fill", "stylers": [{"color": "#d59563"}]},
  {"featureType": "poi", "elementType": "labels.text.fill", "stylers": [{"color": "#d59563"}]},
  {"featureType": "poi.park", "elementType": "geometry", "stylers": [{"color": "#263c3f"}]},
  {"featureType": "poi.park", "elementType": "labels.text.fill", "stylers": [{"color": "#6b9a76"}]},
  {"featureType": "road", "elementType": "geometry", "stylers": [{"color": "#38414e"}]},
  {"featureType": "road", "elementType": "geometry.stroke", "stylers": [{"color": "#212a37"}]},
  {"featureType": "road", "elementType": "labels.text.fill", "stylers": [{"color": "#9ca5b3"}]},
  {"featureType": "road.highway", "elementType": "geometry", "stylers": [{"color": "#746855"}]},
  {"featureType": "road.highway", "elementType": "geometry.stroke", "stylers": [{"color": "#1f2835"}]},
  {"featureType": "road.highway", "elementType": "labels.text.fill", "stylers": [{"color": "#f3d19c"}]},
  {"featureType": "transit", "elementType": "geometry", "stylers": [{"color": "#2f3948"}]},
  {"featureType": "transit.station", "elementType": "labels.text.fill", "stylers": [{"color": "#d59563"}]},
  {"featureType": "water", "elementType": "geometry", "stylers": [{"color": "#17263c"}]},
  {"featureType": "water", "elementType": "labels.text.fill", "stylers": [{"color": "#515c6d"}]},
  {"featureType": "water", "elementType": "labels.text.stroke", "stylers": [{"color": "#17263c"}]}
]''';

class CorridaDetalheMapaScreen extends StatefulWidget {
  final dynamic corrida; // Pass the corrida object
  final Function(String)? onAceitar;
  final Future<void> Function(String, BuildContext)? onRecusar;

  CorridaDetalheMapaScreen({required this.corrida, this.onAceitar, this.onRecusar});

  @override
  _CorridaDetalheMapaScreenState createState() => _CorridaDetalheMapaScreenState();
}

class _CorridaDetalheMapaScreenState extends State<CorridaDetalheMapaScreen> {
  GoogleMapController? mapController;
  Set<Marker> _markers = {};
  Set<Polyline> _polylines = {};
  LatLng? _start;
  LatLng? _end;
  bool _nightMode = false;
  bool _verificacaoEmAndamento = false;
  Timer? _verificacaoTimer;
  bool _isDisposed = false;
  final Key _mapKey = UniqueKey();

  @override
  void initState() {
    super.initState();
    // Resetar variáveis de controle para estado inicial
    _verificacaoEmAndamento = false;
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await _setupMarkersAndRoute();
      await firebaseListener();
    });
  }

  firebaseListener() async {
    try {
      var usuarioService = Provider.of<UsuarioService>(context, listen: false);
      var firebaseService = Provider.of<FirebaseRealtimeService>(context, listen: false);
      
      print("🔥 [CorridaDetalheMapa] Iniciando listener Firebase para cancelamentos");
      print("👤 [CorridaDetalheMapa] Usuário ID: ${usuarioService.usuario.id}");
      print("🆔 [CorridaDetalheMapa] ID da corrida atual: ${widget.corrida.id}");
      
      // Iniciar listener para cancelamentos de corrida via Firebase com callback
      firebaseService.startListeningForCorridaCanceladaWithCallback(
        usuarioService.usuario.id.toString(),
        (data) async {
          print("🔥 [CorridaDetalheMapa] Cancelamento recebido via Firebase: $data");
          
          // Processar cancelamento localmente
          await _processarCancelamentoLocal(data);
        }
      );
      
      // Iniciar verificação periódica da lista de corridas
      _iniciarVerificacaoPeriodica();
      
      print("✅ [CorridaDetalheMapa] Listener Firebase iniciado com sucesso");
      
    } catch (e) {
      print("❌ [CorridaDetalheMapa] Erro ao iniciar listener Firebase: $e");
      throw e;
    }
  }

  // Inicia verificação periódica da lista de corridas
  void _iniciarVerificacaoPeriodica() {
    try {
      // Cancelar timer anterior se existir
      _verificacaoTimer?.cancel();
      
      print("📋 [CorridaDetalheMapa] Iniciando verificação periódica da lista de corridas");
      print("🆔 [CorridaDetalheMapa] Verificando corrida ID: ${widget.corrida.id}");
      
      // Verificar a cada 2 segundos
      _verificacaoTimer = Timer.periodic(Duration(seconds: 2), (timer) {
        if (!mounted) {
          print("⚠️ [CorridaDetalheMapa] Widget não está montado - cancelando timer");
          timer.cancel();
          return;
        }
        
        _verificarCorridaDisponivel();
      });
      
    } catch (e) {
      print("❌ [CorridaDetalheMapa] Erro ao iniciar verificação periódica: $e");
    }
  }
  
  // Verifica se a corrida ainda está disponível
  void _verificarCorridaDisponivel() {
    try {
      var corridaService = Provider.of<CorridaService>(context, listen: false);
      
      // Evitar múltiplas execuções simultâneas
      if (_verificacaoEmAndamento) {
        print("📋 [CorridaDetalheMapa] Verificação já em andamento - ignorando");
        return;
      }
      
      _verificacaoEmAndamento = true;
      
      var corridas = corridaService.corridas;
      print("📋 [CorridaDetalheMapa] Verificando lista: ${corridas.length} corridas");
      print("📋 [CorridaDetalheMapa] IDs das corridas: ${corridas.map((c) => c.id).toList()}");
      print("📋 [CorridaDetalheMapa] Nossa corrida ID: ${widget.corrida.id}");
      
      // Verificar se a corrida atual ainda está na lista
      bool corridaExiste = corridas.any((corrida) {
        return corrida.id.toString() == widget.corrida.id.toString();
      });
      
      if (!corridaExiste) {
        print("🚫 [CorridaDetalheMapa] Corrida ${widget.corrida.id} não está mais na lista - fechando tela");
        _verificacaoTimer?.cancel();
        _fecharTelaCorridaNaoDisponivel();
      } else {
        print("✅ [CorridaDetalheMapa] Corrida ${widget.corrida.id} ainda está disponível - mantendo tela aberta");
      }
      
      // Resetar flag de verificação
      _verificacaoEmAndamento = false;
      
    } catch (e) {
      print("❌ [CorridaDetalheMapa] Erro ao verificar corrida disponível: $e");
      _verificacaoEmAndamento = false;
    }
  }

  // Fecha a tela quando a corrida não está mais disponível
  void _fecharTelaCorridaNaoDisponivel() {
    // if (!mounted) return;
    
    // print("🔄 [CorridaDetalheMapa] Fechando tela - corrida não disponível");
    
    // // Usar addPostFrameCallback para evitar erro de navegação
    // WidgetsBinding.instance.addPostFrameCallback((_) {
    //   if (mounted) {
    //     // Navegar para a tela de navegação (home)
    //     Navigator.pushReplacement(
    //       context,
    //       MaterialPageRoute(builder: (_) => NavigationScreen()),
    //     );
    //   }
    // });
  }

  // Processa cancelamento localmente na tela
  Future<void> _processarCancelamentoLocal(Map<dynamic, dynamic> data) async {
    try {
      print("🚫 [CorridaDetalheMapa] Processando cancelamento local");
      
      // Verificar se ainda estamos na tela correta
      if (!mounted) {
        print("⚠️ [CorridaDetalheMapa] Widget não está montado - ignorando");
        return;
      }
      
      // Fechar a tela atual e voltar para a home
      print("🔄 [CorridaDetalheMapa] Fechando tela e voltando para home...");
      
      // Usar addPostFrameCallback para evitar erro de navegação
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          // Navegar para a tela de navegação (home)
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (_) => NavigationScreen()),
          );
        }
      });
      
      print("✅ [CorridaDetalheMapa] Cancelamento processado com sucesso");
      
    } catch (error) {
      print("❌ [CorridaDetalheMapa] Erro ao processar cancelamento local: $error");
    }
  }

  @override
  void dispose() {
    _isDisposed = true;
    var firebaseService = Provider.of<FirebaseRealtimeService>(context, listen: false);
    var corridaService = Provider.of<CorridaService>(context, listen: false);
    
    print("🔥 CorridaDetalheMapaScreen: Dispose - parando listener Firebase");
    firebaseService.stopListeningForCorridaCancelada();
    
    // Cancelar timer de verificação
    _verificacaoTimer?.cancel();
    _verificacaoTimer = null;
    
    // Resetar variáveis de controle para estado inicial
    _verificacaoEmAndamento = false;
    
    // Resetar flag do CorridaService para estado inicial
    corridaService.listaAtualizada = false;
    corridaService.save();
    
    // Limpar o controller antes de descartar
    if (mapController != null) {
      try {
        mapController!.dispose();
      } catch (e) {
        print('⚠️ Erro ao descartar mapController: $e');
      }
      mapController = null;
    }
    
    super.dispose();
  }

  Future<void> _setupMarkersAndRoute() async {
    // Parse coordinates from Corrida object (fields are String)
    _start = LatLng(
      double.parse(widget.corrida.latitude_partida ?? '0'),
      double.parse(widget.corrida.longitude_partida ?? '0'),
    );
    _end = LatLng(
      double.parse(widget.corrida.latitude_destino ?? '0'),
      double.parse(widget.corrida.longitude_destino ?? '0'),
    );

    setState(() {
      _markers = {
        Marker(
          markerId: MarkerId('start'),
          position: _start!,
          infoWindow: InfoWindow(title: 'Embarque'),
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen),
        ),
        Marker(
          markerId: MarkerId('end'),
          position: _end!,
          infoWindow: InfoWindow(title: 'Destino'),
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
        ),
      };
    });

    await _drawRoute();
    _fitCameraToBounds();
  }

  Future<void> _drawRoute() async {
    // Create an arch (curved line) between start and end using a quadratic Bezier curve
    List<LatLng> polylineCoordinates = [];
    if (_start != null && _end != null) {
      int numPoints = 60;
      // Calculate a control point above the midpoint for the arch
      double midLat = (_start!.latitude + _end!.latitude) / 2;
      double midLng = (_start!.longitude + _end!.longitude) / 2;
      // Offset control point perpendicular to the line for arch effect
      double dx = _end!.longitude - _start!.longitude;
      double dy = _end!.latitude - _start!.latitude;
      double controlLat = midLat + 0.15 * dx; // 0.15 is the arch height factor
      double controlLng = midLng - 0.15 * dy;
      for (int i = 0; i <= numPoints; i++) {
        double t = i / numPoints;
        double lat = (1 - t) * (1 - t) * _start!.latitude + 2 * (1 - t) * t * controlLat + t * t * _end!.latitude;
        double lng = (1 - t) * (1 - t) * _start!.longitude + 2 * (1 - t) * t * controlLng + t * t * _end!.longitude;
        polylineCoordinates.add(LatLng(lat, lng));
      }
    }
    setState(() {
      _polylines = {
        Polyline(
          polylineId: PolylineId('route'),
          color: Colors.black, // Changed from Colors.blue to Colors.black
          width: 5,
          points: polylineCoordinates,
        ),
      };
    });
  }


  void _fitCameraToBounds() {
    if (_start == null || _end == null || mapController == null) return;
    LatLngBounds bounds = LatLngBounds(
      southwest: LatLng(
        (_start!.latitude < _end!.latitude) ? _start!.latitude : _end!.latitude,
        (_start!.longitude < _end!.longitude) ? _start!.longitude : _end!.longitude,
      ),
      northeast: LatLng(
        (_start!.latitude > _end!.latitude) ? _start!.latitude : _end!.latitude,
        (_start!.longitude > _end!.longitude) ? _start!.longitude : _end!.longitude,
      ),
    );
    mapController!.animateCamera(CameraUpdate.newLatLngBounds(bounds, 80));
  }

  void _onMapCreated(GoogleMapController controller) {
    if (_isDisposed || !mounted) {
      // Se o widget foi descartado, descartar o controller imediatamente
      try {
        controller.dispose();
      } catch (e) {
        print('⚠️ Erro ao descartar controller recém-criado: $e');
      }
      return;
    }
    
    try {
      // Descartar controller anterior se existir
      if (mapController != null) {
        try {
          mapController!.dispose();
        } catch (e) {
          print('⚠️ Erro ao descartar controller anterior: $e');
        }
      }
      
      mapController = controller;
      _fitCameraToBounds();
      mapController?.setMapStyle(_nightMode ? _nightMapStyle : null);
    } catch (e) {
      print('❌ Error in _onMapCreated: $e');
    }
  }

  void _toggleNightMode() {
    setState(() {
      _nightMode = !_nightMode;
    });
    mapController?.setMapStyle(_nightMode ? _nightMapStyle : null);
  }

  @override
  Widget build(BuildContext context) {
    final corrida = widget.corrida;
    return Scaffold(
      appBar: AppBar(
        title: Text('Detalhes Da Corrida'),
        actions: [
          IconButton(
            icon: Icon(_nightMode ? Icons.nightlight_round : Icons.wb_sunny),
            onPressed: _toggleNightMode,
          ),
        ],
      ),
      body: Stack(
        children: [
          GoogleMap(
            key: _mapKey, // Key única para evitar recriação de view
            onMapCreated: _onMapCreated,
            markers: _markers,
            polylines: _polylines,
            initialCameraPosition: CameraPosition(
              target: _start ?? LatLng(0, 0),
              zoom: 14,
            ),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                  elevation: 8,
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            Row(
                              children: <Widget>[
                                Icon(
                                  Icons.person,
                                  color: Colors.orange,
                                  size: 30,
                                ),
                                Text(
                                  '${(corrida.tempo_estimado_segundos! / 60).toStringAsFixed(0)} Min',
                                  style: TextStyle(
                                    fontSize: 22,
                                    fontWeight: FontWeight.w500,
                                    color: Colors.grey[800],
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(
                              width: 130.0,
                              height: 30.0,
                              child: ElevatedButton(
                                style: ButtonStyle(
                                  shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                                    RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(80.0),
                                      side: BorderSide(color: AppColors.buttonBorderSecondary),
                                    ),
                                  ),
                                  backgroundColor: MaterialStateProperty.all(Colors.transparent),
                                  shadowColor: MaterialStateProperty.all(Colors.transparent),
                                ),
                                onPressed: () async {
                                  if (widget.onRecusar != null) {
                                    await widget.onRecusar!(corrida.id.toString(), context);
                                  }
                                },
                                child: Text(
                                  'Recusar',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w500,
                                    fontSize: 16,
                                    color: Colors.orange,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                        Text(
                          'R\$' +
                              ((double.parse(corrida.valor_corrida!) + double.parse(corrida.chamadaTarifaValorBase['valor_pedagio']!)).toStringAsFixed(2)),
                          style: TextStyle(
                            fontSize: 30,
                            fontWeight: FontWeight.w500,
                            color: Colors.orange,
                          ),
                        ),
                        Text(
                          "R\$ ${(double.parse(corrida.valor_corrida!) / (((corrida.chamadaDisparo['distancia'] ?? 0) * 1.35 + (corrida.distancia_viagem_metros ?? 0)) / 1000)).toStringAsFixed(2)} por Km estimado",
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w500,
                            color: Colors.grey[800],
                          ),
                        ),
                        if (((corrida.chamadaDisparo['distancia'] * 1.35) / 1000) > 1.5)
                          Text(
                            "Taxa de R\$" +
                                ((double.parse(corrida.valor_corrida!) * 0.10)).toStringAsFixed(2) +
                                " (10%) deslocamento inclusa no valor",
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w500,
                              color: Colors.orange,
                            ),
                          ),
                        SizedBox(height: 10),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            Expanded(
                              child: Row(
                                children: [
                                  Icon(
                                    Icons.accessibility_new,
                                    size: 20,
                                    color: Colors.grey[700],
                                  ),
                                  SizedBox(width: 4),
                                  Text(
                                    "${(((corrida.chamadaDisparo['distancia'] * 1.35) + corrida.distancia_viagem_metros!) / 1000).toStringAsFixed(2)} km estimado",
                                    style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.w500,
                                      color: Colors.grey[800],
                                    ),
                                  ),
                                  SizedBox(width: 10),
                                  Icon(
                                    Icons.person,
                                    size: 20,
                                    color: Colors.grey[700],
                                  ),
                                  SizedBox(width: 4),
                                  Expanded(
                                    child: Text(
                                      "${corrida.nome}",
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.w500,
                                        color: Colors.grey[800],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Row(
                              children: <Widget>[
                                Icon(
                                  Icons.star,
                                  color: Colors.orange,
                                  size: 20,
                                ),
                                SizedBox(width: 4),
                                Text(
                                  "5",
                                  style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.w500,
                                    color: Colors.grey[800],
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                        Divider(),
                        Row(
                          children: <Widget>[
                            Container(
                              alignment: Alignment.topLeft,
                              child: Icon(
                                Icons.person,
                                color: Colors.grey[800],
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.all(5),
                            ),
                            Container(
                              width: 299,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Text(
                                    "Embarque (" +
                                        "${((corrida.chamadaDisparo['distancia'] * 1.35) / 1000).toStringAsFixed(2)} km)",
                                    style: TextStyle(
                                      color: Colors.grey[800],
                                      fontSize: 13,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                  SizedBox(height: 4),
                                  Text(
                                    corrida.endereco_partida!,
                                    style: TextStyle(
                                      color: Colors.grey[700],
                                      fontSize: 14,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 5),
                        Row(
                          children: <Widget>[
                            Container(
                              alignment: Alignment.topLeft,
                              child: Icon(
                                Icons.flag,
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.all(5),
                            ),
                            Container(
                              width: 299,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  corrida.distancia_viagem_metros! >= 1000
                                      ? Text(
                                          "Destino (" +
                                              '${(corrida.distancia_viagem_metros! / 1000).toStringAsFixed(2)}' +
                                              " km)",
                                          style: TextStyle(
                                            color: Colors.grey[800],
                                            fontSize: 13,
                                            fontWeight: FontWeight.w500,
                                          ),
                                        )
                                      : Text(
                                          "Destino (" +
                                              '${corrida.distancia_viagem_metros!}' +
                                              " mestros)",
                                          style: TextStyle(
                                            color: Colors.grey[800],
                                            fontSize: 13,
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                  SizedBox(height: 4),
                                  Text(
                                    corrida.endereco_destino!,
                                    style: TextStyle(
                                      color: Colors.grey[700],
                                      fontSize: 14,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 10),
                        Row(
                          children: <Widget>[
                            Container(
                              padding: EdgeInsets.all(5),
                              decoration: BoxDecoration(
                                border: Border.all(
                                  color: Colors.grey.shade300,
                                ),
                                borderRadius: BorderRadius.circular(20),
                                color: Colors.grey[100],
                              ),
                              child: Text(
                                corrida.categoria['name'],
                                style: TextStyle(
                                  color: Colors.grey[800],
                                ),
                              ),
                            ),
                            SizedBox(width: 8),
                            Container(
                              padding: EdgeInsets.all(5),
                              decoration: BoxDecoration(
                                border: Border.all(
                                  color: Colors.grey.shade300,
                                ),
                                borderRadius: BorderRadius.circular(20),
                                color: Colors.grey[100],
                              ),
                              child: Text(
                                corrida.metodo_pagamento!,
                                style: TextStyle(
                                  color: Colors.grey[800],
                                ),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 20),
                        SizedBox(
                          width: double.infinity,
                          height: 50,
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              elevation: 0,
                              backgroundColor: AppColors.buttonSecondary,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(6),
                                side: BorderSide(
                                  color: Colors.orange,
                                ),
                              ),
                              minimumSize: Size(100, 40),
                            ),
                            onPressed: () {
                              if (widget.onAceitar != null) {
                                widget.onAceitar!(corrida.id.toString());
                              }
                            },
                            child: Text(
                              "Aceitar corrida",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 18,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
} 