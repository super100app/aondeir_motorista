import 'package:aondeir_motorista/styles/app_colors.dart';
import 'package:aondeir_motorista/screens/Usuario/Home/Estatistica/Ganhos/ListaSaqueScreen.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../../service/CorridaService.dart';
import '../../../../../service/GanhoService.dart';
import '../../../../../service/RecargaService.dart';
import '../../../Menu/HistoricoCorridas/HistoricoCorridasMenuScreen.dart';
import 'package:intl/intl.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'PixWithdrawalScreen.dart';

class MyGanhosScreen extends StatefulWidget {
  const MyGanhosScreen({super.key});

  @override
  State<MyGanhosScreen> createState() => _MyGanhosScreenState();
}

class _MyGanhosScreenState extends State<MyGanhosScreen> {
  // final CarouselController _controllerCarousel = CarouselController();
  var dataFiltroTexto = "";
  var dataInicioTexto = "";
  var dataFimTexto = "";
  var tabFiltro = 1;
  DateTime? dataInicio;
  DateTime? dataFim;

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      await handleAcessarMeusGanhos();
      await initializeDateFormatting('pt_BR', null);
      await configurarDataHoje();
      await this.obterDataDeHoje();
      await this.pegarSaldoInvestido();
      await this.pegarGanhosDia();
      await this.pegarTotalCreditosConsumidosDia();
      await this.pegarTotalColetadoDia();
      await this.pegarTotalCorridasDia();
    });
  }

  configurarDataHoje() async {
    final hoje = DateTime.now();

    setState(() {
      dataInicio = hoje;
      dataFim = hoje;
      dataInicioTexto = DateFormat('dd MMM', 'pt_BR').format(hoje);
      dataFimTexto = DateFormat('dd MMM', 'pt_BR').format(hoje);
      dataFiltroTexto = DateFormat('dd MMM', 'pt_BR').format(hoje);
    });

    // Não chamamos obterDataDeHoje() aqui para evitar loops
    // Você pode chamar diretamente após a renderização completa da tela, se necessário
  }

  obterDataDeHoje() async {
    var recargaService = Provider.of<RecargaService>(context, listen: false);
    var ganhoService = Provider.of<GanhoService>(context, listen: false);
    var corridaService = Provider.of<CorridaService>(context, listen: false);
    DateTime hoje = await DateTime.now();
    String formattedDateText = DateFormat('dd MMM', 'pt_BR').format(hoje);

    setState(() {
      tabFiltro = 1;
      dataFiltroTexto = formattedDateText;
    });

    recargaService.dataInicio = formatarData(hoje);
    recargaService.dataFim = formatarData(hoje);
    await recargaService.save();
    await recargaService.pegarTotalCreditosConsumidos();

    ganhoService.dataInicio = formatarData(hoje);
    ganhoService.dataFim = formatarData(hoje);
    await ganhoService.save();
    await ganhoService.pegarGanhos();

    corridaService.dataInicio = formatarData(hoje);
    corridaService.dataFim = formatarData(hoje);
    await corridaService.save();
    await corridaService.pegarTotalColetado();
    await corridaService.pegarTotalCorridas();
  }

  String formatarData(DateTime data) {
    return "${data.year}-${data.month.toString().padLeft(2, '0')}-${data.day.toString().padLeft(2, '0')}";
  }

  obterDatasSemanaAtual() async {
    var recargaService = Provider.of<RecargaService>(context, listen: false);
    var ganhoService = Provider.of<GanhoService>(context, listen: false);
    var corridaService = Provider.of<CorridaService>(context, listen: false);

    DateTime hoje = DateTime.now();
    int diaDaSemana = hoje.weekday;
    int diferencaDias = diaDaSemana - DateTime.sunday;

    if (diferencaDias < 0) {
      diferencaDias += 7;
    }

    DateTime inicioSemana = hoje.subtract(Duration(days: diferencaDias));
    DateTime fimSemana = inicioSemana.add(Duration(days: 6));

    inicioSemana = DateTime(
      inicioSemana.year,
      inicioSemana.month,
      inicioSemana.day,
    );
    fimSemana = DateTime(fimSemana.year, fimSemana.month, fimSemana.day);

    String dataFormatadaInicioSemana = DateFormat(
      'dd MMM',
      'pt_BR',
    ).format(inicioSemana);

    String dataFormatadaFimSemana = DateFormat(
      'dd MMM',
      'pt_BR',
    ).format(fimSemana);

    setState(() {
      tabFiltro = 2;
      dataInicioTexto = dataFormatadaInicioSemana;
      dataFimTexto = dataFormatadaFimSemana;
    });

    recargaService.dataInicio = formatarData(inicioSemana);
    recargaService.dataFim = formatarData(fimSemana);
    await recargaService.save();
    await recargaService.pegarTotalCreditosConsumidos();

    ganhoService.dataInicio = formatarData(inicioSemana);
    ganhoService.dataFim = formatarData(fimSemana);
    await ganhoService.save();
    await ganhoService.pegarGanhos();

    corridaService.dataInicio = formatarData(inicioSemana);
    corridaService.dataFim = formatarData(fimSemana);
    await corridaService.save();
    await corridaService.pegarTotalColetado();
    await corridaService.pegarTotalCorridas();
  }

  obterDatasSemanaPassada() async {
    var recargaService = Provider.of<RecargaService>(context, listen: false);
    var ganhoService = Provider.of<GanhoService>(context, listen: false);
    var corridaService = Provider.of<CorridaService>(context, listen: false);
    DateTime hoje = DateTime.now();
    int diaDaSemana = hoje.weekday;

    int diferencaDias = diaDaSemana - DateTime.sunday - 7;

    if (diferencaDias < 0) {
      diferencaDias += 14;
    }

    DateTime inicioSemanaPassada = DateTime(
      hoje.year,
      hoje.month,
      hoje.day,
      0,
      0,
      0,
    ).subtract(Duration(days: diferencaDias + 7));
    DateTime fimSemanaPassada = DateTime(
      hoje.year,
      hoje.month,
      hoje.day,
      23,
      59,
      59,
    ).subtract(Duration(days: diferencaDias + 1));

    String dataFormatadaInicioSemana = DateFormat(
      'dd MMM',
      'pt_BR',
    ).format(inicioSemanaPassada);

    String dataFormatadaFimSemana = DateFormat(
      'dd MMM',
      'pt_BR',
    ).format(fimSemanaPassada);

    setState(() {
      tabFiltro = 3;
      dataInicioTexto = dataFormatadaInicioSemana;
      dataFimTexto = dataFormatadaFimSemana;
    });

    recargaService.dataInicio = formatarData(inicioSemanaPassada);
    recargaService.dataFim = formatarData(fimSemanaPassada);
    await recargaService.save();
    await recargaService.pegarTotalCreditosConsumidos();

    ganhoService.dataInicio = formatarData(inicioSemanaPassada);
    ganhoService.dataFim = formatarData(fimSemanaPassada);
    await ganhoService.save();
    await ganhoService.pegarGanhos();

    corridaService.dataInicio = formatarData(inicioSemanaPassada);
    corridaService.dataFim = formatarData(fimSemanaPassada);
    await corridaService.save();
    await corridaService.pegarTotalColetado();
    await corridaService.pegarTotalCorridas();
  }

  obterDatasMesPassado() async {
    var recargaService = Provider.of<RecargaService>(context, listen: false);
    var ganhoService = Provider.of<GanhoService>(context, listen: false);
    var corridaService = Provider.of<CorridaService>(context, listen: false);
    DateTime hoje = DateTime.now();

    DateTime primeiroDiaMesAtual = DateTime(hoje.year, hoje.month, 1);

    DateTime ultimoDiaMesPassado = primeiroDiaMesAtual.subtract(
      Duration(days: 1),
    );

    DateTime inicioMesPassado = DateTime(
      ultimoDiaMesPassado.year,
      ultimoDiaMesPassado.month,
      1,
      0,
      0,
      0,
    );
    DateTime fimMesPassado = DateTime(
      ultimoDiaMesPassado.year,
      ultimoDiaMesPassado.month,
      ultimoDiaMesPassado.day,
      23,
      59,
      59,
    );

    String dataFormatadaInicioMesPassado = DateFormat(
      'dd MMM',
      'pt_BR',
    ).format(inicioMesPassado);

    String dataFormatadaFimMesPassado = DateFormat(
      'dd MMM',
      'pt_BR',
    ).format(fimMesPassado);

    setState(() {
      tabFiltro = 4;
      dataInicioTexto = dataFormatadaInicioMesPassado;
      dataFimTexto = dataFormatadaFimMesPassado;
    });

    recargaService.dataInicio = formatarData(inicioMesPassado);
    recargaService.dataFim = formatarData(fimMesPassado);
    await recargaService.save();
    await recargaService.pegarTotalCreditosConsumidos();

    ganhoService.dataInicio = formatarData(inicioMesPassado);
    ganhoService.dataFim = formatarData(fimMesPassado);
    await ganhoService.save();
    await ganhoService.pegarGanhos();

    corridaService.dataInicio = formatarData(inicioMesPassado);
    corridaService.dataFim = formatarData(fimMesPassado);
    await corridaService.save();
    await corridaService.pegarTotalColetado();
    await corridaService.pegarTotalCorridas();
  }

  pegarSaldoInvestido() async {
    try {
      var recargaService = Provider.of<RecargaService>(context, listen: false);
      await recargaService.pegarSaldoInvestido();
    } catch (e) {
      throw Exception('Failed to load data pegarSaldoInvestido');
    }
  }

  pegarTotalCreditosConsumidosDia() async {
    try {
      var recargaService = Provider.of<RecargaService>(context, listen: false);
      await recargaService.pegarTotalCreditosConsumidosDia();
    } catch (e) {
      throw Exception('Failed to load data pegarSaldoInvestido');
    }
  }

  pegarGanhosDia() async {
    try {
      var ganhoService = Provider.of<GanhoService>(context, listen: false);
      await ganhoService.pegarGanhosDia();
    } catch (e) {
      throw Exception('Failed to load data pegarGanhosDia');
    }
  }

  pegarTotalColetadoDia() async {
    try {
      var corridaService = Provider.of<CorridaService>(context, listen: false);
      await corridaService.pegarTotalColetadoDia();
    } catch (e) {
      throw Exception('Failed to load data pegarGanhosDia');
    }
  }

  pegarTotalCorridasDia() async {
    try {
      var corridaService = Provider.of<CorridaService>(context, listen: false);
      await corridaService.pegarTotalCorridasDia();
    } catch (e) {
      throw Exception('Failed to load data pegarGanhosDia');
    }
  }

  Future<void> atualizarDados() async {
    var recargaService = Provider.of<RecargaService>(context, listen: false);
    var ganhoService = Provider.of<GanhoService>(context, listen: false);
    var corridaService = Provider.of<CorridaService>(context, listen: false);

    setState(() {
      tabFiltro = 5; // Valor personalizado para filtro por período
    });

    // Salvando configurações e buscando dados
    await recargaService.save();
    await recargaService.pegarTotalCreditosConsumidos();

    await ganhoService.save();
    await ganhoService.pegarGanhos();

    await corridaService.save();
    await corridaService.pegarTotalColetado();
    await corridaService.pegarTotalCorridas();
  }

  void _buscarDados() async {
    setState(() {
      tabFiltro = 5; // Filtro personalizado para período
    });

    final recargaService = Provider.of<RecargaService>(context, listen: false);
    final ganhoService = Provider.of<GanhoService>(context, listen: false);
    final corridaService = Provider.of<CorridaService>(context, listen: false);

    await recargaService.save();
    await recargaService.pegarTotalCreditosConsumidos();

    await ganhoService.save();
    await ganhoService.pegarGanhos();

    await corridaService.save();
    await corridaService.pegarTotalColetado();
    await corridaService.pegarTotalCorridas();
  }

  void _selecionarData(bool isDataInicio) async {
    // Uso do seletor padrão sem configurações de localização
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate:
          isDataInicio
              ? (dataInicio ?? DateTime.now())
              : (dataFim ?? DateTime.now()),
      firstDate: DateTime(2020),
      lastDate: DateTime(2030),
    );

    if (picked != null) {
      // Formatação manual de data sem depender de pacotes de localização
      String dataFormatada =
          "${picked.day.toString().padLeft(2, '0')}/${picked.month.toString().padLeft(2, '0')}/${picked.year}";

      // Atualizar os serviços
      var recargaService = Provider.of<RecargaService>(context, listen: false);
      var ganhoService = Provider.of<GanhoService>(context, listen: false);
      var corridaService = Provider.of<CorridaService>(context, listen: false);

      setState(() {
        if (isDataInicio) {
          dataInicio = picked;
          dataInicioTexto = dataFormatada;

          recargaService.dataInicio = formatarData(picked);
          ganhoService.dataInicio = formatarData(picked);
          corridaService.dataInicio = formatarData(picked);
        } else {
          dataFim = picked;
          dataFimTexto = dataFormatada;

          recargaService.dataFim = formatarData(picked);
          ganhoService.dataFim = formatarData(picked);
          corridaService.dataFim = formatarData(picked);
        }

        tabFiltro = 5; // Filtro personalizado para período
      });

      // Buscar dados com os novos parâmetros
      await recargaService.save();
      await recargaService.pegarTotalCreditosConsumidos();

      await ganhoService.save();
      await ganhoService.pegarGanhos();

      await corridaService.save();
      await corridaService.pegarTotalColetado();
      await corridaService.pegarTotalCorridas();
    }
  }

  handleSacarPix() async {
    print("Sacar via PIX \$");
    var ganhoService = Provider.of<GanhoService>(context, listen: false);

    await ganhoService.pegarDadosSaque();

    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => PixWithdrawalScreen()),
    );
  }

  handleAcessarMeusGanhos() async {
    print("Sacar via PIX \$");
    var ganhoService = Provider.of<GanhoService>(context, listen: false);
    await ganhoService.pegarSaldoDiponivel();
    await ganhoService.pegarDadosSaque(); // Carregar configuração junto com o saldo
    print('🔍 Configuração carregada: ${ganhoService.saqueAutomatico}');
  }

  carregarConfiguracaoSaque() async {
    try {
      var ganhoService = Provider.of<GanhoService>(context, listen: false);
      await ganhoService.pegarDadosSaque();
    } catch (e) {
      print('Erro ao carregar configuração de saque: $e');
    }
  }

  String _getDiasFuncionamentoTexto(ganhoService) {
    print('🔍 saqueAutomatico: ${ganhoService.saqueAutomatico}');
    if (ganhoService.saqueAutomatico == null) {
      return "de segunda a sexta";
    }

    List<String> diasPermitidos = [];
    if (ganhoService.saqueAutomatico['segunda'] == true) diasPermitidos.add('segunda');
    if (ganhoService.saqueAutomatico['terca'] == true) diasPermitidos.add('terça');
    if (ganhoService.saqueAutomatico['quarta'] == true) diasPermitidos.add('quarta');
    if (ganhoService.saqueAutomatico['quinta'] == true) diasPermitidos.add('quinta');
    if (ganhoService.saqueAutomatico['sexta'] == true) diasPermitidos.add('sexta');
    if (ganhoService.saqueAutomatico['sabado'] == true) diasPermitidos.add('sábado');
    if (ganhoService.saqueAutomatico['domingo'] == true) diasPermitidos.add('domingo');

    if (diasPermitidos.isEmpty) {
      return "em dias específicos";
    }

    if (diasPermitidos.length == 7) {
      return "todos os dias";
    } else if (diasPermitidos.length == 5 && 
               diasPermitidos.contains('segunda') && 
               diasPermitidos.contains('terça') && 
               diasPermitidos.contains('quarta') && 
               diasPermitidos.contains('quinta') && 
               diasPermitidos.contains('sexta')) {
      return "de segunda a sexta";
    } else {
      return "nos dias: ${diasPermitidos.join(', ')}";
    }
  }

  String _getHorarioFuncionamentoTexto(ganhoService) {
    print('🔍 saqueAutomatico horários: ${ganhoService.saqueAutomatico}');
    if (ganhoService.saqueAutomatico == null) {
      return "das 13:00 às 17:00";
    }

    final horarioInicio = ganhoService.saqueAutomatico['horario_inicio'] ?? '13:00:00';
    final horarioFim = ganhoService.saqueAutomatico['horario_fim'] ?? '17:00:00';

    // Formatar horários (remover segundos se existirem)
    final inicioFormatado = horarioInicio.length > 5 ? horarioInicio.substring(0, 5) : horarioInicio;
    final fimFormatado = horarioFim.length > 5 ? horarioFim.substring(0, 5) : horarioFim;

    return "das $inicioFormatado às $fimFormatado";
  }

  @override
  Widget build(BuildContext context) {
    var recargaService = Provider.of<RecargaService>(context, listen: true);
    var ganhoService = Provider.of<GanhoService>(context, listen: true);
    var corridaService = Provider.of<CorridaService>(context, listen: true);

    return MediaQuery(
      data: MediaQuery.of(context).copyWith(textScaler: TextScaler.linear(1.0)),
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          leading: IconButton(
            icon: Icon(Icons.arrow_back_ios_new, color: Colors.white, size: 25),
            onPressed: () => Navigator.of(context).pop(),
          ),
          title: Text("Ganhos", style: TextStyle(fontSize: 17)),
          centerTitle: true,
          backgroundColor: Color.fromARGB(255, 49, 49, 49),
        ),
        body: Material(
          type: MaterialType.transparency,
          child: SingleChildScrollView(
            child: Container(
              padding: EdgeInsets.only(
                bottom: 20,
              ), // Added padding to ensure the last button is fully visible
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Container(
                    margin: EdgeInsets.only(left: 15, right: 15, top: 20),
                    child: Column(
                      children: [
                        // Card for "Carteira de créditos"
                        // Card(
                        //   color: Colors.white, // Set card color to white
                        //   elevation: 3,
                        //   shape: RoundedRectangleBorder(
                        //     borderRadius: BorderRadius.circular(10),
                        //   ),
                        //   child: Padding(
                        //     padding: const EdgeInsets.all(15.0),
                        //     child: Column(
                        //       crossAxisAlignment: CrossAxisAlignment.start,
                        //       children: [
                        //         Text(
                        //           "Carteira de créditos",
                        //           style: TextStyle(
                        //             fontSize: 16,
                        //             fontWeight: FontWeight.bold,
                        //           ),
                        //         ),
                        //         SizedBox(height: 10),
                        //         Row(
                        //           mainAxisAlignment:
                        //               MainAxisAlignment.spaceBetween,
                        //           children: [
                        //             Text(
                        //               "R\$ 0000,00",
                        //               style: TextStyle(
                        //                 fontSize: 16,
                        //                 fontWeight: FontWeight.bold,
                        //                 color: Colors.orange,
                        //               ),
                        //             ),
                        //             ElevatedButton(
                        //               onPressed: () {},
                        //               style: ElevatedButton.styleFrom(
                        //                 backgroundColor: AppColors.buttonSecondary,
                        //                 shape: RoundedRectangleBorder(
                        //                   borderRadius: BorderRadius.circular(
                        //                     6,
                        //                   ),
                        //                 ),
                        //               ),
                        //               child: Text(
                        //                 "Adicionar \$",
                        //                 style: TextStyle(
                        //                   color: Colors.white,
                        //                   fontSize: 16,
                        //                 ),
                        //               ),
                        //             ),
                        //           ],
                        //         ),
                        //       ],
                        //     ),
                        //   ),
                        // ),
                        SizedBox(height: 10),
                        // Card for "Saldo pessoal"
                        Card(
                          color: Colors.white, // Set card color to white
                          elevation: 3,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(15.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Saldo pessoal",
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                SizedBox(height: 10),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          "Disponível (PIX)",
                                          style: TextStyle(
                                            fontSize: 14,
                                            color: Colors.grey,
                                          ),
                                        ),
                                        Text(
                                          "R\$ ${ganhoService.saldoDiponivel ?? '0.00'}",
                                          style: TextStyle(
                                            fontSize: 16,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.green,
                                          ),
                                        ),
                                      ],
                                    ),
                                    ElevatedButton(
                                      onPressed: () {
                                        handleSacarPix();
                                        // Navigator.push(
                                        //   context,
                                        //   MaterialPageRoute(
                                        //     builder:
                                        //         (context) =>
                                        //             PixWithdrawalScreen(),
                                        //   ),
                                        // );
                                      },
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: Colors.green,
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(
                                            6,
                                          ),
                                        ),
                                      ),
                                      child: Text(
                                        "Sacar via PIX \$",
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 16,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 10),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          "À Liberar",
                                          style: TextStyle(
                                            fontSize: 14,
                                            color: Colors.grey,
                                          ),
                                        ),
                                        Text(
                                          "R\$ ${ganhoService.saldoPendente ?? '0.00'}",
                                          style: TextStyle(
                                            fontSize: 16,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.grey,
                                          ),
                                        ),
                                      ],
                                    ),
                                    Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.end,
                                      children: [
                                        Text(
                                          "Saque disponível apenas",
                                          style: TextStyle(
                                            fontSize: 12,
                                            color: Colors.grey,
                                          ),
                                        ),
                                        Text(
                                          _getDiasFuncionamentoTexto(ganhoService),
                                          style: TextStyle(
                                            fontSize: 12,
                                            color: Colors.grey,
                                          ),
                                        ),
                                        Text(
                                          _getHorarioFuncionamentoTexto(ganhoService),
                                          style: TextStyle(
                                            fontSize: 12,
                                            color: Colors.grey,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                                SizedBox(height: 10),
                                // ElevatedButton(
                                //   onPressed: () {},
                                //   style: ElevatedButton.styleFrom(
                                //     backgroundColor: Colors.white,
                                //     side: BorderSide(color: AppColors.buttonBorderSecondary),
                                //     shape: RoundedRectangleBorder(
                                //       borderRadius: BorderRadius.circular(6),
                                //     ),
                                //   ),
                                //   child: Text(
                                //     "Antecipar saldo bloqueado",
                                //     style: TextStyle(
                                //       color: Colors.orange,
                                //       fontSize: 14,
                                //     ),
                                //   ),
                                // ),
                              ],
                            ),
                          ),
                        ),
                        SizedBox(height: 20),
                        // Histórico de Saques
                        Container(
                          width: double.infinity,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(10),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.5),
                                spreadRadius: 1,
                                blurRadius: 5,
                                offset: Offset(0, 3),
                              ),
                            ],
                          ),
                          child: TextButton(
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => ListaSaqueScreen(),
                                ),
                              );
                            },
                            style: TextButton.styleFrom(
                              padding: EdgeInsets.symmetric(vertical: 10),
                            ),
                            child: Text(
                              "Histórico de Saques",
                              style: TextStyle(
                                fontSize: 16,
                                color: Colors.grey,
                              ),
                            ),
                          ),
                        ),
                        SizedBox(height: 20),
                        Divider(color: Colors.grey),
                        SizedBox(height: 10),
                        // Ganhos (resumo)
                        Container(
                          margin: EdgeInsets.only(left: 15),
                          child: Text(
                            "Ganhos (resumo)",
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 10),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Container(
                        margin: EdgeInsets.only(right: 15, left: 15),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            // Substitua o componente de carousel/dropdown pelo código abaixo:
                            Container(
                              margin: EdgeInsets.only(),
                              child: Row(
                                children: [
                                  // Campo Data Inicial
                                  Expanded(
                                    child: InkWell(
                                      onTap: () => _selecionarData(true),
                                      child: Container(
                                        decoration: BoxDecoration(
                                          color: Colors.white,
                                          borderRadius: BorderRadius.circular(
                                            8,
                                          ),
                                          border: Border.all(
                                            color: Colors.grey[300]!,
                                          ),
                                        ),
                                        padding: EdgeInsets.symmetric(
                                          vertical: 8,
                                          horizontal: 10,
                                        ),
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              "De",
                                              style: TextStyle(
                                                fontWeight: FontWeight.bold,
                                                fontSize: 12,
                                                color: Colors.grey[700],
                                              ),
                                            ),
                                            SizedBox(height: 4),
                                            Text(
                                              dataInicioTexto,
                                              style: TextStyle(fontSize: 15),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                  SizedBox(
                                    width: 10,
                                  ), // Added spacing between "De" and "Até" fields
                                  // Campo Data Final
                                  Expanded(
                                    child: InkWell(
                                      onTap: () => _selecionarData(false),
                                      child: Container(
                                        decoration: BoxDecoration(
                                          color: Colors.white,
                                          borderRadius: BorderRadius.circular(
                                            8,
                                          ),
                                          border: Border.all(
                                            color: Colors.grey[300]!,
                                          ),
                                        ),
                                        padding: EdgeInsets.symmetric(
                                          vertical: 8,
                                          horizontal: 10,
                                        ),
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              "Até",
                                              style: TextStyle(
                                                fontWeight: FontWeight.bold,
                                                fontSize: 12,
                                                color: Colors.grey[700],
                                              ),
                                            ),
                                            SizedBox(height: 4),
                                            Text(
                                              dataFimTexto,
                                              style: TextStyle(fontSize: 15),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 15),
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: Container(
                          margin: EdgeInsets.only(right: 15, left: 15),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(6),
                            border: Border.all(color: Colors.grey),
                          ),
                          padding: EdgeInsets.only(left: 15, right: 15),
                          height: 80,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Container(
                                child: Text(
                                  "Corridas",
                                  style: TextStyle(
                                    color: Colors.grey[700],
                                    fontSize: 12,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                              SizedBox(height: 5),
                              Text(
                                corridaService.total_corrida_dia,
                                style: TextStyle(
                                  color: Colors.orange,
                                  fontSize: 15,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Expanded(
                        child: Container(
                          margin: EdgeInsets.only(right: 15),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(6),
                            border: Border.all(color: Colors.grey),
                          ),
                          padding: EdgeInsets.only(left: 15, right: 15),
                          height: 80,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Container(
                                child: Text(
                                  "Ganhos",
                                  style: TextStyle(
                                    color: Colors.grey[700],
                                    fontSize: 12,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                              SizedBox(height: 5),
                              Text(
                                "R\$ " + corridaService.total_coletado_dia,
                                style: TextStyle(
                                  color: Colors.orange,
                                  fontSize: 15,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 15),
                  Container(
                    margin: EdgeInsets.only(left: 15, right: 15),
                    child: Row(
                      children: <Widget>[
                        Text(
                          "Ganhos presenciais",
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(width: 5),
                        InkWell(
                          onTap: () {
                            showModalBottomSheet<void>(
                              context: context,
                              builder: (BuildContext context) {
                                return Container(
                                  padding: EdgeInsets.all(15),
                                  height: 200,
                                  color: Colors.white,
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    mainAxisSize: MainAxisSize.min,
                                    children: <Widget>[
                                      Row(
                                        children: <Widget>[
                                          Icon(
                                            Icons.info,
                                            color: Colors.grey,
                                            size: 19,
                                          ),
                                          SizedBox(width: 10),
                                          Text(
                                            "Ganhos presenciais",
                                            style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 17,
                                            ),
                                          ),
                                        ],
                                      ),
                                      SizedBox(height: 15),
                                      Text(
                                        "Quando você ganhou em corridas pagas em dinheiro e maquininha, descontando os créditos consumidos nessas corridas.",
                                        style: TextStyle(
                                          fontSize: 15,
                                          color: Colors.grey,
                                        ),
                                      ),
                                      Container(
                                        margin: EdgeInsets.only(top: 30),
                                        child: Column(
                                          children: <Widget>[
                                            SizedBox(
                                              width: double.infinity,
                                              height: 50,
                                              child: ElevatedButton(
                                                style: ElevatedButton.styleFrom(
                                                  elevation: 0,
                                                  shadowColor:
                                                      Colors.transparent,
                                                  backgroundColor:
                                                      Colors.transparent,
                                                  foregroundColor:
                                                      Colors.orange,
                                                  shape: RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                          6,
                                                        ),
                                                    side: BorderSide(
                                                      color: Colors.orange,
                                                    ),
                                                  ),
                                                  minimumSize: Size(100, 40),
                                                ),
                                                onPressed: () {
                                                  Navigator.pop(context);
                                                },
                                                child: Text(
                                                  "Fechar",
                                                  style: TextStyle(
                                                    fontSize: 18,
                                                    color: Colors.orange,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              },
                            );
                          },
                          child: Icon(Icons.info, size: 17, color: Colors.grey),
                        ),
                        Spacer(),
                        Text(
                          "R\$ " + corridaService.total_coletado_dia,
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 10),
                  Container(
                    margin: EdgeInsets.only(left: 15, right: 15),
                    padding: EdgeInsets.only(left: 15),
                    child: Row(
                      children: <Widget>[
                        Text(
                          "Coletado",
                          style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                            color: Colors.grey,
                          ),
                        ),
                        SizedBox(width: 5),
                        InkWell(
                          onTap: () {
                            showModalBottomSheet<void>(
                              context: context,
                              builder: (BuildContext context) {
                                return Container(
                                  padding: EdgeInsets.all(15),
                                  height: 200,
                                  color: Colors.white,
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    mainAxisSize: MainAxisSize.min,
                                    children: <Widget>[
                                      Row(
                                        children: <Widget>[
                                          Icon(
                                            Icons.info,
                                            color: Colors.grey,
                                            size: 19,
                                          ),
                                          SizedBox(width: 10),
                                          Text(
                                            "Coletado",
                                            style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 17,
                                            ),
                                          ),
                                        ],
                                      ),
                                      SizedBox(height: 15),
                                      Text(
                                        "Quando um passageiro paga em dinheiro ou maquininha, o valor integral que você recebeu no fim da corrida é o valor coletado.",
                                        style: TextStyle(
                                          fontSize: 15,
                                          color: Colors.grey,
                                        ),
                                      ),
                                      Container(
                                        margin: EdgeInsets.only(top: 30),
                                        child: Column(
                                          children: <Widget>[
                                            SizedBox(
                                              width: double.infinity,
                                              height: 50,
                                              child: ElevatedButton(
                                                style: ElevatedButton.styleFrom(
                                                  elevation: 0,
                                                  shadowColor:
                                                      Colors.transparent,
                                                  backgroundColor:
                                                      Colors.transparent,
                                                  foregroundColor:
                                                      Colors.orange,
                                                  shape: RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                          6,
                                                        ),
                                                    side: BorderSide(
                                                      color: Colors.orange,
                                                    ),
                                                  ),
                                                  minimumSize: Size(100, 40),
                                                ),
                                                onPressed: () {
                                                  Navigator.pop(context);
                                                },
                                                child: Text(
                                                  "Fechar",
                                                  style: TextStyle(
                                                    fontSize: 18,
                                                    color: Colors.orange,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              },
                            );
                          },
                          child: Icon(Icons.info, size: 15, color: Colors.grey),
                        ),
                        Spacer(),
                        Text(
                          "R\$ " + corridaService.total_coletado_dia,
                          style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                            color: Colors.grey,
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 10),
                  Container(
                    margin: EdgeInsets.only(left: 15, right: 15),
                    child: Row(
                      children: <Widget>[
                        Text(
                          "Créditos consumido da carteira",
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(width: 5),
                        InkWell(
                          onTap: () {
                            showModalBottomSheet<void>(
                              context: context,
                              builder: (BuildContext context) {
                                return Container(
                                  padding: EdgeInsets.all(15),
                                  height: 200,
                                  color: Colors.white,
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    mainAxisSize: MainAxisSize.min,
                                    children: <Widget>[
                                      Row(
                                        children: <Widget>[
                                          Icon(
                                            Icons.info,
                                            color: Colors.grey,
                                            size: 19,
                                          ),
                                          SizedBox(width: 10),
                                          Text(
                                            "Taxa da central",
                                            style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 17,
                                            ),
                                          ),
                                        ],
                                      ),
                                      SizedBox(height: 15),
                                      Text(
                                        "Créditos são descontados da sua carteira a cada corrida finalizada para coletar as taxas da central.",
                                        style: TextStyle(
                                          fontSize: 15,
                                          color: Colors.grey,
                                        ),
                                      ),
                                      Container(
                                        margin: EdgeInsets.only(top: 30),
                                        child: Column(
                                          children: <Widget>[
                                            SizedBox(
                                              width: double.infinity,
                                              height: 50,
                                              child: ElevatedButton(
                                                style: ElevatedButton.styleFrom(
                                                  elevation: 0,
                                                  shadowColor:
                                                      Colors.transparent,
                                                  backgroundColor:
                                                      Colors.transparent,
                                                  foregroundColor:
                                                      Colors.orange,
                                                  shape: RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                          6,
                                                        ),
                                                    side: BorderSide(
                                                      color: Colors.orange,
                                                    ),
                                                  ),
                                                  minimumSize: Size(100, 40),
                                                ),
                                                onPressed: () {
                                                  Navigator.pop(context);
                                                },
                                                child: Text(
                                                  "Fechar",
                                                  style: TextStyle(
                                                    fontSize: 18,
                                                    color: Colors.orange,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              },
                            );
                          },
                          child: Icon(Icons.info, size: 17, color: Colors.grey),
                        ),
                        Spacer(),
                        Text(
                          "R\$ " + recargaService.creditos_consumidos_dia,
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(left: 15, right: 15),
                    child: Divider(height: 30, thickness: 2),
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 15, right: 15),
                    child: Row(
                      children: <Widget>[
                        Icon(
                          Icons.monetization_on,
                          color: Colors.black,
                          size: 17,
                        ),
                        SizedBox(width: 15),
                        Text(
                          "Total do período (Bruto)",
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Spacer(),
                        Text(
                          "R\$ " + corridaService.total_coletado_dia,
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 10),
                  Container(
                    margin: EdgeInsets.only(left: 15, right: 15, top: 30),
                    child: Column(
                      children: <Widget>[
                        SizedBox(
                          width: double.infinity,
                          height: 50,
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              elevation: 0,
                              shadowColor: Colors.transparent,
                              backgroundColor: Colors.transparent,
                              foregroundColor: Colors.orange,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(6),
                                side: BorderSide(color: AppColors.buttonBorderSecondary),
                              ),
                              minimumSize: Size(100, 40),
                            ),
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => HistoricoCorridasMenuScreen(),
                                ),
                              );
                            },
                            child: Text(
                              "Histórico de corridas",
                              style: TextStyle(
                                fontSize: 18,
                                color: Colors.orange,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
