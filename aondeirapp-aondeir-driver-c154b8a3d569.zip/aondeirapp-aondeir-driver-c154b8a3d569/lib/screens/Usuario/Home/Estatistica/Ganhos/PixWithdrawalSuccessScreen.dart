import 'package:flutter/material.dart';

class PixWithdrawalSuccessScreen extends StatelessWidget {
  const PixWithdrawalSuccessScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MediaQuery(
      data: MediaQuery.of(context).copyWith(textScaler: TextScaler.linear(1.0)),
      child: Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
          child: Column(
            children: [
              Row(
                children: [
                  IconButton(
                    icon: Icon(Icons.arrow_back_ios_new, color: Colors.black),
                    onPressed: () => Navigator.of(context).pop(),
                  ),
                ],
              ),
              Container(
                margin: const EdgeInsets.only(
                  top: 16,
                ), // Add margin to position the card
                alignment: Alignment.center, // Center the card horizontally
                child: Card(
                  elevation: 3,
                  color: Colors.white, // Ensure the card background is white
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Container(
                    width:
                        MediaQuery.of(context).size.width *
                        0.95, // Increase card width to 95% of the screen
                    padding: const EdgeInsets.all(
                      20.0,
                    ), // Increase padding for more spacing
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Detalhes da transferência",
                          style: TextStyle(
                            fontSize: 18, // Slightly larger font size
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: 20), // Increase spacing
                        Text(
                          "Seu saque foi solicitado e está em processamento. Assim que for concluído, o valor estará disponível na sua conta cadastrada.",
                          style: TextStyle(
                            fontSize: 14,
                            color: Colors.grey.shade700,
                          ),
                        ),
                        SizedBox(height: 30), // Increase spacing
                        _buildDetailRow("Chave PIX", "000.000.000-00"),
                        SizedBox(height: 10), // Add spacing between rows
                        _buildDetailRow("Valor solicitado", "R\$ 500,00"),
                        SizedBox(height: 10),
                        _buildDetailRow("Taxa de saque", "R\$ 3,50"),
                        SizedBox(height: 10),
                        _buildDetailRow("Valor do Saque", "R\$ 496,50"),
                        Divider(),
                        _buildDetailRow("A Receber", "R\$ 496,50"),
                        SizedBox(
                          height: 20,
                        ), // Remove the divider below "A Receber" and add spacing
                        Text(
                          "O prazo pode ser de até 12 horas úteis para que seja confirmado o saque via PIX.",
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.grey.shade700,
                          ),
                        ),
                        SizedBox(height: 20), // Increase spacing
                        Text(
                          "Você verá o valor informado na sua conta PIX cadastrada",
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.grey.shade700,
                          ),
                        ),
                        SizedBox(height: 20),
                        Text(
                          "PIX: 000.000.000-00",
                          style: TextStyle(fontSize: 12, color: Colors.black),
                        ),
                        SizedBox(height: 30), // Increase spacing
                        Center(
                          child: ElevatedButton(
                            onPressed: () => Navigator.of(context).pop(),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.white,
                              side: BorderSide(color: Colors.black),
                              padding: EdgeInsets.symmetric(
                                horizontal: 50,
                                vertical: 15,
                              ),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                              fixedSize: Size(
                                MediaQuery.of(context).size.width * 0.85,
                                50,
                              ), // 85% of the card width
                            ),
                            child: Text(
                              "Fechar",
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 14,
                              ),
                            ),
                          ),
                        ),
                        SizedBox(height: 20),
                        Center(
                          child: Text(
                            "Pedido concluído com sucesso",
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.grey.shade700,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
          ),
          Text(
            value,
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold, // Ensure values are bold
              color: Colors.black,
            ),
          ),
        ],
      ),
    );
  }
}
