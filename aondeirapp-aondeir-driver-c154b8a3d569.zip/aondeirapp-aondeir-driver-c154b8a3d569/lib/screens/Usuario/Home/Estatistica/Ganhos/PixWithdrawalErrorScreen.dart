import 'package:aondeir_motorista/screens/Usuario/Home/Estatistica/Ganhos/MyGanhosScreen.dart';
import 'package:aondeir_motorista/service/GanhoService.dart';
import 'package:flutter/material.dart';
// import 'dart:async';
// import 'package:flutter_spinkit/flutter_spinkit.dart';
// import 'package:aondeir_motorista/screens/Usuario/Home/Estatistica/Ganhos/PixWithdrawalSuccessScreen.dart';
import 'package:provider/provider.dart';

class PixWithdrawalErrorScreen extends StatefulWidget {
  const PixWithdrawalErrorScreen({Key? key}) : super(key: key);

  @override
  State<PixWithdrawalErrorScreen> createState() =>
      _PixWithdrawalErrorScreenState();
}

class _PixWithdrawalErrorScreenState extends State<PixWithdrawalErrorScreen> {
  // bool _isProcessing = false;

  // void _processWithdrawal() {
  //   setState(() {
  //     _isProcessing = true;
  //   });
  // }

  @override
  Widget build(BuildContext context) {
    var ganhoService = Provider.of<GanhoService>(context, listen: false);
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            Row(
              children: [
                IconButton(
                  icon: Icon(Icons.arrow_back_ios_new, color: Colors.black),
                  onPressed: () => Navigator.of(context).pop(),
                ),
              ],
            ),
            Container(
              margin: const EdgeInsets.only(top: 16), //
              child: Card(
                elevation: 3,
                color: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Container(
                  width: MediaQuery.of(context).size.width * 0.9,
                  height: MediaQuery.of(context).size.height * 0.6,
                  padding: const EdgeInsets.all(15.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Detalhes da transferência",
                        style: TextStyle(fontSize: 16),
                      ),

                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(height: 19),
                          Text(
                            "OCORREU UM ERRO",
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.bold,
                              color: const Color.fromARGB(255, 255, 7, 7),
                            ),
                            textAlign: TextAlign.left,
                          ),
                          // Text(
                          //   ganhoService.mensagemRetorno,
                          //   style: TextStyle(
                          //     fontSize: 13,
                          //     fontWeight: FontWeight.bold,
                          //     color: const Color.fromARGB(255, 255, 7, 7),
                          //   ),
                          //   textAlign: TextAlign.left,
                          // ),
                          SizedBox(height: 20),
                        ],
                      ),

                      SizedBox(height: 20),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(height: 10),
                          Text(
                            "O valor de R\$ ${ganhoService.valorSaque} Retornou a sua carteira de Saldo Pessoal.",
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.bold,
                              color: Color(
                                0xFF339966,
                              ), // Cor equivalente a #339966
                            ),
                            textAlign: TextAlign.left,
                          ),

                          SizedBox(height: 80),
                          Align(
                            alignment: Alignment.center,
                            child: Text(
                              "Tente novamente mais tarde...",
                              style: TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.bold,
                                color: const Color.fromARGB(255, 255, 7, 7),
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 150),
                      Center(
                        child: ElevatedButton(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => MyGanhosScreen(),
                              ),
                            );
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.grey,
                            padding: EdgeInsets.symmetric(
                              horizontal: 50,
                              vertical: 15,
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                            side: BorderSide(color: Colors.grey, width: 2),
                            fixedSize: Size(
                              MediaQuery.of(context).size.width * 0.85,
                              50,
                            ),
                          ),
                          child: Text(
                            "Fechar",
                            style: TextStyle(
                              color: const Color.fromARGB(255, 238, 238, 238),
                              fontSize: 15,
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 10),
                      Center(
                        child: Text(
                          "Taxa de saque: R\$ ${ganhoService.valorFinalComPercentual} por saque",
                          style: TextStyle(fontSize: 12, color: Colors.grey),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          
              // Row(
              //   children: [
              //     IconButton(
              //       icon: Icon(Icons.arrow_back_ios_new, color: Colors.black),
              //       onPressed: () => Navigator.of(context).pop(),
              //     ),
              //   ],
              // ),
              // Container(
              //   margin: const EdgeInsets.only(top: 16),
              //   alignment: Alignment.center,
              //   child: Card(
              //     elevation: 3,
              //     color: Colors.white,
              //     shape: RoundedRectangleBorder(
              //       borderRadius: BorderRadius.circular(10),
              //     ),
              //     child: Container(
              //       width: MediaQuery.of(context).size.width * 0.95,
              //       padding: const EdgeInsets.all(20.0),
              //       child: Column(
              //         crossAxisAlignment: CrossAxisAlignment.start,
              //         children: [
              //           Text(
              //             "Detalhes da transferência",
              //             style: TextStyle(fontSize: 16),
              //           ),
              //           SizedBox(height: 20),
              //           Text(
              //             "OCORREU UM ERRO",
              //             style: TextStyle(
              //               fontSize: 14,
              //               color: const Color.fromARGB(255, 228, 10, 10),
              //               fontWeight: FontWeight.bold,
              //             ),
              //           ),
              //           SizedBox(height: 10),
              //           Text(
              //             "O valor de R\$ ${ganhoService.valorSolicitado} Retornou a sua carteira de Saldo Pessoal",
              //             style: TextStyle(fontSize: 14, color: Colors.green),
              //           ),
              //           SizedBox(height: 150),
              //           Center(
              //             child: Text(
              //               "Tente novamente mais tarde...",
              //               style: TextStyle(
              //                 fontSize: 14,
              //                 color: Color.fromARGB(255, 228, 10, 10),
              //                 fontWeight: FontWeight.bold,
              //               ),
              //             ),
              //           ),

              //           SizedBox(height: 150),
              //           Center(
              //             child: ElevatedButton(
              //               onPressed: () {
              //                 Navigator.push(
              //                   context,
              //                   MaterialPageRoute(
              //                     builder: (_) => MyGanhosScreen(),
              //                   ),
              //                 );
              //               },
              //               style: ElevatedButton.styleFrom(
              //                 backgroundColor: Colors.grey,
              //                 side: BorderSide(color: Colors.grey),
              //                 padding: EdgeInsets.symmetric(
              //                   horizontal: 50,
              //                   vertical: 15,
              //                 ),
              //                 shape: RoundedRectangleBorder(
              //                   borderRadius: BorderRadius.circular(8),
              //                 ),
              //                 fixedSize: Size(
              //                   MediaQuery.of(context).size.width * 0.85,
              //                   50,
              //                 ),
              //               ),
              //               child: Text(
              //                 "Fechar",
              //                 style: TextStyle(
              //                   color: const Color.fromARGB(255, 255, 255, 255),
              //                   fontSize: 14,
              //                 ),
              //               ),
              //             ),
              //           ),
              //           SizedBox(height: 10),
              //           Center(
              //             child: Text(
              //               "Taxa de saque: R\$ ${ganhoService.valorTaxaSaque} por saque",
              //               style: TextStyle(fontSize: 12, color: Colors.grey),
              //             ),
              //           ),
              //         ],
              //       ),
              //     ),
              //   ),
              // ),
            ],
          ),
        ),
    );
  }
  // Widget _buildCustomLoader() {
  //   return const SizedBox(
  //     height: 60,
  //     width: 60,
  //     child: SpinKitFadingCircle(color: Colors.grey, size: 60.0),
  //   );
  // }

  // Widget _buildDetailRow(String label, String value) {
  //   return Padding(
  //     padding: const EdgeInsets.symmetric(vertical: 5.0),
  //     child: Row(
  //       mainAxisAlignment: MainAxisAlignment.spaceBetween,
  //       children: [
  //         Text(
  //           label,
  //           style: TextStyle(
  //             fontSize: 14,
  //             fontWeight: FontWeight.bold, // Make the topic bold
  //             color: Colors.black, // Set text color to black
  //           ),
  //         ),
  //         Text(
  //           value,
  //           style: TextStyle(
  //             fontSize: 14,
  //             fontWeight: FontWeight.normal, // Keep the details unbolded
  //             color: Colors.black, // Set text color to black
  //           ),
  //         ),
  //       ],
  //     ),
  //   );
  // }
}
