import 'package:aondeir_motorista/screens/Usuario/Home/Estatistica/Ganhos/MyGanhosScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Home/HomeScreen.dart';
import 'package:aondeir_motorista/service/GanhoService.dart';
import 'package:flutter/material.dart';
import 'dart:async';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:aondeir_motorista/screens/Usuario/Home/Estatistica/Ganhos/PixWithdrawalSuccessScreen.dart';
import 'package:provider/provider.dart';

class PixWithdrawalFinalizadoScreen extends StatefulWidget {
  const PixWithdrawalFinalizadoScreen({Key? key}) : super(key: key);

  @override
  State<PixWithdrawalFinalizadoScreen> createState() =>
      _PixWithdrawalFinalizadoScreenState();
}

class _PixWithdrawalFinalizadoScreenState
    extends State<PixWithdrawalFinalizadoScreen> {
  bool _isProcessing = false;

  void _processWithdrawal() {
    setState(() {
      _isProcessing = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    var ganhoService = Provider.of<GanhoService>(context, listen: false);
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            Row(
              children: [
                IconButton(
                  icon: Icon(Icons.arrow_back_ios_new, color: Colors.black),
                  onPressed: () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => HomeScreen(),
                              ),
                            ),
                ),
              ],
            ),
            Container(
              margin: const EdgeInsets.only(top: 16), //
              child: Card(
                elevation: 3,
                color: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Container(
                  width: MediaQuery.of(context).size.width * 0.9,
                  height: MediaQuery.of(context).size.height * 0.6,
                  padding: const EdgeInsets.all(15.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Detalhes da transferência",
                        style: TextStyle(fontSize: 16),
                      ),

                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(height: 5),
                          Text(
                            "Seu saque foi solicitado e está em processamento. Assim que for concluído, o valor estará disponível na sua conta cadastrada.",
                            style: TextStyle(fontSize: 12, color: Colors.grey),
                            textAlign: TextAlign.left,
                          ),
                          SizedBox(height: 20),
                        ],
                      ),
                      _buildDetailRow("Chave PIX", "${ganhoService.chavePix}"),
                      _buildDetailRow(
                        "Valor solicitado",
                        "R\$ ${ganhoService.valorSolicitado}",
                      ),
                      _buildDetailRow(
                        "Taxa de saque",
                        "R\$ ${ganhoService.valorFinalComPercentual}",
                      ),
                      _buildDetailRow(
                        "Valor do Saque",
                        "R\$ ${ganhoService.valorSaque}",
                      ),
                      Divider(),
                      _buildDetailRow(
                        "A Receber",
                        "R\$ ${ganhoService.valorSaque}",
                      ),
                      SizedBox(height: 20),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(height: 10),
                          Text(
                            "O prazo pode ser de até 12 horas uteis para que seja confirmado o saque via PIX",
                            style: TextStyle(fontSize: 12, color: Colors.grey),
                            textAlign: TextAlign.left,
                          ),
                          SizedBox(height: 12),
                          Text(
                            "Você verá o valor informado na sua conta PIX cadastrada",
                            style: TextStyle(fontSize: 12, color: Colors.grey),
                            textAlign: TextAlign.left,
                          ),
                          SizedBox(height: 12),
                          Text(
                            "PIX: ${ganhoService.chavePix}",
                            style: TextStyle(fontSize: 12, color: Colors.grey),
                            textAlign: TextAlign.left,
                          ),
                        ],
                      ),
                      SizedBox(height: 35),
                      Center(
                        child: ElevatedButton(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => MyGanhosScreen(),
                              ),
                            );
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color.fromARGB(
                              255,
                              255,
                              255,
                              255,
                            ),
                            padding: EdgeInsets.symmetric(
                              horizontal: 50,
                              vertical: 15,
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                            side: BorderSide(color: Colors.black, width: 2),
                            fixedSize: Size(
                              MediaQuery.of(context).size.width * 0.85,
                              50,
                            ),
                          ),
                          child: Text(
                            "Fechar",
                            style: TextStyle(
                              color: const Color.fromARGB(255, 2, 2, 2),
                              fontSize: 15,
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 10),
                      Center(
                        child: Text(
                          "Pedido concluído com sucesso",
                          style: TextStyle(fontSize: 12, color: Colors.grey),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCustomLoader() {
    return const SizedBox(
      height: 60,
      width: 60,
      child: SpinKitFadingCircle(color: Colors.grey, size: 60.0),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold, // Make the topic bold
              color: Colors.black, // Set text color to black
            ),
          ),
          Text(
            value,
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.normal, // Keep the details unbolded
              color: Colors.black, // Set text color to black
            ),
          ),
        ],
      ),
    );
  }
}
