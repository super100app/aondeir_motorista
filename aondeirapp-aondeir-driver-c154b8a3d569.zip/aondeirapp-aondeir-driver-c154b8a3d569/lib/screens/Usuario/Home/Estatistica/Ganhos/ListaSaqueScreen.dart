import 'package:aondeir_motorista/models/Saque.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../../service/CorridaService.dart';
import '../../../../../service/GanhoService.dart';
import '../../../../../service/RecargaService.dart';
import '../../../Menu/HistoricoCorridas/HistoricoCorridasMenuScreen.dart';
import 'package:intl/intl.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'PixWithdrawalScreen.dart';
import 'package:flutter_svg/flutter_svg.dart';

class ListaSaqueScreen extends StatefulWidget {
  const ListaSaqueScreen({super.key});

  @override
  State<ListaSaqueScreen> createState() => _ListaSaqueScreenState();
}

class _ListaSaqueScreenState extends State<ListaSaqueScreen> {
  // final CarouselController _controllerCarousel = CarouselController();
  var dataFiltroTexto = "";
  var dataInicioTexto = "";
  var dataFimTexto = "";
  var tabFiltro = 1;
  DateTime dataInicio = DateTime.now();
  DateTime dataFim = DateTime.now();
  List<Saque> historicoSaques = [];

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      await handleAcessarMeusGanhos();
      await initializeDateFormatting('pt_BR', null);
      await configurarDataHoje();
      await this.obterDataDeHoje();
      await this.pegarSaldoInvestido();
      await this.pegarGanhosDia();
      await this.pegarTotalCreditosConsumidosDia();
      await this.pegarTotalColetadoDia();
      await this.pegarTotalCorridasDia();
    });
  }

  configurarDataHoje() async {
    final hoje = DateTime.now();

    setState(() {
      dataInicio = hoje;
      dataFim = hoje;
      dataInicioTexto = DateFormat('dd MMM', 'pt_BR').format(hoje);
      dataFimTexto = DateFormat('dd MMM', 'pt_BR').format(hoje);
      dataFiltroTexto = DateFormat('dd MMM', 'pt_BR').format(hoje);
    });

    // Não chamamos obterDataDeHoje() aqui para evitar loops
    // Você pode chamar diretamente após a renderização completa da tela, se necessário
  }

  obterDataDeHoje() async {
    var recargaService = Provider.of<RecargaService>(context, listen: false);
    var ganhoService = Provider.of<GanhoService>(context, listen: false);
    var corridaService = Provider.of<CorridaService>(context, listen: false);
    DateTime hoje = await DateTime.now();
    String formattedDateText = DateFormat('dd MMM', 'pt_BR').format(hoje);

    setState(() {
      tabFiltro = 1;
      dataFiltroTexto = formattedDateText;
    });

    final agora = DateTime.now();
    // final dataInicio = DateTime(agora.year, agora.month, 1);
    // final dataFim = DateTime(agora.year, agora.month + 1, 0);
    List<Saque> listaPix = await ganhoService.pegarListaPix(
      dataInicio,
      dataFim,
    );
    historicoSaques = listaPix;

    recargaService.dataInicio = formatarData(hoje);
    recargaService.dataFim = formatarData(hoje);
    await recargaService.save();
    await recargaService.pegarTotalCreditosConsumidos();

    ganhoService.dataInicio = formatarData(hoje);
    ganhoService.dataFim = formatarData(hoje);
    await ganhoService.save();
    await ganhoService.pegarGanhos();

    corridaService.dataInicio = formatarData(hoje);
    corridaService.dataFim = formatarData(hoje);
    await corridaService.save();
    await corridaService.pegarTotalColetado();
    await corridaService.pegarTotalCorridas();
  }

  String formatarData(DateTime data) {
    return "${data.year}-${data.month.toString().padLeft(2, '0')}-${data.day.toString().padLeft(2, '0')}";
  }

  String dataFormatada(DateTime data) {
    return "${data.day.toString().padLeft(2, '0')}/"
        "${data.month.toString().padLeft(2, '0')}/"
        "${data.year}";
  }

  obterDatasSemanaAtual() async {
    var recargaService = Provider.of<RecargaService>(context, listen: false);
    var ganhoService = Provider.of<GanhoService>(context, listen: false);
    var corridaService = Provider.of<CorridaService>(context, listen: false);

    DateTime hoje = DateTime.now();
    int diaDaSemana = hoje.weekday;
    int diferencaDias = diaDaSemana - DateTime.sunday;

    if (diferencaDias < 0) {
      diferencaDias += 7;
    }

    DateTime inicioSemana = hoje.subtract(Duration(days: diferencaDias));
    DateTime fimSemana = inicioSemana.add(Duration(days: 6));

    inicioSemana = DateTime(
      inicioSemana.year,
      inicioSemana.month,
      inicioSemana.day,
    );
    fimSemana = DateTime(fimSemana.year, fimSemana.month, fimSemana.day);

    String dataFormatadaInicioSemana = DateFormat(
      'dd MMM',
      'pt_BR',
    ).format(inicioSemana);

    String dataFormatadaFimSemana = DateFormat(
      'dd MMM',
      'pt_BR',
    ).format(fimSemana);

    setState(() {
      tabFiltro = 2;
      dataInicioTexto = dataFormatadaInicioSemana;
      dataFimTexto = dataFormatadaFimSemana;
    });

    recargaService.dataInicio = formatarData(inicioSemana);
    recargaService.dataFim = formatarData(fimSemana);
    await recargaService.save();
    await recargaService.pegarTotalCreditosConsumidos();

    ganhoService.dataInicio = formatarData(inicioSemana);
    ganhoService.dataFim = formatarData(fimSemana);
    await ganhoService.save();
    await ganhoService.pegarGanhos();

    corridaService.dataInicio = formatarData(inicioSemana);
    corridaService.dataFim = formatarData(fimSemana);
    await corridaService.save();
    await corridaService.pegarTotalColetado();
    await corridaService.pegarTotalCorridas();
  }

  obterDatasSemanaPassada() async {
    var recargaService = Provider.of<RecargaService>(context, listen: false);
    var ganhoService = Provider.of<GanhoService>(context, listen: false);
    var corridaService = Provider.of<CorridaService>(context, listen: false);
    DateTime hoje = DateTime.now();
    int diaDaSemana = hoje.weekday;

    int diferencaDias = diaDaSemana - DateTime.sunday - 7;

    if (diferencaDias < 0) {
      diferencaDias += 14;
    }

    DateTime inicioSemanaPassada = DateTime(
      hoje.year,
      hoje.month,
      hoje.day,
      0,
      0,
      0,
    ).subtract(Duration(days: diferencaDias + 7));
    DateTime fimSemanaPassada = DateTime(
      hoje.year,
      hoje.month,
      hoje.day,
      23,
      59,
      59,
    ).subtract(Duration(days: diferencaDias + 1));

    String dataFormatadaInicioSemana = DateFormat(
      'dd MMM',
      'pt_BR',
    ).format(inicioSemanaPassada);

    String dataFormatadaFimSemana = DateFormat(
      'dd MMM',
      'pt_BR',
    ).format(fimSemanaPassada);

    setState(() {
      tabFiltro = 3;
      dataInicioTexto = dataFormatadaInicioSemana;
      dataFimTexto = dataFormatadaFimSemana;
    });

    recargaService.dataInicio = formatarData(inicioSemanaPassada);
    recargaService.dataFim = formatarData(fimSemanaPassada);
    await recargaService.save();
    await recargaService.pegarTotalCreditosConsumidos();

    ganhoService.dataInicio = formatarData(inicioSemanaPassada);
    ganhoService.dataFim = formatarData(fimSemanaPassada);
    await ganhoService.save();
    await ganhoService.pegarGanhos();

    corridaService.dataInicio = formatarData(inicioSemanaPassada);
    corridaService.dataFim = formatarData(fimSemanaPassada);
    await corridaService.save();
    await corridaService.pegarTotalColetado();
    await corridaService.pegarTotalCorridas();
  }

  obterDatasMesPassado() async {
    var recargaService = Provider.of<RecargaService>(context, listen: false);
    var ganhoService = Provider.of<GanhoService>(context, listen: false);
    var corridaService = Provider.of<CorridaService>(context, listen: false);
    DateTime hoje = DateTime.now();

    DateTime primeiroDiaMesAtual = DateTime(hoje.year, hoje.month, 1);

    DateTime ultimoDiaMesPassado = primeiroDiaMesAtual.subtract(
      Duration(days: 1),
    );

    DateTime inicioMesPassado = DateTime(
      ultimoDiaMesPassado.year,
      ultimoDiaMesPassado.month,
      1,
      0,
      0,
      0,
    );
    DateTime fimMesPassado = DateTime(
      ultimoDiaMesPassado.year,
      ultimoDiaMesPassado.month,
      ultimoDiaMesPassado.day,
      23,
      59,
      59,
    );

    String dataFormatadaInicioMesPassado = DateFormat(
      'dd MMM',
      'pt_BR',
    ).format(inicioMesPassado);

    String dataFormatadaFimMesPassado = DateFormat(
      'dd MMM',
      'pt_BR',
    ).format(fimMesPassado);

    setState(() {
      tabFiltro = 4;
      dataInicioTexto = dataFormatadaInicioMesPassado;
      dataFimTexto = dataFormatadaFimMesPassado;
    });

    recargaService.dataInicio = formatarData(inicioMesPassado);
    recargaService.dataFim = formatarData(fimMesPassado);
    await recargaService.save();
    await recargaService.pegarTotalCreditosConsumidos();

    ganhoService.dataInicio = formatarData(inicioMesPassado);
    ganhoService.dataFim = formatarData(fimMesPassado);
    await ganhoService.save();
    await ganhoService.pegarGanhos();

    corridaService.dataInicio = formatarData(inicioMesPassado);
    corridaService.dataFim = formatarData(fimMesPassado);
    await corridaService.save();
    await corridaService.pegarTotalColetado();
    await corridaService.pegarTotalCorridas();
  }

  pegarSaldoInvestido() async {
    try {
      var recargaService = Provider.of<RecargaService>(context, listen: false);
      await recargaService.pegarSaldoInvestido();
    } catch (e) {
      throw Exception('Failed to load data pegarSaldoInvestido');
    }
  }

  pegarTotalCreditosConsumidosDia() async {
    try {
      var recargaService = Provider.of<RecargaService>(context, listen: false);
      await recargaService.pegarTotalCreditosConsumidosDia();
    } catch (e) {
      throw Exception('Failed to load data pegarSaldoInvestido');
    }
  }

  pegarGanhosDia() async {
    try {
      var ganhoService = Provider.of<GanhoService>(context, listen: false);
      await ganhoService.pegarGanhosDia();
    } catch (e) {
      throw Exception('Failed to load data pegarGanhosDia');
    }
  }

  pegarTotalColetadoDia() async {
    try {
      var corridaService = Provider.of<CorridaService>(context, listen: false);
      await corridaService.pegarTotalColetadoDia();
    } catch (e) {
      throw Exception('Failed to load data pegarGanhosDia');
    }
  }

  pegarTotalCorridasDia() async {
    try {
      var corridaService = Provider.of<CorridaService>(context, listen: false);
      await corridaService.pegarTotalCorridasDia();
    } catch (e) {
      throw Exception('Failed to load data pegarGanhosDia');
    }
  }

  Future<void> atualizarDados() async {
    var recargaService = Provider.of<RecargaService>(context, listen: false);
    var ganhoService = Provider.of<GanhoService>(context, listen: false);
    var corridaService = Provider.of<CorridaService>(context, listen: false);

    setState(() {
      tabFiltro = 5; // Valor personalizado para filtro por período
    });

    // Salvando configurações e buscando dados
    await recargaService.save();
    await recargaService.pegarTotalCreditosConsumidos();

    await ganhoService.save();
    await ganhoService.pegarGanhos();

    await corridaService.save();
    await corridaService.pegarTotalColetado();
    await corridaService.pegarTotalCorridas();
  }

  void _buscarDados() async {
    setState(() {
      tabFiltro = 5; // Filtro personalizado para período
    });

    final recargaService = Provider.of<RecargaService>(context, listen: false);
    final ganhoService = Provider.of<GanhoService>(context, listen: false);
    final corridaService = Provider.of<CorridaService>(context, listen: false);

    await recargaService.save();
    await recargaService.pegarTotalCreditosConsumidos();

    await ganhoService.save();
    await ganhoService.pegarGanhos();

    await corridaService.save();
    await corridaService.pegarTotalColetado();
    await corridaService.pegarTotalCorridas();
  }

  void _selecionarData(bool isDataInicio) async {
    var ganhoService = Provider.of<GanhoService>(context, listen: false);
    // Uso do seletor padrão sem configurações de localização
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate:
          isDataInicio
              ? (dataInicio ?? DateTime.now())
              : (dataFim ?? DateTime.now()),
      firstDate: DateTime(2020),
      lastDate: DateTime(2030),
    );

    if (picked != null) {
      // Formatação manual de data sem depender de pacotes de localização
      String dataFormatada =
          "${picked.day.toString().padLeft(2, '0')}/${picked.month.toString().padLeft(2, '0')}/${picked.year}";

      // Atualizar os serviços
      var recargaService = Provider.of<RecargaService>(context, listen: false);
      var ganhoService = Provider.of<GanhoService>(context, listen: false);
      var corridaService = Provider.of<CorridaService>(context, listen: false);

      setState(() {
        if (isDataInicio) {
          dataInicio = picked;
          dataInicioTexto = dataFormatada;

          recargaService.dataInicio = formatarData(picked);
          ganhoService.dataInicio = formatarData(picked);
          corridaService.dataInicio = formatarData(picked);
        } else {
          dataFim = picked;
          dataFimTexto = dataFormatada;

          recargaService.dataFim = formatarData(picked);
          ganhoService.dataFim = formatarData(picked);
          corridaService.dataFim = formatarData(picked);
        }

        tabFiltro = 5; // Filtro personalizado para período
      });

      List<Saque> listaPix = await ganhoService.pegarListaPix(
        dataInicio,
        dataFim,
      );
      historicoSaques = listaPix;

      // Buscar dados com os novos parâmetros
      await recargaService.save();
      await recargaService.pegarTotalCreditosConsumidos();

      await ganhoService.save();
      await ganhoService.pegarGanhos();

      await corridaService.save();
      await corridaService.pegarTotalColetado();
      await corridaService.pegarTotalCorridas();
    }
  }

  handleSacarPix() async {
    print("Sacar via PIX \$");
    var ganhoService = Provider.of<GanhoService>(context, listen: false);

    await ganhoService.pegarDadosSaque();
    // await ganhoService.pegarSaldoDiponivel();

    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => PixWithdrawalScreen()),
    );
  }

  handleAcessarMeusGanhos() async {
    print("Sacar via PIX \$");
    var ganhoService = Provider.of<GanhoService>(context, listen: false);
    await ganhoService.pegarSaldoDiponivel();
  }

  @override
  Widget build(BuildContext context) {
    var ganhoService = Provider.of<GanhoService>(context, listen: true);

    return MediaQuery(
      data: MediaQuery.of(context).copyWith(textScaler: TextScaler.linear(1.0)),
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          leading: IconButton(
            icon: Icon(Icons.arrow_back_ios_new, color: Colors.white, size: 25),
            onPressed: () => Navigator.of(context).pop(),
          ),
          title: Text("Ganhos", style: TextStyle(fontSize: 17)),
          centerTitle: true,
          backgroundColor: Color.fromARGB(255, 49, 49, 49),
        ),
        body: Material(
          type: MaterialType.transparency,
          child: SingleChildScrollView(
            child: Container(
              padding: EdgeInsets.only(
                bottom: 20,
              ), // Added padding to ensure the last button is fully visible
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Container(
                    margin: EdgeInsets.only(left: 15, right: 15, top: 20),
                    child: Column(
                      children: [
                        SizedBox(height: 10),
                        Text(
                          "Historico de saque",
                          style: TextStyle(
                            fontSize: 15,
                            color: Colors.grey,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: 10),
                        Card(
                          color: Colors.white,
                          elevation: 3,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(15.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Saldo pessoal",
                                  style: TextStyle(
                                    fontSize: 15,
                                    color: Colors.grey,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                SizedBox(height: 10),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          "Disponível",
                                          style: TextStyle(
                                            fontSize: 10,
                                            color: Colors.grey,
                                          ),
                                        ),
                                        Text(
                                          "R\$ ${ganhoService.saldoDiponivel ?? '0.00'}",
                                          style: TextStyle(
                                            fontSize: 20,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.green,
                                          ),
                                        ),
                                      ],
                                    ),
                                    // ElevatedButton(
                                    //   onPressed: () {
                                    //     handleSacarPix();
                                    //     // Navigator.push(
                                    //     //   context,
                                    //     //   MaterialPageRoute(
                                    //     //     builder:
                                    //     //         (context) =>
                                    //     //             PixWithdrawalScreen(),
                                    //     //   ),
                                    //     // );
                                    //   },
                                    //   style: ElevatedButton.styleFrom(
                                    //     backgroundColor: Colors.green,
                                    //     shape: RoundedRectangleBorder(
                                    //       borderRadius: BorderRadius.circular(
                                    //         6,
                                    //       ),
                                    //     ),
                                    //   ),
                                    //   child: Text(
                                    //     "Adicionar \$",
                                    //     style: TextStyle(
                                    //       color: Colors.white,
                                    //       fontSize: 15,
                                    //     ),
                                    //   ),
                                    // ),
                                  ],
                                ),
                                SizedBox(height: 10),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    // Column(
                                    //   crossAxisAlignment:
                                    //       CrossAxisAlignment.start,
                                    //   children: [
                                    //     Row(
                                    //       children: [
                                    //         Text(
                                    //           "À Liberar",
                                    //           style: TextStyle(
                                    //             fontSize: 10,
                                    //             color: Colors.grey,
                                    //           ),
                                    //         ),
                                    //         const SizedBox(width: 4),
                                    //         SvgPicture.asset(
                                    //           'assets/Vector.svg', // Substitua pelo caminho do seu SVG
                                    //           width: 14,
                                    //           height: 14,
                                    //         ),
                                    //       ],
                                    //     ),
                                    //     Text(
                                    //       "R\$ 0000,00",
                                    //       style: TextStyle(
                                    //         fontSize: 20,
                                    //         fontWeight: FontWeight.bold,
                                    //         color: Colors.grey,
                                    //       ),
                                    //     ),
                                    //   ],
                                    // ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                        SizedBox(height: 20),

                        // Histórico de Saques
                        Divider(color: Colors.grey),
                        SizedBox(height: 10),
                      ],
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(right: 15, left: 15),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        // Substitua o componente de carousel/dropdown pelo código abaixo:
                        Container(
                          margin: EdgeInsets.only(),
                          child: Row(
                            children: [
                              // Campo Data Inicial
                              Expanded(
                                child: InkWell(
                                  onTap: () => _selecionarData(true),
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(8),
                                      border: Border.all(
                                        color: Colors.grey[300]!,
                                      ),
                                    ),
                                    padding: EdgeInsets.symmetric(
                                      vertical: 8,
                                      horizontal: 10,
                                    ),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          "De",
                                          style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 14,
                                            color: Colors.grey,
                                          ),
                                        ),
                                        SizedBox(height: 4),
                                        Text(
                                          dataInicioTexto,
                                          style: TextStyle(fontSize: 15),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              SizedBox(
                                width: 10,
                              ), // Added spacing between "De" and "Até" fields
                              // Campo Data Final
                              Expanded(
                                child: InkWell(
                                  onTap: () => _selecionarData(false),
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(8),
                                      border: Border.all(
                                        color: Colors.grey[300]!,
                                      ),
                                    ),
                                    padding: EdgeInsets.symmetric(
                                      vertical: 8,
                                      horizontal: 10,
                                    ),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          "Até",
                                          style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 14,
                                            color: Colors.grey,
                                          ),
                                        ),
                                        SizedBox(height: 4),
                                        Text(
                                          dataFimTexto,
                                          style: TextStyle(fontSize: 15),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 20),
                  Column(
                    children:
                        historicoSaques.map((saque) {
                          return Card(
                            margin: EdgeInsets.only(
                              right: 15,
                              left: 15,
                              bottom: 10,
                              top: 10,
                            ),
                            color: Colors.white,
                            elevation: 3,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(15.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    saque.tipo == 'SAQUE' ? "Saque via PIX" : "Deposito",
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.grey,
                                    ),
                                  ),
                                  Text(
                                    "Solicitação N: ${saque.id}",
                                    style: TextStyle(
                                      fontSize: 10,
                                      color: Colors.grey[700],
                                    ),
                                  ),
                                  SizedBox(height: 5),
                                  if (saque.tipo == 'SAQUE')
                                  Text(
                                    "PIX: ${saque.pix}",
                                    style: TextStyle(
                                      fontSize: 10,
                                      color: Colors.grey[700],
                                    ),
                                  ),
                                  Text(
                                    "Data: ${dataFormatada(saque.data)}",
                                    style: TextStyle(
                                      fontSize: 10,
                                      color: Colors.grey[700],
                                    ),
                                  ),
                                  SizedBox(height: 10),
                                  _buildDetailRow(
                                    "Valor pedido: ",
                                    "R\$ ${saque.valor.toStringAsFixed(2)}",
                                  ),
                                  if (saque.tipo == 'SAQUE')
                                  _buildDetailRow(
                                    "Taxa de saque:",
                                    "R\$ ${saque.taxa}",
                                  ),
                                  if (saque.tipo == 'SAQUE')
                                  _buildDetailRow(
                                    "Valor do saque:",
                                    "R\$ ${(saque.valor + saque.taxa).toStringAsFixed(2)}",
                                  ),
                                  // _buildDetailRow(
                                  //   "Valor restante carteira: ",
                                  //   "R\$ 503,50",
                                  // ), // se tiver valor real, troque
                                  _buildStatus(saque.status),
                                  SizedBox(height: 15),
                                  _buildStatusTexto(saque),
                                ],
                              ),
                            ),
                          );
                        }).toList(),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 1.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label),
          Text(
            value,
            style: TextStyle(
              // fontWeight: FontWeight.bold,
              fontSize: 13,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatus(String status) {
    Color? statusColor;
    if (status == 'FINALIZADO') {
      statusColor = Colors.green;
    } else if (status == 'RECUSADO') {
      statusColor = const Color.fromARGB(255, 247, 4, 4); // vermelho
    } else {
      statusColor = const Color(0xFFF9AD1E); // amarelo
    }

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 1.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text('Status'),
          Text(
            status,
            style: TextStyle(
              color: statusColor ?? Colors.black,
              // fontWeight: FontWeight.bold,
              fontSize: 13,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusTexto(saque) {
    Color statusColor = Colors.black;
    String statusTexto = '';
    print('🍊🍊🍊saque');
    print(saque.tipo);
    if (saque.tipo == 'DEPOSITO') {
      statusColor = Colors.green;
      statusTexto =
          'Seu deposito foi confirmado no valor de R\$ ${saque.valor.toStringAsFixed(2)}';
    } else if (saque.status == 'FINALIZADO') {
      statusColor = Colors.green;
      statusTexto =
          'Seu saque foi confirmado, seu valor de R\$ ${saque.valor.toStringAsFixed(2)} já está em sua conta PIX de número: ${saque.pix}';
    } else if (saque.status == 'RECUSADO') {
      statusColor = const Color.fromARGB(255, 247, 4, 4);
      statusTexto =
          'Seu saque foi NEGADO, ou apresentou erro. Seu pedido de R\$ ${saque.valor.toStringAsFixed(2)} está de volta em sua carteira de saldo';
    } else {
      statusColor = const Color(0xFFF9AD1E);
      statusTexto =
          'Seu saque está em analise, aguarde o sistema bancário fazer a confirmação do saque!';
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 8),
        Text(
          statusTexto,
          style: TextStyle(
            color: statusColor,
            fontWeight: FontWeight.bold,
            fontSize: 13,
          ),
        ),
      ],
    );
  }
}
