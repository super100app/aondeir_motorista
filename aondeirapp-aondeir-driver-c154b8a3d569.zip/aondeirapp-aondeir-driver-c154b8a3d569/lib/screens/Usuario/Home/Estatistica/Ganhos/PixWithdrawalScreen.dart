import 'package:aondeir_motorista/screens/Modal/ModalPadrao.dart';
import 'package:aondeir_motorista/screens/Usuario/Home/Estatistica/Ganhos/PixWithdrawalDetailScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Home/Estatistica/Ganhos/PixWithdrawalSuccessScreen.dart';
import 'package:aondeir_motorista/service/GanhoService.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'PixWithdrawalFinalizadoScreen.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:flutter_masked_text2/flutter_masked_text2.dart';

class PixWithdrawalScreen extends StatefulWidget {
  const PixWithdrawalScreen({super.key});

  @override
  State<PixWithdrawalScreen> createState() => _PixWithdrawalScreenState();
}

class _PixWithdrawalScreenState extends State<PixWithdrawalScreen> {
  String? tipoSelecionado = "selecionar";
  final TextEditingController chaveController = TextEditingController();
  // final TextEditingController valorController = TextEditingController();
  var valorController = MoneyMaskedTextController(thousandSeparator: '.');
  String? erroChave;
  String? erroValor;

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      chaveController.addListener(validarChave);
    });
  }

  @override
  void dispose() {
    chaveController.dispose();
    valorController.dispose();
    super.dispose();
  }

  void validarChave() {
    final chave = chaveController.text.trim();
    final chaveNumerica = chave.replaceAll(RegExp(r'\D'), ''); // Remove todos os caracteres não numéricos.

    setState(() {
      erroChave = null;

      // Se a chave for um CPF
      if (tipoSelecionado == "cpf") {
        final mascara = MaskTextInputFormatter(mask: '###.###.###-##');
        final novoTexto = mascara.maskText(chaveNumerica);

        // Atualiza o campo de texto com a máscara aplicada, sem alterar o cursor
        if (chave != novoTexto) {
          chaveController.value = TextEditingValue(
            text: novoTexto,
            selection: TextSelection.collapsed(offset: novoTexto.length),
          );
        }

        // Validação enquanto digita
        if (chaveNumerica.length < 11) {
          // Se ainda não atingiu 11 números, mostra a validação
          erroChave = "CPF deve conter 11 números.";
        } else if (chaveNumerica.length == 11) {
          // Se atingiu 11 números, a validação desaparece
          erroChave = null;
        }

      } else if (tipoSelecionado == "cnpj") {
        final mascara = MaskTextInputFormatter(mask: '##.###.###/####-##');
        final novoTexto = mascara.maskText(chaveNumerica);

        // Atualiza o campo de texto com a máscara aplicada, sem alterar o cursor
        if (chave != novoTexto) {
          chaveController.value = TextEditingValue(
            text: novoTexto,
            selection: TextSelection.collapsed(offset: novoTexto.length),
          );
        }

        // Validação enquanto digita
        if (chaveNumerica.length < 14) {
          // Se ainda não atingiu 14 números, mostra a validação
          erroChave = "CNPJ deve conter 14 números.";
        } else if (chaveNumerica.length == 14) {
          // Se atingiu 14 números, a validação desaparece
          erroChave = null;
        }

      } else if (tipoSelecionado == "celular") {
        final mascara = MaskTextInputFormatter(mask: '(##) #####-####');
        final novoTexto = mascara.maskText(chaveNumerica);

        // Atualiza o campo de texto com a máscara aplicada, sem alterar o cursor
        if (chave != novoTexto) {
          chaveController.value = TextEditingValue(
            text: novoTexto,
            selection: TextSelection.collapsed(offset: novoTexto.length),
          );
        }

        // Validação enquanto digita
        if (chaveNumerica.length < 11) {
          // Se ainda não atingiu 11 números, mostra a validação
          erroChave = "Celular deve conter 11 números (com DDD).";
        } else if (chaveNumerica.length == 11) {
          // Se atingiu 11 números, a validação desaparece
          erroChave = null;
        }

      } else if (tipoSelecionado == "email" && !RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(chave)) {
        erroChave = "Email inválido.";

      } else if (tipoSelecionado == "selecionar" || chave.isEmpty) {
        erroChave = "Selecione um tipo de chave e preencha o valor.";
      }
    });
  }

  void validarValor() async {
    var ganhoService = Provider.of<GanhoService>(context, listen: false);
    
    if (ganhoService.saqueAutomatico == null) {
      showDialog<String>(
            context: context,
            builder: (BuildContext context) => ModalPadrao(
                message: "Configuração de saque não encontrada. Tente novamente mais tarde.",
                loading: false));
      return;
    }

    // Validar horário e dia da semana no backend
    try {
      bool saquePermitido = await ganhoService.validarSaque();
      if (!saquePermitido) {
        return; // A validação já mostra o modal de erro
      }
    } catch (e) {
      showDialog<String>(
            context: context,
            builder: (BuildContext context) => ModalPadrao(
                message: e.toString().replaceAll('Exception: ', ''),
                loading: false));
      return;
    }
    
    final valor = valorController.text.trim();

    double valorNumerico = double.parse(valor.replaceAll(',', '.'));
    if (ganhoService.saldoDiponivel < valorNumerico) {
      setState(() {
        erroValor =
            "O valor solicitado excede o saldo disponível na sua carteira. Por favor, revise o valor e tente novamente!";
      });
      return;
    }

    setState(() {
      erroValor = null;

      if (valor.isEmpty) {
        setState(() {
          erroValor = "Digite um valor para saque";
        });
        return;
      }
      double valorNumerico = double.parse(valor.replaceAll(',', '.'));
      double valorMinimo = double.parse(
        ganhoService.saqueAutomatico['valor_minimo'].toString(),
      );
      if (valorNumerico < valorMinimo) {
        setState(() {
          erroValor = "O valor deve ser maior que o valor mínimo de saque";
        });
        return;
      }

      verificarTaxaValor();
    });
  }

  void verificarTaxaValor() async {
    var ganhoService = Provider.of<GanhoService>(context, listen: false);

    if (erroValor != null || valorController.text.isEmpty) {
      setState(() {
        erroValor = "Digite um valor válido para saque";
      });
      return;
    }

    final diaAtual = DateTime.now().weekday;

    String diaSemana;
    switch (diaAtual) {
      case 1:
        diaSemana = 'segunda';
        break;
      case 2:
        diaSemana = 'terca';
        break;
      case 3:
        diaSemana = 'quarta';
        break;
      case 4:
        diaSemana = 'quinta';
        break;
      case 5:
        diaSemana = 'sexta';
        break;
      case 6:
        diaSemana = 'sabado';
        break;
      case 7:
        diaSemana = 'domingo';
        break;
      default:
        diaSemana = '';
    }

    var tarifaDoDia = ganhoService.tarifas.firstWhere(
      (tarifa) => tarifa[diaSemana] == 1,
      orElse: () => null,
    );

    if (tarifaDoDia != null) {
      double valorFixo = double.parse(tarifaDoDia['valor_fixo'].toString());
      double valorPercentual = double.parse(
        tarifaDoDia['valor_percentual'].toString(),
      );
      double valorDigitado = double.parse(
        valorController.text.replaceAll(',', '.'),
      );

      // Primeiro cálculo: valorDigitado - valorPercentual%
      double valorComPercentual =
          valorDigitado - (valorDigitado * (valorPercentual / 100));
      double valorDescontado = valorDigitado - valorComPercentual;

      // Segundo cálculo: resultado anterior - valorFixo
      double resultadoFinal = valorComPercentual - valorFixo;
      double valorFinalComPercentual = valorFixo + valorDescontado;

      double saldoCarteiraDescontado =
          ganhoService.saldoDiponivel - valorDigitado;
      String carteiraDescontadoFormatado = saldoCarteiraDescontado
          .toStringAsFixed(2);

      ganhoService.chavePix = chaveController.text;
      ganhoService.tipoChavePix = tipoSelecionado;
      ganhoService.valorSolicitado = valorDigitado;

      ganhoService.valorTaxaSaque = valorFixo;
      ganhoService.valorSaque = resultadoFinal;
      ganhoService.saldoDisponivelCarteira = '';
      ganhoService.valorFinalComPercentual = valorFinalComPercentual;
      ganhoService.saldoDiponivel = ganhoService.saldoDiponivel;
      ganhoService.carteiraDescontadoFormatado = carteiraDescontadoFormatado;
      ganhoService.save();

      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => PixWithdrawalDetailScreen()),
      );

      // Exemplo com seus valores:
      // 16 - 5% = 15,2
      // 15,2 - 12 = 3,2
    } else {
      print("Nenhuma tarifa encontrada para hoje");
      setState(() {
        erroValor = "Não há tarifa disponível para hoje";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    var ganhoService = Provider.of<GanhoService>(context, listen: true);

    return WillPopScope(
      onWillPop: () async => false,
      child: MediaQuery(
      data: MediaQuery.of(context).copyWith(textScaler: TextScaler.linear(1.0)),
      child: Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
          child: Column(
            children: [
              Row(
                children: [
                  IconButton(
                    icon: Icon(Icons.arrow_back_ios_new, color: Colors.black),
                    onPressed: () => Navigator.of(context).pop(),
                  ),
                ],
              ),
              Expanded(
                child: Container(
                  color: Colors.white,
                  child: Center(
                    child: Card(
                      color: Colors.white,
                      elevation: 3,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Container(
                        width: MediaQuery.of(context).size.width * 0.9,
                        padding: const EdgeInsets.all(15.0),
                        child: SingleChildScrollView(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Text(
                                    "Selecione tipo de chave PIX",
                                    style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.grey.shade700,
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(height: 8),
                              Container(
                                width: MediaQuery.of(context).size.width * 0.8,
                                decoration: BoxDecoration(
                                  color: Colors.grey.shade200,
                                  borderRadius: BorderRadius.circular(10),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.grey.withOpacity(0.5),
                                      spreadRadius: 1,
                                      blurRadius: 5,
                                      offset: Offset(0, 3),
                                    ),
                                  ],
                                ),
                                child: DropdownButtonFormField(
                                  value: tipoSelecionado,
                                  items: [
                                    DropdownMenuItem(
                                      child: Text(
                                        "Selecionar",
                                        style: TextStyle(
                                          color: Colors.grey.shade600,
                                          fontSize: 8,
                                        ),
                                      ),
                                      value: "selecionar",
                                    ),
                                    DropdownMenuItem(
                                      child: Text(
                                        "Cnpj",
                                        style: TextStyle(
                                          color: Colors.grey.shade600,
                                          fontSize: 8,
                                        ),
                                      ),
                                      value: "cnpj",
                                    ),
                                    DropdownMenuItem(
                                      child: Text(
                                        "Cpf",
                                        style: TextStyle(
                                          color: Colors.grey.shade600,
                                          fontSize: 8,
                                        ),
                                      ),
                                      value: "cpf",
                                    ),
                                    DropdownMenuItem(
                                      child: Text(
                                        "Email",
                                        style: TextStyle(
                                          color: Colors.grey.shade600,
                                          fontSize: 8,
                                        ),
                                      ),
                                      value: "email",
                                    ),
                                    DropdownMenuItem(
                                      child: Text(
                                        "Celular",
                                        style: TextStyle(
                                          color: Colors.grey.shade600,
                                          fontSize: 8,
                                        ),
                                      ),
                                      value: "celular",
                                    ),
                                  ],
                                  onChanged: (value) {
                                    setState(() {
                                      tipoSelecionado = value;
                                    });
                                    validarChave();
                                  },
                                  decoration: InputDecoration(
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    contentPadding: EdgeInsets.symmetric(
                                      vertical: 8,
                                      horizontal: 12,
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                        color: Colors.grey.shade300,
                                      ),
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    focusedBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                        color: Colors.grey.shade500,
                                      ),
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    hintText: "Selecionar",
                                    hintStyle: TextStyle(
                                      color: Colors.grey.shade600,
                                      fontSize: 10,
                                    ),
                                  ),
                                ),
                              ),
                              SizedBox(height: 16),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Text(
                                    "Digite a Chave PIX",
                                    style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.grey.shade700,
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(height: 8),
                              Container(
                                width: MediaQuery.of(context).size.width * 0.8,
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(10),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.grey.withOpacity(0.5),
                                      spreadRadius: 1,
                                      blurRadius: 5,
                                      offset: Offset(0, 3),
                                    ),
                                  ],
                                ),
                                child: TextField(
                                  controller: chaveController,
                                  decoration: InputDecoration(
                                    hintText: "Insira a chave aqui",
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    contentPadding: EdgeInsets.symmetric(
                                      vertical: 8,
                                      horizontal: 12,
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                        color: Colors.grey.shade300,
                                      ),
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    focusedBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                        color: Colors.grey.shade500,
                                      ),
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    hintStyle: TextStyle(fontSize: 10),
                                  ),
                                  style: TextStyle(fontSize: 10),
                                ),
                              ),
                              if (erroChave != null) ...[
                                SizedBox(height: 8),
                                Text(
                                  erroChave!,
                                  style: TextStyle(
                                    fontSize: 10,
                                    color: Colors.red,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                              SizedBox(height: 16),
                              Divider(),
                              SizedBox(height: 16),
                              Text(
                                "Saldo disponível",
                                style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.grey.shade700,
                                ),
                              ),
                              Text(
                                "para saque",
                                style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.grey.shade700,
                                ),
                              ),
                              SizedBox(height: 8),
                              Text(
                                "R\$ ${ganhoService.saldoDiponivel ?? '0.00'}",
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.green,
                                ),
                              ),
                              SizedBox(height: 16),
                              Text(
                                "Qual valor você quer sacar?",
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.grey.shade700,
                                ),
                              ),
                              SizedBox(height: 8),
                              Text(
                                "Min de saque: " +
                                    ganhoService.saqueAutomatico['valor_minimo']
                                        .toString() +
                                    " / Máx: " +
                                    ganhoService.saqueAutomatico['valor_maximo']
                                        .toString(),
                                style: TextStyle(
                                  fontSize: 10,
                                  color: Colors.grey,
                                ),
                              ),
                              SizedBox(height: 8),
                              Container(
                                width: MediaQuery.of(context).size.width * 0.8,
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(10),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.grey.withOpacity(0.5),
                                      spreadRadius: 1,
                                      blurRadius: 5,
                                      offset: Offset(0, 3),
                                    ),
                                  ],
                                ),
                                child: TextField(
                                  controller: valorController,
                                  keyboardType: TextInputType.numberWithOptions(
                                    decimal: true,
                                  ),
                                  decoration: InputDecoration(
                                    hintText: "Digite o valor",
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    contentPadding: EdgeInsets.symmetric(
                                      vertical: 8,
                                      horizontal: 12,
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                        color: Colors.grey.shade300,
                                      ),
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    focusedBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                        color: Colors.grey.shade500,
                                      ),
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    hintStyle: TextStyle(fontSize: 10),
                                  ),
                                  style: TextStyle(fontSize: 10),
                                ),
                              ),
                              if (erroValor != null) ...[
                                SizedBox(height: 8),
                                Text(
                                  erroValor!,
                                  style: TextStyle(
                                    fontSize: 10,
                                    color: Colors.red,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                              SizedBox(height: 16),
                              Text(
                                "O limite diário para saque é de R\$" +
                                    ganhoService.saqueAutomatico['valor_maximo']
                                        .toString() +
                                    ".\nO valor mínimo para saque é de R\$" +
                                    ganhoService.saqueAutomatico['valor_minimo']
                                        .toString() +
                                    ".\nVocê só pode fazer " +
                                    ganhoService.saqueAutomatico['dia_saque']
                                        .toString() +
                                    " saque por dia do valor mínimo de R\$" +
                                    ganhoService.saqueAutomatico['valor_minimo']
                                        .toString() +
                                    " e o máximo de R\$" +
                                    ganhoService.saqueAutomatico['valor_maximo']
                                        .toString() +
                                    ".",
                                style: TextStyle(
                                  fontSize: 8,
                                  color: Colors.red,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              SizedBox(height: 16),

                              Center(
                                child: ElevatedButton(
                                  onPressed: () {
                                    validarValor();
                                  },
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.green,
                                    padding: EdgeInsets.symmetric(
                                      horizontal: 50,
                                      vertical: 15,
                                    ),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                  ),
                                  child: Text(
                                    "AVANÇAR",
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 12,
                                    ),
                                  ),
                                ),
                              ),
                              SizedBox(height: 20),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    ),);
  }
}
