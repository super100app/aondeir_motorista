import 'package:aondeir_motorista/screens/Usuario/Home/Estatistica/Ganhos/PixWithdrawalErrorScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Home/Estatistica/Ganhos/PixWithdrawalFinalizadoScreen.dart';
import 'package:aondeir_motorista/service/GanhoService.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:provider/provider.dart';

class PixWithdrawalDetailScreen extends StatefulWidget {
  const PixWithdrawalDetailScreen({super.key});

  @override
  State<PixWithdrawalDetailScreen> createState() =>
      _PixWithdrawalDetailScreenState();
}

class _PixWithdrawalDetailScreenState extends State<PixWithdrawalDetailScreen> {
  bool loading = false;

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {});
  }

  void sacarSaldo(BuildContext context) {
    setState(() {
      loading = true;
    });
    var ganhoService = Provider.of<GanhoService>(context, listen: false);
    ganhoService.sacarSaldo().then((sucesso) {
      if (sucesso) {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => PixWithdrawalFinalizadoScreen(),
          ),
        );
      } else {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => PixWithdrawalErrorScreen()),
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return MediaQuery(
      data: MediaQuery.of(context).copyWith(textScaler: TextScaler.linear(1.0)),
      child: Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
          child: Column(
            children: [
              Row(
                children: [
                  IconButton(
                    icon: Icon(Icons.arrow_back_ios_new, color: Colors.black),
                    onPressed: () => Navigator.of(context).pop(),
                  ),
                ],
              ),
              Container(
                margin: const EdgeInsets.only(top: 16),
                alignment: Alignment.center,
                child: Card(
                  elevation: 3,
                  color: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Container(
                    width: MediaQuery.of(context).size.width * 0.95,
                    padding: const EdgeInsets.all(20.0),
                    child:
                        loading == false
                            ? _buildDetalhes(context)
                            : _buildProcessando(),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
          ),
          Text(
            value,
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProcessando() {
    var ganhoService = Provider.of<GanhoService>(context, listen: true);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text("Detalhes da transferência", style: TextStyle(fontSize: 16)),
        SizedBox(height: 10),

        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 32),
            Text(
              "Processando seu pedido",
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Text(
              "Aguarde um momento enquanto realizamos o saque via PIX",
              style: TextStyle(fontSize: 14, color: Colors.grey),
              textAlign: TextAlign.left,
            ),
            SizedBox(height: 20),
            Center(
              child: Column(
                children: [
                  SizedBox(height: 10),
                  Container(
                    margin: const EdgeInsets.all(62),
                    child: Column(
                      children: [
                        SizedBox(height: 10),
                        SizedBox(
                          height: 60,
                          width: 60,
                          child: SpinKitFadingCircle(
                            color: Colors.grey,
                            size: 60.0,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),

        Center(
          child: ElevatedButton(
            onPressed: null,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.grey,
              padding: EdgeInsets.symmetric(horizontal: 50, vertical: 15),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
            child: Text(
              "Sacar via PIX - R\$ ${ganhoService.valorSaque}",
              style: TextStyle(color: Colors.white, fontSize: 14),
            ),
          ),
        ),
        SizedBox(height: 10),
        Center(
          child: Text(
            "Taxa de saque: R\$ ${ganhoService.valorFinalComPercentual} por saque",
            style: TextStyle(fontSize: 12, color: Colors.grey),
          ),
        ),
      ],
    );
  }

  Widget _buildDetalhes(context) {
    var ganhoService = Provider.of<GanhoService>(context, listen: true);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Detalhes da transferências",
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        SizedBox(height: 30),
        _buildDetailRow("Chave PIX", "${ganhoService.chavePix}"),
        SizedBox(height: 10),
        _buildDetailRow(
          "Valor solicitado",
          "R\$ ${ganhoService.valorSolicitado}",
        ),
        SizedBox(height: 10),
        _buildDetailRow(
          "Taxa de saque",
          "R\$ ${ganhoService.valorFinalComPercentual}",
        ),
        SizedBox(height: 10),
        _buildDetailRow("Valor do Saque", "R\$ ${ganhoService.valorSaque}"),
        Divider(),
        _buildDetailRow("A Receber", "R\$ ${ganhoService.valorSaque}"),
        Divider(),
        _buildDetailRow(
          "Saldo disponivel na carteira",
          "R\$ ${ganhoService.carteiraDescontadoFormatado}",
        ),
        SizedBox(height: 20),

        Center(
          child: ElevatedButton(
            onPressed: () {
              sacarSaldo(context);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.green,
              side: BorderSide(color: Colors.green),
              padding: EdgeInsets.symmetric(horizontal: 50, vertical: 15),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
              fixedSize: Size(MediaQuery.of(context).size.width * 0.85, 50),
            ),
            child: Text(
              "Sacar via Pix - R\$ ${ganhoService.valorSaque}",
              style: TextStyle(color: Colors.white, fontSize: 14),
            ),
          ),
        ),
        SizedBox(height: 20),
        Center(
          child: Text(
            "Taxa de saque: R\$ ${ganhoService.valorFinalComPercentual} por saque",
            style: TextStyle(fontSize: 12, color: Colors.grey.shade700),
          ),
        ),
      ],
    );
  }
}
