import 'package:aondeir_motorista/models/BarChart.dart';
import 'package:flutter/material.dart';
import 'package:charts_flutter/flutter.dart' as charts;

class BarChart extends StatelessWidget {
  const BarChart({Key? key}) : super(key: key);

  static List<charts.Series<BarMmodel, String>> _createSampleData() {
    final data = [
      BarMmodel("Seg", 0),
      BarMmodel("Ter", 15),
      BarMmodel("Qua", 0),
      BarMmodel("Qui", 5),
      BarMmodel("Sex", 0),
      BarMmodel("Sab", 6),
      BarMmodel("Dom", 0),
    ];
    return [
      charts.Series<BarMmodel, String>(
        data: data,
        id: 'sales',
        colorFn: (_, __) => charts.MaterialPalette.gray.shade300,
        domainFn: (BarMmodel barModeel, _) => barModeel.year,
        measureFn: (BarMmodel barModeel, _) => barModeel.value,
      )
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 150,
      child: charts.BarChart(
        _createSampleData(),
        animate: true,

        domainAxis: new charts.OrdinalAxisSpec(
          renderSpec: new charts.SmallTickRendererSpec(
            
            labelStyle: new charts.TextStyleSpec(
                fontSize: 15, 
                color: charts.MaterialPalette.white),

            
            lineStyle: new charts.LineStyleSpec(
                color: charts.MaterialPalette.white, thickness: 0),
          ),
        ),

       
        primaryMeasureAxis: new charts.NumericAxisSpec(
          renderSpec: new charts.GridlineRendererSpec(
            
            labelStyle: new charts.TextStyleSpec(
              fontSize: 0, // size in Pts.
              color: charts.MaterialPalette.transparent,
            ),

            
            lineStyle: new charts.LineStyleSpec(
              color: charts.MaterialPalette.transparent,
            ),
          ),
        ),
      ),
    );
  }
}
