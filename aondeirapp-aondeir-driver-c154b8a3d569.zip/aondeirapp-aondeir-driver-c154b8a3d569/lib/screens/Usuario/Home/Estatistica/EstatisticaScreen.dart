import 'package:aondeir_motorista/screens/Usuario/Home/Estatistica/Ganhos/MyGanhosScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/MenuScreen.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../service/GanhoService.dart';
import '../../../../service/RecargaService.dart';
import '../../../../service/UsuarioService.dart';
import '../../Menu/Recarga/HistoricoRecargasScreen.dart';

class EstatisticaScreen extends StatefulWidget {
  const EstatisticaScreen({super.key});

  @override
  State<EstatisticaScreen> createState() => _EstatisticaScreenState();
}

class _EstatisticaScreenState extends State<EstatisticaScreen> {
  final ExpansionTileController controllerExpansion = ExpansionTileController();

  var expanded = true;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      await this.pegarSaldoInvestido();
      await this.pegarGanhosDia();
    });
  }

  pegarSaldoInvestido() async {
    try {
      var recargaService = Provider.of<RecargaService>(context, listen: false);
      await recargaService.pegarSaldoInvestido();
    } catch (e) {
      throw Exception('Failed to load data pegarSaldoInvestido');
    }
  }

  pegarGanhosDia() async {
    try {
      var ganhoService = Provider.of<GanhoService>(context, listen: false);
      await ganhoService.pegarGanhosDia();
    } catch (e) {
      throw Exception('Failed to load data pegarGanhosDia');
    }
  }

  @override
  Widget build(BuildContext context) {
    var usuarioService = Provider.of<UsuarioService>(context, listen: true);
    var recargaService = Provider.of<RecargaService>(context, listen: true);
    var ganhoService = Provider.of<GanhoService>(context, listen: true);

    return Scaffold(
      backgroundColor: Color.fromARGB(255, 58, 58, 58),
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(
            Icons.list,
            color: Colors.white,
            size: 30,
          ),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => MenuScreen(),
              ),
            );
          },
        ),
        title: Icon(
          Icons.directions_car,
          size: 30,
          color: Colors.white,
        ),
        centerTitle: true,
        actions: [],
        backgroundColor: Color.fromARGB(255, 49, 49, 49),
      ),
      body: Padding(
        padding: EdgeInsets.only(left: 15, top: 15, right: 15),
        child: Material(
          type: MaterialType.transparency,
          child: new SingleChildScrollView(
            child: Container(
              color: Color.fromARGB(255, 58, 58, 58),
              child: Column(
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      CircleAvatar(
                        backgroundImage: AssetImage("assets/notPerfil.png"),
                        radius: 30,
                      ),
                      SizedBox(width: 15),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            usuarioService.usuario.name,
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 15,
                                fontWeight: FontWeight.w500),
                          ),
                          SizedBox(height: 5),
                        ],
                      ),
                      Spacer(),
                    ],
                  ),
                  SizedBox(height: 25),
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(6),
                          ),
                          height: 80,
                          padding: EdgeInsets.only(left: 15, right: 5),
                          child: Row(
                            children: <Widget>[
                              InkWell(
                                onTap: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) => MyGanhosScreen(),
                                    ),
                                  );
                                },
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: <Widget>[
                                    Padding(
                                      padding: EdgeInsets.only(right: 15),
                                      child: Container(
                                        child: Text(
                                          "R\$ " + ganhoService.ganhos_dia,
                                          style: TextStyle(
                                            color: Colors.black,
                                            fontSize: 20,
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                      ),
                                    ),
                                    SizedBox(
                                      height: 5,
                                    ),
                                    Text(
                                      "Ganhos do dia",
                                      style: TextStyle(
                                        color: Colors.grey,
                                        fontSize: 12,
                                        fontWeight: FontWeight.w400,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Spacer(),
                              InkWell(
                                onTap: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) => MyGanhosScreen(),
                                    ),
                                  );
                                },
                                child: Container(
                                  child: Icon(
                                    Icons.keyboard_arrow_right_outlined,
                                    size: 30,
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                      ),
                      SizedBox(width: 15),
                      Expanded(
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(6),
                          ),
                          padding: EdgeInsets.only(left: 15, right: 5),
                          height: 80,
                          child: Row(
                            children: <Widget>[
                              InkWell(
                                onTap: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) => HistoricoRecargasScreen(),
                                    ),
                                  );
                                },
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: <Widget>[
                                    Padding(
                                      padding: EdgeInsets.only(right: 15),
                                      child: Container(
                                        child: Text(
                                          "R\$" +
                                              recargaService.saldo_investido,
                                          // "R\$ 25,00",
                                          style: TextStyle(
                                            color: Colors.black,
                                            fontSize: 20,
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                      ),
                                    ),
                                    SizedBox(
                                      height: 5,
                                    ),
                                    Text(
                                      "Créditos",
                                      style: TextStyle(
                                        color: Colors.grey,
                                        fontSize: 12,
                                        fontWeight: FontWeight.w400,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Spacer(),
                              InkWell(
                                onTap: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) => HistoricoRecargasScreen(),
                                    ),
                                  );
                                },
                                child: Container(
                                  child: Icon(
                                    Icons.keyboard_arrow_right_outlined,
                                    size: 30,
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 15,
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
