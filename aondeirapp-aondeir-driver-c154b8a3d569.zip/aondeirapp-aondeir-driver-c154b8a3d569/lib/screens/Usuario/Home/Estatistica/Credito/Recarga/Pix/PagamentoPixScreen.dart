import 'package:aondeir_motorista/styles/app_colors.dart';
import 'package:aondeir_motorista/screens/Usuario/Home/Estatistica/Credito/Recarga/Pix/PagamentoPixAprovadoScreen.dart';
import 'package:flutter/material.dart';

class PagamentoPixScreen extends StatefulWidget {
  const PagamentoPixScreen({super.key});

  @override
  State<PagamentoPixScreen> createState() => _PagamentoPixScreenState();
}

class _PagamentoPixScreenState extends State<PagamentoPixScreen> {
  TextEditingController _controller = new TextEditingController();
  String pixCode = "000002910yed0932109009310v_293192901923";
  @override
  void initState() {
    super.initState();
    _controller.value = TextEditingValue(text: pixCode);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_ios_new,
            color: Colors.orange,
            size: 25,
          ),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(
          "Pagamento",
          style: TextStyle(fontSize: 17, color: Colors.black),
        ),
        elevation: 0,
        centerTitle: true,
        backgroundColor: Colors.white,
      ),
      body: Padding(
        padding: EdgeInsets.all(15),
        child: Material(
          type: MaterialType.transparency,
          child: new SingleChildScrollView(
            child: Container(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Icon(
                        Icons.pix,
                        color: Color.fromARGB(255, 3, 214, 168),
                        size: 50,
                      ),
                      SizedBox(width: 5),
                      Text(
                        "Pix",
                        style: TextStyle(
                          fontSize: 30,
                          fontWeight: FontWeight.bold,
                        ),
                      )
                    ],
                  ),
                  SizedBox(height: 25),
                  Container(
                    margin: EdgeInsets.symmetric(horizontal: 30),
                    child: RichText(
                      textAlign: TextAlign.center,
                      text: TextSpan(
                        style: const TextStyle(
                          fontSize: 16.0,
                          color: Colors.black,
                        ),
                        children: <TextSpan>[
                          TextSpan(text: "Pague "),
                          TextSpan(
                            text: "R\$ 10,00 ",
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          TextSpan(
                              text:
                                  "via Pix no seu banco e adicionaremos o crédito da recarga."),
                        ],
                      ),
                    ),
                  ),
                  Container(
                    alignment: Alignment.center,
                    margin: EdgeInsets.only(top: 20, bottom: 20),
                    child: Text(
                      "Esse código expira em",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.grey[700],
                      ),
                    ),
                  ),
                  TextField(
                    controller: _controller,
                    readOnly: true,
                    enableInteractiveSelection: true,
                    onTap: () {},
                    style: TextStyle(
                      color: Colors.grey.shade700,
                    ),
                    decoration: InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          width: 1,
                          color: Colors.grey.shade200,
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          width: 1,
                          color: Colors.grey.shade200,
                        ),
                      ),
                      filled: true,
                      fillColor: Colors.grey.shade200,
                    ),
                  ),
                  SizedBox(height: 35),
                  Container(
                    child: SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          elevation: 0,
                          backgroundColor: AppColors.buttonSecondary,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(6),
                            side: BorderSide(color: AppColors.buttonBorderSecondary),
                          ),
                          minimumSize: Size(100, 40),
                        ),
                        onPressed: () {},
                        child: Text(
                          "Copiar código PIX",
                          style: TextStyle(fontSize: 16),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 15),
                  Container(
                    child: SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          shadowColor: Colors.transparent,
                          elevation: 0,
                          backgroundColor: Colors.transparent,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(6),
                            side: BorderSide(color: Colors.transparent),
                          ),
                          minimumSize: Size(100, 40),
                        ),
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => PagamentoPixAprovadoScreen(),
                            ),
                          );
                        },
                        child: Text(
                          "Ja fiz o pagamento",
                          style: TextStyle(fontSize: 16, color: Colors.orange),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 30),
                  Divider(thickness: 2),
                  SizedBox(height: 30),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        "Como pagar?",
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 14),
                      ),
                      SizedBox(height: 8),
                      Text(
                        "1.  Acesse seu internet banking ou app do banco.",
                        style: TextStyle(
                            fontWeight: FontWeight.w400, fontSize: 13),
                      ),
                      SizedBox(height: 2),
                      Text(
                        "2. Escolha a opção pagar via Pix.",
                        style: TextStyle(
                            fontWeight: FontWeight.w400, fontSize: 13),
                      ),
                      SizedBox(height: 2),
                      Text(
                        "3. Cole o código.",
                        style: TextStyle(
                            fontWeight: FontWeight.w400, fontSize: 13),
                      ),
                      SizedBox(height: 2),
                      Text(
                        "4. Após o pagamento, a confirmação irá aparecer nesta tela.",
                        style: TextStyle(
                            fontWeight: FontWeight.w400, fontSize: 13),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
