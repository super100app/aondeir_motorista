import 'package:aondeir_motorista/screens/Usuario/Home/Estatistica/Credito/Recarga/Cartao/CadastroCartaoScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Home/Estatistica/Credito/Recarga/Cartao/PagamentoCartaoScreen.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_masked_text2/flutter_masked_text2.dart';

class ValorRecargaCartaoScreen extends StatefulWidget {
  const ValorRecargaCartaoScreen({super.key});

  @override
  State<ValorRecargaCartaoScreen> createState() =>
      _ValorRecargaCartaoScreenState();
}

class _ValorRecargaCartaoScreenState extends State<ValorRecargaCartaoScreen> {
  var validValorMinimo = false;
  String valor = "";

  @override
  Widget build(BuildContext context) {
    final lowPrice = MoneyMaskedTextController(
        decimalSeparator: '.', thousandSeparator: ','); //after

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_ios_new,
            color: Colors.orange,
            size: 25,
          ),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(
          "Recarga com Cartão de credito",
          style: TextStyle(fontSize: 17, color: Colors.black),
        ),
        elevation: 0,
        centerTitle: true,
        backgroundColor: Colors.white,
      ),
      body: Padding(
        padding: EdgeInsets.all(15),
        child: Material(
          type: MaterialType.transparency,
          child: Center(
            child: new SingleChildScrollView(
              child: Container(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Container(
                      margin: EdgeInsets.symmetric(horizontal: 50),
                      child: Text(
                        "Quantos créditos você gostaria de adicionar?",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    Container(
                      child: Center(
                        child: IntrinsicWidth(
                          child: TextField(
                            keyboardType: TextInputType.number,
                            controller: lowPrice,
                            onChanged: (value) {
                              lowPrice.updateValue(double.parse(value));
                            },
                            style: TextStyle(
                              fontSize: 60,
                              fontWeight: FontWeight.bold,
                              color: Colors.orange,
                            ),
                            textAlignVertical: TextAlignVertical.center,
                            decoration: InputDecoration(
                              prefixIcon: Text(
                                "R\$",
                                style: TextStyle(
                                  fontSize: 60,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.orange,
                                ),
                              ),
                              border: InputBorder.none,
                            ),
                          ),
                        ),
                      ),
                    ),
                    if (validValorMinimo == true)
                      Container(
                        child: Text(
                          "Valor mínimo para recarga: R\$10,00",
                          style: TextStyle(
                            fontSize: 15,
                            color: Colors.red,
                          ),
                        ),
                      ),
                    SizedBox(height: 50),
                    Divider(),
                    InkWell(
                      onTap: () {
                        if (lowPrice.numberValue < 10.0) {
                          setState(() {
                            validValorMinimo = true;
                          });
                        } else {
                          setState(() {
                            validValorMinimo = false;
                          });

                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => PagamentoCartaoScreen(),
                            ),
                          );
                        }
                      },
                      child: Container(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            Icon(
                              CupertinoIcons.creditcard,
                              size: 50,
                              color: Colors.grey[800],
                            ),
                            SizedBox(width: 10),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                  "**** 4512",
                                  style: TextStyle(
                                    fontWeight: FontWeight.w600,
                                    color: Colors.grey[800],
                                  ),
                                ),
                                SizedBox(height: 2),
                                Text(
                                  "GUILHERME BARBOSA AMARAL",
                                  style: TextStyle(
                                    fontWeight: FontWeight.w500,
                                    fontSize: 12,
                                    color: Colors.grey[800],
                                  ),
                                ),
                              ],
                            ),
                            Spacer(),
                            Icon(
                              Icons.arrow_forward_ios,
                              size: 16,
                              color: Colors.grey[800],
                            )
                          ],
                        ),
                      ),
                    ),
                    Divider(),
                    SizedBox(height: 15),
                    InkWell(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => CadastroCartaoScreen(),
                          ),
                        );
                      },
                      child: Text(
                        "+ Adicionar novo cartão de crédito",
                        style: TextStyle(
                          color: Colors.grey,
                          fontWeight: FontWeight.w500,
                          fontSize: 14,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
