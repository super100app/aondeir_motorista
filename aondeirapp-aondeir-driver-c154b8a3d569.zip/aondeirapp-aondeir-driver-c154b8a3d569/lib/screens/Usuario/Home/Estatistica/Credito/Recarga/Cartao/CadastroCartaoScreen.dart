import 'package:aondeir_motorista/styles/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_credit_card/flutter_credit_card.dart';

class CadastroCartaoScreen extends StatefulWidget {
  const CadastroCartaoScreen({super.key});

  @override
  State<CadastroCartaoScreen> createState() => _CadastroCartaoScreenState();
}

class _CadastroCartaoScreenState extends State<CadastroCartaoScreen> {
  String cardNumber = '';
  String expiryDate = '';
  String cardHolderName = '';
  String cvvCode = '';
  bool isCvvFocused = false;
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  void onCreditCardModelChange(CreditCardModel creditCardModel) {
    setState(() {
      cardNumber = creditCardModel.cardNumber;
      expiryDate = creditCardModel.expiryDate;
      cardHolderName = creditCardModel.cardHolderName;
      cvvCode = creditCardModel.cvvCode;
      isCvvFocused = creditCardModel.isCvvFocused;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_ios_new,
            color: Colors.orange,
            size: 25,
          ),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(
          "Cadastrar Cartão de crédito",
          style: TextStyle(fontSize: 17, color: Colors.black),
        ),
        elevation: 0,
        centerTitle: true,
        backgroundColor: Colors.white,
      ),
      body: Material(
        type: MaterialType.transparency,
        child: new SingleChildScrollView(
          child: Container(
            color: Colors.white,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                CreditCardWidget(
                  onCreditCardWidgetChange: (p0) {},
                  cardBgColor: Colors.orange,
                  cardNumber: cardNumber,
                  expiryDate: expiryDate,
                  cardHolderName: cardHolderName,
                  cvvCode: cvvCode,
                  showBackView: isCvvFocused,
                  obscureCardNumber: true,
                  obscureCardCvv: true,
                ),
                // CreditCardForm(
                //   formKey: formKey,
                //   cardNumber: cardNumber,
                //   cvvCode: cvvCode,
                //   expiryDate: expiryDate,
                //   cardHolderName: cardHolderName,
                //   onCreditCardModelChange: onCreditCardModelChange,
                  // themeColor: Colors.red,
                  // cardNumberDecoration: const InputDecoration(
                  //   border: OutlineInputBorder(),
                  //   labelText: 'Numero do cartão',
                  //   hintText: 'XXXX XXXX XXXX XXXX',
                  // ),
                  // expiryDateDecoration: const InputDecoration(
                  //   border: OutlineInputBorder(),
                  //   labelText: 'Validade',
                  //   hintText: 'XX/XX',
                  // ),
                  // cvvCodeDecoration: const InputDecoration(
                  //   border: OutlineInputBorder(),
                  //   labelText: 'CVV',
                  //   hintText: 'XXX',
                  // ),
                  // cardHolderDecoration: const InputDecoration(
                  //   border: OutlineInputBorder(),
                  //   labelText: 'Nome do titular',
                  // ),
                // ),
                Padding(
                  padding: EdgeInsets.only(left: 15, right: 15, top: 16),
                  child: TextField(
                    decoration: const InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'CPF',
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(left: 15, right: 15, top: 25),
                  child: TextField(
                    decoration: const InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'CEP',
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(left: 15, right: 15, top: 25),
                  child: TextField(
                    decoration: const InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Número do endereço',
                    ),
                  ),
                ),
                SizedBox(height: 25),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 15),
                  child: SizedBox(
                    width: double.infinity,
                    height: 60,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        elevation: 0,
                        backgroundColor: AppColors.buttonSecondary,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(6),
                          side: BorderSide(color: AppColors.buttonBorderSecondary),
                        ),
                        minimumSize: Size(100, 40),
                      ),
                      onPressed: () {},
                      child: Text(
                        "Cadastrar",
                        style: TextStyle(fontSize: 18),
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 25),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
