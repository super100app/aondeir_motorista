import 'package:aondeir_motorista/styles/app_colors.dart';
import 'package:aondeir_motorista/screens/Usuario/Home/Estatistica/Credito/AddMetodoCreditoScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Home/Estatistica/Credito/Extrato/ExtratoScreen.dart';
import 'package:flutter/material.dart';

class MyCreditoScreen extends StatefulWidget {
  const MyCreditoScreen({super.key});

  @override
  State<MyCreditoScreen> createState() => _MyCreditoScreenState();
}

class _MyCreditoScreenState extends State<MyCreditoScreen> {
// final carousel_slider.CarouselController _controllerCarousel = carousel_slider.CarouselController();


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_ios_new,
            color: Colors.white,
            size: 25,
          ),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(
          "Meus créditos",
          style: TextStyle(fontSize: 17),
        ),
        centerTitle: true,
        backgroundColor: Color.fromARGB(255, 49, 49, 49),
      ),
      body: Material(
        type: MaterialType.transparency,
        child: new SingleChildScrollView(
          child: Container(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Container(
                  color: Color.fromARGB(255, 221, 220, 220),
                  padding: EdgeInsets.all(15),
                  width: double.infinity,
                  child: Column(
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          Text(
                            "Créditos",
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 25,
                            ),
                          ),
                          Spacer(),
                          Text(
                            "R\$ 25,00",
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 19,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 8),
                      Row(
                        children: <Widget>[
                          Text(
                            "Limite minimo de R\$ 5,00",
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Colors.grey[600],
                                fontSize: 13),
                          ),
                          SizedBox(width: 4),
                          InkWell(
                            onTap: () {
                              showModalBottomSheet<void>(
                                context: context,
                                builder: (BuildContext context) {
                                  return Container(
                                    padding: EdgeInsets.all(15),
                                    height: 200,
                                    color: Colors.white,
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      mainAxisSize: MainAxisSize.min,
                                      children: <Widget>[
                                        Row(
                                          children: <Widget>[
                                            Icon(
                                              Icons.info,
                                              color: Colors.grey,
                                              size: 19,
                                            ),
                                            SizedBox(width: 10),
                                            Text(
                                              "Limite mínimo",
                                              style: TextStyle(
                                                fontWeight: FontWeight.bold,
                                                fontSize: 17,
                                              ),
                                            )
                                          ],
                                        ),
                                        SizedBox(height: 15),
                                        Text(
                                          "Se seu saldo de créditos estiver abaixo desse valor, você deixa de receber corridas em dinheiro e maquininha.",
                                          style: TextStyle(
                                              fontSize: 15, color: Colors.grey),
                                        ),
                                        Container(
                                          margin: EdgeInsets.only(top: 30),
                                          child: Column(
                                            children: <Widget>[
                                              SizedBox(
                                                width: double.infinity,
                                                height: 50,
                                                child: ElevatedButton(
                                                  style:
                                                      ElevatedButton.styleFrom(
                                                    elevation: 0,
                                                    shadowColor:
                                                        Colors.transparent,
                                                    backgroundColor:
                                                        Colors.transparent,
                                                    foregroundColor:
                                                        Colors.orange,
                                                    shape:
                                                        RoundedRectangleBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              6),
                                                      side: BorderSide(
                                                          color: Colors.orange),
                                                    ),
                                                    minimumSize: Size(100, 40),
                                                  ),
                                                  onPressed: () {
                                                    Navigator.pop(context);
                                                  },
                                                  child: Text(
                                                    "Fechar",
                                                    style: TextStyle(
                                                        fontSize: 18,
                                                        color: Colors.orange),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  );
                                },
                              );
                            },
                            child: Icon(
                              Icons.info,
                              color: Colors.grey[600],
                              size: 16,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 30),
                      SizedBox(
                        width: double.infinity,
                        height: 50,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppColors.buttonSecondary,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(6),
                              side: BorderSide(color: Colors.orange.shade800),
                            ),
                            minimumSize: Size(100, 40),
                          ),
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => AddMetodoCreditoScreen(),
                              ),
                            );
                          },
                          child: Text(
                            "Adicionar",
                            style: TextStyle(fontSize: 18),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                // Container(
                //   margin: EdgeInsets.all(15),
                //   padding: EdgeInsets.only(left: 15, right: 15),
                //   width: double.infinity,
                //   height: 80,
                //   decoration: BoxDecoration(
                //     color: Color.fromARGB(255, 221, 220, 220),
                //     borderRadius: BorderRadius.circular(6),
                //   ),
                //   child: Column(
                //     crossAxisAlignment: CrossAxisAlignment.start,
                //     children: <Widget>[
                //       Row(
                //         crossAxisAlignment: CrossAxisAlignment.start,
                //         children: <Widget>[
                //           Container(
                //             transform:
                //                 Matrix4.translationValues(0.0, 30.0, 0.0),
                //             child: InkWell(
                //               onTap: () {
                //                 _controllerCarousel.previousPage();
                //               },
                //               child: Icon(Icons.arrow_back_ios_new),
                //             ),
                //           ),
                //           Spacer(),
                //           Container(
                //             transform:
                //                 Matrix4.translationValues(0.0, 30.0, 0.0),
                //             child: InkWell(
                //               onTap: () {
                //                 _controllerCarousel.nextPage();
                //               },
                //               child: Icon(Icons.arrow_forward_ios),
                //             ),
                //           ),
                //         ],
                //       ),
                //       Container(
                //         margin: EdgeInsets.only(right: 25, left: 25),
                //         child: CarouselSlider(
                //           carouselController: _controllerCarousel,
                //           options: CarouselOptions(
                //             height: 37,
                //           ),
                //           items: ["Hoje", "Essa semana", "Semana passada"]
                //               .map((i) {
                //             return Builder(
                //               builder: (BuildContext context) {
                //                 return Padding(
                //                   padding: EdgeInsets.only(left: 35, right: 35),
                //                   child: (Container(
                //                     decoration: BoxDecoration(
                //                       borderRadius: BorderRadius.circular(25),
                //                       color: Color.fromARGB(255, 221, 220, 220),
                //                     ),
                //                     child: Row(
                //                       children: <Widget>[
                //                         Spacer(),
                //                         Column(
                //                           children: <Widget>[
                //                             Text(
                //                               i,
                //                               style: TextStyle(
                //                                 fontWeight: FontWeight.bold,
                //                               ),
                //                             ),
                //                             Text(
                //                               "17 de mai.",
                //                               style: TextStyle(fontSize: 17),
                //                             )
                //                           ],
                //                         ),
                //                         Spacer(),
                //                       ],
                //                     ),
                //                   )),
                //                 );
                //               },
                //             );
                //           }).toList(),
                //         ),
                //       ),
                //     ],
                //   ),
                // ),
                Container(
                  margin: EdgeInsets.only(left: 15, right: 15),
                  child: Row(
                    children: <Widget>[
                      Text(
                        "Adicionados",
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Spacer(),
                      Text(
                        "R\$ 0,00",
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      )
                    ],
                  ),
                ),
                SizedBox(height: 10),
                Container(
                  margin: EdgeInsets.only(left: 15, right: 15),
                  child: Row(
                    children: <Widget>[
                      Text(
                        "Retirados",
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Spacer(),
                      Text(
                        "R\$ 0,00",
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      )
                    ],
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(left: 15, right: 15),
                  child: Divider(height: 30, thickness: 2),
                ),
                Container(
                  margin: EdgeInsets.only(left: 15, right: 15),
                  child: Row(
                    children: <Widget>[
                      Icon(
                        Icons.monetization_on,
                        color: Colors.black,
                        size: 17,
                      ),
                      SizedBox(width: 15),
                      Text(
                        "Total do período",
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Spacer(),
                      Text(
                        "R\$ 0,00",
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      )
                    ],
                  ),
                ),
                SizedBox(height: 10),
                Container(
                  margin: EdgeInsets.only(left: 15, right: 15),
                  child: Row(
                    children: <Widget>[
                      SizedBox(width: 35),
                      Text(
                        "Saldo anterior",
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                          color: Colors.grey,
                        ),
                      ),
                      Spacer(),
                      Text(
                        "R\$ 0,00",
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                          color: Colors.grey,
                        ),
                      )
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.only(left: 15, right: 15, top: 30),
                  child: Column(
                    children: <Widget>[
                      SizedBox(
                        width: double.infinity,
                        height: 50,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            elevation: 0,
                            shadowColor: Colors.transparent,
                            backgroundColor: Colors.transparent,
                            foregroundColor: Colors.orange,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(6),
                              side: BorderSide(color: AppColors.buttonBorderSecondary),
                            ),
                            minimumSize: Size(100, 40),
                          ),
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => ExtratoScreen(),
                              ),
                            );
                          },
                          child: Text(
                            "Extrato",
                            style:
                                TextStyle(fontSize: 18, color: Colors.orange),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
