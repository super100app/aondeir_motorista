import 'package:aondeir_motorista/styles/app_colors.dart';
import 'package:aondeir_motorista/screens/Usuario/Home/Estatistica/Credito/Recarga/Boleto/PagamentoBoletoScreen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_masked_text2/flutter_masked_text2.dart';

class ValorRecargaBoletoScreen extends StatefulWidget {
  const ValorRecargaBoletoScreen({super.key});

  @override
  State<ValorRecargaBoletoScreen> createState() =>
      _ValorRecargaBoletoScreenState();
}

class _ValorRecargaBoletoScreenState extends State<ValorRecargaBoletoScreen> {
  var validValorMinimo = false;
  String valor = "";

  @override
  Widget build(BuildContext context) {
    final lowPrice = MoneyMaskedTextController(
        decimalSeparator: '.', thousandSeparator: ',');

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_ios_new,
            color: Colors.orange,
            size: 25,
          ),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(
          "Recarga por Boleto Bancario",
          style: TextStyle(fontSize: 17, color: Colors.black),
        ),
        elevation: 0,
        centerTitle: true,
        backgroundColor: Colors.white,
      ),
      body: Padding(
        padding: EdgeInsets.all(15),
        child: Material(
          type: MaterialType.transparency,
          child: new Center(
            child: Container(
              child: Column(
                children: <Widget>[
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Container(
                          margin: EdgeInsets.symmetric(horizontal: 50),
                          child: Text(
                            "Quantos créditos você gostaria de adicionar?",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        Container(
                          child: Center(
                            child: IntrinsicWidth(
                              child: TextField(
                                keyboardType: TextInputType.number,
                                controller: lowPrice,
                                onChanged: (value) {
                                  lowPrice.updateValue(double.parse(value));
                                },
                                style: TextStyle(
                                  fontSize: 60,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.orange,
                                ),
                                textAlignVertical: TextAlignVertical.center,
                                decoration: InputDecoration(
                                  prefixIcon: Text(
                                    "R\$",
                                    style: TextStyle(
                                      fontSize: 60,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.orange,
                                    ),
                                  ),
                                  border: InputBorder.none,
                                ),
                              ),
                            ),
                          ),
                        ),
                        if (validValorMinimo == true)
                          Container(
                            child: Text(
                              "Valor mínimo para recarga: R\$10,00",
                              style: TextStyle(
                                fontSize: 15,
                                color: Colors.red,
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                  Container(
                    child: SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          elevation: 0,
                          backgroundColor: AppColors.buttonSecondary,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(6),
                            side: BorderSide(color: AppColors.buttonBorderSecondary),
                          ),
                          minimumSize: Size(100, 40),
                        ),
                        onPressed: () {
                          if (lowPrice.numberValue < 10.0) {
                            setState(() {
                              validValorMinimo = true;
                            });
                          } else {
                            setState(() {
                              validValorMinimo = false;
                            });

                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => PagamentoBoletoScreen(),
                              ),
                            );
                          }
                        },
                        child: Text(
                          "Enviar",
                          style: TextStyle(fontSize: 18),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
