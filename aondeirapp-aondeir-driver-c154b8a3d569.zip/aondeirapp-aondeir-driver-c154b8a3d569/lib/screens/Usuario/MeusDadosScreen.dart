import 'package:aondeir_motorista/models/Categoria.dart';
import 'package:aondeir_motorista/service/LocalizacaoService.dart';
import 'package:aondeir_motorista/styles/app_colors.dart';
import 'package:flutter/material.dart';

import 'package:geolocator/geolocator.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:provider/provider.dart';

import '../../../../models/Passageiro.dart';
import '../../../../service/CorridaService.dart';
import '../../../../service/categoria/CategoriaService.dart';
import '../../../../service/localizacao/PesquisaEnderecoGeocodificacaoPorCoordenadaService.dart';
import '../../../../service/passageiro/PassageiroService.dart';

class MeusDadosScreen extends StatefulWidget {
  const MeusDadosScreen({super.key});

  @override
  State<MeusDadosScreen> createState() => _MeusDadosScreenState();
}

class _MeusDadosScreenState extends State<MeusDadosScreen> {
  TextEditingController _controllerTelefone = TextEditingController();
  TextEditingController _controllerNome = TextEditingController();
  var enderecoAtual;
  var isLoading = false;
  var enderecoAtualLatitude;
  var enderecoAtualLongitude;
  var maskCelular = MaskTextInputFormatter(
      mask: "(##) #####-####", filter: {"#": RegExp(r'[0-9]')});
  List<Categoria> listaCategoria = [];
  var categoriaSelecionada = "";

  @override
  void initState() {
    super.initState();
    buscarCategoriasMacaneta();
  }

  Future<void> buscarUsuarioPassageiroPorTelefone(telefone) async {
    try {
      var passageiroService =
          Provider.of<PassageiroService>(context, listen: false);
      Passageiro? passageiro =
          await passageiroService.buscarPorTelefone(telefone);
      if (passageiro != null) {
        List<String> partes = passageiro.name.split(' ');
        var primeiroNome = partes[0];
        setState(() {
          _controllerNome.text = primeiroNome;
        });
      }
    } catch (e) {
      throw e;
    }
  }

  Future<void> buscarCategoriasMacaneta() async {
    try {
      var categoriaService =
          Provider.of<CategoriaService>(context, listen: false);
      List<Categoria> listaCategoriaResp =
          await categoriaService.buscarCategoriasMacaneta();
      if (listaCategoriaResp.length > 0) {
        setState(() {
          listaCategoria = listaCategoriaResp;
        });
      }
    } catch (e) {
      throw e;
    }
  }

  criarCorridaTeste() async {


  }

  criarCorridaMacaneta() async {
    try {
     
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      Navigator.of(context).pop();
      showModalAlertError("Ops! Algo deu errado, tente novamente mais tarde!");
    }
  }

  showModalAlertError(String message) async {
    showDialog<String>(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        title: Text(
          'Ops!',
          textAlign: TextAlign.center,
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.error,
              color: Colors.red,
              size: 50,
            ),
            SizedBox(height: 10),
            Text(
              message,
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.black),
            ),
          ],
        ),
        actions: <Widget>[
          InkWell(
            onTap: () {
              Navigator.pop(context, "Fechar");
            },
            child: Padding(
              padding: EdgeInsets.only(bottom: 10, left: 15, right: 15),
              child: Text(
                'Fechar',
                style: TextStyle(color: Colors.orange),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void showDialogCreditoInsuficiente(BuildContext context) async {
    await showDialog<String>(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) => AlertDialog(
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(12.0))),
        title: Container(
          child: Text(
            'Ops!',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 13,
              color: Colors.grey[700],
            ),
          ),
        ),
        content: Container(
          width: 350,
          height: 210,
          child: Column(
            children: <Widget>[
              Row(
                children: <Widget>[
                  Flexible(
                    child: Text(
                      "Créditos insuficiente para abrir a corrida!",
                      style: TextStyle(
                        color: Colors.grey[700],
                        fontWeight: FontWeight.w500,
                        fontSize: 12,
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 5),
              Divider(),
              SizedBox(height: 5),
              Row(
                children: <Widget>[
                  Flexible(
                    child: Text(
                      "Clique no botão recarga para fazer um nova recarga de créditos",
                      style: TextStyle(
                        color: Colors.grey[700],
                        fontWeight: FontWeight.w500,
                        fontSize: 12,
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 5),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    elevation: 0,
                    backgroundColor: Colors.transparent,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(6),
                      side: BorderSide(color: AppColors.buttonBorderSecondary),
                    ),
                    minimumSize: Size(100, 40),
                    shadowColor: Colors.transparent,
                  ),
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: Text(
                    "Cancelar",
                    style: TextStyle(fontSize: 18, color: Colors.orange),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  showLoader() {
    if (isLoading == true) {
      showDialog<String>(
        barrierDismissible: false,
        context: context,
        builder: (BuildContext context) => AlertDialog(
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(12.0))),
          title: Container(
            child: Text(
              'Abrindo corrida...',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 13,
                color: Colors.grey[700],
              ),
            ),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(),
              SizedBox(height: 16),
              Text('Carregando...'),
            ],
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    var corridaService = Provider.of<CorridaService>(context, listen: true);
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 58, 58, 58),
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_ios_new,
            color: Colors.white,
            size: 25,
          ),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(
          "Meus Dados",
          style: TextStyle(fontSize: 17),
        ),
        centerTitle: true,
        backgroundColor: Color.fromARGB(255, 49, 49, 49),
      ),
      body: Padding(
        padding: EdgeInsets.only(left: 15, top: 35, right: 15),
        child: Material(
          type: MaterialType.transparency,
          child: new SingleChildScrollView(
            child: Container(
              color: Color.fromARGB(255, 58, 58, 58),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        "E-mail ",
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      SizedBox(height: 5),
                      Container(
                        child: TextField(
                          controller: _controllerTelefone,
                          inputFormatters: [maskCelular],
                          keyboardType: TextInputType.number,
                          onChanged: (value) => {
                            if (value.length == 15)
                              {buscarUsuarioPassageiroPorTelefone(value)}
                          },
                          decoration: InputDecoration(
                            filled: true,
                            fillColor: Colors.grey[100],
                            hintText: " ",
                            errorText:
                                corridaService.formErrorsCorridaMacaneta?[
                                            'telefone'] !=
                                        null
                                    ? corridaService
                                        .formErrorsCorridaMacaneta['telefone']
                                    : null,
                          ),
                        ),
                      )
                    ],
                  ),
                  SizedBox(height: 15),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        "Telefone",
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      SizedBox(height: 5),
                      Container(
                        child: TextField(
                          controller: _controllerTelefone,
                          inputFormatters: [maskCelular],
                          keyboardType: TextInputType.number,
                          onChanged: (value) => {
                            if (value.length == 15)
                              {buscarUsuarioPassageiroPorTelefone(value)}
                          },
                          decoration: InputDecoration(
                            filled: true,
                            fillColor: Colors.grey[100],
                            hintText: " ",
                            errorText:
                                corridaService.formErrorsCorridaMacaneta?[
                                            'telefone'] !=
                                        null
                                    ? corridaService
                                        .formErrorsCorridaMacaneta['telefone']
                                    : null,
                          ),
                        ),
                      )
                    ],
                  ),
                  SizedBox(height: 15),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        "Dados bancários",
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      SizedBox(height: 5),
                      Container(
                        child: TextField(
                          controller: _controllerTelefone,
                          inputFormatters: [maskCelular],
                          keyboardType: TextInputType.number,
                          onChanged: (value) => {
                            if (value.length == 15)
                              {buscarUsuarioPassageiroPorTelefone(value)}
                          },
                          decoration: InputDecoration(
                            filled: true,
                            fillColor: Colors.grey[100],
                            hintText: " ",
                            errorText:
                                corridaService.formErrorsCorridaMacaneta?[
                                            'telefone'] !=
                                        null
                                    ? corridaService
                                        .formErrorsCorridaMacaneta['telefone']
                                    : null,
                          ),
                        ),
                      )
                    ],
                  ),
                  SizedBox(height: 15),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        "Fotos Documentos ",
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      SizedBox(height: 5),
                      Container(
                        child: TextField(
                          controller: _controllerTelefone,
                          inputFormatters: [maskCelular],
                          keyboardType: TextInputType.number,
                          onChanged: (value) => {
                            if (value.length == 15)
                              {buscarUsuarioPassageiroPorTelefone(value)}
                          },
                          decoration: InputDecoration(
                            filled: true,
                            fillColor: Colors.grey[100],
                            hintText: " ",
                            errorText:
                                corridaService.formErrorsCorridaMacaneta?[
                                            'telefone'] !=
                                        null
                                    ? corridaService
                                        .formErrorsCorridaMacaneta['telefone']
                                    : null,
                          ),
                        ),
                      )
                    ],
                  ),
                  SizedBox(height: 15),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        "Fotos perfil ",
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      SizedBox(height: 5),
                      Container(
                        child: TextField(
                          controller: _controllerTelefone,
                          inputFormatters: [maskCelular],
                          keyboardType: TextInputType.number,
                          onChanged: (value) => {
                            if (value.length == 15)
                              {buscarUsuarioPassageiroPorTelefone(value)}
                          },
                          decoration: InputDecoration(
                            filled: true,
                            fillColor: Colors.grey[100],
                            hintText: " ",
                            errorText:
                                corridaService.formErrorsCorridaMacaneta?[
                                            'telefone'] !=
                                        null
                                    ? corridaService
                                        .formErrorsCorridaMacaneta['telefone']
                                    : null,
                          ),
                        ),
                      )
                    ],
                  ),
                  SizedBox(height: 15),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        "Endereço",
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      SizedBox(height: 5),
                      Container(
                        child: TextField(
                          controller: _controllerTelefone,
                          inputFormatters: [maskCelular],
                          keyboardType: TextInputType.number,
                          onChanged: (value) => {
                            if (value.length == 15)
                              {buscarUsuarioPassageiroPorTelefone(value)}
                          },
                          decoration: InputDecoration(
                            filled: true,
                            fillColor: Colors.grey[100],
                            hintText: " ",
                            errorText:
                                corridaService.formErrorsCorridaMacaneta?[
                                            'telefone'] !=
                                        null
                                    ? corridaService
                                        .formErrorsCorridaMacaneta['telefone']
                                    : null,
                          ),
                        ),
                      )
                    ],
                  ),
                  SizedBox(height: 15),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        "Dados do veículo",
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      SizedBox(height: 5),
                      Container(
                        child: TextField(
                          controller: _controllerTelefone,
                          inputFormatters: [maskCelular],
                          keyboardType: TextInputType.number,
                          onChanged: (value) => {
                            if (value.length == 15)
                              {buscarUsuarioPassageiroPorTelefone(value)}
                          },
                          decoration: InputDecoration(
                            filled: true,
                            fillColor: Colors.grey[100],
                            hintText: " ",
                            errorText:
                                corridaService.formErrorsCorridaMacaneta?[
                                            'telefone'] !=
                                        null
                                    ? corridaService
                                        .formErrorsCorridaMacaneta['telefone']
                                    : null,
                          ),
                        ),
                      )
                    ],
                  ),
                  SizedBox(height: 15),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        "E-mail ",
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      SizedBox(height: 5),
                      Container(
                        child: TextField(
                          controller: _controllerTelefone,
                          inputFormatters: [maskCelular],
                          keyboardType: TextInputType.number,
                          onChanged: (value) => {
                            if (value.length == 15)
                              {buscarUsuarioPassageiroPorTelefone(value)}
                          },
                          decoration: InputDecoration(
                            filled: true,
                            fillColor: Colors.grey[100],
                            hintText: " ",
                            errorText:
                                corridaService.formErrorsCorridaMacaneta?[
                                            'telefone'] !=
                                        null
                                    ? corridaService
                                        .formErrorsCorridaMacaneta['telefone']
                                    : null,
                          ),
                        ),
                      )
                    ],
                  ),
                  SizedBox(height: 15),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
