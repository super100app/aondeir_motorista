import 'package:aondeir_motorista/screens/Usuario/Menu/Recarga/CadastroCartaoScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/Recarga/RecargaCartaoCreditoScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/Recarga/RecargaPixScreen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:provider/provider.dart';

import '../../../../service/CartaoService.dart';

class OpcoesRecargaScreen extends StatefulWidget {
  const OpcoesRecargaScreen({super.key});

  @override
  State<OpcoesRecargaScreen> createState() => _OpcoesRecargaScreenState();
}

class _OpcoesRecargaScreenState extends State<OpcoesRecargaScreen> {
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      await pegarCartoes();
    });
  }

  limparListaCartoes() async {
    try {
      var cartaoService = Provider.of<CartaoService>(context, listen: false);
      cartaoService.cartoes.clear();
    } catch (e) {
      throw e;
    }
  }

  pegarCartoes() async {
    try {
      var cartaoService = Provider.of<CartaoService>(context, listen: false);
      await cartaoService.pegarCartoes();
    } catch (e) {
      throw e;
    }
  }

  @override
  Widget build(BuildContext context) {
    var cartaoService = Provider.of<CartaoService>(context, listen: true);
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_ios_new,
            color: Colors.orange,
            size: 25,
          ),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(
          "Opções de recarga",
          style: TextStyle(fontSize: 17),
        ),
        centerTitle: true,
        backgroundColor: Color.fromARGB(255, 49, 49, 49),
      ),
      body: Padding(
        padding: EdgeInsets.all(15),
        child: Material(
          type: MaterialType.transparency,
          child: new SingleChildScrollView(
            child: Container(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    "Aqui você pode escolher a forma de pagamento que deseja fazer a recarga",
                    style: TextStyle(
                      color: Colors.grey,
                      fontSize: 17,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  SizedBox(height: 30),
                  InkWell(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => RecargaPixScreen(),
                        ),
                      );
                    },
                    child: Row(
                      children: <Widget>[
                        Container(
                          padding: EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: Colors.orange.withOpacity(0.2),
                          ),
                          child: Text(
                            "1",
                            style: TextStyle(
                              color: Colors.orange,
                              fontSize: 25,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        SizedBox(width: 15),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              "PIX",
                              style: TextStyle(
                                color: Colors.grey[800],
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                        Spacer(),
                        Icon(
                          Icons.arrow_forward_ios,
                          color: Colors.orange,
                          size: 20,
                        )
                      ],
                    ),
                  ),
                  Divider(),
                  for (var cartao in cartaoService.cartoes)
                    InkWell(
                      onTap: () {
                        cartaoService.cartaoSelecionadoId =
                            cartao.id.toString();

                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => RecargaCartaoCreditoScreen(),
                          ),
                        );
                      },
                      child: Row(
                        children: <Widget>[
                          Container(
                            padding: EdgeInsets.all(20),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.orange.withOpacity(0.2),
                            ),
                            child: Text(
                              "2",
                              style: TextStyle(
                                color: Colors.orange,
                                fontSize: 25,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          SizedBox(width: 15),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(
                                "**********" + cartao.last_four_digits,
                                style: TextStyle(
                                  color: Colors.grey[800],
                                  fontSize: 22,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              SizedBox(width: 5),
                              Text(
                                cartao.brand,
                                style: TextStyle(
                                  color: Colors.grey[800],
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                          Spacer(),
                          Icon(
                            Icons.arrow_forward_ios,
                            color: Colors.orange,
                            size: 20,
                          )
                        ],
                      ),
                    ),
                  Divider(),
                  // InkWell(
                  //   child: Row(children: [
                  //     Container(
                  //       margin: EdgeInsets.symmetric(horizontal: 15),
                  //       child: Column(
                  //         children: <Widget>[
                  //           Row(
                  //             children: <Widget>[
                  //               SvgPicture.asset("assets/mais.svg"),
                  //               SizedBox(
                  //                 width: 15,
                  //               ),
                  //               Container(
                  //                 width: 240,
                  //                 child: InkWell(
                  //                     onTap: () {
                  //                       Navigator.of(context).push(
                  //                         MaterialPageRoute(
                  //                           builder: (context) =>
                  //                               CadastroCartaoScreen(),
                  //                         ),
                  //                       );
                  //                     },
                  //                     child: Text(
                  //                       "Adicionar novo cartão crédito",
                  //                       style: const TextStyle(
                  //                         color: Colors.black,
                  //                       ),
                  //                     )),
                  //               ),
                  //               SizedBox(
                  //                 width: 15,
                  //               ),
                  //             ],
                  //           ),
                  //         ],
                  //       ),
                  //     ),
                  //   ]),
                  // )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
