import 'package:aondeir_motorista/styles/app_colors.dart';
import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_masked_text2/flutter_masked_text2.dart';
import 'package:provider/provider.dart';
import '../../../../service/CartaoService.dart';
import '../../../../service/RecargaService.dart';
import 'HistoricoRecargasScreen.dart';

class RecargaCartaoCreditoScreen extends StatefulWidget {
  const RecargaCartaoCreditoScreen({super.key});

  @override
  State<RecargaCartaoCreditoScreen> createState() =>
      _RecargaCartaoCreditoScreenState();
}

class _RecargaCartaoCreditoScreenState
    extends State<RecargaCartaoCreditoScreen> {
  String valorRecarga = '';
  var isLoading = false;
  var textLoading = "";
  var controller = MoneyMaskedTextController(thousandSeparator: '.');

  criarPedido() async {
    try {
      String valorRecargaConvertido =
          valorRecarga.replaceAll(RegExp('[.,]'), '');
      if (int.parse(valorRecargaConvertido) > 0) {
        setState(() {
          isLoading = true;
          textLoading = "Solicitando recarga...";
        });
        await showLoader();
        await Future.delayed(Duration(seconds: 1));
        final cartaoService =
            Provider.of<CartaoService>(context, listen: false);
        final recargaService =
            Provider.of<RecargaService>(context, listen: false);
        var resultado = await recargaService.gerarPedidoViaCartaoCredito(
            valorRecarga, cartaoService.cartaoSelecionadoId);

        await Future.delayed(Duration(seconds: 1));

        if (resultado == "PENDENTE") {
          Navigator.of(context).pop();
          await showModalAlertSucessoError(
              "Solicitão de recarga efetuada com sucesso! Aguarde a aprovação da recarga!");
          await Future.delayed(Duration(seconds: 3));
          Navigator.of(context).pop();
          setState(() {
            isLoading = false;
          });
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (context) => HistoricoRecargasScreen(),
            ),
          );
        }

        if (resultado == "EFETUADA") {
          Navigator.of(context).pop();
          await showModalAlertSucessoError("Recarga efetuada com sucesso!");
          await Future.delayed(Duration(seconds: 2));
          Navigator.of(context).pop();
          setState(() {
            isLoading = false;
          });
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (context) => HistoricoRecargasScreen(),
            ),
          );
        }
      }
    } catch (e) {
      Navigator.of(context).pop();
      String message = e.toString();
      setState(() {
        isLoading = false;
      });
      showModalAlertError(message);
    }
  }

  showModalAlertError(String message) async {
    showDialog<String>(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        title: Text(
          'Ops!',
          textAlign: TextAlign.center,
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.error,
              color: Colors.red,
              size: 50,
            ),
            SizedBox(height: 10),
            Text(
              message,
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.black),
            ),
          ],
        ),
        actions: <Widget>[
          InkWell(
            onTap: () {
              Navigator.pop(context, "Fechar");
            },
            child: Padding(
              padding: EdgeInsets.only(bottom: 10, left: 15, right: 15),
              child: Text(
                'Fechar',
                style: TextStyle(color: Colors.orange),
              ),
            ),
          ),
        ],
      ),
    );
  }

  showLoader() {
    if (isLoading == true) {
      showDialog<String>(
        barrierDismissible: false,
        context: context,
        builder: (BuildContext context) => AlertDialog(
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(12.0))),
          title: Container(
            child: Text(
              textLoading,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 13,
                color: Colors.grey[700],
              ),
            ),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(),
              SizedBox(height: 16),
              Text('Carregando...'),
            ],
          ),
        ),
      );
    }
  }

  showModalAlertSucessoError(String message) async {
    showDialog<String>(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        title: Text(
          'Sucesso!',
          textAlign: TextAlign.center,
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.check_circle,
              color: Colors.green,
              size: 50,
            ),
            SizedBox(height: 10),
            Text(
              message,
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.black),
            ),
          ],
        ),
        actions: <Widget>[
          InkWell(
            onTap: () {
              Navigator.pop(context, "Fechar");
            },
            child: Padding(
              padding: EdgeInsets.only(bottom: 10, left: 15, right: 15),
              child: Text(
                'Fechar',
                style: TextStyle(color: Colors.orange),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    Provider.of<CartaoService>(context, listen: false);
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 58, 58, 58),
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_ios_new,
            color: Colors.white,
            size: 25,
          ),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(
          "Recarga via Cartão de crédito",
          style: TextStyle(fontSize: 17),
        ),
        centerTitle: true,
        backgroundColor: Color.fromARGB(255, 49, 49, 49),
      ),
      body: Padding(
        padding: EdgeInsets.only(left: 15, top: 35, right: 15),
        child: Material(
          type: MaterialType.transparency,
          child: new SingleChildScrollView(
            child: Container(
              color: Color.fromARGB(255, 58, 58, 58),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Container(
                    child: Text(
                      "Informaçoes da recarga",
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 17,
                      ),
                    ),
                  ),
                  SizedBox(height: 15),
                  Container(
                    child: Text(
                      "Preencha os dados abaixo para gerar efetuar a recarga",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w400,
                        fontSize: 16,
                      ),
                    ),
                  ),
                  SizedBox(height: 20),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        "Valor (R\$)*",
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      SizedBox(height: 5),
                      Container(
                        child: TextField(
                          controller: controller,
                          inputFormatters: [
                            FilteringTextInputFormatter.digitsOnly,
                          ],
                          keyboardType: TextInputType.number,
                          decoration: InputDecoration(
                            filled: true,
                            fillColor: Colors.grey[100],
                            hintText: "Insira o valor da recarga",
                          ),
                          onChanged: (value) {
                            setState(() {
                              valorRecarga = value;
                            });
                          },
                        ),
                      )
                    ],
                  ),
                  SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        elevation: 0,
                        backgroundColor: AppColors.buttonSecondary,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(6),
                          side: BorderSide(color: AppColors.buttonBorderSecondary),
                        ),
                        minimumSize: Size(100, 40),
                      ),
                      onPressed: () {
                        criarPedido();
                      },
                      child: Text(
                        "Fazer recarga",
                        style: TextStyle(fontSize: 18),
                      ),
                    ),
                  ),
                  SizedBox(height: 15),
                  Container(
                    child: Text(
                      "Solicitação de recarga via cartão de crédito",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.white60,
                        fontWeight: FontWeight.w400,
                        fontSize: 12,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
