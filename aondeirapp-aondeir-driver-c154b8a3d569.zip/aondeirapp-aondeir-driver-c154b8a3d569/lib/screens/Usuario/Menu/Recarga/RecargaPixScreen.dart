import 'package:aondeir_motorista/styles/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_masked_text2/flutter_masked_text2.dart';
import 'package:provider/provider.dart';
import 'package:qr_flutter/qr_flutter.dart';
import '../../../../models/Transaca.dart';
import '../../../../service/RecargaService.dart';

class RecargaPixScreen extends StatefulWidget {
  const RecargaPixScreen({super.key});

  @override
  State<RecargaPixScreen> createState() => _RecargaPixScreenState();
}

class _RecargaPixScreenState extends State<RecargaPixScreen> {
  String qrCodeData = '';
  String qrCode = '';
  String valorRecarga = '0,00';
  var controller = MoneyMaskedTextController(thousandSeparator: '.');
  var isLoading = false;
  var textLoading = "";

  gerarCodigo() async {
    try {
      if (valorRecarga == '0,00') {
        await showModalAlertError("Digite um valor para fazer sua recarga!");
      }
      String valorRecargaConvertido =
          valorRecarga.replaceAll(RegExp('[.,]'), '');
          
      if (int.parse(valorRecargaConvertido) > 0) {
        setState(() {
          isLoading = true;
          textLoading = "Gerando código...";
        });
        await showLoader();
        await Future.delayed(Duration(seconds: 1));

        final recargaService =
            Provider.of<RecargaService>(context, listen: false);
        final Transacao transacao =
            await recargaService.gerarPedido(valorRecarga);

        Navigator.of(context).pop();
        await showModalAlertSucessoError("Código gerado com sucesso!");
        await Future.delayed(Duration(seconds: 1));
        Navigator.of(context).pop();
        setState(() {
          isLoading = false;
        });
        await fetchQrCodeData(transacao);
      }
    } catch (e) {
      Navigator.of(context).pop();
      String message = e.toString();
      setState(() {
        isLoading = false;
      });
      showModalAlertError(message);
    }
  }

  copiarCodigo() async {
    await Clipboard.setData(ClipboardData(text: qrCode));
    final snackBar = SnackBar(
      content: Text('Código QR copiado para a área de transferência!'),
    );
    ScaffoldMessenger.of(context).showSnackBar(snackBar);
  }

  Future<void> fetchQrCodeData(Transacao transacao) async {
    try {

      setState(() {
        qrCode = transacao.qr_code;
        qrCodeData = transacao.qr_code_url;
      });
    } catch (e) {
      throw e;
    }
  }

  showModalAlertError(String message) async {
    showDialog<String>(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        title: Text(
          'Ops!',
          textAlign: TextAlign.center,
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.error,
              color: Colors.red,
              size: 50,
            ),
            SizedBox(height: 10),
            Text(
              message,
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.black),
            ),
          ],
        ),
        actions: <Widget>[
          InkWell(
            onTap: () {
              Navigator.pop(context, "Fechar");
            },
            child: Padding(
              padding: EdgeInsets.only(bottom: 10, left: 15, right: 15),
              child: Text(
                'Fechar',
                style: TextStyle(color: Colors.orange),
              ),
            ),
          ),
        ],
      ),
    );
  }

  showLoader() {
    if (isLoading == true) {
      showDialog<String>(
        barrierDismissible: false,
        context: context,
        builder: (BuildContext context) => AlertDialog(
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(12.0))),
          title: Container(
            child: Text(
              textLoading,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 13,
                color: Colors.grey[700],
              ),
            ),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(),
              SizedBox(height: 16),
              Text('Carregando...'),
            ],
          ),
        ),
      );
    }
  }

  showModalAlertSucessoError(String message) async {
    showDialog<String>(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        title: Text(
          'Sucesso!',
          textAlign: TextAlign.center,
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.check_circle,
              color: Colors.green,
              size: 50,
            ),
            SizedBox(height: 10),
            Text(
              message,
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.black),
            ),
          ],
        ),
        actions: <Widget>[
          InkWell(
            onTap: () {
              Navigator.pop(context, "Fechar");
            },
            child: Padding(
              padding: EdgeInsets.only(bottom: 10, left: 15, right: 15),
              child: Text(
                'Fechar',
                style: TextStyle(color: Colors.orange),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 58, 58, 58),
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_ios_new,
            color: Colors.white,
            size: 25,
          ),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(
          "Recarga via PIX",
          style: TextStyle(fontSize: 17),
        ),
        centerTitle: true,
        backgroundColor: Color.fromARGB(255, 49, 49, 49),
      ),
      body: Padding(
        padding: EdgeInsets.only(left: 15, top: 35, right: 15),
        child: Material(
          type: MaterialType.transparency,
          child: new SingleChildScrollView(
            child: Container(
              color: Color.fromARGB(255, 58, 58, 58),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Container(
                    child: Text(
                      "Informações da recarga",
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 17,
                      ),
                    ),
                  ),
                  SizedBox(height: 15),
                  Container(
                    child: Text(
                      "Preencha os dados abaixo para gerar o QR code da chave pix",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w400,
                        fontSize: 16,
                      ),
                    ),
                  ),
                  SizedBox(height: 20),
                  qrCodeData.isEmpty
                      ? Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              "Valor (R\$)*",
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            SizedBox(height: 5),
                            Container(
                              child: TextField(
                                controller: controller,
                                inputFormatters: [
                                  FilteringTextInputFormatter.digitsOnly,
                                ],
                                keyboardType: TextInputType.number,
                                decoration: InputDecoration(
                                  filled: true,
                                  fillColor: Colors.grey[100],
                                  hintText: "Insira o valor da recarga",
                                ),
                                onChanged: (value) {
                                  setState(() {
                                    valorRecarga = value;
                                  });
                                },
                              ),
                            )
                          ],
                        )
                      : SizedBox(),
                  qrCodeData.isNotEmpty
                      ? Container(
                          child: LayoutBuilder(
                            builder: (BuildContext context,
                                    BoxConstraints constraints) =>
                                QrImageView(
                                    data: qrCodeData,
                                    version: QrVersions.auto,
                                    size: 200.0,
                                    backgroundColor: Colors.white),
                          ),
                        )
                      : SizedBox(),
                  if (qrCode.isNotEmpty) SizedBox(height: 20),
                  qrCode.isNotEmpty
                      ? Container(
                          child: Text(
                            qrCode,
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: Colors.white60,
                              fontWeight: FontWeight.w400,
                              fontSize: 12,
                            ),
                          ),
                        )
                      : SizedBox(),
                  SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        elevation: 0,
                        backgroundColor: AppColors.buttonSecondary,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(6),
                          side: BorderSide(color: AppColors.buttonBorderSecondary),
                        ),
                        minimumSize: Size(100, 40),
                      ),
                      onPressed: () {
                        qrCodeData.isEmpty ? gerarCodigo() : copiarCodigo();
                      },
                      child: Text(
                        qrCodeData.isEmpty ? "Gerar código" : "Copiar código",
                        style: TextStyle(fontSize: 18),
                      ),
                    ),
                  ),
                  SizedBox(height: 15),
                  Container(
                    child: Text(
                      "A solicitação de recarga via pix, vai gerar um QR code e uma chave copia e cola para que seja feito o pagamento",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.white60,
                        fontWeight: FontWeight.w400,
                        fontSize: 12,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
