import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:provider/provider.dart';

import '../../../../service/RecargaService.dart';
import 'OpcoesRecargaScreen.dart';
import 'package:intl/intl.dart';

class HistoricoRecargasScreen extends StatefulWidget {
  const HistoricoRecargasScreen({super.key});

  @override
  State<HistoricoRecargasScreen> createState() =>
      _HistoricoRecargasScreenState();
}

class _HistoricoRecargasScreenState extends State<HistoricoRecargasScreen> {
  final formatoReais = NumberFormat("#,##0.00", "pt_BR");

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      await this.pegarSaldoInvestido();
      await this.pegarLista();
    });
  }

  pegarSaldoInvestido() async {
    try {
      var recargaService = Provider.of<RecargaService>(context, listen: false);
      await recargaService.pegarSaldoInvestido();
    } catch (e) {
      throw Exception('Failed to load data pegarSaldoInvestido');
    }
  }

  pegarLista() async {
    try {
      var recargaService = Provider.of<RecargaService>(context, listen: false);
      await recargaService.pegarLista();
    } catch (e) {
      throw Exception('Failed to load data pegarSaldoInvestido');
    }
  }

  @override
  Widget build(BuildContext context) {
    var recargaService = Provider.of<RecargaService>(context, listen: true);
    return MediaQuery(
      data: MediaQuery.of(context).copyWith(textScaler: TextScaler.linear(1.0)),
      child:Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_ios_new,
            color: Colors.white,
            size: 25,
          ),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(
          "Histórico de Recargas",
          style: TextStyle(fontSize: 17),
        ),
        centerTitle: true,
        backgroundColor: Color.fromARGB(255, 49, 49, 49),
      ),
      body: Material(
        type: MaterialType.transparency,
        child: new SingleChildScrollView(
          child: Container(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                SizedBox(height: 25),
                Container(
                  margin: EdgeInsets.only(left: 15, right: 15),
                  child: Row(
                    children: <Widget>[
                      Icon(
                        Icons.monetization_on,
                        color: Colors.black,
                        size: 17,
                      ),
                      SizedBox(width: 15),
                      Text(
                        "Créditos atual",
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Spacer(),
                      Text(
                        "R\$" + recargaService.saldo_investido,
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      )
                    ],
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(left: 15, right: 15),
                  child: Divider(height: 30, thickness: 2),
                ),
                InkWell(
                  child: Row(children: [
                    Container(
                      margin: EdgeInsets.symmetric(horizontal: 15),
                      child: Column(
                        children: <Widget>[
                          Row(
                            children: <Widget>[
                              SvgPicture.asset("assets/mais.svg"),
                              SizedBox(
                                width: 15,
                              ),
                              Container(
                                width: 240,
                                child: InkWell(
                                    onTap: () {
                                      Navigator.of(context).push(
                                        MaterialPageRoute(
                                          builder: (context) =>
                                              OpcoesRecargaScreen(),
                                        ),
                                      );
                                    },
                                    child: Text(
                                      "Fazer nova recarga",
                                      style: const TextStyle(
                                        color: Colors.black,
                                      ),
                                    )),
                              ),
                              SizedBox(
                                width: 15,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ]),
                ),
                SizedBox(height: 15),
                for (var recarga in recargaService.recargas)
                  InkWell(
                    child: Container(
                      margin: EdgeInsets.only(left: 15, right: 15, bottom: 15),
                      padding: EdgeInsets.all(15),
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: Color.fromARGB(255, 49, 49, 49),
                        ),
                        borderRadius: BorderRadius.circular(10),
                        color: Color.fromARGB(255, 49, 49, 49),
                      ),
                      child: Row(
                        children: <Widget>[
                          Column(
                            children: <Widget>[
                              Text(
                                DateTime.parse(recarga.data)
                                        .day
                                        .toString()
                                        .padLeft(2, '0') +
                                    "/" +
                                    DateTime.parse(recarga.data)
                                        .month
                                        .toString()
                                        .padLeft(2, '0'),
                                style: TextStyle(
                                  color: Colors.orange,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 13,
                                ),
                              ),
                              Text(
                                DateTime.parse(recarga.data)
                                        .hour
                                        .toString()
                                        .padLeft(2, '0') +
                                    ":" +
                                    DateTime.parse(recarga.data)
                                        .minute
                                        .toString()
                                        .padLeft(2, '0'),
                                style: TextStyle(
                                  color: Colors.orange,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 13,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(width: 15),
                          Flexible(
                            child: Container(
                              child: Text(
                                maxLines: 3,
                                recarga.observacao,
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 14,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ),
                          ),
                          Spacer(),
                          Text(
                            "R\$ " +
                                formatoReais
                                    .format(double.parse(recarga.valor)),
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 14,
                              fontWeight: FontWeight.w500,
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                SizedBox(height: 15),
              ],
            ),
          ),
        ),
      ),
    ));
  }
}
