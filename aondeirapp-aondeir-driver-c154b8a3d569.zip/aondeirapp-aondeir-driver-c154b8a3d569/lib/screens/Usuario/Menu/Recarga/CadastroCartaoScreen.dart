import 'package:aondeir_motorista/styles/app_colors.dart';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_credit_card/flutter_credit_card.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import '../../../../service/CartaoService.dart';
import 'package:provider/provider.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/Recarga/OpcoesRecargaScreen.dart';

class CadastroCartaoScreen extends StatefulWidget {
  const CadastroCartaoScreen({super.key});

  @override
  State<CadastroCartaoScreen> createState() => _CadastroCartaoScreenState();
}

class _CadastroCartaoScreenState extends State<CadastroCartaoScreen> {
  TextEditingController _controllerEstado = TextEditingController();

  final storage = new FlutterSecureStorage();
  String cardNumber = '';
  String expiryDate = '';
  String cardHolderName = '';
  String cvvCode = '';
  bool isCvvFocused = false;
  String cpf = '';
  String cep = '';
  String rua = '';
  String rua_numero = '';
  String bairro = '';
  String cidade = '';
  String estado = '';

  String estadoSelecionado = '';

  var isLoading = false;
  var textLoading = "";

  var errorsForm = null;

  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  final maskCpf = MaskTextInputFormatter(
      mask: "###.###.###-##", filter: {"#": RegExp(r'[0-9]')});
  final maskCep = MaskTextInputFormatter(
      mask: "#####-###", filter: {"#": RegExp(r'[0-9]')});
  final maskNumeroEndereco = MaskTextInputFormatter(
      mask: "###########", filter: {"#": RegExp(r'[0-9]')});

  void onCreditCardModelChange(CreditCardModel creditCardModel) {
    setState(() {
      cardNumber = creditCardModel.cardNumber;
      expiryDate = creditCardModel.expiryDate;
      cardHolderName = creditCardModel.cardHolderName;
      cvvCode = creditCardModel.cvvCode;
      isCvvFocused = creditCardModel.isCvvFocused;
    });
  }

  void handleCadastro() async {
    try {
      setState(() {
        isLoading = true;
        textLoading = "Cadastrando...";
      });
      await showLoader();
      await Future.delayed(Duration(seconds: 1));

      var exp_partes = expiryDate.split('/');
      String url =
          dotenv.env['BASE_URL']! + "api/pagarme/cadastrar-cartao-credito";
      var token = await storage.read(key: 'jwt');

      var response = await http.post(
        Uri.parse(url),
        body: {
          "number": cardNumber,
          "exp_month": expiryDate.isNotEmpty ? exp_partes[0] : "",
          "exp_year": expiryDate.isNotEmpty ? exp_partes[1] : "",
          "cvv": cvvCode,
          "holder_name": cardHolderName,
          "holder_document": cpf,
          "cep": cep,
          "rua": rua,
          "rua_numero": rua_numero,
          "bairro": bairro,
          "cidade": cidade,
          "estado": estado,
        },
        headers: {
          HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
        },
      );

      final json = jsonDecode(response.body);

      if (response.statusCode == 201) {
        Navigator.of(context).pop();
        await showModalAlertSucessoError("Cartão cadastrado com sucesso!");
        await Future.delayed(Duration(seconds: 1));
        Navigator.of(context).pop();
        setState(() {
          isLoading = false;
        });
      } else {
        Navigator.of(context).pop();
        setState(() {
          isLoading = false;
          errorsForm = json;
        });
      }
    } catch (e) {
      Navigator.of(context).pop();
      String message = e.toString();
      setState(() {
        isLoading = false;
      });
      showModalAlertError(message);
    }
  }

  showLoader() {
    if (isLoading == true) {
      showDialog<String>(
        barrierDismissible: false,
        context: context,
        builder: (BuildContext context) => AlertDialog(
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(12.0))),
          title: Container(
            child: Text(
              textLoading,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 13,
                color: Colors.grey[700],
              ),
            ),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(),
              SizedBox(height: 16),
              Text('Carregando...'),
            ],
          ),
        ),
      );
    }
  }

  showModalAlertError(String message) async {
    showDialog<String>(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        title: Text(
          'Ops!',
          textAlign: TextAlign.center,
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.error,
              color: Colors.red,
              size: 50,
            ),
            SizedBox(height: 10),
            Text(
              message,
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.black),
            ),
          ],
        ),
        actions: <Widget>[
          InkWell(
            onTap: () {
              Navigator.pop(context, "Fechar");
            },
            child: Padding(
              padding: EdgeInsets.only(bottom: 10, left: 15, right: 15),
              child: Text(
                'Fechar',
                style: TextStyle(color: Colors.orange),
              ),
            ),
          ),
        ],
      ),
    );
  }

  showModalAlertSucessoError(String message) async {
    showDialog<String>(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        title: Text(
          'Sucesso!',
          textAlign: TextAlign.center,
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.check_circle,
              color: Colors.green,
              size: 50,
            ),
            SizedBox(height: 10),
            Text(
              message,
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.black),
            ),
          ],
        ),
        actions: <Widget>[
          InkWell(
            onTap: () {
              Navigator.pop(context, "Fechar");
            },
            child: Padding(
              padding: EdgeInsets.only(bottom: 10, left: 15, right: 15),
              child: Text(
                'Fechar',
                style: TextStyle(color: Colors.orange),
              ),
            ),
          ),
        ],
      ),
    );
  }

  cadastrar() async {
    try {
      var cartaoService = Provider.of<CartaoService>(context, listen: false);
      setState(() {
        isLoading = true;
        textLoading = "Cadastrando...";
      });
      await showLoader();
      await Future.delayed(Duration(seconds: 1));
      var resultado = await cartaoService.cadastrar();

      if (resultado == true) {
        Navigator.of(context).pop();
        await showModalAlertSucessoError("Cartão cadastrado com sucesso!");
        await Future.delayed(Duration(seconds: 1));
        Navigator.of(context).pop();
        setState(() {
          isLoading = false;
        });

        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (context) => OpcoesRecargaScreen(),
          ),
        );
      } else {
        Navigator.of(context).pop();
        setState(() {
          isLoading = false;
        });
      }
    } catch (e) {
      Navigator.of(context).pop();
      String message = e.toString();
      setState(() {
        isLoading = false;
      });
      showModalAlertError(message);
    }
  }

  @override
  Widget build(BuildContext context) {
    Provider.of<CartaoService>(context, listen: true);
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back,
            color: Color(0xFFF9AD1E),
            size: 25,
          ),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(
          "Cadastro de cartão",
          style: TextStyle(fontSize: 17, color: Color(0xFFF9AD1E)),
        ),
        elevation: 0,
        centerTitle: true,
        backgroundColor: Colors.white,
      ),
      body: Material(
        type: MaterialType.transparency,
        child: new SingleChildScrollView(
          child: Container(
            color: Colors.white,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 15),
                  alignment: Alignment.centerLeft,
                  child: Text(
                    "Pagamentos com Motorista ",
                    textAlign: TextAlign.start,
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w400,
                      color: Color(0xFF979797),
                    ),
                  ),
                ),
                CreditCardWidget(
                  onCreditCardWidgetChange: (p0) {},
                  cardBgColor: Color(0xFFF9AD1E),
                  cardNumber: cardNumber,
                  expiryDate: expiryDate,
                  cardHolderName: cardHolderName,
                  cvvCode: cvvCode,
                  showBackView: isCvvFocused,
                  obscureCardNumber: true,
                  obscureCardCvv: true,
                ),
                // CreditCardForm(
                //   formKey: formKey,
                //   cardNumber: cardNumber,
                //   cvvCode: cvvCode,
                //   expiryDate: expiryDate,
                //   cardHolderName: cardHolderName,
                //   onCreditCardModelChange: onCreditCardModelChange,
                  // themeColor: Colors.red,
                  // cardNumberDecoration: InputDecoration(
                  //   border: OutlineInputBorder(
                  //     borderRadius: BorderRadius.all(
                  //       Radius.circular(10),
                  //     ),
                  //     borderSide: BorderSide(
                  //       color: Color(0xFFEDEDED),
                  //     ),
                  //   ),
                  //   enabledBorder: OutlineInputBorder(
                  //     borderRadius: BorderRadius.all(
                  //       Radius.circular(10),
                  //     ),
                  //     borderSide: BorderSide(
                  //       color: Color(0xFFEDEDED),
                  //     ),
                  //   ),
                  //   focusedBorder: OutlineInputBorder(
                  //     borderRadius: BorderRadius.all(
                  //       Radius.circular(10),
                  //     ),
                  //     borderSide: BorderSide(
                  //       color: Color(0xFFEDEDED),
                  //     ),
                  //   ),
                  //   fillColor: Color(0xFFEDEDED),
                  //   filled: true,
                  //   labelText: 'Numero do cartão',
                  //   hintText: 'XXXX XXXX XXXX XXXX',
                  //   errorText: errorsForm?['number'] != null
                  //       ? errorsForm['number']
                  //       : null,
                  //   labelStyle: TextStyle(
                  //     color: Color(0xFF979797),
                  //     fontSize: 16,
                  //     fontWeight: FontWeight.w700,
                  //   ),
                  // ),
                  // expiryDateDecoration: InputDecoration(
                  //   border: OutlineInputBorder(
                  //     borderRadius: BorderRadius.all(
                  //       Radius.circular(10),
                  //     ),
                  //     borderSide: BorderSide(
                  //       color: Color(0xFFEDEDED),
                  //     ),
                  //   ),
                  //   enabledBorder: OutlineInputBorder(
                  //     borderRadius: BorderRadius.all(
                  //       Radius.circular(10),
                  //     ),
                  //     borderSide: BorderSide(
                  //       color: Color(0xFFEDEDED),
                  //     ),
                  //   ),
                  //   focusedBorder: OutlineInputBorder(
                  //     borderRadius: BorderRadius.all(
                  //       Radius.circular(10),
                  //     ),
                  //     borderSide: BorderSide(
                  //       color: Color(0xFFEDEDED),
                  //     ),
                  //   ),
                  //   fillColor: Color(0xFFEDEDED),
                  //   filled: true,
                  //   labelText: 'Validade',
                  //   hintText: 'XX/XXXX',
                  //   errorText: errorsForm?['exp_year'] != null
                  //       ? errorsForm['exp_year']
                  //       : null,
                  //   labelStyle: TextStyle(
                  //     color: Color(0xFF979797),
                  //     fontSize: 16,
                  //     fontWeight: FontWeight.w700,
                  //   ),
                  // ),
                  // cvvCodeDecoration: InputDecoration(
                  //   border: OutlineInputBorder(
                  //     borderRadius: BorderRadius.all(
                  //       Radius.circular(10),
                  //     ),
                  //     borderSide: BorderSide(
                  //       color: Color(0xFFEDEDED),
                  //     ),
                  //   ),
                  //   enabledBorder: OutlineInputBorder(
                  //     borderRadius: BorderRadius.all(
                  //       Radius.circular(10),
                  //     ),
                  //     borderSide: BorderSide(
                  //       color: Color(0xFFEDEDED),
                  //     ),
                  //   ),
                  //   focusedBorder: OutlineInputBorder(
                  //     borderRadius: BorderRadius.all(
                  //       Radius.circular(10),
                  //     ),
                  //     borderSide: BorderSide(
                  //       color: Color(0xFFEDEDED),
                  //     ),
                  //   ),
                  //   fillColor: Color(0xFFEDEDED),
                  //   filled: true,
                  //   labelText: 'CVV',
                  //   hintText: 'XXX',
                  //   errorText:
                  //       errorsForm?['cvv'] != null ? errorsForm['cvv'] : null,
                  //   labelStyle: TextStyle(
                  //     color: Color(0xFF979797),
                  //     fontSize: 16,
                  //     fontWeight: FontWeight.w700,
                  //   ),
                  // ),
                  // cardHolderDecoration: InputDecoration(
                  //   border: OutlineInputBorder(
                  //     borderRadius: BorderRadius.all(
                  //       Radius.circular(10),
                  //     ),
                  //     borderSide: BorderSide(
                  //       color: Color(0xFFEDEDED),
                  //     ),
                  //   ),
                  //   enabledBorder: OutlineInputBorder(
                  //     borderRadius: BorderRadius.all(
                  //       Radius.circular(10),
                  //     ),
                  //     borderSide: BorderSide(
                  //       color: Color(0xFFEDEDED),
                  //     ),
                  //   ),
                  //   focusedBorder: OutlineInputBorder(
                  //     borderRadius: BorderRadius.all(
                  //       Radius.circular(10),
                  //     ),
                  //     borderSide: BorderSide(
                  //       color: Color(0xFFEDEDED),
                  //     ),
                  //   ),
                  //   fillColor: Color(0xFFEDEDED),
                  //   filled: true,
                  //   labelText: 'Nome do titular',
                  //   errorText: errorsForm?['holder_name'] != null
                  //       ? errorsForm['holder_name']
                  //       : null,
                  //   labelStyle: TextStyle(
                  //     color: Color(0xFF979797),
                  //     fontSize: 16,
                  //     fontWeight: FontWeight.w700,
                  //   ),
                  // ),
                // ),
                Padding(
                  padding: EdgeInsets.only(left: 15, right: 15, top: 16),
                  child: TextField(
                    onChanged: (String value) async {
                      setState(() {
                        cpf = value;
                      });
                    },
                    inputFormatters: [maskCpf],
                    decoration: InputDecoration(
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.all(
                          Radius.circular(10),
                        ),
                        borderSide: BorderSide(
                          color: Color(0xFFEDEDED),
                        ),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.all(
                          Radius.circular(10),
                        ),
                        borderSide: BorderSide(
                          color: Color(0xFFEDEDED),
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.all(
                          Radius.circular(10),
                        ),
                        borderSide: BorderSide(
                          color: Color(0xFFEDEDED),
                        ),
                      ),
                      fillColor: Color(0xFFEDEDED),
                      filled: true,
                      labelText: 'CPF',
                      hintText: '000.000.00-00',
                      errorText: errorsForm?['holder_document'] != null
                          ? errorsForm['holder_document']
                          : null,
                      labelStyle: TextStyle(
                        color: Color(0xFF979797),
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(left: 15, right: 15, top: 25),
                  child: TextField(
                    onChanged: (String value) async {
                      setState(() {
                        cep = value;
                      });
                    },
                    inputFormatters: [maskCep],
                    decoration: InputDecoration(
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.all(
                          Radius.circular(10),
                        ),
                        borderSide: BorderSide(
                          color: Color(0xFFEDEDED),
                        ),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.all(
                          Radius.circular(10),
                        ),
                        borderSide: BorderSide(
                          color: Color(0xFFEDEDED),
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.all(
                          Radius.circular(10),
                        ),
                        borderSide: BorderSide(
                          color: Color(0xFFEDEDED),
                        ),
                      ),
                      fillColor: Color(0xFFEDEDED),
                      filled: true,
                      labelText: 'CEP',
                      errorText:
                          errorsForm?['cep'] != null ? errorsForm['cep'] : null,
                      labelStyle: TextStyle(
                        color: Color(0xFF979797),
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(left: 15, right: 15, top: 25),
                  child: TextField(
                    onChanged: (String value) async {
                      setState(() {
                        rua = value;
                      });
                    },
                    decoration: InputDecoration(
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.all(
                          Radius.circular(10),
                        ),
                        borderSide: BorderSide(
                          color: Color(0xFFEDEDED),
                        ),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.all(
                          Radius.circular(10),
                        ),
                        borderSide: BorderSide(
                          color: Color(0xFFEDEDED),
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.all(
                          Radius.circular(10),
                        ),
                        borderSide: BorderSide(
                          color: Color(0xFFEDEDED),
                        ),
                      ),
                      fillColor: Color(0xFFEDEDED),
                      filled: true,
                      labelText: 'Rua',
                      errorText:
                          errorsForm?['rua'] != null ? errorsForm['rua'] : null,
                      labelStyle: TextStyle(
                        color: Color(0xFF979797),
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(left: 15, right: 15, top: 25),
                  child: TextField(
                    onChanged: (String value) async {
                      setState(() {
                        rua_numero = value;
                      });
                    },
                    inputFormatters: [maskNumeroEndereco],
                    decoration: InputDecoration(
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.all(
                          Radius.circular(10),
                        ),
                        borderSide: BorderSide(
                          color: Color(0xFFEDEDED),
                        ),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.all(
                          Radius.circular(10),
                        ),
                        borderSide: BorderSide(
                          color: Color(0xFFEDEDED),
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.all(
                          Radius.circular(10),
                        ),
                        borderSide: BorderSide(
                          color: Color(0xFFEDEDED),
                        ),
                      ),
                      fillColor: Color(0xFFEDEDED),
                      filled: true,
                      labelText: 'Número da rua',
                      errorText: errorsForm?['rua_numero'] != null
                          ? errorsForm['rua_numero']
                          : null,
                      labelStyle: TextStyle(
                        color: Color(0xFF979797),
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(left: 15, right: 15, top: 25),
                  child: TextField(
                    onChanged: (String value) async {
                      setState(() {
                        bairro = value;
                      });
                    },
                    decoration: InputDecoration(
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.all(
                          Radius.circular(10),
                        ),
                        borderSide: BorderSide(
                          color: Color(0xFFEDEDED),
                        ),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.all(
                          Radius.circular(10),
                        ),
                        borderSide: BorderSide(
                          color: Color(0xFFEDEDED),
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.all(
                          Radius.circular(10),
                        ),
                        borderSide: BorderSide(
                          color: Color(0xFFEDEDED),
                        ),
                      ),
                      fillColor: Color(0xFFEDEDED),
                      filled: true,
                      labelText: 'Bairro',
                      errorText: errorsForm?['bairro'] != null
                          ? errorsForm['bairro']
                          : null,
                      labelStyle: TextStyle(
                        color: Color(0xFF979797),
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(left: 15, right: 15, top: 25),
                  child: TextField(
                    onChanged: (String value) async {
                      setState(() {
                        cidade = value;
                      });
                    },
                    decoration: InputDecoration(
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.all(
                          Radius.circular(10),
                        ),
                        borderSide: BorderSide(
                          color: Color(0xFFEDEDED),
                        ),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.all(
                          Radius.circular(10),
                        ),
                        borderSide: BorderSide(
                          color: Color(0xFFEDEDED),
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.all(
                          Radius.circular(10),
                        ),
                        borderSide: BorderSide(
                          color: Color(0xFFEDEDED),
                        ),
                      ),
                      fillColor: Color(0xFFEDEDED),
                      filled: true,
                      labelText: 'Cidade',
                      errorText: errorsForm?['cidade'] != null
                          ? errorsForm['cidade']
                          : null,
                      labelStyle: TextStyle(
                        color: Color(0xFF979797),
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(left: 15, right: 15, top: 25),
                  child: TextField(
                    controller: _controllerEstado,
                    onChanged: (String value) async {
                      setState(() {
                        estado = value.toUpperCase();
                      });
                      _controllerEstado.text = value.toUpperCase();
                      _controllerEstado.selection = TextSelection.fromPosition(
                          TextPosition(offset: _controllerEstado.text.length));
                    },
                    inputFormatters: [
                      FilteringTextInputFormatter.allow(RegExp(r'[a-zA-Z]')),
                      LengthLimitingTextInputFormatter(2)
                    ],
                    decoration: InputDecoration(
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.all(
                          Radius.circular(10),
                        ),
                        borderSide: BorderSide(
                          color: Color(0xFFEDEDED),
                        ),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.all(
                          Radius.circular(10),
                        ),
                        borderSide: BorderSide(
                          color: Color(0xFFEDEDED),
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.all(
                          Radius.circular(10),
                        ),
                        borderSide: BorderSide(
                          color: Color(0xFFEDEDED),
                        ),
                      ),
                      fillColor: Color(0xFFEDEDED),
                      filled: true,
                      labelText: 'Estado (Sigla)',
                      errorText: errorsForm?['estado'] != null
                          ? errorsForm['estado']
                          : null,
                      labelStyle: TextStyle(
                        color: Color(0xFF979797),
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: 25,
                ),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 15),
                  child: SizedBox(
                    width: double.infinity,
                    height: 60,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        elevation: 0,
                        backgroundColor: AppColors.buttonTertiary,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(6),
                          side: BorderSide(color: Color(0xFFF9AD1E)),
                        ),
                        minimumSize: Size(100, 40),
                      ),
                      onPressed: () {
                        handleCadastro();
                      },
                      child: Text(
                        "Cadastrar Cartão",
                        style: TextStyle(fontSize: 18),
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 25),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
