import 'package:aondeir_motorista/styles/app_colors.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/Recarga/OpcoesRecargaScreen.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../../../service/CartaoService.dart';

class CadastroCartaoCreditoScreen extends StatefulWidget {
  const CadastroCartaoCreditoScreen({super.key});

  @override
  State<CadastroCartaoCreditoScreen> createState() =>
      _CadastroCartaoCreditoScreenState();
}

class _CadastroCartaoCreditoScreenState
    extends State<CadastroCartaoCreditoScreen> {
  TextEditingController _controllerEstado = TextEditingController();
  var holder_name = "";
  var holder_document = "";
  var number_digits = "";
  var number = "";
  var exp_month = "";
  var exp_year = "";
  var cvv = "";
  var brand = "";

  var isLoading = false;
  var textLoading = "";

  void initState() {
    super.initState();
  }

  cadastrar() async {
    try {
      var cartaoService = Provider.of<CartaoService>(context, listen: false);
      setState(() {
        isLoading = true;
        textLoading = "Cadastrando...";
      });
      await showLoader();
      await Future.delayed(Duration(seconds: 1));
      var resultado = await cartaoService.cadastrar();

      if (resultado == true) {
        Navigator.of(context).pop();
        await showModalAlertSucessoError("Cartão cadastrado com sucesso!");
        await Future.delayed(Duration(seconds: 1));
        Navigator.of(context).pop();
        setState(() {
          isLoading = false;
        });

        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (context) => OpcoesRecargaScreen(),
          ),
        );
      } else {
        Navigator.of(context).pop();
        setState(() {
          isLoading = false;
        });
      }
    } catch (e) {
      Navigator.of(context).pop();
      String message = e.toString();
      setState(() {
        isLoading = false;
      });
      showModalAlertError(message);
    }
  }

  showModalAlertSucessoError(String message) async {
    showDialog<String>(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        title: Text(
          'Sucesso!',
          textAlign: TextAlign.center,
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.check_circle,
              color: Colors.green,
              size: 50,
            ),
            SizedBox(height: 10),
            Text(
              message,
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.black),
            ),
          ],
        ),
        actions: <Widget>[
          InkWell(
            onTap: () {
              Navigator.pop(context, "Fechar");
            },
            child: Padding(
              padding: EdgeInsets.only(bottom: 10, left: 15, right: 15),
              child: Text(
                'Fechar',
                style: TextStyle(color: Colors.orange),
              ),
            ),
          ),
        ],
      ),
    );
  }

  showModalAlertError(String message) async {
    showDialog<String>(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        title: Text(
          'Ops!',
          textAlign: TextAlign.center,
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.error,
              color: Colors.red,
              size: 50,
            ),
            SizedBox(height: 10),
            Text(
              message,
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.black),
            ),
          ],
        ),
        actions: <Widget>[
          InkWell(
            onTap: () {
              Navigator.pop(context, "Fechar");
            },
            child: Padding(
              padding: EdgeInsets.only(bottom: 10, left: 15, right: 15),
              child: Text(
                'Fechar',
                style: TextStyle(color: Colors.orange),
              ),
            ),
          ),
        ],
      ),
    );
  }

  showLoader() {
    if (isLoading == true) {
      showDialog<String>(
        barrierDismissible: false,
        context: context,
        builder: (BuildContext context) => AlertDialog(
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(12.0))),
          title: Container(
            child: Text(
              textLoading,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 13,
                color: Colors.grey[700],
              ),
            ),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(),
              SizedBox(height: 16),
              Text('Carregando...'),
            ],
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    var cartaoService = Provider.of<CartaoService>(context, listen: true);
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_ios_new,
            color: Colors.orange,
            size: 25,
          ),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(
          "Cartão Crédito",
          style: TextStyle(fontSize: 17, color: Colors.black),
        ),
        elevation: 0,
        centerTitle: true,
        backgroundColor: Colors.white,
      ),
      body: Padding(
        padding: EdgeInsets.all(15),
        child: Material(
          type: MaterialType.transparency,
          child: new SingleChildScrollView(
            child: Container(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  SizedBox(height: 25),
                  TextField(
                    onChanged: (value) {
                      cartaoService.holder_name = value;
                      cartaoService.save();
                    },
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      enabledBorder: OutlineInputBorder(
                        borderSide:
                            BorderSide(width: 1, color: Colors.grey.shade200),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide:
                            BorderSide(width: 1, color: Colors.grey.shade200),
                      ),
                      label: Text(
                        "Nome Titular",
                        style: TextStyle(color: Colors.grey.shade500),
                      ),
                      errorText:
                          cartaoService.errorsForm?['holder_name'] != null
                              ? cartaoService.errorsForm['holder_name']
                              : null,
                    ),
                  ),
                  SizedBox(height: 10),
                  Row(
                    children: <Widget>[
                      Container(
                          child: Flexible(
                        child: TextField(
                          onChanged: (value) {
                            cartaoService.holder_document = value;
                            cartaoService.save();
                          },
                          decoration: InputDecoration(
                            border: OutlineInputBorder(),
                            enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(
                                  width: 1, color: Colors.grey.shade200),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide: BorderSide(
                                  width: 1, color: Colors.grey.shade200),
                            ),
                            label: Text(
                              "Documento titular",
                              style: TextStyle(color: Colors.grey.shade500),
                            ),
                            errorText: cartaoService
                                        .errorsForm?['holder_document'] !=
                                    null
                                ? cartaoService.errorsForm['holder_document']
                                : null,
                          ),
                        ),
                      )),
                      SizedBox(width: 5),
                      Container(
                        child: Flexible(
                          child: TextField(
                            onChanged: (value) {
                              cartaoService.number = value;
                              cartaoService.save();
                            },
                            decoration: InputDecoration(
                              border: OutlineInputBorder(),
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    width: 1, color: Colors.grey.shade200),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    width: 1, color: Colors.grey.shade200),
                              ),
                              label: Text(
                                "Número cartão",
                                style: TextStyle(color: Colors.grey.shade500),
                              ),
                              errorText:
                                  cartaoService.errorsForm?['number'] != null
                                      ? cartaoService.errorsForm['number']
                                      : null,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 10),
                  Row(
                    children: <Widget>[
                      Container(
                        width: 123,
                        child: TextField(
                          onChanged: (value) {
                            cartaoService.exp_month = value;
                            cartaoService.save();
                          },
                          decoration: InputDecoration(
                            border: OutlineInputBorder(),
                            enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(
                                  width: 1, color: Colors.grey.shade200),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide: BorderSide(
                                  width: 1, color: Colors.grey.shade200),
                            ),
                            label: Text(
                              "Mês",
                              style: TextStyle(color: Colors.grey.shade500),
                            ),
                            errorText:
                                cartaoService.errorsForm?['exp_month'] != null
                                    ? cartaoService.errorsForm['exp_month']
                                    : null,
                          ),
                        ),
                      ),
                      SizedBox(width: 5),
                      Container(
                        width: 124,
                        child: TextField(
                          onChanged: (value) {
                            cartaoService.exp_year = value;
                            cartaoService.save();
                          },
                          decoration: InputDecoration(
                            border: OutlineInputBorder(),
                            enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(
                                  width: 1, color: Colors.grey.shade200),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide: BorderSide(
                                  width: 1, color: Colors.grey.shade200),
                            ),
                            label: Text(
                              "Ano",
                              style: TextStyle(color: Colors.grey.shade500),
                            ),
                            errorText:
                                cartaoService.errorsForm?['exp_year'] != null
                                    ? cartaoService.errorsForm['exp_year']
                                    : null,
                          ),
                        ),
                      ),
                      SizedBox(width: 5),
                      Container(
                        width: 124,
                        child: TextField(
                          onChanged: (value) {
                            cartaoService.cvv = value;
                            cartaoService.save();
                          },
                          decoration: InputDecoration(
                            border: OutlineInputBorder(),
                            enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(
                                  width: 1, color: Colors.grey.shade200),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide: BorderSide(
                                  width: 1, color: Colors.grey.shade200),
                            ),
                            label: Text(
                              "CVV",
                              style: TextStyle(color: Colors.grey.shade500),
                            ),
                            errorText: cartaoService.errorsForm?['cvv'] != null
                                ? cartaoService.errorsForm['cvv']
                                : null,
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 10),
                  Divider(),
                  SizedBox(height: 10),
                  Row(
                    children: <Widget>[
                      Container(
                          child: Flexible(
                        child: TextField(
                          onChanged: (value) {
                            cartaoService.cep = value;
                            cartaoService.save();
                          },
                          decoration: InputDecoration(
                            border: OutlineInputBorder(),
                            enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(
                                  width: 1, color: Colors.grey.shade200),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide: BorderSide(
                                  width: 1, color: Colors.grey.shade200),
                            ),
                            label: Text(
                              "Cep",
                              style: TextStyle(color: Colors.grey.shade500),
                            ),
                            errorText: cartaoService.errorsForm?['cep'] != null
                                ? cartaoService.errorsForm['cep']
                                : null,
                          ),
                        ),
                      )),
                    ],
                  ),
                  SizedBox(height: 10),
                  Row(
                    children: <Widget>[
                      Container(
                        child: Flexible(
                          child: TextField(
                            onChanged: (value) {
                              cartaoService.rua = value;
                              cartaoService.save();
                            },
                            decoration: InputDecoration(
                              border: OutlineInputBorder(),
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    width: 1, color: Colors.grey.shade200),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    width: 1, color: Colors.grey.shade200),
                              ),
                              label: Text(
                                "Rua",
                                style: TextStyle(color: Colors.grey.shade500),
                              ),
                              errorText:
                                  cartaoService.errorsForm?['rua'] != null
                                      ? cartaoService.errorsForm['rua']
                                      : null,
                            ),
                          ),
                        ),
                      ),
                      SizedBox(width: 5),
                      Container(
                        width: 100,
                        child: TextField(
                          onChanged: (value) {
                            cartaoService.rua_numero = value;
                            cartaoService.save();
                          },
                          decoration: InputDecoration(
                            border: OutlineInputBorder(),
                            enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(
                                  width: 1, color: Colors.grey.shade200),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide: BorderSide(
                                  width: 1, color: Colors.grey.shade200),
                            ),
                            label: Text(
                              "Número",
                              style: TextStyle(color: Colors.grey.shade500),
                            ),
                            errorText:
                                cartaoService.errorsForm?['rua_numero'] != null
                                    ? cartaoService.errorsForm['rua_numero']
                                    : null,
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 10),
                  Row(
                    children: <Widget>[
                      Container(
                        child: Flexible(
                          child: TextField(
                            onChanged: (value) {
                              cartaoService.bairro = value;
                              cartaoService.save();
                            },
                            decoration: InputDecoration(
                              border: OutlineInputBorder(),
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    width: 1, color: Colors.grey.shade200),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    width: 1, color: Colors.grey.shade200),
                              ),
                              label: Text(
                                "Bairro",
                                style: TextStyle(color: Colors.grey.shade500),
                              ),
                              errorText:
                                  cartaoService.errorsForm?['bairro'] != null
                                      ? cartaoService.errorsForm['bairro']
                                      : null,
                            ),
                          ),
                        ),
                      ),
                      SizedBox(width: 5),
                      Container(
                        child: Flexible(
                          child: TextField(
                            onChanged: (value) {
                              cartaoService.cidade = value;
                              cartaoService.save();
                            },
                            decoration: InputDecoration(
                              border: OutlineInputBorder(),
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    width: 1, color: Colors.grey.shade200),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    width: 1, color: Colors.grey.shade200),
                              ),
                              label: Text(
                                "Cidade",
                                style: TextStyle(color: Colors.grey.shade500),
                              ),
                              errorText:
                                  cartaoService.errorsForm?['cidade'] != null
                                      ? cartaoService.errorsForm['cidade']
                                      : null,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 10),
                  Row(
                    children: <Widget>[
                      Container(
                        width: 100,
                        child: TextField(
                          onChanged: (value) {
                            cartaoService.estado = value.toUpperCase();
                            cartaoService.save();
                            _controllerEstado.text = value.toUpperCase();
                            _controllerEstado.selection =
                                TextSelection.fromPosition(TextPosition(
                                    offset: _controllerEstado.text.length));
                          },
                          inputFormatters: [
                            FilteringTextInputFormatter.allow(
                                RegExp(r'[a-zA-Z]')),
                            LengthLimitingTextInputFormatter(2),
                          ],
                          controller: _controllerEstado,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(),
                            enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(
                                  width: 1, color: Colors.grey.shade200),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide: BorderSide(
                                  width: 1, color: Colors.grey.shade200),
                            ),
                            label: Text(
                              "Estados",
                              style: TextStyle(color: Colors.grey.shade500),
                            ),
                            errorText:
                                cartaoService.errorsForm?['estado'] != null
                                    ? cartaoService.errorsForm['estado']
                                    : null,
                          ),
                        ),
                      ),
                      SizedBox(width: 5),
                      Container(
                        child: Flexible(
                          child: TextField(
                            onChanged: (value) {
                              cartaoService.complemento = value;
                              cartaoService.save();
                            },
                            decoration: InputDecoration(
                              border: OutlineInputBorder(),
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    width: 1, color: Colors.grey.shade200),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    width: 1, color: Colors.grey.shade200),
                              ),
                              label: Text(
                                "Complemento",
                                style: TextStyle(color: Colors.grey.shade500),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 25),
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        elevation: 0,
                        backgroundColor: AppColors.buttonSecondary,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(6),
                          side: BorderSide(color: AppColors.buttonBorderSecondary),
                        ),
                        minimumSize: Size(100, 40),
                      ),
                      onPressed: () {
                        cadastrar();
                      },
                      child: Text(
                        "Cadastrar",
                        style: TextStyle(fontSize: 18),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
