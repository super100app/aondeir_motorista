import 'dart:io';
import 'package:aondeir_motorista/screens/Inicio/InitialScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/BottomNavigationBar/NavigationScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/AberturaCorrida/AberturaCorridaScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/HistoricoCorridas/HistoricoCorridasMenuScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/Mensagens/ConversasScreen.dart';
import 'package:aondeir_motorista/service/GanhoService.dart';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../../models/Usuario.dart';
import '../../../service/MensagemService.dart';
import '../../../service/UsuarioService.dart';
import '../../../service/helper/VariavelControleService.dart';
import '../../../service/mensagem/PegarMensagensNaoLidaService.dart';
import '../Home/Estatistica/Ganhos/MyGanhosScreen.dart';
import 'Recarga/HistoricoRecargasScreen.dart';
import 'package:http/http.dart' as http;
import 'dart:convert' as convert;

class MenuScreen extends StatefulWidget {
  const MenuScreen({super.key});

  @override
  State<MenuScreen> createState() => _MenuScreenState();
}

class _MenuScreenState extends State<MenuScreen> {
  final storage = new FlutterSecureStorage();
  bool isLoading = false;
  int counter = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      await pegarMensagens();
    });
  }

  pegarMensagens() async {
    var mensagemService = Provider.of<MensagemService>(context, listen: false);
    await mensagemService.pegarMensagensFranquia();
  }

  logout() async {
    var usuarioService = Provider.of<UsuarioService>(context, listen: false);
    var variavelControleService = Provider.of<VariavelControleService>(
      context,
      listen: false,
    );
    String url =
        dotenv.env['BASE_URL']! +
        "api/motorista/logout/" +
        usuarioService.usuario.id.toString();
    var token = await storage.read(key: 'jwt');
    var response = await http.post(
      Uri.parse(url),
      headers: {HttpHeaders.authorizationHeader: 'Bearer ' + token.toString()},
    );

    convert.jsonDecode(response.body);

    await storage.delete(key: 'jwt');
    usuarioService.usuario = new Usuario(
      id: 0,
      name: "",
      email: "",
      celular: "",
      tipoId: 0,
      status: "",
      doc: "",
      franquia: "",
      motorista: "",
      dados_bancarios: "",
      versaoAppMotorista: '0',
      versaoApp: '0',
    );

    usuarioService.dadosPessoaisForm = {};
    usuarioService.dadosEnderecoForm = {};
    usuarioService.dadosVeiculoForm = {};
    usuarioService.etapaCadastro = {};

    await usuarioService.save();

    variavelControleService.checkIsLogged = false;
    await variavelControleService.save();

    Navigator.push(context, MaterialPageRoute(builder: (_) => InitialScreen()));
  }

  excluirConta() async {
    try {
      setState(() {
        isLoading = true;
      });

      await showLoader();
      await Future.delayed(Duration(seconds: 3));

      var usuarioService = Provider.of<UsuarioService>(context, listen: false);
      var resp = await usuarioService.excluirConta();

      setState(() {
        isLoading = false;
      });
      Navigator.of(context).pop();

      if (resp) {
        showModalAlertSucesso("Conta excluída com sucesso!");

        await Future.delayed(Duration(seconds: 3));

        logout();
      } else {
        showModalAlertError(
          "Ops! Ocorreu um erro ao excluir a conta, tente mais tarde novamente.",
        );
      }
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      showModalAlertError(
        "Ops! Ocorreu um erro ao excluir a conta, tente mais tarde novamente.",
      );
    }
  }

  showModalExcluirConta() {
    showDialog<String>(
      context: context,
      builder:
          (BuildContext context) => AlertDialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(12.0)),
            ),
            title: const Text('Confirmar'),
            content: const Text('Tem certeza que deseja excluir esta conta?'),
            actions: <Widget>[
              InkWell(
                onTap: () {
                  Navigator.pop(context, "Nao");
                },
                child: Padding(
                  padding: EdgeInsets.all(15),
                  child: Text('Não', style: TextStyle(color: Colors.orange)),
                ),
              ),
              InkWell(
                onTap: () {
                  Navigator.pop(context, "Sim");
                  excluirConta();
                },
                child: Padding(
                  padding: EdgeInsets.all(15),
                  child: Text('Sim', style: TextStyle(color: Colors.orange)),
                ),
              ),
            ],
          ),
    );
  }

  showLoader() {
    if (isLoading == true) {
      showDialog<String>(
        barrierDismissible: false,
        context: context,
        builder:
            (BuildContext context) => AlertDialog(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(12.0)),
              ),
              title: Container(
                child: Text(
                  "Excluindo conta...",
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 13, color: Colors.grey[700]),
                ),
              ),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 16),
                  Text('Carregando...'),
                ],
              ),
            ),
      );
    }
  }

  showModalAlertSucesso(String message) async {
    showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder:
          (BuildContext context) => AlertDialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(12.0)),
            ),
            title: Text('Sucesso!', textAlign: TextAlign.center),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.check_circle, color: Colors.green, size: 50),
                SizedBox(height: 10),
                Text(
                  message,
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.black),
                ),
                SizedBox(height: 10),
              ],
            ),
          ),
    );
  }

  showModalAlertError(String message) async {
    showDialog<String>(
      context: context,
      builder:
          (BuildContext context) => AlertDialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(12.0)),
            ),
            title: Text('Ops!', textAlign: TextAlign.center),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.error, color: Colors.red, size: 50),
                SizedBox(height: 10),
                Text(
                  message,
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.black),
                ),
              ],
            ),
            actions: <Widget>[
              InkWell(
                onTap: () {
                  Navigator.pop(context, "Fechar");
                },
                child: Padding(
                  padding: EdgeInsets.only(bottom: 10, left: 15, right: 15),
                  child: Text('Fechar', style: TextStyle(color: Colors.orange)),
                ),
              ),
            ],
          ),
    );
  }

  handleAcessarMeusGanhos() async {
    print("Sacar via PIX \$");
    var ganhoService = Provider.of<GanhoService>(context, listen: false);
    await ganhoService.pegarSaldoDiponivel();

    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => MyGanhosScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    var pegarMensagensNaoLidaService =
        Provider.of<PegarMensagensNaoLidaService>(this.context, listen: true);
    return MediaQuery(
      data: MediaQuery.of(context).copyWith(textScaler: TextScaler.linear(1.0)),
      child: Scaffold(
        backgroundColor: Color.fromARGB(255, 58, 58, 58),
        appBar: AppBar(
          leading: IconButton(
            icon: Icon(Icons.arrow_back_ios_new, color: Colors.white, size: 25),
            onPressed:
                () => {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => NavigationScreen()),
                  ),
                },
          ),
          title: Text("Menu", style: TextStyle(fontSize: 17)),
          centerTitle: true,
          backgroundColor: Color.fromARGB(255, 49, 49, 49),
        ),
        body: Padding(
          padding: EdgeInsets.only(left: 15, top: 15, right: 15),
          child: Material(
            type: MaterialType.transparency,
            child: new SingleChildScrollView(
              child: Container(
                color: Color.fromARGB(255, 58, 58, 58),
                child: Column(
                  children: <Widget>[
                    InkWell(
                      onTap: () async {
                        await logout();
                      },
                      child: Container(
                        padding: EdgeInsets.all(15),
                        decoration: BoxDecoration(
                          border: Border.all(
                            color: Color.fromARGB(255, 49, 49, 49),
                          ),
                          borderRadius: BorderRadius.circular(10),
                          color: Color.fromARGB(255, 49, 49, 49),
                        ),
                        child: Row(
                          children: <Widget>[
                            Column(
                              children: <Widget>[
                                Icon(
                                  Icons.exit_to_app,
                                  size: 30,
                                  color: Colors.orange,
                                ),
                              ],
                            ),
                            SizedBox(width: 15),
                            Text(
                              "Sair",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            Spacer(),
                            Icon(
                              Icons.arrow_forward_ios,
                              color: Colors.white,
                              size: 15,
                            ),
                          ],
                        ),
                      ),
                    ),
                    // SizedBox(height: 15),
                    // InkWell(
                    //   onTap: () {
                    //     showDialog<String>(
                    //       context: context,
                    //       builder: (BuildContext context) => ModalPadraoClick(
                    //         message: "Qualquer alteração no cadastro, seus dados serão reavaliado pela franquia, você nao recebera corridas enquando o cadastro não for aprovado!",
                    //         btnAcao: true,
                    //         btnAcaoTexto: "Continuar",
                    //         btnAcaoClick: () {
                    //             Navigator.push(
                    //               context,
                    //               MaterialPageRoute(
                    //                 builder: (_) => MeuCadastroScreen(),
                    //               ),
                    //             );
                    //         },
                    //       ));

                    //   },
                    //   child: Container(
                    //     padding: EdgeInsets.all(15),
                    //     decoration: BoxDecoration(
                    //       border: Border.all(
                    //         color: Color.fromARGB(255, 49, 49, 49),
                    //       ),
                    //       borderRadius: BorderRadius.circular(10),
                    //       color: Color.fromARGB(255, 49, 49, 49),
                    //     ),
                    //     child: Row(
                    //       children: <Widget>[
                    //         Column(
                    //           children: <Widget>[
                    //             Icon(
                    //               Icons.person,
                    //               size: 30,
                    //               color: Colors.orange,
                    //             ),
                    //           ],
                    //         ),
                    //         SizedBox(width: 15),
                    //         Text(
                    //           "Meus Dados",
                    //           style: TextStyle(
                    //             color: Colors.white,
                    //             fontSize: 16,
                    //             fontWeight: FontWeight.w500,
                    //           ),
                    //         ),
                    //         Spacer(),
                    //         Icon(
                    //           Icons.arrow_forward_ios,
                    //           color: Colors.white,
                    //           size: 15,
                    //         )
                    //       ],
                    //     ),
                    //   ),
                    // ),
                    SizedBox(height: 15),
                    InkWell(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => AberturaCorridaScreen(),
                          ),
                        );
                      },
                      child: Container(
                        padding: EdgeInsets.all(15),
                        decoration: BoxDecoration(
                          border: Border.all(
                            color: Color.fromARGB(255, 49, 49, 49),
                          ),
                          borderRadius: BorderRadius.circular(10),
                          color: Color.fromARGB(255, 49, 49, 49),
                        ),
                        child: Row(
                          children: <Widget>[
                            Column(
                              children: <Widget>[
                                Icon(
                                  Icons.person,
                                  size: 30,
                                  color: Colors.orange,
                                ),
                              ],
                            ),
                            SizedBox(width: 15),
                            Text(
                              "Abertura de corrida",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            Spacer(),
                            Icon(
                              Icons.arrow_forward_ios,
                              color: Colors.white,
                              size: 15,
                            ),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(height: 15),
                    InkWell(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => HistoricoRecargasScreen(),
                          ),
                        );
                      },
                      child: Container(
                        padding: EdgeInsets.all(15),
                        decoration: BoxDecoration(
                          border: Border.all(
                            color: Color.fromARGB(255, 49, 49, 49),
                          ),
                          borderRadius: BorderRadius.circular(10),
                          color: Color.fromARGB(255, 49, 49, 49),
                        ),
                        child: Row(
                          children: <Widget>[
                            Column(
                              children: <Widget>[
                                Icon(
                                  Icons.person,
                                  size: 30,
                                  color: Colors.orange,
                                ),
                              ],
                            ),
                            SizedBox(width: 15),
                            Text(
                              "Minhas Recarga",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            Spacer(),
                            Icon(
                              Icons.arrow_forward_ios,
                              color: Colors.white,
                              size: 15,
                            ),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(height: 15),
                    InkWell(
                      onTap: () {
                        handleAcessarMeusGanhos();
                        // Navigator.push(
                        //   context,
                        //   MaterialPageRoute(builder: (_) => MyGanhosScreen()),
                        // );
                      },
                      child: Container(
                        padding: EdgeInsets.all(15),
                        decoration: BoxDecoration(
                          border: Border.all(
                            color: Color.fromARGB(255, 49, 49, 49),
                          ),
                          borderRadius: BorderRadius.circular(10),
                          color: Color.fromARGB(255, 49, 49, 49),
                        ),
                        child: Row(
                          children: <Widget>[
                            Column(
                              children: <Widget>[
                                Icon(
                                  Icons.person,
                                  size: 30,
                                  color: Colors.orange,
                                ),
                              ],
                            ),
                            SizedBox(width: 15),
                            Text(
                              "Meus ganhos",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            Spacer(),
                            Icon(
                              Icons.arrow_forward_ios,
                              color: Colors.white,
                              size: 15,
                            ),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(height: 15),
                    InkWell(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => HistoricoCorridasMenuScreen(),
                          ),
                        );
                      },
                      child: Container(
                        padding: EdgeInsets.all(15),
                        decoration: BoxDecoration(
                          border: Border.all(
                            color: Color.fromARGB(255, 49, 49, 49),
                          ),
                          borderRadius: BorderRadius.circular(10),
                          color: Color.fromARGB(255, 49, 49, 49),
                        ),
                        child: Row(
                          children: <Widget>[
                            Column(
                              children: <Widget>[
                                Icon(
                                  Icons.history_edu,
                                  size: 30,
                                  color: Colors.orange,
                                ),
                              ],
                            ),
                            SizedBox(width: 15),
                            Text(
                              "Hístorico de corridas",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            Spacer(),
                            Icon(
                              Icons.arrow_forward_ios,
                              color: Colors.white,
                              size: 15,
                            ),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(height: 15),
                    InkWell(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => ConversasScreen()),
                        );
                      },
                      child: Container(
                        padding: EdgeInsets.all(15),
                        decoration: BoxDecoration(
                          border: Border.all(
                            color: Color.fromARGB(255, 49, 49, 49),
                          ),
                          borderRadius: BorderRadius.circular(10),
                          color: Color.fromARGB(255, 49, 49, 49),
                        ),
                        child: Row(
                          children: <Widget>[
                            Column(
                              children: <Widget>[
                                Icon(
                                  Icons.message,
                                  size: 30,
                                  color: Colors.orange,
                                ),
                              ],
                            ),
                            SizedBox(width: 15),
                            Text(
                              pegarMensagensNaoLidaService.qtdMensagemNaoLida >
                                      0
                                  ? "Mensagens (" +
                                      pegarMensagensNaoLidaService
                                          .qtdMensagemNaoLida
                                          .toString() +
                                      ")"
                                  : "Mensagens (0)",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            Spacer(),
                            Icon(
                              Icons.arrow_forward_ios,
                              color: Colors.white,
                              size: 15,
                            ),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(height: 15),
                    InkWell(
                      onTap: () async {
                        final Uri url = Uri.parse('https://aondeirpassageiro.com/termosmotorista/');
                        if (!await launchUrl(url, mode: LaunchMode.externalApplication)) {
                          throw Exception('Não foi possível abrir ${url.toString()}');
                        }
                      },
                      child: Container(
                        padding: EdgeInsets.all(15),
                        decoration: BoxDecoration(
                          border: Border.all(
                            color: Color.fromARGB(255, 49, 49, 49),
                          ),
                          borderRadius: BorderRadius.circular(10),
                          color: Color.fromARGB(255, 49, 49, 49),
                        ),
                        child: Row(
                          children: <Widget>[
                            Column(
                              children: <Widget>[
                                Icon(
                                  Icons.menu_book,
                                  size: 30,
                                  color: Colors.orange,
                                ),
                              ],
                            ),
                            SizedBox(width: 15),
                            Text(
                              "Termos de uso e privacidade",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            Spacer(),
                            Icon(
                              Icons.arrow_forward_ios,
                              color: Colors.white,
                              size: 15,
                            ),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(height: 15),
                    InkWell(
                      onTap: () {
                        showModalExcluirConta();
                      },
                      child: Container(
                        padding: EdgeInsets.all(15),
                        decoration: BoxDecoration(
                          border: Border.all(
                            color: Color.fromARGB(255, 49, 49, 49),
                          ),
                          borderRadius: BorderRadius.circular(10),
                          color: Color.fromARGB(255, 49, 49, 49),
                        ),
                        child: Row(
                          children: <Widget>[
                            Column(
                              children: <Widget>[
                                Icon(
                                  Icons.person_off,
                                  size: 30,
                                  color: Colors.orange,
                                ),
                              ],
                            ),
                            SizedBox(width: 15),
                            Text(
                              "Excluir conta",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            Spacer(),
                            Icon(
                              Icons.arrow_forward_ios,
                              color: Colors.white,
                              size: 15,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
