import 'package:aondeir_motorista/service/UsuarioService.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../../service/SocketService.dart';
import '../../../../service/MensagemService.dart';
import '../../../../service/mensagem/PegarMensagensNaoLidaService.dart';

class MensagemChatFranquiaScreen extends StatefulWidget {
  const MensagemChatFranquiaScreen({super.key});

  @override
  State<MensagemChatFranquiaScreen> createState() =>
      _MensagemChatFranquiaScreenState();
}

class _MensagemChatFranquiaScreenState
    extends State<MensagemChatFranquiaScreen> {
  var mensagemText = "";
  List<String> listaMensagemPreProntas = [];
  TextEditingController _textEditingController = TextEditingController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      await pegarMensagens();
      await visualizarMensagens();
      await socket();
    });
  }

  socket() async {
    var socketService = Provider.of<SocketService>(context, listen: false);
    var usuarioService = Provider.of<UsuarioService>(context, listen: false);

    // socketService.socket.on(
    //     "enviarMensagemChatUsuario" + usuarioService.usuario.id.toString(),
    //     (data) => {
    //           addMensagem(data),
    //         });
  }

  addMensagem(data) async {
    var mensagemService = Provider.of<MensagemService>(context, listen: false);
    mensagemService.addNovaMensagemLista(data['mensagem']);
  }

  pegarMensagens() async {
    var mensagemService = Provider.of<MensagemService>(context, listen: false);
    await mensagemService.pegarMensagensFranquia();
  }

  visualizarMensagens() async {
    var mensagemService = Provider.of<MensagemService>(context, listen: false);
    var pegarMensagensNaoLidaService =
        Provider.of<PegarMensagensNaoLidaService>(this.context, listen: false);
    await mensagemService.visualizarMensagens();

    await pegarMensagensNaoLidaService.execute();
  }

  enviarMensagem() async {
    var mensagemService = Provider.of<MensagemService>(context, listen: false);
    mensagemService.mensagem = _textEditingController.text;
    await mensagemService.save();
    await mensagemService.enviarMensagemFranquia();

    setState(() {
      mensagemText = "";
    });

    _textEditingController.text = "";
  }

  @override
  Widget build(BuildContext context) {
    var mensagemService = Provider.of<MensagemService>(context, listen: true);
    var usuarioService = Provider.of<UsuarioService>(context, listen: true);

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_ios_new,
            color: Colors.white,
            size: 25,
          ),
          onPressed: () => {
            Navigator.of(context).pop(),
            mensagemService.mensagensFranquia.clear()
          },
        ),
        title: Text(
          usuarioService.usuario.franquia['nome'],
          style: TextStyle(
            fontSize: 17,
            overflow: TextOverflow.ellipsis,
          ),
        ),
        centerTitle: true,
        backgroundColor: Color.fromARGB(255, 49, 49, 49),
      ),
      body: Material(
        type: MaterialType.transparency,
        child: new SingleChildScrollView(
          child: Container(
            color: Colors.white,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: Colors.white,
                  ),
                  height: MediaQuery.of(context).size.height - 160,
                  child: Padding(
                    padding: EdgeInsets.only(top: 15, left: 15, right: 15),
                    child: SizedBox(
                      width: double.infinity,
                      child: SingleChildScrollView(
                        reverse: true,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            if (mensagemService.mensagensFranquia.length > 0)
                              for (var mensagem
                                  in mensagemService.mensagensFranquia)
                                mensagem.remetente['id'] ==
                                        usuarioService.usuario.id
                                    ? Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                        children: <Widget>[
                                          Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.end,
                                            children: <Widget>[
                                              IntrinsicWidth(
                                                child: Container(
                                                  constraints: BoxConstraints(
                                                      maxWidth:
                                                          MediaQuery.of(context)
                                                                  .size
                                                                  .width /
                                                              1.3),
                                                  margin: EdgeInsets.symmetric(
                                                      vertical: 4,
                                                      horizontal: 0),
                                                  padding: EdgeInsets.symmetric(
                                                      vertical: 10,
                                                      horizontal: 10),
                                                  decoration: BoxDecoration(
                                                    color: Colors.orange[200],
                                                    borderRadius:
                                                        BorderRadius.only(
                                                      topLeft:
                                                          Radius.circular(20),
                                                      bottomLeft:
                                                          Radius.circular(20),
                                                      bottomRight:
                                                          Radius.circular(0),
                                                      topRight:
                                                          Radius.circular(20),
                                                    ),
                                                  ),
                                                  child: Text(
                                                    mensagem.mensagem!,
                                                    style: TextStyle(
                                                        color: Colors.grey[800],
                                                        fontWeight:
                                                            FontWeight.w400,
                                                        fontSize: 16),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                          Container(
                                            margin: EdgeInsets.only(left: 5),
                                            width: 28,
                                            child: ClipRRect(
                                              borderRadius:
                                                  BorderRadius.circular(120),
                                              child: Image.asset(
                                                "assets/notPerfil.png",
                                              ),
                                            ),
                                          ),
                                          SizedBox(height: 10),
                                        ],
                                      )
                                    : Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: <Widget>[
                                          Container(
                                            margin: EdgeInsets.only(right: 5),
                                            width: 28,
                                            child: ClipRRect(
                                              borderRadius:
                                                  BorderRadius.circular(120),
                                              child: Image.asset(
                                                "assets/notPerfil.png",
                                              ),
                                            ),
                                          ),
                                          Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: <Widget>[
                                              IntrinsicWidth(
                                                child: Container(
                                                  constraints: BoxConstraints(
                                                      maxWidth:
                                                          MediaQuery.of(context)
                                                                  .size
                                                                  .width /
                                                              1.3),
                                                  margin: EdgeInsets.symmetric(
                                                      vertical: 4,
                                                      horizontal: 0),
                                                  padding: EdgeInsets.symmetric(
                                                      vertical: 10,
                                                      horizontal: 10),
                                                  decoration: BoxDecoration(
                                                    color: Colors.orange,
                                                    borderRadius:
                                                        BorderRadius.only(
                                                      topLeft:
                                                          Radius.circular(20),
                                                      bottomLeft:
                                                          Radius.circular(0),
                                                      bottomRight:
                                                          Radius.circular(20),
                                                      topRight:
                                                          Radius.circular(20),
                                                    ),
                                                  ),
                                                  child: Text(
                                                    mensagem.mensagem!,
                                                    style: TextStyle(
                                                        color: Colors.white,
                                                        fontWeight:
                                                            FontWeight.w400,
                                                        fontSize: 16),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                            SizedBox(height: 10),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 10),
                Container(
                  color: Colors.grey[300],
                  height: 80,
                  padding: EdgeInsets.symmetric(horizontal: 15),
                  child: Row(
                    children: <Widget>[
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 15),
                        child: SizedBox(
                          width: 300,
                          child: TextField(
                            controller: _textEditingController,
                            onChanged: (String value) async {
                              setState(() {
                                mensagemText = value;
                              });
                            },
                            decoration: InputDecoration(
                              border: OutlineInputBorder(),
                              filled: true,
                              fillColor: Colors.white,
                              hintText: "Digite sua mensagem....",
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        child: GestureDetector(
                          onTap: () {
                            enviarMensagem();
                          },
                          child: Icon(
                            Icons.send,
                            color: Colors.grey[800],
                            size: 30,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
