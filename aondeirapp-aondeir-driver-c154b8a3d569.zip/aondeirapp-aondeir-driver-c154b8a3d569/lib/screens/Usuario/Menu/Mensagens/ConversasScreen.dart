import 'package:aondeir_motorista/screens/Usuario/Menu/Mensagens/MensagemChatFranquiaScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/Mensagens/MensagemChatMatrizScreen.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../service/UsuarioService.dart';
import '../../../../service/mensagem/PegarMensagensNaoLidaService.dart';

class ConversasScreen extends StatefulWidget {
  const ConversasScreen({super.key});

  @override
  State<ConversasScreen> createState() => _ConversasScreenState();
}

class _ConversasScreenState extends State<ConversasScreen> {
  @override
  Widget build(BuildContext context) {
    var usuarioService = Provider.of<UsuarioService>(context, listen: true);
    var pegarMensagensNaoLidaService =
        Provider.of<PegarMensagensNaoLidaService>(this.context, listen: true);

    return MediaQuery(
      data: MediaQuery.of(context).copyWith(textScaler: TextScaler.linear(1.0)),
      child:Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_ios_new,
            color: Colors.white,
            size: 25,
          ),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(
          "Conversas",
          style: TextStyle(fontSize: 17),
        ),
        centerTitle: true,
        backgroundColor: Color.fromARGB(255, 49, 49, 49),
      ),
      body: Padding(
        padding: EdgeInsets.only(left: 15, top: 15, right: 15),
        child: Material(
          type: MaterialType.transparency,
          child: new SingleChildScrollView(
            child: Container(
              color: Colors.white,
              child: Column(
                children: <Widget>[
                  if (usuarioService.usuario.franquia['id'] != 1)
                    InkWell(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => MensagemChatMatrizScreen(),
                          ),
                        );
                      },
                      child: Container(
                        padding: EdgeInsets.all(15),
                        decoration: BoxDecoration(
                          border: Border.all(
                            color: Colors.grey.shade300,
                          ),
                          borderRadius: BorderRadius.circular(10),
                          color: Colors.grey.shade300,
                        ),
                        child: Row(
                          children: <Widget>[
                            Container(
                              width: 300,
                              child: Text(
                                pegarMensagensNaoLidaService
                                            .qtdMensagemMatrizNaoLida >
                                        0
                                    ? "Central" +
                                        " (" +
                                        pegarMensagensNaoLidaService
                                            .qtdMensagemMatrizNaoLida
                                            .toString() +
                                        ")"
                                    : "Central" + " (0)",
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  color: Colors.grey[800],
                                  fontSize: 16,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ),
                            Spacer(),
                            Icon(
                              Icons.arrow_forward_ios,
                              color: Colors.grey[800],
                              size: 15,
                            )
                          ],
                        ),
                      ),
                    ),
                  SizedBox(height: 15),
                  InkWell(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => MensagemChatFranquiaScreen(),
                        ),
                      );
                    },
                    child: Container(
                      padding: EdgeInsets.all(15),
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: Colors.grey.shade300,
                        ),
                        borderRadius: BorderRadius.circular(10),
                        color: Colors.grey.shade300,
                      ),
                      child: Row(
                        children: <Widget>[
                          Container(
                            width: 300,
                            child: Text(
                              pegarMensagensNaoLidaService
                                          .qtdMensagemFranquiaNaoLida >
                                      0
                                  ? usuarioService.usuario.franquia['nome'] +
                                      " (" +
                                      pegarMensagensNaoLidaService
                                          .qtdMensagemFranquiaNaoLida
                                          .toString() +
                                      ")"
                                  : usuarioService.usuario.franquia['nome'] +
                                      " (0)",
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                color: Colors.grey[800],
                                fontSize: 16,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                          Spacer(),
                          Icon(
                            Icons.arrow_forward_ios,
                            color: Colors.grey[800],
                            size: 15,
                          )
                        ],
                      ),
                    ),
                  ),
                  SizedBox(height: 15),
                ],
              ),
            ),
          ),
        ),
      ),
    ));
  }
}
