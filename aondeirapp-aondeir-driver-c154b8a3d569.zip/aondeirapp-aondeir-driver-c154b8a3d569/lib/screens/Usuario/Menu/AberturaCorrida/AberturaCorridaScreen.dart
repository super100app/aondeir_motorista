import 'package:aondeir_motorista/styles/app_colors.dart';
import 'package:aondeir_motorista/models/Categoria.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/AberturaCorrida/DetalhesMacanetaScreen.dart';
import 'package:aondeir_motorista/service/LocalizacaoService.dart';
import 'package:flutter/material.dart';

import 'package:geolocator/geolocator.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:provider/provider.dart';

import '../../../../models/Passageiro.dart';
import '../../../../service/CorridaService.dart';
import '../../../../service/categoria/CategoriaService.dart';
import '../../../../service/localizacao/PesquisaEnderecoGeocodificacaoPorCoordenadaService.dart';
import '../../../../service/passageiro/PassageiroService.dart';
import '../Recarga/HistoricoRecargasScreen.dart';

class AberturaCorridaScreen extends StatefulWidget {
  const AberturaCorridaScreen({super.key});

  @override
  State<AberturaCorridaScreen> createState() => _AberturaCorridaScreenState();
}

class _AberturaCorridaScreenState extends State<AberturaCorridaScreen> {
  TextEditingController _controllerTelefone = TextEditingController();
  TextEditingController _controllerNome = TextEditingController();
  var enderecoAtual;
  var isLoading = false;
  var enderecoAtualLatitude;
  var enderecoAtualLongitude;
  var maskCelular = MaskTextInputFormatter(
    mask: "(##) #####-####",
    filter: {"#": RegExp(r'[0-9]')},
  );
  List<Categoria> listaCategoria = [];
  var categoriaSelecionada = "";

  @override
  void initState() {
    super.initState();
    buscarCategoriasMacaneta();
  }

  Future<void> buscarUsuarioPassageiroPorTelefone(telefone) async {
    try {
      var passageiroService = Provider.of<PassageiroService>(
        context,
        listen: false,
      );
      Passageiro? passageiro = await passageiroService.buscarPorTelefone(
        telefone,
      );
      if (passageiro != null) {
        List<String> partes = passageiro.name.split(' ');
        var primeiroNome = partes[0];
        setState(() {
          _controllerNome.text = primeiroNome;
        });
      }
    } catch (e) {
      throw e;
    }
  }

  Future<void> buscarCategoriasMacaneta() async {
    try {
      var categoriaService = Provider.of<CategoriaService>(
        context,
        listen: false,
      );
      List<Categoria> listaCategoriaResp =
          await categoriaService.buscarCategoriasMacaneta();
      if (listaCategoriaResp.length > 0) {
        setState(() {
          listaCategoria = listaCategoriaResp;
        });
      }
    } catch (e) {
      throw e;
    }
  }

  criarCorridaTeste() async {
    try {
      var localizacaoService = Provider.of<LocalizacaoService>(
        context,
        listen: false,
      );
      var pesquisaEnderecoGeocodificacaoPorCoordenadaService =
          Provider.of<PesquisaEnderecoGeocodificacaoPorCoordenadaService>(
            context,
            listen: false,
          );

      Position position =
          await localizacaoService.getCurrentLocationAberturaCorrida();

      var localAtual = await pesquisaEnderecoGeocodificacaoPorCoordenadaService
          .execute(position.latitude, position.longitude);
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      Navigator.of(context).pop();
      showModalAlertError(e.toString());
    }
  }

  criarCorridaMacaneta() async {
    try {
      var corridaService = Provider.of<CorridaService>(context, listen: false);
      var localizacaoService = Provider.of<LocalizacaoService>(
        context,
        listen: false,
      );

      var pesquisaEnderecoGeocodificacaoPorCoordenadaService =
          Provider.of<PesquisaEnderecoGeocodificacaoPorCoordenadaService>(
            context,
            listen: false,
          );
      setState(() {
        isLoading = true;
      });

      await showLoader();
      await Future.delayed(Duration(seconds: 1));

      Position position =
          await localizacaoService.getCurrentLocationAberturaCorrida();

      var localAtual = await pesquisaEnderecoGeocodificacaoPorCoordenadaService
          .execute(position.latitude, position.longitude);

      corridaService.formCorridaMacaneta = {
        "telefone": _controllerTelefone.text,
        "nome": _controllerNome.text,
        "endereco_partida_texto": localAtual,
        "endereco_partida_latitude": position.latitude.toString(),
        "endereco_partida_longitude": position.longitude.toString(),
        "categoria_selecionada_id": categoriaSelecionada,
      };

      await corridaService.save();
      var resp = await corridaService.criarCorridaMacaneta();

      if (resp == 201) {
        Navigator.of(context).pop();
        setState(() {
          isLoading = false;
        });
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => DetalhesMacanetaScreen()),
        );
      } else if (resp == false) {
        Navigator.of(context).pop();
        setState(() {
          isLoading = false;
        });
        showDialogCreditoInsuficiente(context);
      } else if (resp == 400) {
        Navigator.of(context).pop();
        setState(() {
          isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      Navigator.of(context).pop();
      showModalAlertError("Ops! Algo deu errado, tente novamente mais tarde!");
    }
  }

  showModalAlertError(String message) async {
    showDialog<String>(
      context: context,
      builder:
          (BuildContext context) => AlertDialog(
            title: Text('Ops!', textAlign: TextAlign.center),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.error, color: Colors.red, size: 50),
                SizedBox(height: 10),
                Text(
                  message,
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.black),
                ),
              ],
            ),
            actions: <Widget>[
              InkWell(
                onTap: () {
                  Navigator.pop(context, "Fechar");
                },
                child: Padding(
                  padding: EdgeInsets.only(bottom: 10, left: 15, right: 15),
                  child: Text('Fechar', style: TextStyle(color: Colors.orange)),
                ),
              ),
            ],
          ),
    );
  }

  void showDialogCreditoInsuficiente(BuildContext context) async {
    await showDialog<String>(
      barrierDismissible: false,
      context: context,
      builder:
          (BuildContext context) => AlertDialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(12.0)),
            ),
            title: Container(
              child: Text(
                'Ops!',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 13, color: Colors.grey[700]),
              ),
            ),
            content: Container(
              width: 350,
              height: 210,
              child: Column(
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Flexible(
                        child: Text(
                          "Créditos insuficiente para abrir a corrida!",
                          style: TextStyle(
                            color: Colors.grey[700],
                            fontWeight: FontWeight.w500,
                            fontSize: 12,
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 5),
                  Divider(),
                  SizedBox(height: 5),
                  Row(
                    children: <Widget>[
                      Flexible(
                        child: Text(
                          "Clique no botão recarga para fazer um nova recarga de créditos",
                          style: TextStyle(
                            color: Colors.grey[700],
                            fontWeight: FontWeight.w500,
                            fontSize: 12,
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 5),
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        elevation: 0,
                        backgroundColor: AppColors.buttonSecondary,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(6),
                          side: BorderSide(color: AppColors.buttonBorderSecondary),
                        ),
                        minimumSize: Size(100, 40),
                      ),
                      onPressed: () async {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => HistoricoRecargasScreen(),
                          ),
                        );
                      },
                      child: Text("Recarga", style: TextStyle(fontSize: 18)),
                    ),
                  ),
                  SizedBox(height: 5),
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        elevation: 0,
                        backgroundColor: Colors.transparent,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(6),
                          side: BorderSide(color: AppColors.buttonBorderSecondary),
                        ),
                        minimumSize: Size(100, 40),
                        shadowColor: Colors.transparent,
                      ),
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      child: Text(
                        "Cancelar",
                        style: TextStyle(fontSize: 18, color: Colors.orange),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
    );
  }

  showLoader() {
    if (isLoading == true) {
      showDialog<String>(
        barrierDismissible: false,
        context: context,
        builder:
            (BuildContext context) => AlertDialog(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(12.0)),
              ),
              title: Container(
                child: Text(
                  'Abrindo corrida...',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 13, color: Colors.grey[700]),
                ),
              ),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 16),
                  Text('Carregando...'),
                ],
              ),
            ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    var corridaService = Provider.of<CorridaService>(context, listen: true);
    return MediaQuery(
      data: MediaQuery.of(context).copyWith(textScaler: TextScaler.linear(1.0)),
      child: Scaffold(
        backgroundColor: Color.fromARGB(255, 58, 58, 58),
        appBar: AppBar(
          leading: IconButton(
            icon: Icon(Icons.arrow_back_ios_new, color: Colors.white, size: 25),
            onPressed: () => Navigator.of(context).pop(),
          ),
          title: Text("Abertura de corrida", style: TextStyle(fontSize: 17)),
          centerTitle: true,
          backgroundColor: Color.fromARGB(255, 49, 49, 49),
        ),
        body: Padding(
          padding: EdgeInsets.only(left: 15, top: 35, right: 15),
          child: Material(
            type: MaterialType.transparency,
            child: new SingleChildScrollView(
              child: Container(
                color: Color.fromARGB(255, 58, 58, 58),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    Container(
                      child: Text(
                        "Informações do passageiro",
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 17,
                        ),
                      ),
                    ),
                    SizedBox(height: 15),
                    Container(
                      child: Text(
                        "Preencha os dados abaixo para iniciar uma corrida com um passageiro na rua",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w400,
                          fontSize: 16,
                        ),
                      ),
                    ),
                    SizedBox(height: 40),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          "Telefone *",
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        SizedBox(height: 5),
                        Container(
                          child: TextField(
                            controller: _controllerTelefone,
                            inputFormatters: [maskCelular],
                            keyboardType: TextInputType.number,
                            onChanged:
                                (value) => {
                                  if (value.length == 15)
                                    {buscarUsuarioPassageiroPorTelefone(value)},
                                },
                            decoration: InputDecoration(
                              filled: true,
                              fillColor: Colors.grey[100],
                              hintText: "Ex: (00) 00000 0000",
                              errorText:
                                  corridaService
                                              .formErrorsCorridaMacaneta?['telefone'] !=
                                          null
                                      ? corridaService
                                          .formErrorsCorridaMacaneta['telefone']
                                      : null,
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 15),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          "Nome *",
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        SizedBox(height: 5),
                        Container(
                          child: TextField(
                            controller: _controllerNome,
                            decoration: InputDecoration(
                              filled: true,
                              fillColor: Colors.grey[100],
                              hintText: "Ex: João Silva",
                              errorText:
                                  corridaService
                                              .formErrorsCorridaMacaneta?['nome'] !=
                                          null
                                      ? corridaService
                                          .formErrorsCorridaMacaneta['nome']
                                      : null,
                            ),
                            onChanged: (value) {},
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 15),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          "Categoria *",
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        SizedBox(height: 5),
                        Container(
                          child: DropdownButtonFormField<Categoria>(
                            value: null,
                            items:
                                listaCategoria.map((Categoria categoria) {
                                  return DropdownMenuItem<Categoria>(
                                    value: categoria,
                                    child: Text(categoria.name),
                                  );
                                }).toList(),
                            onChanged: (Categoria? selectedCategoria) {
                              if (selectedCategoria != null) {
                                setState(() {
                                  categoriaSelecionada =
                                      selectedCategoria.id.toString();
                                });
                              }
                            },
                            decoration: InputDecoration(
                              filled: true,
                              fillColor: Colors.grey[100],
                              hintText: "Selecione a categoria",
                              errorText:
                                  corridaService
                                              .formErrorsCorridaMacaneta?['categoria_selecionada_id'] !=
                                          null
                                      ? corridaService
                                          .formErrorsCorridaMacaneta['categoria_selecionada_id']
                                      : null,
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 40),
                    SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          elevation: 0,
                          backgroundColor: AppColors.buttonSecondary,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(6),
                            side: BorderSide(color: AppColors.buttonBorderSecondary),
                          ),
                          minimumSize: Size(100, 40), //////// HERE
                        ),
                        onPressed: () async {
                          await criarCorridaMacaneta();
                        },
                        child: Text(
                          "Abrir corrida",
                          style: TextStyle(fontSize: 18, color: Colors.white,),
                        ),
                      ),
                    ),
                    SizedBox(height: 15),
                    Container(
                      child: Text(
                        "A solicitação da abertura de corrida poderá demorar até 30 segundos para ser iniciada pelo sistema.",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Colors.white60,
                          fontWeight: FontWeight.w400,
                          fontSize: 12,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
