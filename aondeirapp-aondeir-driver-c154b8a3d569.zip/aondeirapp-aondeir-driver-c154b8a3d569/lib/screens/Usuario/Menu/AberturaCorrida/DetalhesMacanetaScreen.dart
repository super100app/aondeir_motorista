import 'package:aondeir_motorista/styles/app_colors.dart';
import 'dart:async';

import 'package:aondeir_motorista/screens/Usuario/BottomNavigationBar/NavigationScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/AberturaCorrida/FichaTecnica/FichaTecnicaScreen.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:geolocator/geolocator.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:slidable_button/slidable_button.dart';
import '../../../../service/CorridaService.dart';
import '../../../../service/LocalizacaoService.dart';
import '../../../../service/corrida/CorridaConverterDistanciaParaTextoService.dart';
import '../../../../service/corrida/CorridaConverterDuracaoParaTextoService.dart';
import '../../../../service/corrida/macaneta/CorridaMacanetaAlterarStatusAguardandoPassageiroService.dart';
import '../../../../service/corrida/macaneta/CorridaMacanetaConfirmarPagamentoService.dart';
import '../../../../service/corrida/macaneta/CorridaMacanetaFinalizarService.dart';
import '../../../../service/corrida/macaneta/CorridaMacanetaIniciarCorridaService.dart';
import '../../../../service/corrida/macaneta/CorridaMacanetaPegarEmAndamentoService.dart';
import '../../../../service/corrida/macaneta/CorridaMacanetaSalvarCoordenadaRotaService.dart';
import '../../../../service/corrida/macaneta/CorridaMacanetaSalvarPrimeiraCoordenadaRotaService.dart';
import '../../../../service/corrida/macaneta/parada/CorridaMacanetaAdicionarParadaService.dart';
import '../../../../service/corrida/macaneta/parada/CorridaMacanetaBuscarDuracaoParadaService.dart';
import '../../../../service/corrida/macaneta/parada/CorridaMacanetaFinalizarParadaService.dart';
import '../../../../service/corrida/macaneta/parada/CorridaMacanetaPegarDuracaoParadaService.dart';
import '../../../../service/helper/ConverterDinheiroParaReaisService.dart';
import '../../../../service/localizacao/PesquisaEnderecoGeocodificacaoPorCoordenadaService.dart';
import '../../../../service/mapbox/MapboxRecalcularRotaService.dart';
import '../../../../service/corrida/CorridaGuardarCoordenadasOfflineService.dart';
import '../../../../service/corrida/CorridaPegarCoordenadasResitradaService.dart';
import '../../../../service/corrida/CorridaPegarDistanciaEntrePontosService.dart';
import '../../../../service/corrida/macaneta/CorridaMacanetaPegarUltimaCoordenadaResitradaService.dart';
import '../../../../service/corrida/CorridaPegarDuracaoService.dart';
import '../../../../service/corrida/CorridaSomarTotalDistanciaPercorridaRotaService.dart';
import '../../../../service/helper/CalcularSegundosRestanteService.dart';
import '../../../../service/helper/CheckConexaoService.dart';
import '../../../../service/helper/ConverterSegundoParaMinutoService.dart';
import '../../../../service/middleware/CurrentScreenService.dart';
import 'OpcionalCancelamentoMacanetaScreen.dart';
import 'package:connectivity_plus/connectivity_plus.dart';

class DetalhesMacanetaScreen extends StatefulWidget {
  const DetalhesMacanetaScreen({super.key});

  @override
  State<DetalhesMacanetaScreen> createState() => _DetalhesMacanetaScreenState();
}

class _DetalhesMacanetaScreenState extends State<DetalhesMacanetaScreen> {
  final storage = new FlutterSecureStorage();
  Timer? meuTimer;
  bool status = false;
  bool ShowDialog = false;
  bool isLoading = false;
  bool isFinalizandoCorrida = false;
  bool salvando = false;
  bool isGuardandoPossicao = false;
  bool isRecalculandoRota = false;
  bool isCalculando = false;
  bool startContarParada = false;
  bool isSaving = false;
  bool isInicioCotadorMinutoParada = false;
  var corrida = {};
  var pedido = {};
  var tarifa = {};
  var motivoId = null;
  var dataInicioParada = null;
  var isOptionSelected = false;
  var motivoDescricao = "";
  var parte = 0;
  var kmRodado = 0;
  var minutoServico = 0;
  var valorCalculado = 0.0;
  var valorBase = 0.0;
  var valorMinutoTarifa = 0.0;
  var valorMinimo = 0.0;
  var valorCorrida = 0.0;
  var valorEmSegundos = 0.0;
  var valorKmEmSegundo = 0.0;
  var totalValorPorMinuto = 0.0;
  var totalValorPorKm = 0.0;
  var totalParada = 0.0;
  var valorParadaAdicional = 0.0;
  var valorMinutoParada = 0.0;
  var tarifaValores = [];
  var duracaoSegundos = 0;
  var positionStreamState;

  late Position _startPosition = Position(
    longitude: 0,
    latitude: 0,
    timestamp: DateTime.now(),
    accuracy: 0,
    altitude: 0,
    heading: 0,
    speed: 0,
    headingAccuracy: 0,
    altitudeAccuracy: 0,
    speedAccuracy: 0,
  );
  var distanciaTexto = "";
  var distanciaEntreOsPontos = 0.0;
  var totalPercorridoEntrePontos = 0.0;
  var totalPercorridoRota = 0.0;
  var totalPercorridoRotaParaSalvar = 0.0;
  var tempoTotalParadaSegundos = 0;
  var duracaoEmSegundos = 0;
  var duracao = "00:00";
  var enderecoDestino = "";
  var distanciaPercorridaCorridaText = "0";
  String etapas = "Cheguei ao local";
  String tempoParadoTexto = "00:00";

  final GeolocatorPlatform _geolocatorPlatform = GeolocatorPlatform.instance;
  StreamSubscription<Position>? _positionStreamSubscription;
  StreamSubscription<ServiceStatus>? _serviceStatusStreamSubscription;

  late LocationSettings locationSettings;
  bool positionStreamStarted = false;
  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      await setCurrenteScreen();
      await checkConexaoInternet();
      await pegarCorridaMacaneta();
      await setParte();
      await pegarUltimaCorridanaRegistrada();
      await adicionarValorCorridaTexto();
      await fillState();
      await _getLocation();
      await obterValorMinutoEmSegundos();
      await obterValorKmRodadoEmSegundos();
      await setDistanciaPercoorridaCorridaText();
      await calcularValorCorridaPorMinuto();
      await calcularValorCorridaPorKm();
      await calcularValorCorrida();
      await buscarDuaracaoParadaCorrida();

      Timer.periodic(Duration(seconds: 1), (timer) {
        pegarDurancaoCorrida();
      });
    });
  }

  @override
  void dispose() {
    if (_positionStreamSubscription != null) {
      _positionStreamSubscription!.cancel();
      _positionStreamSubscription = null;
    }

    super.dispose();
  }

  setCurrenteScreen() async {
    var currentScreenService = Provider.of<CurrentScreenService>(
      context,
      listen: false,
    );
    currentScreenService.setCurrentScreen("DetalhesMacanetaScreen");
  }

  pegarCorridaMacaneta() async {
    var corridaMacanetaPegarEmAndamentoService =
        Provider.of<CorridaMacanetaPegarEmAndamentoService>(
          context,
          listen: false,
        );

    var corridaMacanetaResp =
        await corridaMacanetaPegarEmAndamentoService.execute();

    setState(() {
      corrida = corridaMacanetaResp;
      pedido = corridaMacanetaResp['pedidos'][0];
      tarifa = corridaMacanetaResp['tarifa'];
    });
  }

  checkConexaoInternet() async {
    var checkConexaoService = Provider.of<CheckConexaoService>(
      context,
      listen: false,
    );

    await checkConexaoService.execute();
    // Connectivity()
    //     .onConnectivityChanged
    //     .listen((List<ConnectivityResult> results) async {
    //   if (results.isNotEmpty && !results.contains(ConnectivityResult.none)) {
    //     await checkConexaoService.execute();
    //   }
    // });
  }

  fillState() async {
    setState(() {
      valorCorrida = double.parse(corrida['valor_corrida']);
      valorMinimo = double.parse(tarifa['valor_minimo']);
      valorBase = double.parse(tarifa['valor_bandeirada']);
      valorMinutoTarifa = double.parse(tarifa['valor_minuto']);
      valorParadaAdicional = double.parse(tarifa['valor_parada_adicional']);
      valorMinutoParada = double.parse(tarifa['valor_minuto_parada']);
      tarifaValores = tarifa['tarifa_valores'];
    });
  }

  pegarUltimaCorridanaRegistrada() async {
    var corridaMacanetaPegarUltimaCoordenadaResitradaService =
        Provider.of<CorridaMacanetaPegarUltimaCoordenadaResitradaService>(
          context,
          listen: false,
        );

    await corridaMacanetaPegarUltimaCoordenadaResitradaService.execute();
  }

  setDistanciaPercoorridaCorridaText() async {
    var corridaConverterDistanciaParaTextoService =
        Provider.of<CorridaConverterDistanciaParaTextoService>(
          context,
          listen: false,
        );

    var text = await corridaConverterDistanciaParaTextoService.execute(corrida);

    setState(() {
      distanciaPercorridaCorridaText = text;
    });
  }

  adicionarValorCorridaTexto() async {
    var converterDinheiroParaReaisService =
        Provider.of<ConverterDinheiroParaReaisService>(context, listen: false);

    setState(() {
      valorCorrida = double.parse(corrida['valor_corrida']);
    });

    await converterDinheiroParaReaisService.execute(valorCorrida);
  }

  pegarDurancaoCorrida() async {
    try {
      if (parte == 2) {
        var corridaPegarDuracaoService =
            Provider.of<CorridaPegarDuracaoService>(context, listen: false);
        var converterSegundoParaMinutoService =
            Provider.of<ConverterSegundoParaMinutoService>(
              context,
              listen: false,
            );
        var calcularSegundosRestanteService =
            Provider.of<CalcularSegundosRestanteService>(
              context,
              listen: false,
            );

        await corridaPegarDuracaoService.execute(corrida);

        await converterSegundoParaMinutoService.execute(
          corridaPegarDuracaoService.duracaoEmSegundos,
        );

        await calcularSegundosRestanteService.execute(
          corridaPegarDuracaoService.duracaoEmSegundos,
        );

        if (corridaPegarDuracaoService.duracaoEmSegundos > 0) {
          setState(() {
            duracao =
                converterSegundoParaMinutoService.minutos.toString() +
                ":" +
                calcularSegundosRestanteService.segundosRestantes
                    .toString()
                    .padLeft(2, '0');
          });

          if (converterSegundoParaMinutoService.minutos > 0 &&
              calcularSegundosRestanteService.segundosRestantes == 0) {
            var total =
                valorMinutoTarifa * converterSegundoParaMinutoService.minutos;

            setState(() {
              totalValorPorMinuto = total;
            });

            await calcularValorCorrida();
          }
        }
      }
    } catch (e) {
      throw e;
    }
  }

  calcularValorCorridaPorMinuto() async {
    try {
      if (parte == 2) {
        var corridaPegarDuracaoService =
            Provider.of<CorridaPegarDuracaoService>(context, listen: false);
        var converterSegundoParaMinutoService =
            Provider.of<ConverterSegundoParaMinutoService>(
              context,
              listen: false,
            );
        var calcularSegundosRestanteService =
            Provider.of<CalcularSegundosRestanteService>(
              context,
              listen: false,
            );

        await corridaPegarDuracaoService.execute(corrida);
        await converterSegundoParaMinutoService.execute(
          corridaPegarDuracaoService.duracaoEmSegundos,
        );
        await calcularSegundosRestanteService.execute(
          corridaPegarDuracaoService.duracaoEmSegundos,
        );

        if (converterSegundoParaMinutoService.minutos > 0) {
          var total =
              valorMinutoTarifa * converterSegundoParaMinutoService.minutos;

          setState(() {
            totalValorPorMinuto = total;
          });
        }
      }
    } catch (e) {
      throw e;
    }
  }

  calcularValorCorridaPorKm() async {
    try {
      if (parte == 2) {
        var distancia = double.parse(
          corrida['distancia_percorrida_metros'].toString(),
        );

        if (distancia == 0) {
          return;
        }

        for (var tarifa in tarifaValores) {
          if (tarifa['distancia_ate'] == null) {
            var convertido = double.parse(tarifa['valor_km'].toString()) / 1000;

            var total = distancia * convertido;

            setState(() {
              totalValorPorKm = total;
            });
          } else {
            if (distancia <= double.parse(tarifa['distancia_ate'])) {
              var convertido =
                  double.parse(tarifa['valor_km'].toString()) / 1000;

              var total = distancia * convertido;

              setState(() {
                totalValorPorKm = total;
              });
            }
          }
        }
      }
    } catch (e) {
      throw e;
    }
  }

  calcularValorCorrida() async {
    try {
      if (parte == 2) {
        var converterDinheiroParaReaisService =
            Provider.of<ConverterDinheiroParaReaisService>(
              context,
              listen: false,
            );

        var valor = valorBase + totalValorPorMinuto + totalValorPorKm;

        if (valor > valorMinimo) {
          setState(() {
            valorCorrida = valor + totalParada;
          });

          await converterDinheiroParaReaisService.execute(valorCorrida);
        }
      }
    } catch (e) {
      throw e;
    }
  }

  Future<void> _getLocation() async {
    print('✅✅CAIUUUUUUUUUUU AQUIIIIIIIIIIII!!✅✅');
    if (parte != 2) {
      return;
    }
    _toggleServiceStatusStream();
    _toggleListening();
  }

  Future<void> _toggleListening() async {
    if (parte == 2 && _positionStreamSubscription == null) {
      setState(() {
        totalPercorridoRota = 0.0;
        distanciaEntreOsPontos = 0.0;
        totalPercorridoEntrePontos = 0.0;
      });

      var locationSettings;

      if (defaultTargetPlatform == TargetPlatform.android) {
        locationSettings = await AndroidSettings(
          // accuracy: LocationAccuracy.bestForNavigation,
          accuracy: LocationAccuracy.low,
          distanceFilter: 100,
          foregroundNotificationConfig: const ForegroundNotificationConfig(
            notificationText:
                "O aplicativo continuará recebendo sua localização mesmo quando você estiver com ele em segundo plano",
            notificationTitle: "Executando em segundo plano",
            enableWakeLock: true,
          ),
        );
      } else if (defaultTargetPlatform == TargetPlatform.iOS ||
          defaultTargetPlatform == TargetPlatform.macOS) {
        locationSettings = await AppleSettings(
          // accuracy: LocationAccuracy.bestForNavigation,
          accuracy: LocationAccuracy.low,
          activityType: ActivityType.fitness,
          distanceFilter: 100,
          pauseLocationUpdatesAutomatically: true,
          showBackgroundLocationIndicator: false,
        );
      } else {
        locationSettings = await LocationSettings(
          // accuracy: LocationAccuracy.bestForNavigation,
          accuracy: LocationAccuracy.low,
          distanceFilter: 100,
        );
      }

      final positionStream = await Geolocator.getPositionStream(
        locationSettings: locationSettings,
      );

      _positionStreamSubscription = positionStream
          .handleError((error) {
            _positionStreamSubscription?.cancel();
            _positionStreamSubscription = null;
          })
          .listen((Position position) async {
            if (position == null) {
              return;
            }

            if (isCalculando) {
              return;
            }

            if (_startPosition.latitude == position.latitude &&
                _startPosition.longitude == position.longitude) {
              return;
            }

            setState(() {
              isCalculando = true;
            });

            if (_startPosition.latitude == 0) {
              await setStartPosition(position);
            }

            await pegarDistanciaEntrePontos(_startPosition, position);

            setState(() {
              _startPosition = position;
            });

            await somarDistaciaPercorridaEntrePontos();
            await somarTotalPercorridoRota();
            await somarTotalPercorridoRotaParaSalvar();

            await guardarCoordenada(position);

            setState(() {
              isCalculando = false;
            });
          });

      if (isLoading == true) {
        Navigator.of(context).pop();
      }

      setState(() {
        positionStreamState = _positionStreamSubscription;
        _positionStreamSubscription = _positionStreamSubscription;
        isLoading = false;
      });
    }
  }

  void _toggleServiceStatusStream() {
    if (_serviceStatusStreamSubscription == null) {
      final serviceStatusStream = _geolocatorPlatform.getServiceStatusStream();
      serviceStatusStream
          .handleError((error) {
            _serviceStatusStreamSubscription?.cancel();
            _serviceStatusStreamSubscription = null;
          })
          .listen((serviceStatus) {
            String serviceStatusValue;
            if (serviceStatus == ServiceStatus.enabled) {
              _toggleListening();
              serviceStatusValue = 'enabled';
            } else {
              if (_positionStreamSubscription != null) {
                setState(() {
                  _positionStreamSubscription?.cancel();
                  _positionStreamSubscription = null;
                });
              }
              serviceStatusValue = 'disabled';
            }
          });
    }
  }

  setParte() async {
    if (corrida["status"]['id'] == 4) {
      setState(() {
        parte = 0;
      });
    }

    if (corrida["status"]['id'] == 5) {
      setState(() {
        parte = 1;
        etapas = "Iniciar corrida";
      });
    }

    if (corrida["status"]['id'] == 6) {
      setState(() {
        parte = 2;
        etapas = 'Finalizar corrida';
      });
    }

    if (corrida["status"]['id'] == 7) {
      setState(() {
        parte = 3;
      });

      showModal();
    }
  }

  setStartPosition(position) async {
    if (_startPosition.latitude == 0) {
      setState(() {
        _startPosition = position;
      });

      await salvarPrimeiraCoordenadaRotaMacaneta();
    }
  }

  salvarPrimeiraCoordenadaRotaMacaneta() async {
    try {
      var corridaMacanetaSalvarPrimeiraCoordenadaRotaService =
          Provider.of<CorridaMacanetaSalvarPrimeiraCoordenadaRotaService>(
            context,
            listen: false,
          );

      await corridaMacanetaSalvarPrimeiraCoordenadaRotaService.execute(
        _startPosition.latitude,
        _startPosition.longitude,
      );
    } catch (e) {
      throw e;
    }
  }

  guardarCoordenada(Position position) async {
    try {
      var checkConexaoService = Provider.of<CheckConexaoService>(
        context,
        listen: false,
      );

      var corridaGuardarCoordenadasOfflineService =
          Provider.of<CorridaGuardarCoordenadasOfflineService>(
            context,
            listen: false,
          );

      if (distanciaEntreOsPontos > 10) {
        await corridaGuardarCoordenadasOfflineService.execute(
          position,
          distanciaEntreOsPontos,
        );
      }

      if (totalPercorridoRota >= 20) {
        var textTotalKm = await converterDistanciaParaTexto(
          totalPercorridoRota,
        );
        setState(() {
          distanciaPercorridaCorridaText = textTotalKm;
        });
      }

      if (isSaving) {
        return;
      }

      await checkConexaoService.execute();

      if (checkConexaoService.connectionStatus == true &&
          totalPercorridoRotaParaSalvar >= 100) {
        setState(() {
          isSaving = true;
          totalPercorridoEntrePontos = 0.0;
          totalPercorridoRotaParaSalvar = 0.0;
        });

        var coordenadas = await storage.read(key: 'coordenadas');

        var corridaMacanetaSalvarCoordenadaRotaService =
            Provider.of<CorridaMacanetaSalvarCoordenadaRotaService>(
              context,
              listen: false,
            );

        var corridaAtualizada = await corridaMacanetaSalvarCoordenadaRotaService
            .execute(position.latitude, position.longitude, coordenadas);

        setState(() {
          corrida = corridaAtualizada;
          totalPercorridoEntrePontos = 0.0;
        });

        corridaGuardarCoordenadasOfflineService.coordenadas.clear();
        await corridaGuardarCoordenadasOfflineService.save();
        await calcularValorCorridaPorKm();
        await calcularValorCorrida();

        await storage.delete(key: 'coordenadas');

        setState(() {
          isSaving = false;
        });
      } else if (checkConexaoService.connectionStatus == false) {
        setState(() {
          isSaving = false;
        });
      }
    } catch (e) {
      setState(() {
        isSaving = false;
        isCalculando = false;
      });
      throw e;
    }
  }

  converterDistanciaParaTexto(distancia) async {
    var distanciaPercorridaFormatada = "0";
    if (distancia > 0) {
      double distanceInKilometers = double.parse(distancia.toString()) / 1000;

      if (distanceInKilometers < 1) {
        var numeroFormatadoMetros = distanceInKilometers
            .toStringAsFixed(3)
            .toString()
            .replaceAll('.', ',');

        distanciaPercorridaFormatada =
            numeroFormatadoMetros.substring(2) + " m";
      } else {
        var numeroFormatadoKm = distanceInKilometers.toStringAsFixed(1);
        distanciaPercorridaFormatada =
            numeroFormatadoKm.replaceAll('.', ',') + " km";
      }
      return distanciaPercorridaFormatada;
    } else {
      return distanciaPercorridaFormatada;
    }
  }

  pegarDistanciaEntrePontos(Position _startPosition, Position position) async {
    var distanciaEntreOsPontosResp = await Geolocator.distanceBetween(
      _startPosition.latitude,
      _startPosition.longitude,
      position.latitude,
      position.longitude,
    );

    setState(() {
      distanciaEntreOsPontos = distanciaEntreOsPontosResp;
    });
  }

  somarDistaciaPercorridaEntrePontos() async {
    var total = totalPercorridoEntrePontos + distanciaEntreOsPontos;

    setState(() {
      totalPercorridoEntrePontos = total;
    });
  }

  somarTotalPercorridoRota() async {
    var total = 0.0;
    total = totalPercorridoRota + distanciaEntreOsPontos;

    setState(() {
      totalPercorridoRota = total;
    });
  }

  somarTotalPercorridoRotaParaSalvar() async {
    var total = 0.0;
    total = totalPercorridoRotaParaSalvar + distanciaEntreOsPontos;

    setState(() {
      totalPercorridoRotaParaSalvar = total;
    });
  }

  alterarStatusMacaneta() async {
    try {
      var corridaMacanetaAlterarStatusAguardandoPassageiroService =
          Provider.of<CorridaMacanetaAlterarStatusAguardandoPassageiroService>(
            context,
            listen: false,
          );

      setState(() {
        isLoading = true;
      });

      await showLoader("Alterando status da corrida");
      await Future.delayed(Duration(seconds: 1));
      var corridaAguradandoPassageiro =
          await corridaMacanetaAlterarStatusAguardandoPassageiroService
              .execute();

      setState(() {
        corrida = corridaAguradandoPassageiro;
      });

      setState(() {
        parte = 1;
        etapas = 'Iniciar corrida';
      });

      Navigator.of(context).pop();
      setState(() {
        isLoading = false;
      });
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      Navigator.of(context).pop();
      showModalAlertError(
        "Ops! Houve um erro ao alterar o status da corrida, tente novamente mais tarde.",
      );
    }
  }

  showModalAlertError(String message) async {
    showDialog<String>(
      context: context,
      builder:
          (BuildContext context) => AlertDialog(
            title: Text('Ops!', textAlign: TextAlign.center),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.error, color: Colors.red, size: 50),
                SizedBox(height: 10),
                Text(
                  message,
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.black),
                ),
              ],
            ),
            actions: <Widget>[
              InkWell(
                onTap: () {
                  Navigator.pop(context, "Fechar");
                },
                child: Padding(
                  padding: EdgeInsets.only(bottom: 10, left: 15, right: 15),
                  child: Text('Fechar', style: TextStyle(color: Colors.orange)),
                ),
              ),
            ],
          ),
    );
  }

  inciarCorrida() async {
    try {
      setState(() {
        isLoading = true;
      });
      var checkConexaoService = Provider.of<CheckConexaoService>(
        context,
        listen: false,
      );
      await checkConexaoService.execute();

      if (checkConexaoService.connectionStatus == false) {
        setState(() {
          isLoading = false;
        });
        showModalAlertError(
          "Ops! Você está sem conexão com a internet, por favor, verifique sua conexão e tente novamente.",
        );
        return;
      }

      await showLoader("Iniciando a corrida");
      await Future.delayed(Duration(seconds: 1));

      var localizacaoService = Provider.of<LocalizacaoService>(
        context,
        listen: false,
      );

      Position position =
          await localizacaoService.getCurrentLocationAberturaCorrida();

      await setStartPosition(position);

      var corridaMacanetaIniciarCorridaService =
          Provider.of<CorridaMacanetaIniciarCorridaService>(
            context,
            listen: false,
          );
      var corridaInciada = await corridaMacanetaIniciarCorridaService.execute();

      setState(() {
        corrida = corridaInciada;
      });

      setState(() {
        parte = 2;
        etapas = 'Finalizar corrida';
      });

      Navigator.of(context).pop();
      setState(() {
        isLoading = false;
      });

      await _getLocation();
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      Navigator.of(context).pop();
      showModalAlertError(
        "Ops! Houve um erro ao iniciar a corrida, tente novamente mais tarde!",
      );
    }
  }

  finalizarCorrida() async {
    try {
      setState(() {
        isLoading = true;
      });
      var checkConexaoService = Provider.of<CheckConexaoService>(
        context,
        listen: false,
      );

      await checkConexaoService.execute();
      if (checkConexaoService.connectionStatus == false) {
        setState(() {
          isLoading = false;
        });
        showModalAlertError(
          "Ops! Você está sem conexão com a internet, por favor, verifique sua conexão e tente novamente.",
        );
        return;
      }

      setState(() {
        isFinalizandoCorrida = true;
        isSaving = true;
      });

      _positionStreamSubscription!.pause();

      var corridaMacanetaFinalizarService =
          Provider.of<CorridaMacanetaFinalizarService>(context, listen: false);

      var localizacaoService = Provider.of<LocalizacaoService>(
        context,
        listen: false,
      );

      var pesquisaEnderecoGeocodificacaoPorCoordenadaService =
          Provider.of<PesquisaEnderecoGeocodificacaoPorCoordenadaService>(
            context,
            listen: false,
          );

      var corridaGuardarCoordenadasOfflineService =
          Provider.of<CorridaGuardarCoordenadasOfflineService>(
            context,
            listen: false,
          );

      var corridaMacanetaSalvarCoordenadaRotaService =
          Provider.of<CorridaMacanetaSalvarCoordenadaRotaService>(
            context,
            listen: false,
          );

      if (checkConexaoService.connectionStatus == true) {
        await showLoader("Finalizando a corrida");
        await Future.delayed(Duration(seconds: 1));

        Position enderecoDestino =
            await localizacaoService.getCurrentLocationAberturaCorrida();

        var enderecoAtualTexto =
            await pesquisaEnderecoGeocodificacaoPorCoordenadaService.execute(
              enderecoDestino.latitude,
              enderecoDestino.longitude,
            );

        setState(() {
          totalPercorridoRota = 0.0;
        });

        await pegarDistanciaEntrePontos(_startPosition, enderecoDestino);

        await corridaGuardarCoordenadasOfflineService.execute(
          enderecoDestino,
          distanciaEntreOsPontos,
        );

        var coordenadas = await storage.read(key: 'coordenadas');

        var corridaAtualizada = await corridaMacanetaSalvarCoordenadaRotaService
            .execute(
              enderecoDestino.latitude,
              enderecoDestino.longitude,
              coordenadas,
            );

        setState(() {
          corrida = corridaAtualizada;
          totalPercorridoEntrePontos = 0.0;
        });

        var corridaConverterDistanciaParaTextoService =
            Provider.of<CorridaConverterDistanciaParaTextoService>(
              context,
              listen: false,
            );

        var text = await corridaConverterDistanciaParaTextoService.execute(
          corrida,
        );

        corridaGuardarCoordenadasOfflineService.coordenadas.clear();

        await corridaGuardarCoordenadasOfflineService.save();

        setState(() {
          distanciaPercorridaCorridaText = text;
        });

        await calcularValorCorridaPorKm();

        await calcularValorCorrida();

        await storage.delete(key: 'coordenadas');

        var corridaFinalizada = await corridaMacanetaFinalizarService.execute(
          enderecoDestino.latitude,
          enderecoDestino.longitude,
          enderecoAtualTexto,
        );

        setState(() {
          parte = 3;
          corrida = corridaFinalizada;
        });

        _positionStreamSubscription!.cancel();
        await cancelarTimer();

        Navigator.of(context).pop();

        setState(() {
          totalPercorridoRota = 0.0;
          distanciaEntreOsPontos = 0.0;
          totalPercorridoEntrePontos = 0.0;
          isLoading = false;
          isFinalizandoCorrida = false;
        });
      } else {
        setState(() {
          isLoading = false;
          isFinalizandoCorrida = false;
          isSaving = false;
        });

        _positionStreamSubscription!.resume();
      }
    } catch (e) {
      if (e is Exception) {
        setState(() {
          isLoading = false;
          isFinalizandoCorrida = false;
          isSaving = false;
        });
        _positionStreamSubscription!.resume();
        Navigator.of(context).pop();
        showModalAlertError(e.toString());
      } else {
        setState(() {
          isLoading = false;
          isFinalizandoCorrida = false;
          isSaving = false;
        });
        _positionStreamSubscription!.resume();
        Navigator.of(context).pop();
        showModalAlertError(e.toString());
      }
    }
  }

  confirmarPagamentoCorridaMacaneta() async {
    try {
      var corridaMacanetaConfirmarPagamentoService =
          Provider.of<CorridaMacanetaConfirmarPagamentoService>(
            context,
            listen: false,
          );

      setState(() {
        isLoading = true;
      });

      await showLoader("Confirmando pagamento da corrida");
      await Future.delayed(Duration(seconds: 1));

      var resp = await corridaMacanetaConfirmarPagamentoService.execute();

      Navigator.of(context).pop();
      setState(() {
        isLoading = false;
      });

      if (resp == true) {
        await resetarCorrida();
        await Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => NavigationScreen()),
        );
      }
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      Navigator.of(context).pop();
      showModalAlertError(e.toString());
    }
  }

  showModal() async {
    var corridaConverterDistanciaParaTextoService =
        Provider.of<CorridaConverterDistanciaParaTextoService>(
          context,
          listen: false,
        );

    var corridaConverterDuracaoParaTextoService =
        Provider.of<CorridaConverterDuracaoParaTextoService>(
          context,
          listen: false,
        );

    var converterDinheiroParaReaisService =
        Provider.of<ConverterDinheiroParaReaisService>(context, listen: false);

    var text = await corridaConverterDistanciaParaTextoService.execute(corrida);

    setState(() {
      distanciaPercorridaCorridaText = text;
    });

    var duracaoCorrida = await corridaConverterDuracaoParaTextoService.execute(
      corrida,
    );

    var taxaDaCorrida = await converterDinheiroParaReaisService.execute(
      double.parse(corrida['valor_taxa'].toString()),
    );

    var valorDaCorrida = await converterDinheiroParaReaisService.execute(
      double.parse(corrida['valor_corrida'].toString()),
    );

    var formatador = NumberFormat.currency(locale: 'pt_BR', symbol: 'R\$');
    var valorTotalPorParada = 0.0;
    var valorTotalMinutoParada = 0.0;
    var totalParadaAdicional = 0.0;
    var totalParadaAdicionalTexto = 'R\$ 0.00';

    valorTotalPorParada = double.parse(
      corrida['valor_total_por_parada'].toString(),
    );
    valorTotalMinutoParada = double.parse(
      corrida['valor_total_minuto_parada'].toString(),
    );
    totalParadaAdicional = valorTotalPorParada + valorTotalMinutoParada;

    totalParadaAdicionalTexto = formatador.format(totalParadaAdicional);

    showDialog<String>(
      barrierDismissible: false,
      context: context,
      builder:
          (BuildContext context) => AlertDialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(12.0)),
            ),
            title: Container(
              child: Text(
                'VALOR DA CORRIDA',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 13, color: Colors.grey[700]),
              ),
            ),
            content: SingleChildScrollView(
              child: Container(
                width: 350,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        Text(
                          "Valor a ser pago:",
                          style: TextStyle(
                            color: Colors.grey[700],
                            fontWeight: FontWeight.w500,
                            fontSize: 14,
                          ),
                        ),
                        Spacer(),
                        Text(
                          valorDaCorrida,
                          style: TextStyle(
                            color: Colors.grey[700],
                            fontWeight: FontWeight.w600,
                            fontSize: 18,
                          ),
                        ),
                      ],
                    ),
                    Divider(),
                    Row(
                      children: <Widget>[
                        Text(
                          "Pagamento:",
                          style: TextStyle(
                            color: Colors.grey[700],
                            fontWeight: FontWeight.w500,
                            fontSize: 14,
                          ),
                        ),
                        Spacer(),
                        Text(
                          "Dinheiro",
                          style: TextStyle(
                            color: Colors.grey[700],
                            fontWeight: FontWeight.w500,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                    Row(
                      children: <Widget>[
                        Text(
                          "Distancia percorrida:",
                          style: TextStyle(
                            color: Colors.grey[700],
                            fontWeight: FontWeight.w500,
                            fontSize: 14,
                          ),
                        ),
                        Spacer(),
                        Text(
                          distanciaPercorridaCorridaText,
                          style: TextStyle(
                            color: Colors.grey[700],
                            fontWeight: FontWeight.w500,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                    Row(
                      children: <Widget>[
                        Text(
                          "Duração:",
                          style: TextStyle(
                            color: Colors.grey[700],
                            fontWeight: FontWeight.w500,
                            fontSize: 14,
                          ),
                        ),
                        Spacer(),
                        Text(
                          duracaoCorrida,
                          style: TextStyle(
                            color: Colors.grey[700],
                            fontWeight: FontWeight.w500,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                    Row(
                      children: <Widget>[
                        Text(
                          "Taxas e impostos:",
                          style: TextStyle(
                            color: Colors.grey[700],
                            fontWeight: FontWeight.w500,
                            fontSize: 14,
                          ),
                        ),
                        Spacer(),
                        Text(
                          taxaDaCorrida,
                          style: TextStyle(
                            color: Colors.grey[700],
                            fontWeight: FontWeight.w500,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                    Row(
                      children: <Widget>[
                        Text(
                          "Parada adicional " + tempoParadoTexto,
                          style: TextStyle(
                            color: Colors.grey[700],
                            fontWeight: FontWeight.w500,
                            fontSize: 14,
                          ),
                        ),
                        Spacer(),
                        Text(
                          totalParadaAdicionalTexto,
                          style: TextStyle(
                            color: Colors.grey[700],
                            fontWeight: FontWeight.w500,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 15),
                    SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          elevation: 0,
                          backgroundColor: AppColors.buttonSecondary,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(6),
                            side: BorderSide(color: AppColors.buttonBorderSecondary),
                          ),
                          minimumSize: Size(100, 40),
                        ),
                        onPressed: () async {
                          await confirmarPagamentoCorridaMacaneta();
                        },
                        child: Text("Confirmar", style: TextStyle(fontSize: 18)),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
    );
  }

  showAlertFinalizandoCorrida() {
    if (isLoading == true) {
      showDialog<String>(
        barrierDismissible: false,
        context: context,
        builder:
            (BuildContext context) => AlertDialog(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(12.0)),
              ),
              title: Container(
                child: Text(
                  'Calculando valor da corrida',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 13, color: Colors.grey[700]),
                ),
              ),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 16),
                  Text('Carregando...'),
                ],
              ),
            ),
      );
    }
  }

  showLoader(texto) {
    if (isLoading == true) {
      showDialog<String>(
        barrierDismissible: false,
        context: context,
        builder:
            (BuildContext context) => AlertDialog(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(12.0)),
              ),
              title: Container(
                child: Text(
                  texto,
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 13, color: Colors.grey[700]),
                ),
              ),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 16),
                  Text('Carregando...'),
                ],
              ),
            ),
      );
    }
  }

  obterValorMinutoEmSegundos() {
    try {
      print('🟨🟨🟨 - 5555 obterValorMinutoEmSegundos');
    
      double numeroDouble = double.parse(tarifa['valor_minuto']);
      var valorMinutoEmSegundo = numeroDouble / 60;

      print('🟨🟨🟨 - totalSegundos');
      print(valorMinutoEmSegundo);

      setState(() {
        valorEmSegundos = valorMinutoEmSegundo;
      });
    } catch (e) {
      showModalAlertError(e.toString());
    }
  }

  obterValorKmRodadoEmSegundos() {
    try {
      double numeroDouble = double.parse(
        tarifa['tarifa_valores'][0]['valor_km'].toString(),
      );
      var valorKmRodadoEmSegundo = numeroDouble / 1000;

      setState(() {
        valorKmEmSegundo = valorKmRodadoEmSegundo;
      });
    } catch (e) {
      showModalAlertError(e.toString());
    }
  }

  resetarCorrida() async {
    try {
      var corridaPegarDuracaoService = Provider.of<CorridaPegarDuracaoService>(
        context,
        listen: false,
      );
      var corridaPegarDistanciaEntrePontosService =
          Provider.of<CorridaPegarDistanciaEntrePontosService>(
            context,
            listen: false,
          );
      var corridaSomarTotalDistanciaPercorridaRotaService =
          Provider.of<CorridaSomarTotalDistanciaPercorridaRotaService>(
            context,
            listen: false,
          );
      var corridaConverterDuracaoParaTextoService =
          Provider.of<CorridaConverterDuracaoParaTextoService>(
            context,
            listen: false,
          );

      var corridaPegarCoordenadasResitradaService =
          Provider.of<CorridaPegarCoordenadasResitradaService>(
            context,
            listen: false,
          );

      var mapboxRecalcularRotaService =
          Provider.of<MapboxRecalcularRotaService>(context, listen: false);

      var corridaConverterDistanciaParaTextoService =
          Provider.of<CorridaConverterDistanciaParaTextoService>(
            context,
            listen: false,
          );

      _positionStreamSubscription!.cancel();

      corridaPegarCoordenadasResitradaService.coordenadasRegistrada = [];
      corridaPegarCoordenadasResitradaService.partida = Position(
        longitude: 0,
        latitude: 0,
        timestamp: DateTime.now(),
        altitudeAccuracy: 0,
        accuracy: 0,
        altitude: 0,
        heading: 0,
        speed: 0,
        headingAccuracy: 0,
        speedAccuracy: 0,
      );
      corridaPegarCoordenadasResitradaService.destino = Position(
        longitude: 0,
        latitude: 0,
        timestamp: DateTime.now(),
        altitudeAccuracy: 0,
        accuracy: 0,
        altitude: 0,
        heading: 0,
        speed: 0,
        headingAccuracy: 0,
        speedAccuracy: 0,
      );
      setState(() {
        _startPosition = Position(
          longitude: 0,
          latitude: 0,
          timestamp: DateTime.now(),
          altitudeAccuracy: 0,
          accuracy: 0,
          altitude: 0,
          heading: 0,
          speed: 0,
          headingAccuracy: 0,
          speedAccuracy: 0,
        );
        corrida = {};
        tarifa = {};
        pedido = {};
        distanciaPercorridaCorridaText = '0';
      });

      corridaConverterDistanciaParaTextoService.distanciaPercorridaFormatada =
          '0';
      await corridaConverterDistanciaParaTextoService.save();

      await corridaPegarCoordenadasResitradaService.save();

      mapboxRecalcularRotaService.distancia = 0.0;
      mapboxRecalcularRotaService.duracao = 0.0;
      mapboxRecalcularRotaService.rota = {};

      corridaConverterDuracaoParaTextoService.duracaoCorrida = "";
      await corridaConverterDuracaoParaTextoService.save();

      corridaSomarTotalDistanciaPercorridaRotaService.totalPercorrido = 0.0;
      await corridaSomarTotalDistanciaPercorridaRotaService.save();

      corridaPegarDistanciaEntrePontosService.distanciaEntreOsPontos = 0.0;
      await corridaPegarDistanciaEntrePontosService.save();
      corridaPegarDuracaoService.duracaoEmSegundos = 0.0;
      await corridaPegarDuracaoService.save();
    } catch (e) {
      showModalAlertError(e.toString());
    }
  }

  iniciarParada() async {
    try {
      if (isLoading) {
        return;
      }

      if (startContarParada) {
        return;
      }

      setState(() {
        startContarParada = true;
        isLoading = true;
      });

      await showLoader("Obtendo localização da parada...");
      await Future.delayed(Duration(seconds: 1));

      var localizacaoService = Provider.of<LocalizacaoService>(
        context,
        listen: false,
      );

      Position position =
          await localizacaoService.getCurrentLocationAberturaCorrida();

      var pesquisaEnderecoGeocodificacaoPorCoordenadaService =
          Provider.of<PesquisaEnderecoGeocodificacaoPorCoordenadaService>(
            context,
            listen: false,
          );

      var localAtual = await pesquisaEnderecoGeocodificacaoPorCoordenadaService
          .execute(position.latitude, position.longitude);

      Navigator.of(context).pop();

      await showLoader("Iniciando parada...");
      await Future.delayed(Duration(seconds: 1));

      var latitude = position.latitude.toString();
      var longitude = position.longitude.toString();
      var endereco = localAtual;

      var corridaAdicionarParadaService =
          Provider.of<CorridaMacanetaAdicionarParadaService>(
            context,
            listen: false,
          );

      await corridaAdicionarParadaService.execute(
        latitude,
        longitude,
        endereco,
      );

      setState(() {
        dataInicioParada = corridaAdicionarParadaService.dataInicioParada;
        tempoTotalParadaSegundos =
            corridaAdicionarParadaService.tempoTotalParadaSegundos;
        totalParada = totalParada + valorParadaAdicional;
        valorCorrida = valorCorrida + valorParadaAdicional;
        isInicioCotadorMinutoParada = true;
      });

      await Future.delayed(Duration(seconds: 3));
      await pegarDurancaoParaCorrida();

      iniciarTimer();

      setState(() {
        isLoading = false;
      });
      Navigator.of(context).pop();

      var converterDinheiroParaReaisService =
          Provider.of<ConverterDinheiroParaReaisService>(
            context,
            listen: false,
          );
      await converterDinheiroParaReaisService.execute(valorCorrida);
    } catch (e) {
      setState(() {
        isLoading = false;
        startContarParada = false;
      });
      Navigator.of(context).pop();
      showModalAlertError(e.toString());
    }
  }

  pegarDurancaoParaCorrida() async {
    await pegarDuracaoEmSegundos();
    print('🟨🟨🟨 - 4444 obterValorMinutoEmSegundos');

    var totalSegundos = duracaoEmSegundos + tempoTotalParadaSegundos;

    var horas = totalSegundos ~/ 3600;
    var minutos = (totalSegundos % 3600) ~/ 60;
    var segundosRestantes = totalSegundos % 60;

    if (totalSegundos > 0) {
      var texto =
          horas > 0
              ? horas.toString().padLeft(2, '0') +
                  ":" +
                  minutos.toString().padLeft(2, '0') +
                  ":" +
                  segundosRestantes.toString().padLeft(2, '0')
              : minutos.toString() +
                  ":" +
                  segundosRestantes.toString().padLeft(2, '0');

      setState(() {
        tempoParadoTexto = texto;
      });
    }

    if (segundosRestantes == 0 && isInicioCotadorMinutoParada == false) {
      setState(() {
        totalParada = totalParada + valorMinutoParada;
        valorCorrida = valorCorrida + valorMinutoParada;
      });

      var converterDinheiroParaReaisService =
          Provider.of<ConverterDinheiroParaReaisService>(
            context,
            listen: false,
          );
      await converterDinheiroParaReaisService.execute(valorCorrida);
    }

    setState(() {
      isInicioCotadorMinutoParada = false;
    });
  }

  pegarDuracaoEmSegundos() async {
    if (dataInicioParada == null) {
      return;
    }

    var corridaPegarDuracaoParadaService =
        Provider.of<CorridaMacanetaPegarDuracaoParadaService>(
          context,
          listen: false,
        );
    await corridaPegarDuracaoParadaService.execute(dataInicioParada);

    setState(() {
      duracaoEmSegundos = corridaPegarDuracaoParadaService.duracaoEmSegundos;
    });
  }

  void iniciarTimer() {
    meuTimer = Timer.periodic(Duration(seconds: 1), (timer) {
      pegarDurancaoParaCorrida();
    });
  }

  cancelarTimer() {
    meuTimer?.cancel();
  }

  finalizarParada() async {
    try {
      if (isLoading) {
        return;
      }

      setState(() {
        isLoading = true;
      });

      await showLoader("finalizando parada...");
      await Future.delayed(Duration(seconds: 1));
      var corridaFinalizarParadaService =
          Provider.of<CorridaMacanetaFinalizarParadaService>(
            context,
            listen: false,
          );

      await corridaFinalizarParadaService.execute();

      setState(() {
        dataInicioParada = null;
        duracaoEmSegundos = 0;
        tempoTotalParadaSegundos =
            corridaFinalizarParadaService.tempoTotalParadaSegundos;
      });

      await Future.delayed(Duration(seconds: 3));

      await pegarDurancaoParaCorrida();

      await cancelarTimer();

      setState(() {
        isLoading = false;
        startContarParada = false;
      });
      Navigator.of(context).pop();
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      Navigator.of(context).pop();
      showModalAlertError(e.toString());
    }
  }

  buscarDuaracaoParadaCorrida() async {
    var corridaBuscarDuracaoParadaService =
        Provider.of<CorridaMacanetaBuscarDuracaoParadaService>(
          context,
          listen: false,
        );

    if (corrida.isNotEmpty) {
      if (corrida['status']['id'] == 6) {
        await corridaBuscarDuracaoParadaService.execute();
        if (corridaBuscarDuracaoParadaService.dataInicioParada != null) {
          var quantidade_paradas =
              corridaBuscarDuracaoParadaService.quantidadeParadas;

          setState(() {
            totalParada = quantidade_paradas * valorParadaAdicional;
            valorCorrida = valorCorrida + totalParada;
            startContarParada = true;
            dataInicioParada =
                corridaBuscarDuracaoParadaService.dataInicioParada;
            tempoTotalParadaSegundos =
                corridaBuscarDuracaoParadaService.tempoTotalParadaSegundos;
          });

          await pegarDuracaoEmSegundos();
print('🟨🟨🟨 - 33333 obterValorMinutoEmSegundos');
          var totalSegundos = duracaoEmSegundos + tempoTotalParadaSegundos;

          var minutos = (totalSegundos % 3600) ~/ 60;

          if (minutos > 0) {
            var totalValorPorMinuto = valorMinutoParada * minutos;
            setState(() {
              valorCorrida = valorCorrida + totalValorPorMinuto;
            });
          }

          var converterDinheiroParaReaisService =
              Provider.of<ConverterDinheiroParaReaisService>(
                context,
                listen: false,
              );
          await converterDinheiroParaReaisService.execute(valorCorrida);

          iniciarTimer();
        } else {
          setState(() {
            totalParada =
                corridaBuscarDuracaoParadaService.quantidadeParadas *
                valorParadaAdicional;
          });
          setState(() {
            valorCorrida = valorCorrida + totalParada;
            tempoTotalParadaSegundos =
                corridaBuscarDuracaoParadaService.tempoTotalParadaSegundos;
          });
print('🟨🟨🟨 - 6666 obterValorMinutoEmSegundos');
          var minutos = (tempoTotalParadaSegundos % 3600) ~/ 60;

          if (minutos > 0) {
            var totalValorPorMinuto = valorMinutoParada * minutos;
            setState(() {
              valorCorrida = valorCorrida + totalValorPorMinuto;
            });
          }

          var converterDinheiroParaReaisService =
              Provider.of<ConverterDinheiroParaReaisService>(
                context,
                listen: false,
              );
          await converterDinheiroParaReaisService.execute(valorCorrida);
          await pegarDurancaoParaCorrida();
        }
      }
    }
  }

  pegarDuracaoParadaAtualizado() async {
    var corridaBuscarDuracaoParadaService =
        Provider.of<CorridaMacanetaBuscarDuracaoParadaService>(
          context,
          listen: false,
        );

    await corridaBuscarDuracaoParadaService.execute();

    var totalSegundos =
        corridaBuscarDuracaoParadaService.tempoTotalParadaSegundos;

    if (totalSegundos > 0) {
      var horas = totalSegundos ~/ 3600;
      print('🟨🟨🟨 - 7777 obterValorMinutoEmSegundos');
      var minutos = (totalSegundos % 3600) ~/ 60;
      var segundosRestantes = totalSegundos % 60;

      var texto =
          horas > 0
              ? horas.toString().padLeft(2, '0') +
                  ":" +
                  minutos.toString().padLeft(2, '0') +
                  ":" +
                  segundosRestantes.toString().padLeft(2, '0')
              : minutos.toString().padLeft(2, '0') +
                  ":" +
                  segundosRestantes.toString().padLeft(2, '0');

      setState(() {
        tempoParadoTexto = texto;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    var corridaService = Provider.of<CorridaService>(context, listen: true);
    var converterDinheiroParaReaisService =
        Provider.of<ConverterDinheiroParaReaisService>(context, listen: true);

    return Scaffold(
      backgroundColor: Color.fromARGB(255, 58, 58, 58),
      appBar: AppBar(
        leading: null,
        title: Text("Detalhes", style: TextStyle(fontSize: 17)),
        centerTitle: true,
        backgroundColor: Color.fromARGB(255, 49, 49, 49),
      ),
      body: WillPopScope(
        onWillPop: () async {
          return false;
        },
        child: Material(
          type: MaterialType.transparency,
          child: new SingleChildScrollView(
            child: Container(
              height: MediaQuery.of(context).size.height,
              color: Color.fromARGB(255, 58, 58, 58),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  if (parte == 2 || parte == 3)
                    Container(
                      padding: EdgeInsets.all(15),
                      color: Colors.grey[800],
                      child: Row(
                        children: <Widget>[
                          Text(
                            converterDinheiroParaReaisService.valorConvertido,
                            style: TextStyle(
                              color: Colors.orange,
                              fontWeight: FontWeight.w500,
                              fontSize: 25,
                            ),
                          ),
                          Spacer(),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: <Widget>[
                                  Text(
                                    "Distância : ",
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 14,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                  Text(
                                    distanciaPercorridaCorridaText,
                                    style: TextStyle(
                                      color: Colors.orange,
                                      fontSize: 15,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ],
                              ),
                              Row(
                                children: <Widget>[
                                  Text(
                                    "Duração : ",
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 14,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                  Text(
                                    this.duracao,
                                    style: TextStyle(
                                      color: Colors.orange,
                                      fontSize: 15,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  SizedBox(height: 15),
                  Padding(
                    padding: EdgeInsets.only(left: 15, right: 15),
                    child: Column(
                      children: <Widget>[
                        SizedBox(height: 25),
                        HorizontalSlidableButton(
                          width: double.infinity,
                          height: 70,
                          buttonWidth: 80.0,
                          color: Colors.grey.withOpacity(0.2),
                          buttonColor: Colors.orange,
                          dismissible: false,
                          borderRadius: BorderRadius.circular(6),
                          isRestart: true,
                          label: Center(
                            child: Icon(
                              Icons.arrow_forward_ios,
                              color: Colors.grey[800],
                              size: 30,
                            ),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(''),
                                Text(
                                  etapas,
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 16,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          onChanged: (position) async {
                            if (position == SlidableButtonPosition.end) {
                              if (parte == 2) {
                                await finalizarCorrida();
                              }

                              if (parte == 1) {
                                await inciarCorrida();
                              }

                              if (parte == 0) {
                                await alterarStatusMacaneta();
                              }
                            }

                            if (parte == 3) {
                              showModal();
                            }
                          },
                        ),
                        SizedBox(height: 25),
                        Row(
                          children: <Widget>[
                            Icon(
                              Icons.phone_android,
                              color:
                                  parte == 2 || parte == 3
                                      ? Colors.orange
                                      : Colors.white,
                              size: 20,
                            ),
                            SizedBox(width: 10),
                            Text(
                              corrida.isNotEmpty ? corrida['nome'] : "",
                              style: TextStyle(
                                color:
                                    parte == 2 || parte == 3
                                        ? Colors.orange
                                        : Colors.white,
                                fontWeight: FontWeight.w500,
                                fontSize: 14,
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 15),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            if (parte != 2 && parte != 3)
                              Icon(
                                Icons.person,
                                color: Colors.orange,
                                size: 22,
                              ),
                            if (parte != 2 && parte != 3) SizedBox(width: 10),
                            Container(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  if (parte != 2 && parte != 3)
                                    Container(
                                      child: Text(
                                        "Embarque",
                                        style: TextStyle(
                                          fontWeight: FontWeight.w600,
                                          color: Colors.orange,
                                          fontSize: 15,
                                        ),
                                      ),
                                    ),
                                  Container(
                                    width: parte == 2 || parte == 3 ? 320 : 290,
                                    child: Text(
                                      corrida.isNotEmpty
                                          ? corrida['endereco_partida']
                                          : "",
                                      style: TextStyle(
                                        fontWeight:
                                            parte == 2 && parte == 3
                                                ? FontWeight.bold
                                                : FontWeight.w500,
                                        color: Colors.orange,
                                        fontSize:
                                            parte == 2 || parte == 3 ? 22 : 16,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        parte != 2 && parte != 3
                            ? SizedBox(height: 15)
                            : SizedBox(height: 5),
                        if (parte != 2 && parte != 3)
                          Row(
                            children: <Widget>[
                              Icon(
                                Icons.attach_money,
                                color: Colors.white,
                                size: 19,
                              ),
                              SizedBox(width: 10),
                              Text(
                                "Dinheiro",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w500,
                                  fontSize: 14,
                                ),
                              ),
                            ],
                          ),
                        SizedBox(height: 10),
                        Row(
                          children: <Widget>[
                            Text(
                              "OS",
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 15,
                              ),
                            ),
                            SizedBox(width: 10),
                            Text(
                              corridaService.pedido.isNotEmpty
                                  ? corridaService.pedido['id'].toString()
                                  : "",
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w500,
                                fontSize: 14,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 20),
                  Padding(
                    padding: EdgeInsets.only(left: 15, right: 15),
                    child: Column(
                      children: <Widget>[
                        SizedBox(
                          width: double.infinity,
                          height: 50,
                          child: ElevatedButton(
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => FichaTecnicaScreen(),
                                ),
                              );
                            },
                            style: ButtonStyle(
                              backgroundColor: MaterialStateProperty.all<Color>(
                                Colors.grey.shade700,
                              ),
                              overlayColor:
                                  MaterialStateProperty.resolveWith<Color?>((
                                    Set<MaterialState> states,
                                  ) {
                                    if (states.contains(MaterialState.pressed))
                                      return Colors.orange;
                                    return null;
                                  }),
                            ),
                            child: Text(
                              "Abrir ficha técnica",
                              style: TextStyle(fontSize: 18, color: Colors.white,),
                              
                            ),
                          ),
                        ),
                        SizedBox(height: 15),
                        if (parte == 0 || parte == 1)
                          SizedBox(
                            width: double.infinity,
                            height: 50,
                            child: ElevatedButton(
                              style: ButtonStyle(
                                backgroundColor:
                                    MaterialStateProperty.all<Color>(
                                      Colors.grey.shade700,
                                    ),
                                overlayColor: MaterialStateProperty.resolveWith<
                                  Color?
                                >((Set<MaterialState> states) {
                                  if (states.contains(MaterialState.pressed))
                                    return Colors.orange;
                                  return null;
                                }),
                              ),
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder:
                                        (_) =>
                                            OpcionalCancelamentoMacanetaScreen(),
                                  ),
                                );
                              },
                              child: Text(
                                "Cancelar corrida",
                                style: TextStyle(fontSize: 18, color: Colors.white,),
                              ),
                            ),
                          ),
                        if (corrida.isNotEmpty && corrida['status']['id'] == 6)
                          SizedBox(
                            width: double.infinity,
                            height: 50,
                            child: ElevatedButton(
                              style: ButtonStyle(
                                backgroundColor:
                                    MaterialStateProperty.all<Color>(
                                      startContarParada
                                          ? Colors.red
                                          : Colors.grey.shade700,
                                    ),
                                overlayColor: MaterialStateProperty.resolveWith<
                                  Color?
                                >((Set<MaterialState> states) {
                                  if (states.contains(MaterialState.pressed))
                                    return Colors.orange;
                                  return null;
                                }),
                              ),
                              onPressed: () {
                                if (startContarParada == true) {
                                  finalizarParada();
                                } else {
                                  iniciarParada();
                                }
                              },
                              child: Text(
                                startContarParada
                                    ? "Finalizar parada: " + tempoParadoTexto
                                    : "Iniciar parada: " + tempoParadoTexto,
                                style: TextStyle(fontSize: 18, color: Colors.white,),
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
