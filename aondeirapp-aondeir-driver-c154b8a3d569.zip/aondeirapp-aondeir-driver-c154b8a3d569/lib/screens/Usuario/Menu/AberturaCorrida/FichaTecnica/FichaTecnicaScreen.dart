import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../../service/CorridaService.dart';
import '../../../../../service/UsuarioService.dart';

class FichaTecnicaScreen extends StatefulWidget {
  const FichaTecnicaScreen({super.key});

  @override
  State<FichaTecnicaScreen> createState() => _FichaTecnicaScreenState();
}

class _FichaTecnicaScreenState extends State<FichaTecnicaScreen> {
  @override
  Widget build(BuildContext context) {
    var corridaService = Provider.of<CorridaService>(context, listen: true);
    var usuarioService = Provider.of<UsuarioService>(context, listen: true);
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 58, 58, 58),
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_ios_new,
            color: Colors.white,
            size: 25,
          ),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(
          "Ficha Tecnica",
          style: TextStyle(fontSize: 17),
        ),
        centerTitle: true,
        backgroundColor: Color.fromARGB(255, 49, 49, 49),
      ),
      body: Material(
        type: MaterialType.transparency,
        child: new SingleChildScrollView(
          child: Container(
            color: Color.fromARGB(255, 58, 58, 58),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Container(
                  margin: EdgeInsets.only(top: 15),
                  child: Text(
                    usuarioService.usuario != null ||
                            usuarioService.usuario != "undefined"
                        ? usuarioService.usuario.name
                        : "",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 24,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.only(top: 5),
                  child: Text(
                    usuarioService.usuario != null ||
                            usuarioService.usuario != "undefined"
                        ? usuarioService.usuario.motorista['modelo']
                        : "",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.w300,
                    ),
                  ),
                ),
                if (usuarioService.usuario != null &&
                        usuarioService.usuario.motorista['cor_veiculo'] !=
                            null ||
                    usuarioService.usuario != "undefined" &&
                        usuarioService.usuario.motorista['cor_veiculo'] != null)
                  Container(
                    margin: EdgeInsets.only(top: 5),
                    child: Text(
                      usuarioService.usuario.motorista['cor_veiculo'],
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.w300,
                      ),
                    ),
                  ),
                Container(
                  margin: EdgeInsets.only(top: 5),
                  child: Text(
                    usuarioService.usuario != null ||
                            usuarioService.usuario != "undefined"
                        ? "Placa: " + usuarioService.usuario.motorista['placa']
                        : "",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.w300,
                    ),
                  ),
                ),
                SizedBox(height: 25),
                Container(
                  margin: EdgeInsets.symmetric(horizontal: 15),
                  padding: EdgeInsets.symmetric(horizontal: 15, vertical: 15),
                  decoration: BoxDecoration(
                      color: Colors.grey.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(8)),
                  child: Column(
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          Icon(
                            Icons.person_pin_rounded,
                            color: Colors.white,
                            size: 40,
                          ),
                          SizedBox(width: 8),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              RichText(
                                text: TextSpan(
                                  text: 'CPF motorista: ',
                                  children: <TextSpan>[
                                    TextSpan(
                                      text: usuarioService.usuario != null ||
                                              usuarioService.usuario !=
                                                  "undefined"
                                          ? usuarioService
                                              .usuario.motorista['cpf']
                                          : "",
                                      style: TextStyle(
                                        color: Colors.orange,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(height: 3),
                              RichText(
                                text: TextSpan(
                                  text: 'Número CNH: ',
                                  children: <TextSpan>[
                                    TextSpan(
                                      text: usuarioService.usuario != null ||
                                              usuarioService.usuario !=
                                                  "undefined"
                                          ? usuarioService
                                              .usuario.motorista['numero_cnh']
                                          : "",
                                      style: TextStyle(
                                        color: Colors.orange,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          )
                        ],
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 15),
                Container(
                  margin: EdgeInsets.symmetric(horizontal: 15),
                  padding: EdgeInsets.symmetric(horizontal: 15, vertical: 15),
                  decoration: BoxDecoration(
                      color: Colors.grey.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(8)),
                  child: Column(
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          Icon(
                            Icons.person,
                            color: Colors.white,
                            size: 40,
                          ),
                          SizedBox(width: 8),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              RichText(
                                text: TextSpan(
                                  text: 'Passageiro: ',
                                  children: <TextSpan>[
                                    TextSpan(
                                      text: corridaService.corrida.isNotEmpty
                                          ? corridaService.corrida['nome']
                                          : "",
                                      style: TextStyle(
                                        color: Colors.orange,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(height: 3),
                              RichText(
                                text: TextSpan(
                                  text: 'Telefone: ',
                                  children: <TextSpan>[
                                    TextSpan(
                                      text: corridaService.corrida.isNotEmpty
                                          ? corridaService
                                              .corrida['telefone_contato']
                                          : "",
                                      style: TextStyle(
                                        color: Colors.orange,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          )
                        ],
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 15),
                Container(
                  margin: EdgeInsets.symmetric(horizontal: 15),
                  padding: EdgeInsets.symmetric(horizontal: 15, vertical: 15),
                  decoration: BoxDecoration(
                      color: Colors.grey.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(8)),
                  child: Column(
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          Icon(
                            Icons.pin_drop,
                            color: Colors.white,
                            size: 40,
                          ),
                          SizedBox(width: 8),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              RichText(
                                text: TextSpan(
                                  text: 'OS: ',
                                  children: <TextSpan>[
                                    TextSpan(
                                      text: corridaService.pedido.isNotEmpty
                                          ? corridaService.pedido["id"]
                                              .toString()
                                          : "",
                                      style: TextStyle(
                                        color: Colors.orange,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(height: 5),
                              Container(
                                width: 260,
                                child: RichText(
                                  text: TextSpan(
                                    text: 'Partida: ',
                                    children: <TextSpan>[
                                      TextSpan(
                                        text: corridaService.corrida.isNotEmpty
                                            ? corridaService
                                                .corrida['endereco_partida']
                                            : "",
                                        style: TextStyle(
                                          color: Colors.orange,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              SizedBox(height: 5),
                              Container(
                                width: 260,
                                child: RichText(
                                  text: TextSpan(
                                    text: 'Destino: ',
                                    children: <TextSpan>[
                                      TextSpan(
                                        text: corridaService.corrida.isNotEmpty
                                            ? corridaService
                                                .corrida['endereco_destino']
                                            : "",
                                        style: TextStyle(
                                          color: Colors.orange,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          )
                        ],
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 50,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
