import 'package:aondeir_motorista/service/UsuarioService.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../../service/CorridaService.dart';
import '../../../../../service/toque/ToqueService.dart';
import '../../../Home/Corrida/DetalhesCorridaScreen.dart';

class MensagemScreen extends StatefulWidget {
  const MensagemScreen({super.key});

  @override
  State<MensagemScreen> createState() => _MensagemScreenState();
}

class _MensagemScreenState extends State<MensagemScreen> {
  var mensagemText = "";
  List<String> listaMensagemPreProntas = [];
  TextEditingController _textEditingController = TextEditingController();

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      var corridaService = Provider.of<CorridaService>(
        this.context,
        listen: false,
      );

      corridaService.modalAlerta = true;
      corridaService.save();

      corridaService.mensagens.clear();

      await corridaService.pegarCorridaAndamento();

      await corridaService.pegarMensagens(corridaService.corrida['id']);

      if (corridaService.mensagens.length == 0) {
        setState(() {
          listaMensagemPreProntas = [
            "chego em 10 min",
            "Estou a caminho, favor aguardar",
            "Me envie um ponto de referência",
            "Pode confirmar seu endereço?",
            "Aguarde, já estou a caminho!",
          ];
        });
      }
      
    });
  }

  enviarMensagem() async {
    var corridaService = Provider.of<CorridaService>(context, listen: false);
    var toqueService = Provider.of<ToqueService>(context, listen: false);

    if (_textEditingController.text.isNotEmpty &&
        corridaService.corrida.isNotEmpty) {
      toqueService.execute(
        "toques/toque_clique_no_botao_de_enviar_mensagem_motorista_e_passageiro.mp3",
      );
      _textEditingController.text = "";
      await corridaService.enviarMensagem(
        mensagemText,
        corridaService.corrida['usuario']['id'].toString(),
        corridaService.corrida['id'].toString(),
      );

      setState(() {
        mensagemText = "";
        listaMensagemPreProntas = [];
      });

      _textEditingController.text = "";
    }
  }

  enviarMensagemPrePronta() async {
    var corridaService = Provider.of<CorridaService>(context, listen: false);
    var toqueService = Provider.of<ToqueService>(context, listen: false);

    if (mensagemText.isNotEmpty && corridaService.corrida.isNotEmpty) {
      toqueService.execute(
        "toques/toque_clique_no_botao_de_enviar_mensagem_motorista_e_passageiro.mp3",
      );
      var text = mensagemText;
      setState(() {
        mensagemText = "";
        listaMensagemPreProntas = [];
      });
      await corridaService.enviarMensagem(
        text,
        corridaService.corrida['usuario']['id'].toString(),
        corridaService.corrida['id'].toString(),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    var corridaService = Provider.of<CorridaService>(context, listen: true);
    var usuarioService = Provider.of<UsuarioService>(context, listen: true);
    final mediaQuery = MediaQuery.of(context);
    final keyboardHeight = mediaQuery.viewInsets.bottom;
    
    return MediaQuery(
      data: MediaQuery.of(context).copyWith(textScaler: TextScaler.linear(1.0)),
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          leading: IconButton(
            icon: Icon(Icons.arrow_back_ios_new, color: Colors.white, size: 25),
            onPressed:
                () => {
                  corridaService.mensagens.clear(),
                  corridaService.save(),
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => DetalhesCorridaScreen()),
                  ),
                },
          ),
          title: Text(
            corridaService.corrida.isNotEmpty
                ? corridaService.corrida['usuario']['name']
                : "",
            style: TextStyle(fontSize: 17, overflow: TextOverflow.ellipsis),
          ),
          centerTitle: true,
          backgroundColor: Color.fromARGB(255, 49, 49, 49),
        ),
        body: WillPopScope(
          onWillPop: () async {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => DetalhesCorridaScreen()),
            );

            return false;
          },
          child: SafeArea(
                child: Column(
                  children: <Widget>[
                // Área de mensagens - expande para ocupar espaço disponível
                Expanded(
                  child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Colors.white,
                      ),
                      child: Padding(
                        padding: EdgeInsets.only(top: 15, left: 15, right: 15),
                          child: SingleChildScrollView(
                            reverse: true,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: <Widget>[
                                if (corridaService.mensagens.length == 0)
                                  for (var msg in this.listaMensagemPreProntas)
                                    GestureDetector(
                                      onTap: () {
                                        setState(() {
                                          mensagemText = msg;
                                        });
                                        enviarMensagemPrePronta();
                                      },
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                        children: <Widget>[
                                          Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.end,
                                            children: <Widget>[
                                              IntrinsicWidth(
                                                child: Container(
                                                  constraints: BoxConstraints(
                                                    maxWidth:
                                                        MediaQuery.of(
                                                          context,
                                                        ).size.width /
                                                        1.3,
                                                  ),
                                                  margin: EdgeInsets.symmetric(
                                                    vertical: 4,
                                                    horizontal: 0,
                                                  ),
                                                  padding: EdgeInsets.symmetric(
                                                    vertical: 10,
                                                    horizontal: 10,
                                                  ),
                                                  decoration: BoxDecoration(
                                                    color: Colors.white,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                          10,
                                                        ),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: Colors.grey
                                                            .withOpacity(0.5),
                                                        spreadRadius: 2,
                                                        blurRadius: 4,
                                                        offset: Offset(0, 7),
                                                      ),
                                                    ],
                                                  ),
                                                  child: Text(
                                                    msg,
                                                    style: TextStyle(
                                                      color: Colors.grey[800],
                                                      fontWeight:
                                                          FontWeight.w400,
                                                      fontSize: 16,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                if (corridaService.mensagens.length > 0)
                                  for (var mensagem in corridaService.mensagens)
                                    mensagem.remetente['id'] ==
                                            usuarioService.usuario.id
                                        ? Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.end,
                                          children: <Widget>[
                                            Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.end,
                                              children: <Widget>[
                                                IntrinsicWidth(
                                                  child: Container(
                                                    constraints: BoxConstraints(
                                                      maxWidth:
                                                          MediaQuery.of(
                                                            context,
                                                          ).size.width /
                                                          1.3,
                                                    ),
                                                    margin:
                                                        EdgeInsets.symmetric(
                                                          vertical: 4,
                                                          horizontal: 0,
                                                        ),
                                                    padding:
                                                        EdgeInsets.symmetric(
                                                          vertical: 10,
                                                          horizontal: 10,
                                                        ),
                                                    decoration: BoxDecoration(
                                                      color: Colors.orange[200],
                                                      borderRadius:
                                                          BorderRadius.only(
                                                            topLeft:
                                                                Radius.circular(
                                                                  20,
                                                                ),
                                                            bottomLeft:
                                                                Radius.circular(
                                                                  20,
                                                                ),
                                                            bottomRight:
                                                                Radius.circular(
                                                                  0,
                                                                ),
                                                            topRight:
                                                                Radius.circular(
                                                                  20,
                                                                ),
                                                          ),
                                                    ),
                                                    child: Text(
                                                      mensagem.mensagem,
                                                      style: TextStyle(
                                                        color: Colors.grey[800],
                                                        fontWeight:
                                                            FontWeight.w400,
                                                        fontSize: 16,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Container(
                                              margin: EdgeInsets.only(left: 5),
                                              width: 28,
                                              child: ClipRRect(
                                                borderRadius:
                                                    BorderRadius.circular(120),
                                                child: Image.asset(
                                                  "assets/notPerfil.png",
                                                ),
                                              ),
                                            ),
                                            SizedBox(height: 10),
                                          ],
                                        )
                                        : Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: <Widget>[
                                            Container(
                                              margin: EdgeInsets.only(right: 5),
                                              width: 28,
                                              child: ClipRRect(
                                                borderRadius:
                                                    BorderRadius.circular(120),
                                                child: Image.asset(
                                                  "assets/notPerfil.png",
                                                ),
                                              ),
                                            ),
                                            Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: <Widget>[
                                                IntrinsicWidth(
                                                  child: Container(
                                                    constraints: BoxConstraints(
                                                      maxWidth:
                                                          MediaQuery.of(
                                                            context,
                                                          ).size.width /
                                                          1.3,
                                                    ),
                                                    margin:
                                                        EdgeInsets.symmetric(
                                                          vertical: 4,
                                                          horizontal: 0,
                                                        ),
                                                    padding:
                                                        EdgeInsets.symmetric(
                                                          vertical: 10,
                                                          horizontal: 10,
                                                        ),
                                                    decoration: BoxDecoration(
                                                      color: Colors.orange,
                                                      borderRadius:
                                                          BorderRadius.only(
                                                            topLeft:
                                                                Radius.circular(
                                                                  20,
                                                                ),
                                                            bottomLeft:
                                                                Radius.circular(
                                                                  0,
                                                                ),
                                                            bottomRight:
                                                                Radius.circular(
                                                                  20,
                                                                ),
                                                            topRight:
                                                                Radius.circular(
                                                                  20,
                                                                ),
                                                          ),
                                                    ),
                                                    child: Text(
                                                      mensagem.mensagem,
                                                      style: TextStyle(
                                                        color: Colors.white,
                                                        fontWeight:
                                                            FontWeight.w400,
                                                        fontSize: 16,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                SizedBox(height: 10),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                // Campo de texto fixo na parte inferior
                        Container(
                          color: Colors.grey[300],
                  padding: EdgeInsets.only(
                    left: 15,
                    right: 15,
                    top: 10,
                    bottom: 10 + keyboardHeight, // Adiciona padding quando teclado está aberto
                  ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: <Widget>[
                              Expanded(
                                child: Padding(
                          padding: EdgeInsets.symmetric(horizontal: 5),
                                  child: TextField(
                                    controller: _textEditingController,
                                    onChanged: (String value) async {
                                      setState(() {
                                        mensagemText = value;
                                      });
                                    },
                                    decoration: InputDecoration(
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(25),
                              ),
                                      filled: true,
                                      fillColor: Colors.white,
                                      hintText: "Digite sua mensagem...",
                              contentPadding: EdgeInsets.symmetric(
                                horizontal: 20,
                                vertical: 10,
                              ),
                                    ),
                                  ),
                                ),
                              ),
                              SizedBox(width: 10),
                              GestureDetector(
                                onTap: () {
                                  enviarMensagem();
                                },
                                child: Container(
                                  width: 50,
                                  height: 50,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(25),
                                  ),
                                  child: Icon(
                                    Icons.send,
                                    color: Colors.grey[800],
                                    size: 30,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
            ),
          ),
        ),
      ),
    );
  }
}
