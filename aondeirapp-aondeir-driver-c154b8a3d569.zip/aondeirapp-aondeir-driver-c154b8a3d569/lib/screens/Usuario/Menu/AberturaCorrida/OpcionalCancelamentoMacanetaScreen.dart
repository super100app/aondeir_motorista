import 'package:aondeir_motorista/styles/app_colors.dart';
import 'package:aondeir_motorista/screens/Usuario/BottomNavigationBar/NavigationScreen.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../service/CorridaService.dart';

class OpcionalCancelamentoMacanetaScreen extends StatefulWidget {
  const OpcionalCancelamentoMacanetaScreen({super.key});

  @override
  State<OpcionalCancelamentoMacanetaScreen> createState() =>
      _OpcionalCancelamentoMacanetaScreenState();
}

class _OpcionalCancelamentoMacanetaScreenState
    extends State<OpcionalCancelamentoMacanetaScreen> {
  var motivoId = null;
  var isLoading = false;
  var isOptionSelected = false;
  var motivoDescricao = "";
  var corridaAtual = {};

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      Provider.of<CorridaService>(context, listen: false);
    });
  }

  @override
  void dispose() {
    super.dispose();
  }

  cancelarCorrida() async {
    setState(() {
      isLoading = true;
    });

    await showLoader();
    await Future.delayed(Duration(seconds: 1));
    var corridaService = Provider.of<CorridaService>(context, listen: false);
    corridaService.formCorridaMacanetaMotivoCancelamento = {
      "motivoId": motivoId,
      "motivoDescricao": motivoDescricao
    };
    await corridaService.save();

    var resp = await corridaService.cancelarCorridaMacaneta();
    if (resp == true) {
      corridaService.corrida = {};
      corridaService.save();
      Navigator.of(context).pop();
      setState(() {
        isLoading = false;
      });
      await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => NavigationScreen(),
        ),
      );
    }
  }

  void _showDialog() {
    showDialog<String>(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        contentPadding: EdgeInsets.all(15),
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(20.0))),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Text(
              "Outros",
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w700,
              ),
            ),
            Text(
              "Aqui você pode descrever o motivo do cancelamento da corrida!",
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w500,
              ),
            ),
            SizedBox(height: 15),
            Container(
              padding: EdgeInsets.only(left: 15, right: 15, top: 10),
              child: TextField(
                onChanged: (value) {
                  setState(() {
                    motivoId = '8';
                    motivoDescricao = value;
                  });
                },
                decoration: InputDecoration(
                  prefixIcon: Icon(
                    Icons.article_outlined,
                    color: Color(0xFF161616),
                    size: 20,
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(28),
                    borderSide: BorderSide(
                      color: Color(0xFFF2F2F2),
                    ),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(28),
                    borderSide: BorderSide(
                      color: Color(0xFFF2F2F2),
                    ),
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(28),
                    borderSide: BorderSide(
                      color: Color(0xFFF2F2F2),
                    ),
                  ),
                  filled: true,
                  fillColor: Color(0xFFF2F2F2),
                  contentPadding: EdgeInsets.all(0),
                  hintText: "Insira a descrição do motivo",
                  hintStyle: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                    color: Colors.black,
                  ),
                ),
              ),
            ),
            SizedBox(height: 15),
            Container(
              width: double.infinity,
              height: 45,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  backgroundColor: AppColors.buttonSecondary,
                  shadowColor: Colors.transparent,
                ),
                onPressed: () {
                  cancelarCorrida();
                },
                child: Text("Confirmar"),
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Container(
              width: double.infinity,
              height: 45,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                    side: BorderSide(
                      color: Colors.orange,
                    ),
                  ),
                  shadowColor: Colors.transparent,
                  backgroundColor: Colors.transparent,
                ),
                onPressed: () {
                  setState(() {
                    motivoId = null;
                    motivoDescricao = "";
                    isOptionSelected = false;
                  });
                  Navigator.of(context).pop();
                },
                child: Text(
                  "Cancelar",
                  style: TextStyle(
                    color: Colors.orange,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  showLoader() {
    if (isLoading == true) {
      showDialog<String>(
        barrierDismissible: false,
        context: context,
        builder: (BuildContext context) => AlertDialog(
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(12.0))),
          title: Container(
            child: Text(
              'Cancelando corrida...',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 13,
                color: Colors.grey[700],
              ),
            ),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(),
              SizedBox(height: 16),
              Text('Carregando...'),
            ],
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 58, 58, 58),
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_ios_new,
            color: Colors.white,
            size: 25,
          ),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(
          "Motivos do cancelamento.",
          style: TextStyle(fontSize: 17),
        ),
        centerTitle: true,
        backgroundColor: Color.fromARGB(255, 49, 49, 49),
      ),
      body: Material(
        type: MaterialType.transparency,
        child: new SingleChildScrollView(
          child: Container(
            color: Color.fromARGB(255, 58, 58, 58),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Container(
                  margin: EdgeInsets.only(top: 15),
                  child: Text(
                    "Selecione uma opção do motivo do cancelamento:",
                    style: TextStyle(
                      color: Color(0xFF979797),
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.symmetric(horizontal: 15),
                  padding: EdgeInsets.symmetric(horizontal: 15, vertical: 15),
                  child: Column(
                    children: <Widget>[
                      GestureDetector(
                        onTap: () {
                          setState(() {
                            motivoId = "5";
                            motivoDescricao = 'Acidente/Carro quebrado';
                            isOptionSelected = true;
                          });
                        },
                        child: Row(
                          children: <Widget>[
                            Expanded(
                              child: Text(
                                "Acidente/Carro quebrado",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w500,
                                  fontSize: 14,
                                ),
                              ),
                            ),
                            Radio(
                              fillColor: MaterialStateColor.resolveWith(
                                  (states) => Colors.white),
                              value: "5",
                              groupValue: motivoId,
                              onChanged: (value) {
                                setState(() {
                                  motivoId = value;
                                  motivoDescricao = 'Motorista não está vindo';
                                  isOptionSelected = true;
                                });
                              },
                            ),
                          ],
                        ),
                      ),
                      GestureDetector(
                        onTap: () {
                          setState(() {
                            motivoId = "6";
                            motivoDescricao = 'Difícil acesso';
                            isOptionSelected = true;
                          });
                        },
                        child: Row(
                          children: <Widget>[
                            Expanded(
                              child: Text(
                                "Difícil acesso",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w500,
                                  fontSize: 14,
                                ),
                              ),
                            ),
                            Radio(
                              fillColor: MaterialStateColor.resolveWith(
                                  (states) => Colors.white),
                              value: "6",
                              groupValue: motivoId,
                              onChanged: (value) {
                                setState(() {
                                  motivoId = value;
                                  motivoDescricao = 'Difícil acesso';
                                  isOptionSelected = true;
                                });
                              },
                            ),
                          ],
                        ),
                      ),
                      GestureDetector(
                        onTap: () {
                          setState(() {
                            motivoId = "7";
                            motivoDescricao = 'Passageiro não entrou';
                            isOptionSelected = true;
                          });
                        },
                        child: Row(
                          children: <Widget>[
                            Expanded(
                              child: Text(
                                "Passageiro não entrou",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w500,
                                  fontSize: 14,
                                ),
                              ),
                            ),
                            Radio(
                              fillColor: MaterialStateColor.resolveWith(
                                  (states) => Colors.white),
                              value: "7",
                              groupValue: motivoId,
                              onChanged: (value) {
                                setState(() {
                                  motivoId = value;
                                  motivoDescricao = 'Passageiro não entrou';
                                  isOptionSelected = true;
                                });
                              },
                            ),
                          ],
                        ),
                      ),
                      GestureDetector(
                        onTap: () {
                          setState(() {
                            motivoId = "8";
                            motivoDescricao = 'Outros';
                            isOptionSelected = true;
                          });
                          _showDialog();
                        },
                        child: Row(
                          children: <Widget>[
                            Expanded(
                              child: Text(
                                "Outros",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w500,
                                  fontSize: 14,
                                ),
                              ),
                            ),
                            Radio(
                              fillColor: MaterialStateColor.resolveWith(
                                  (states) => Colors.white),
                              value: "8",
                              groupValue: motivoId,
                              onChanged: (value) {
                                setState(() {
                                  motivoId = value;
                                  motivoDescricao = 'Outros';
                                  isOptionSelected = false;
                                });
                                _showDialog();
                              },
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 15),
                SizedBox(
                  height: 50,
                ),
                Container(
                    margin: EdgeInsets.symmetric(horizontal: 15),
                    padding: EdgeInsets.symmetric(horizontal: 15, vertical: 15),
                    child: Column(children: <Widget>[
                      SizedBox(
                        width: double.infinity,
                        height: 62,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            elevation: 0,
                            shadowColor: Colors.transparent,
                            backgroundColor: isOptionSelected == false
                                ? Color.fromARGB(255, 206, 206, 205)
                                : Color.fromARGB(255, 255, 152, 0),
                            foregroundColor: isOptionSelected == false
                                ? const Color.fromARGB(255, 211, 211, 210)
                                : Colors.orange,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                              side: isOptionSelected == false
                                  ? BorderSide(
                                      color: Color.fromARGB(255, 214, 214, 213))
                                  : BorderSide(color: Color(0xFFFEC530)),
                            ),
                            minimumSize: Size(100, 40),
                          ),
                          onPressed: () {
                            isOptionSelected == true ? cancelarCorrida() : "";
                          },
                          child: Text(
                            "Confirmar",
                            style: TextStyle(
                              fontSize: 20,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                    ])),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
