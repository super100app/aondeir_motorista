import 'package:aondeir_motorista/screens/Usuario/Menu/HistoricoCorridas/DetalhesHistoricoScreen.dart';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import 'package:intl/date_symbol_data_local.dart';

import '../../../../service/CorridaService.dart';

class HistoricoCorridasMenuScreen extends StatefulWidget {
  const HistoricoCorridasMenuScreen({super.key});

  @override
  State<HistoricoCorridasMenuScreen> createState() =>
      _HistoricoCorridasMenuScreenState();
}

class Mes {
  final int id;
  final String nome;

  Mes(this.id, this.nome);
}

class Anos {
  final String nome;

  Anos(this.nome);
}

class _HistoricoCorridasMenuScreenState
    extends State<HistoricoCorridasMenuScreen> {
  var mesSelecionado;
  var anoSelecionado;
  var dataInicio = "";
  var dataFim = "";
  var dataFiltroTexto = "";
  List<Mes> meses = [
    Mes(1, 'Janeiro'),
    Mes(2, 'Fevereiro'),
    Mes(3, 'Março'),
    Mes(4, 'Abril'),
    Mes(5, 'Maio'),
    Mes(6, 'Junho'),
    Mes(7, 'Julho'),
    Mes(8, 'Agosto'),
    Mes(9, 'Setembro'),
    Mes(10, 'Outubro'),
    Mes(11, 'Novembro'),
    Mes(12, 'Dezembro')
  ];
  List<Anos> anos = [
    Anos('2023'),
    Anos('2024'),
    Anos('2025'),
    Anos('2026'),
    Anos('2027'),
    Anos('2028'),
    Anos('2029'),
    Anos('2030'),
    Anos('2031'),
    Anos('2032'),
    Anos('2033'),
    Anos('2034')
  ];

  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      await initializeDateFormatting('pt_BR', null);

      await obterAnoAtual();
      await obterMesAtual();
      await obterDataHoje();
      await pegarCorridas();
    });
  }

  obterAnoAtual() async {
    int anoAtual = DateTime.now().year;
    setState(() {
      anoSelecionado = anoAtual.toString();
    });

    await pegarCorridas();
  }

  obterMesAtual() async {
    DateTime dataAtual = DateTime.now();
    int mesAtual = dataAtual.month;

    DateTime dataInicioMes = DateTime(int.parse(anoSelecionado), mesAtual, 1);

    DateTime ultimoDiaMes =
        DateTime(int.parse(anoSelecionado), mesAtual + 1, 0);

    String dataFormatadaDataInicio =
        DateFormat('yyyy-MM-dd', 'pt_BR').format(dataInicioMes);

    String dataFormatadaUltimoDia =
        DateFormat('yyyy-MM-dd', 'pt_BR').format(ultimoDiaMes);

    setState(() {
      mesSelecionado = mesAtual.toString();
      dataInicio = dataFormatadaDataInicio;
      dataFim = dataFormatadaUltimoDia;
    });

    await pegarCorridas();
  }

  obterDataHoje() async {
    await handleDataSelecionada();
  }

  handleDataSelecionada() async {
    DateTime dataInicioMes =
        DateTime(int.parse(anoSelecionado), int.parse(mesSelecionado), 1);
    DateTime ultimoDiaMes =
        DateTime(int.parse(anoSelecionado), int.parse(mesSelecionado) + 1, 0);

    String dataFormatadaDataInicio =
        DateFormat('yyyy-MM-dd', 'pt_BR').format(dataInicioMes);
    String dataFormatadaUltimoDia =
        DateFormat('yyyy-MM-dd', 'pt_BR').format(ultimoDiaMes);

    String dataFormatadaDataInicioTexto =
        DateFormat('dd MMM ', 'pt_BR').format(dataInicioMes);

    String dataFormatadaUltimoDiaTexto =
        DateFormat('dd MMM yyyy', 'pt_BR').format(ultimoDiaMes);

    setState(() {
      dataInicio = dataFormatadaDataInicio;
      dataFim = dataFormatadaUltimoDia;
      dataFiltroTexto =
          dataFormatadaDataInicioTexto + " até " + dataFormatadaUltimoDiaTexto;
    });

    await pegarCorridas();
  }

  pegarCorridas() async {
    var corridaService = Provider.of<CorridaService>(context, listen: false);
    corridaService.dataInicio = this.dataInicio;
    corridaService.dataFim = this.dataFim;
    await corridaService.save();
    await corridaService.pegarCorridas();
  }

  converterData(dataOriginal) {
    DateTime data = DateTime.parse(dataOriginal);

    String dataFormatada = DateFormat('dd MMMM yyyy', 'pt_BR').format(data);

    return dataFormatada;
  }

  converterDataHora(dataOriginal) {
    DateTime data = DateTime.parse(dataOriginal);

    String horaFormatada = DateFormat('kk:mm').format(data);

    return horaFormatada;
  }

  @override
  Widget build(BuildContext context) {
    var corridaService = Provider.of<CorridaService>(context, listen: true);

    return MediaQuery(
      data: MediaQuery.of(context).copyWith(textScaler: TextScaler.linear(1.0)),
      child:Scaffold(
      backgroundColor: Color.fromARGB(255, 58, 58, 58),
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_ios_new,
            color: Colors.white,
            size: 25,
          ),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(
          "Históricos de corridas",
          style: TextStyle(fontSize: 17),
        ),
        centerTitle: true,
        backgroundColor: Color.fromARGB(255, 49, 49, 49),
      ),
      body: Material(
        type: MaterialType.transparency,
        child: new SingleChildScrollView(
          child: Container(
            color: Color.fromARGB(255, 58, 58, 58),
            margin: EdgeInsets.all(15),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    SizedBox(width: 20),
                    SizedBox(
                      width: 169,
                      child: DropdownButton(
                        isExpanded: true,
                        value: mesSelecionado,
                        onChanged: (value) async {
                          setState(() {
                            mesSelecionado = value;
                          });
                          await handleDataSelecionada();
                        },
                        dropdownColor: Color.fromARGB(255, 58, 58, 58),
                        items: [
                          DropdownMenuItem<String>(
                            value: null,
                            child: Text("Mês",
                                style: TextStyle(
                                  color: Color.fromARGB(255, 136, 129, 129),
                                )),
                          ),
                          ...meses.map((mes) {
                            return DropdownMenuItem<String>(
                              value: mes.id.toString(),
                              child: Text(
                                mes.nome,
                                style: TextStyle(
                                  color: Colors.white,
                                ),
                              ),
                            );
                          }).toList(),
                        ],
                      ),
                    ),
                    SizedBox(width: 15),
                    SizedBox(
                      width: 169,
                      child: DropdownButton(
                        isExpanded: true,
                        value: anoSelecionado,
                        onChanged: (value) async {
                          setState(() {
                            anoSelecionado = value;
                          });
                          await handleDataSelecionada();
                        },
                        dropdownColor: Color.fromARGB(255, 58, 58, 58),
                        items: [
                          ...anos.map((ano) {
                            return DropdownMenuItem<String>(
                              value: ano.nome,
                              child: Text(
                                ano.nome,
                                style: TextStyle(
                                  color: Colors.white,
                                ),
                              ),
                            );
                          }).toList(),
                        ],
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 10),
                Row(
                  children: [
                    SizedBox(width: 15),
                    Text(
                      dataFiltroTexto,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
                SingleChildScrollView(
                  child: Column(
                    children: <Widget>[
                      SizedBox(height: 15),
                      for (var corrida in corridaService.corridasHitorico)
                        InkWell(
                          onTap: () async {
                            corridaService.corridaSelecionadaDetalhes = corrida;
                            await corridaService.save();
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => DetalhesHistoricoScreen(
                                  corrida: corrida,
                                ),
                              ),
                            );
                          },
                          child: Container(
                            margin: EdgeInsets.only(
                                left: 15, right: 15, bottom: 15),
                            padding: EdgeInsets.all(15),
                            decoration: BoxDecoration(
                              border: Border.all(
                                color: Color.fromARGB(255, 49, 49, 49),
                              ),
                              borderRadius: BorderRadius.circular(10),
                              color: Color.fromARGB(255, 49, 49, 49),
                            ),
                            child: Row(
                              children: <Widget>[
                                Column(
                                  children: <Widget>[
                                    Text(
                                      corrida.data_finalizado != null
                                          ? converterData(
                                              corrida.data_finalizado)
                                          : "",
                                      style: TextStyle(
                                        color: Colors.orange,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 13,
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(width: 15),
                                Flexible(
                                  child: Container(
                                    child: Text(
                                      corrida.endereco_partida.toString(),
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 14,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      SizedBox(height: 15),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    ));
  }
}
