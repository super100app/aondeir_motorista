import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../../../models/Corrida.dart';

class DetalhesHistoricoScreen extends StatefulWidget {
  final Corrida corrida;
  const DetalhesHistoricoScreen({super.key, required this.corrida});

  @override
  State<DetalhesHistoricoScreen> createState() =>
      _DetalhesHistoricoScreenState();
}

class _DetalhesHistoricoScreenState extends State<DetalhesHistoricoScreen> {
  converterData(dataOriginal) {
    DateTime data = DateTime.parse(dataOriginal);

    String dataFormatada = DateFormat('dd MMMM yyyy', 'pt_BR').format(data);

    return dataFormatada;
  }

  converterParaDinheiro(valor) {
    var valorConvertido = "R\$ 0,0";
    var formatador = NumberFormat.currency(locale: 'pt_BR', symbol: 'R\$');
    valorConvertido = formatador.format(double.parse(valor));

    return valorConvertido;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 58, 58, 58),
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_ios_new,
            color: Colors.white,
            size: 25,
          ),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(
          "Detalhes da corrida",
          style: TextStyle(fontSize: 17),
        ),
        centerTitle: true,
        backgroundColor: Color.fromARGB(255, 49, 49, 49),
      ),
      body: Padding(
        padding: EdgeInsets.only(left: 15, top: 35, right: 15),
        child: Material(
          type: MaterialType.transparency,
          child: new SingleChildScrollView(
            child: Container(
              color: Color.fromARGB(255, 58, 58, 58),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Container(
                    padding: EdgeInsets.all(15),
                    width: double.infinity,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        color: Colors.grey[700]),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          this.widget.corrida.endereco_partida.toString(),
                          style: TextStyle(
                            color: Colors.orange,
                            fontSize: 20,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        SizedBox(height: 15),
                        Text(
                          "DATA",
                          style: TextStyle(
                            color: Colors.grey[300],
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        Text(
                          converterData(this.widget.corrida.data_finalizado),
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                        SizedBox(height: 15),
                        Text(
                          "Passageiro:",
                          style: TextStyle(
                            color: Colors.grey[300],
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        Text(
                          this.widget.corrida.nome.toString(),
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                        SizedBox(height: 15),
                        Text(
                          "OBSERVAÇÃO:",
                          style: TextStyle(
                            color: Colors.grey[300],
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        Text(
                          this.widget.corrida.complemento_partida != null
                              ? this
                                  .widget
                                  .corrida
                                  .complemento_partida
                                  .toString()
                              : "Sem observações",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                        SizedBox(height: 15),
                        Text(
                          "DESTINO:",
                          style: TextStyle(
                            color: Colors.grey[300],
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        Text(
                          this.widget.corrida.endereco_destino.toString(),
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                        SizedBox(height: 15),
                        Text(
                          "FINALIZADA EM:",
                          style: TextStyle(
                            color: Colors.grey[300],
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        Text(
                          this.widget.corrida.endereco_finalizacao.toString(),
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                        SizedBox(height: 15),
                        Text(
                          "TIPO DE PAGAMENTO:",
                          style: TextStyle(
                            color: Colors.grey[300],
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        Text(
                          this.widget.corrida.metodo_pagamento.toString(),
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                        SizedBox(height: 15),
                        Text(
                          "VALOR TOTAL:",
                          style: TextStyle(
                            color: Colors.grey[300],
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        Text(
                          converterParaDinheiro(
                              this.widget.corrida.valor_corrida),
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                        SizedBox(height: 15),
                        Text(
                          "SITUAÇÃO:",
                          style: TextStyle(
                            color: Colors.grey[300],
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        Text(
                          "Finalizada",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                        SizedBox(height: 15),
                        Text(
                          "Distância corrida:",
                          style: TextStyle(
                            color: Colors.grey[300],
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        Text(
                          this.widget.corrida.distancia_percorrida_metros! >
                                  1000
                              ? (this
                                              .widget
                                              .corrida
                                              .distancia_percorrida_metros! /
                                          1000)
                                      .toStringAsFixed(1) +
                                  ' Km'
                              : this
                                      .widget
                                      .corrida
                                      .distancia_percorrida_metros!
                                      .toString() +
                                  " Metros",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                        SizedBox(height: 15),
                        Text(
                          "Duração da corrida:",
                          style: TextStyle(
                            color: Colors.grey[300],
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        Text(
                          (this.widget.corrida.duracao_segundos! / 60)
                                  .floor()
                                  .toString() +
                              " Min",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                        SizedBox(height: 15),
                        Text(
                          "Categoria da corrida:",
                          style: TextStyle(
                            color: Colors.grey[300],
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        Text(
                          this.widget.corrida.categoria['name'].toString(),
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                        SizedBox(height: 15),
                        Text(
                          "Tarifa e imposto:",
                          style: TextStyle(
                            color: Colors.grey[300],
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        Text(
                          converterParaDinheiro(
                              this.widget.corrida.valor_taxa.toString()),
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                      ],
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
