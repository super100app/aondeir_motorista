import 'package:aondeir_motorista/screens/Usuario/Menu/Cadastro/OpcoesScreen.dart';
import 'package:aondeir_motorista/service/UsuarioService.dart';
import 'package:aondeir_motorista/styles/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:provider/provider.dart';

class DadosPessoaisScreen extends StatefulWidget {
  const DadosPessoaisScreen({super.key});

  @override
  State<DadosPessoaisScreen> createState() => _DadosPessoaisScreenState();
}

class _DadosPessoaisScreenState extends State<DadosPessoaisScreen> {
  TextEditingController _controllerNome = new TextEditingController();
  TextEditingController _controllerEmail = new TextEditingController();
  TextEditingController _controllerCpf = new TextEditingController();
  TextEditingController _controllerTelefone = new TextEditingController();
  TextEditingController _controllerNascimento = new TextEditingController();
  TextEditingController _controllerGenero = new TextEditingController();
  TextEditingController _controllerChavePix = new TextEditingController();

  final _maskFormatter = MaskTextInputFormatter(
    mask: '##/##/####',
    filter: {"#": RegExp(r'[0-9]')},
  );

  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      await preencherControladorDadosPessoais();
    });
  }

  preencherControladorDadosPessoais() async {
    var usuarioService = Provider.of<UsuarioService>(context, listen: false);
    _controllerNome.text = usuarioService.usuario.name;
    _controllerEmail.text = usuarioService.usuario.email;
    _controllerCpf.text = usuarioService.usuario.doc;
    _controllerTelefone.text = usuarioService.usuario.celular;
    _controllerNascimento.text = usuarioService
                .usuario.motorista['nascimento'] !=
            null
        ? formatarDataDoBanco(usuarioService.usuario.motorista['nascimento'])
        : "";
    _controllerGenero.text = usuarioService.usuario.motorista['genero'] != null
        ? usuarioService.usuario.motorista['genero']
        : "";
    _controllerChavePix.text =
        usuarioService.usuario.motorista['chave_pix'] != null
            ? usuarioService.usuario.motorista['chave_pix']
            : "";
  }

  String formatarDataDoBanco(String data) {
    DateTime dataFormatada = DateTime.parse(data);
    String dataFormatadaString = DateFormat('dd/MM/yyyy').format(dataFormatada);
    return dataFormatadaString;
  }

  salvarDadosPessoais() async {
    var usuarioService = Provider.of<UsuarioService>(context, listen: false);
    usuarioService.dadosPessoaisForm = {
      "name": _controllerNome.text,
      "email": _controllerEmail.text,
      "cpf": _controllerCpf.text,
      "telefone": _controllerTelefone.text,
      "nascimento": _controllerNascimento.text,
      "genero": _controllerGenero.text,
      "pix": _controllerChavePix.text
    };
    await usuarioService.save();
    await usuarioService.salvarDadosPessoais();
    if (usuarioService.errorsForm.isEmpty) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => OpcoesScreen(),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    var usuarioService = Provider.of<UsuarioService>(context, listen: true);
    return MediaQuery(
      data: MediaQuery.of(context).copyWith(textScaler: TextScaler.linear(1.0)),
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          leading: IconButton(
            icon: Icon(
              Icons.arrow_back_ios_new,
              color: Colors.orange,
              size: 25,
            ),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => OpcoesScreen(),
                ),
              );
            },
          ),
          title: Text(
            "Dados pessoais",
            style: TextStyle(fontSize: 17, color: Colors.black),
          ),
          elevation: 0,
          centerTitle: true,
          backgroundColor: Colors.white,
          actions: <Widget>[
            Container(
              padding: EdgeInsets.all(17),
              margin: EdgeInsets.only(right: 20),
              child: Text(
                "1 de 5",
                style: TextStyle(
                    color: Colors.grey,
                    fontSize: 18,
                    fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
        body: WillPopScope(
          onWillPop: () async {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => OpcoesScreen(),
              ),
            );
            return false;
          },
          child: Padding(
            padding: EdgeInsets.all(15),
            child: Material(
              type: MaterialType.transparency,
              child: new SingleChildScrollView(
                child: Container(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      SizedBox(height: 25),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          RichText(
                            text: TextSpan(
                              children: [
                                TextSpan(
                                  text: "Nome Completo",
                                  style: TextStyle(color: Colors.grey.shade500),
                                ),
                                TextSpan(
                                  text: " *",
                                  style: TextStyle(color: Colors.red),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: 5),
                          TextField(
                            controller: _controllerNome,
                            decoration: InputDecoration(
                              border: OutlineInputBorder(),
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    width: 1, color: Colors.grey.shade200),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    width: 1, color: Colors.grey.shade200),
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 25),
                      Row(
                        children: <Widget>[
                          Container(
                            child: Flexible(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  RichText(
                                    text: TextSpan(
                                      children: [
                                        TextSpan(
                                          text: "Email",
                                          style: TextStyle(
                                              color: Colors.grey.shade500),
                                        ),
                                        TextSpan(
                                          text: " *",
                                          style: TextStyle(color: Colors.red),
                                        ),
                                      ],
                                    ),
                                  ),
                                  SizedBox(height: 5),
                                  TextField(
                                    controller: _controllerEmail,
                                    decoration: InputDecoration(
                                      border: OutlineInputBorder(),
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            width: 1,
                                            color: Colors.grey.shade200),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            width: 1,
                                            color: Colors.grey.shade200),
                                      ),
                                      errorText: usuarioService
                                                  .errorsForm?['email'] !=
                                              null
                                          ? usuarioService.errorsForm['email']
                                          : null,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          SizedBox(width: 5),
                          Container(
                            child: Flexible(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  RichText(
                                    text: TextSpan(
                                      children: [
                                        TextSpan(
                                          text: "CPF",
                                          style: TextStyle(
                                              color: Colors.grey.shade500),
                                        ),
                                        TextSpan(
                                          text: " *",
                                          style: TextStyle(color: Colors.red),
                                        ),
                                      ],
                                    ),
                                  ),
                                  SizedBox(height: 5),
                                  TextField(
                                    controller: _controllerCpf,
                                    decoration: InputDecoration(
                                      border: OutlineInputBorder(),
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            width: 1,
                                            color: Colors.grey.shade200),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            width: 1,
                                            color: Colors.grey.shade200),
                                      ),
                                      errorText:
                                          usuarioService.errorsForm?['cpf'] !=
                                                  null
                                              ? usuarioService.errorsForm['cpf']
                                              : null,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 25),
                      Row(
                        children: <Widget>[
                          Container(
                            child: Flexible(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  RichText(
                                    text: TextSpan(
                                      children: [
                                        TextSpan(
                                          text: "Telefone de contato",
                                          style: TextStyle(
                                              color: Colors.grey.shade500),
                                        ),
                                        TextSpan(
                                          text: " *",
                                          style: TextStyle(color: Colors.red),
                                        ),
                                      ],
                                    ),
                                  ),
                                  SizedBox(height: 5),
                                  TextField(
                                    controller: _controllerTelefone,
                                    decoration: InputDecoration(
                                      border: OutlineInputBorder(),
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            width: 1,
                                            color: Colors.grey.shade200),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            width: 1,
                                            color: Colors.grey.shade200),
                                      ),
                                      errorText: usuarioService
                                                  .errorsForm?['telefone'] !=
                                              null
                                          ? usuarioService
                                              .errorsForm['telefone']
                                          : null,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          SizedBox(width: 5),
                          Container(
                            child: Flexible(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  RichText(
                                    text: TextSpan(
                                      children: [
                                        TextSpan(
                                          text: "Data de nascimento",
                                          style: TextStyle(
                                              color: Colors.grey.shade500),
                                        ),
                                        TextSpan(
                                          text: " *",
                                          style: TextStyle(color: Colors.red),
                                        ),
                                      ],
                                    ),
                                  ),
                                  SizedBox(height: 5),
                                  TextField(
                                    controller: _controllerNascimento,
                                    inputFormatters: [_maskFormatter],
                                    decoration: InputDecoration(
                                      border: OutlineInputBorder(),
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            width: 1,
                                            color: Colors.grey.shade200),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            width: 1,
                                            color: Colors.grey.shade200),
                                      ),
                                      errorText: usuarioService
                                                  .errorsForm?['nascimento'] !=
                                              null
                                          ? usuarioService
                                              .errorsForm['nascimento']
                                          : null,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 25),
                      Row(children: <Widget>[
                        Container(
                          child: Flexible(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                RichText(
                                  text: TextSpan(
                                    children: [
                                      TextSpan(
                                        text: "Genero",
                                        style: TextStyle(
                                            color: Colors.grey.shade500),
                                      ),
                                      TextSpan(
                                        text: " *",
                                        style: TextStyle(color: Colors.red),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(height: 5),
                                Autocomplete<String>(
                                  optionsBuilder:
                                      (TextEditingValue textEditingValue) {
                                    if (textEditingValue.text == '') {
                                      return ["MASCULINO", "FEMININO"];
                                    }
                                    return ["MASCULINO", "FEMININO"]
                                        .where((string) {
                                      return string.toLowerCase().contains(
                                          textEditingValue.text.toLowerCase());
                                    });
                                  },
                                  initialValue: TextEditingValue(
                                      text: usuarioService.usuario
                                                  .motorista['genero'] !=
                                              null
                                          ? usuarioService
                                              .usuario.motorista['genero']
                                          : ""),
                                  onSelected: (selectedGenero) {
                                    setState(() {
                                      _controllerGenero.text = selectedGenero;
                                    });
                                    debugPrint(
                                        'You just selected $selectedGenero');
                                  },
                                  fieldViewBuilder: (BuildContext context,
                                      TextEditingController controller,
                                      FocusNode focusNode,
                                      VoidCallback onFieldSubmitted) {
                                    return TextField(
                                      controller: controller,
                                      focusNode: focusNode,
                                      onSubmitted: (String value) {
                                        onFieldSubmitted();
                                      },
                                      decoration: InputDecoration(
                                        hintText: 'Selecione o genero',
                                        border: OutlineInputBorder(),
                                        enabledBorder: OutlineInputBorder(
                                          borderSide: BorderSide(
                                              width: 1,
                                              color: Colors.grey.shade200),
                                        ),
                                        focusedBorder: OutlineInputBorder(
                                          borderSide: BorderSide(
                                              width: 1,
                                              color: Colors.grey.shade200),
                                        ),
                                      ),
                                    );
                                  },
                                ),
                              ],
                            ),
                          ),
                        ),
                      ]),
                      SizedBox(height: 25),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          RichText(
                            text: TextSpan(
                              children: [
                                TextSpan(
                                  text: "Chave Pix",
                                  style: TextStyle(color: Colors.grey.shade500),
                                ),
                                TextSpan(
                                  text: " *",
                                  style: TextStyle(color: Colors.red),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: 5),
                          TextField(
                            controller: _controllerChavePix,
                            decoration: InputDecoration(
                              border: OutlineInputBorder(),
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    width: 1, color: Colors.grey.shade200),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    width: 1, color: Colors.grey.shade200),
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 25),
                      SizedBox(
                        width: double.infinity,
                        height: 50,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            elevation: 0,
                            backgroundColor: AppColors.buttonSecondary,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(6),
                              side: BorderSide(color: AppColors.buttonBorderSecondary),
                            ),
                            minimumSize: Size(100, 40),
                          ),
                          onPressed: () async {
                            await salvarDadosPessoais();
                          },
                          child: Text(
                            "Próximo",
                            style: TextStyle(fontSize: 18, color: Colors.white),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
