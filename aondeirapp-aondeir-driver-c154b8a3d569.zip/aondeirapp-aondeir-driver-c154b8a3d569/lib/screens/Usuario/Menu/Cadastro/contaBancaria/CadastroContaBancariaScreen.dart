import 'dart:async';

import 'package:aondeir_motorista/screens/Usuario/Menu/Cadastro/OpcoesScreen.dart';
import 'package:aondeir_motorista/service/UsuarioService.dart';
import 'package:aondeir_motorista/styles/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:provider/provider.dart';

import '../../../../../models/Banco.dart';
import '../../../../../service/BancoService.dart';

class CadastroContaBancariaScreen extends StatefulWidget {
  const CadastroContaBancariaScreen({super.key});

  @override
  State<CadastroContaBancariaScreen> createState() =>
      _CadastroContaBancariaScreenState();
}

class _CadastroContaBancariaScreenState
    extends State<CadastroContaBancariaScreen> {
  TextEditingController _controllerNomeTitular = TextEditingController();
  TextEditingController _controllerDocumentoTipo = TextEditingController();
  TextEditingController _controllerNumeroDocumento = TextEditingController();
  TextEditingController _controllerBanco = TextEditingController();
  TextEditingController _controllerAgencia = TextEditingController();
  TextEditingController _controllerAgenciaDigito = TextEditingController();
  TextEditingController _controllerContaTipo = TextEditingController();
  TextEditingController _controllerContaNumero = TextEditingController();
  TextEditingController _controllerContaDigito = TextEditingController();

  var tipoDocumentoSelecionado;
  var tipoContaSelecionado;
  var bancoSelecionado;
  var bancoSelecionadoTexto = "";

  bool isLoading = false;
  String dotText = '';
  late Timer timer;
  int dotCount = 1;

  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      await pegarDadosBancarios();
      await pegarBancos();
    });
  }

  setLoaderTrue() async {
    setState(() {
      isLoading = true;
      dotCount = 1;
    });
  }

  setTime() async {
    timer = Timer.periodic(Duration(seconds: 1), (timer) {
      setState(() {
        dotCount = (dotCount % 4) + 1;
      });

      if (dotCount == 1) {
        setState(() {
          dotText = '';
        });
      }
      if (dotCount == 2) {
        setState(() {
          dotText = '.';
        });
      }
      if (dotCount == 3) {
        setState(() {
          dotText = '..';
        });
      }
      if (dotCount == 4) {
        setState(() {
          dotText = '...';
        });
      }
    });
  }

  pegarDadosBancarios() async {
    var usuarioService = Provider.of<UsuarioService>(context, listen: false);

    setState(() {
      _controllerDocumentoTipo.text = "FISICA";
    });

    setState(() {
      _controllerNumeroDocumento.text = usuarioService.usuario.doc;
    });

    print("pegarDadosBancarios################################");
    print(usuarioService.usuario.doc);

    await usuarioService.pegarDadosBancarios();

    if (usuarioService.usuario.dados_bancarios != null) {
      setState(() {
        _controllerNomeTitular.text =
            usuarioService.usuario.dados_bancarios['nome_titular'];
        _controllerBanco.text = usuarioService.usuario.dados_bancarios['banco']
                ['codigo'] +
            " - " +
            usuarioService.usuario.dados_bancarios['banco']['name'];
        _controllerAgencia.text =
            usuarioService.usuario.dados_bancarios['numero_agencia'];

        if (usuarioService.usuario.dados_bancarios['digito_validacao_agencia']
            .toString()
            .isNotEmpty) {
          _controllerAgenciaDigito.text = usuarioService
              .usuario.dados_bancarios['digito_validacao_agencia'];
        }

        _controllerContaNumero.text =
            usuarioService.usuario.dados_bancarios['numero_conta'];
        _controllerContaDigito.text =
            usuarioService.usuario.dados_bancarios['digito_validacao_conta'];
        _controllerDocumentoTipo.text =
            usuarioService.usuario.dados_bancarios['tipo_documento'];
        _controllerContaTipo.text =
            usuarioService.usuario.dados_bancarios['tipo_conta'];
      });
    }
  }

  pegarBancos() async {
    var bancoService = Provider.of<BancoService>(context, listen: false);
    await bancoService.pegarBancos();
  }

  cadastrar() async {
    try {
      var usuarioService = Provider.of<UsuarioService>(context, listen: false);

      var dataForm = {
        "nome_titular": _controllerNomeTitular.text,
        "documento_tipo_titular": _controllerDocumentoTipo.text,
        "documento_titular": _controllerNumeroDocumento.text,
        "banco": bancoSelecionado.toString(),
        "agencia": _controllerAgencia.text,
        "agencia_digito": _controllerAgenciaDigito.text,
        "conta_tipo": _controllerContaTipo.text,
        "conta_numero": _controllerContaNumero.text,
        "conta_digito": _controllerContaDigito.text,
      };

      print("dataForm");
      print(dataForm);
      print("dataForm");

      var resultado = await usuarioService.cadastrarContaBancaria(dataForm);

      timer.cancel();

      if (resultado == true) {
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => OpcoesScreen(),
          ),
        );
      } else if (resultado == false) {
        setState(() {
          isLoading = false;
        });
        timer.cancel();
      }
    } catch (e) {
      throw e;
    }
  }

  @override
  Widget build(BuildContext context) {
    var usuarioService = Provider.of<UsuarioService>(context, listen: true);
    var bancoService = Provider.of<BancoService>(context, listen: true);

    return MediaQuery(
      data: MediaQuery.of(context).copyWith(textScaler: TextScaler.linear(1.0)),
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          leading: IconButton(
            icon: Icon(
              Icons.arrow_back_ios_new,
              color: Colors.orange,
              size: 25,
            ),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => OpcoesScreen(),
                ),
              );
            },
          ),
          title: Text(
            "Dados Bancários",
            style: TextStyle(fontSize: 17, color: Colors.black),
          ),
          elevation: 0,
          centerTitle: true,
          backgroundColor: Colors.white,
          actions: <Widget>[
            Container(
              padding: EdgeInsets.all(17),
              margin: EdgeInsets.only(right: 20),
              child: Text(
                "3 de 5",
                style: TextStyle(
                    color: Colors.grey,
                    fontSize: 18,
                    fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
        body: WillPopScope(
          onWillPop: () async {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => OpcoesScreen(),
              ),
            );
            return false;
          },
          child: Padding(
            padding: EdgeInsets.all(15),
            child: Material(
              type: MaterialType.transparency,
              child: new SingleChildScrollView(
                child: Container(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        "O número do documento do titular deve ser igual ao documento cadastrado no seu usuário!",
                        style: TextStyle(
                          color: Colors.grey,
                          fontSize: 17,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      SizedBox(height: 25),
                      Row(
                        children: <Widget>[
                          Container(
                            child: Flexible(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  RichText(
                                    text: TextSpan(
                                      children: [
                                        TextSpan(
                                          text: "Nome titular",
                                          style: TextStyle(
                                              color: Colors.grey.shade500),
                                        ),
                                        TextSpan(
                                          text: " *",
                                          style: TextStyle(color: Colors.red),
                                        ),
                                      ],
                                    ),
                                  ),
                                  SizedBox(height: 5),
                                  TextField(
                                    enabled: usuarioService
                                                .usuario.dados_bancarios !=
                                            null
                                        ? false
                                        : true,
                                    controller: _controllerNomeTitular,
                                    maxLength: 30,
                                    style: TextStyle(color: Colors.black),
                                    decoration: InputDecoration(
                                      border: OutlineInputBorder(),
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            width: 1,
                                            color: Colors.grey.shade200),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            width: 1,
                                            color: Colors.grey.shade200),
                                      ),
                                      errorText: usuarioService
                                                  .errorsForm['nome_titular'] !=
                                              null
                                          ? usuarioService
                                              .errorsForm['nome_titular']
                                              .toString()
                                          : null,
                                      counterText: "",
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 10),
                      Row(
                        children: <Widget>[
                          Container(
                            child: Flexible(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  RichText(
                                    text: TextSpan(
                                      children: [
                                        TextSpan(
                                          text: "Tipo do documento",
                                          style: TextStyle(
                                              color: Colors.grey.shade500),
                                        ),
                                        TextSpan(
                                          text: " *",
                                          style: TextStyle(color: Colors.red),
                                        ),
                                      ],
                                    ),
                                  ),
                                  SizedBox(height: 5),
                                  TextField(
                                    enabled: false,
                                    controller: _controllerDocumentoTipo,
                                    style: TextStyle(color: Colors.black),
                                    decoration: InputDecoration(
                                      border: OutlineInputBorder(),
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            width: 1,
                                            color: Colors.grey.shade200),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            width: 1,
                                            color: Colors.grey.shade200),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          SizedBox(width: 5),
                          Container(
                            child: Flexible(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  RichText(
                                    text: TextSpan(
                                      children: [
                                        TextSpan(
                                          text: "CPF",
                                          style: TextStyle(
                                              color: Colors.grey.shade500),
                                        ),
                                        TextSpan(
                                          text: " *",
                                          style: TextStyle(color: Colors.red),
                                        ),
                                      ],
                                    ),
                                  ),
                                  SizedBox(height: 5),
                                  TextField(
                                    onChanged: (value) {},
                                    enabled: false,
                                    // usuarioService.usuario.dados_bancarios !=
                                    //         null
                                    //     ? false
                                    //     : true,
                                    controller: _controllerNumeroDocumento,
                                    inputFormatters: [
                                      MaskTextInputFormatter(
                                          mask: "###.###.###-##",
                                          filter: {"#": RegExp(r'[0-9]')})
                                    ],
                                    style: TextStyle(color: Colors.black),
                                    decoration: InputDecoration(
                                      border: OutlineInputBorder(),
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            width: 1,
                                            color: Colors.grey.shade200),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            width: 1,
                                            color: Colors.grey.shade200),
                                      ),
                                      errorText: usuarioService.errorsForm[
                                                  'documento_titular'] !=
                                              null
                                          ? usuarioService
                                              .errorsForm['documento_titular']
                                          : null,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 20),
                      Row(children: <Widget>[
                        Container(
                          child: Flexible(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                RichText(
                                  text: TextSpan(
                                    children: [
                                      TextSpan(
                                        text: "Agência",
                                        style: TextStyle(
                                            color: Colors.grey.shade500),
                                      ),
                                      TextSpan(
                                        text: " *",
                                        style: TextStyle(color: Colors.red),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(height: 5),
                                TextField(
                                  enabled:
                                      usuarioService.usuario.dados_bancarios !=
                                              null
                                          ? false
                                          : true,
                                  onChanged: (value) {},
                                  controller: _controllerAgencia,
                                  maxLength: 4,
                                  style: TextStyle(color: Colors.black),
                                  decoration: InputDecoration(
                                    border: OutlineInputBorder(),
                                    enabledBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          width: 1,
                                          color: Colors.grey.shade200),
                                    ),
                                    focusedBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          width: 1,
                                          color: Colors.grey.shade200),
                                    ),
                                    errorText: usuarioService
                                                .errorsForm['agencia'] !=
                                            null
                                        ? usuarioService.errorsForm['agencia']
                                        : null,
                                    counterText: "",
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        SizedBox(width: 5),
                        Container(
                          child: Flexible(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                RichText(
                                  text: TextSpan(
                                    children: [
                                      TextSpan(
                                        text: "Dígito agência",
                                        style: TextStyle(
                                            color: Colors.grey.shade500),
                                      ),
                                      TextSpan(
                                        text: " *",
                                        style: TextStyle(color: Colors.red),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(height: 5),
                                TextField(
                                  enabled:
                                      usuarioService.usuario.dados_bancarios !=
                                              null
                                          ? false
                                          : true,
                                  onChanged: (value) {},
                                  controller: _controllerAgenciaDigito,
                                  maxLength: 1,
                                  style: TextStyle(color: Colors.black),
                                  decoration: InputDecoration(
                                    border: OutlineInputBorder(),
                                    enabledBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          width: 1,
                                          color: Colors.grey.shade200),
                                    ),
                                    focusedBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          width: 1,
                                          color: Colors.grey.shade200),
                                    ),
                                    counterText: "",
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ]),
                      SizedBox(height: 10),
                      Row(
                        children: <Widget>[
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                RichText(
                                  text: TextSpan(
                                    children: [
                                      TextSpan(
                                        text: "Banco",
                                        style: TextStyle(
                                            color: Colors.grey.shade500),
                                      ),
                                      TextSpan(
                                        text: " *",
                                        style: TextStyle(color: Colors.red),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(height: 5),
                                usuarioService.usuario.dados_bancarios != null
                                    ? TextField(
                                        enabled: false,
                                        controller: _controllerBanco,
                                        style: TextStyle(color: Colors.black),
                                        decoration: InputDecoration(
                                          border: OutlineInputBorder(),
                                          enabledBorder: OutlineInputBorder(
                                            borderSide: BorderSide(
                                                width: 1,
                                                color: Colors.grey.shade200),
                                          ),
                                          focusedBorder: OutlineInputBorder(
                                            borderSide: BorderSide(
                                                width: 1,
                                                color: Colors.grey.shade200),
                                          ),
                                        ),
                                      )
                                    : Autocomplete<Banco>(
                                        key: ValueKey('banco_autocomplete'),
                                        optionsBuilder: (TextEditingValue
                                            textEditingValue) {
                                          if (textEditingValue.text == '') {
                                            return bancoService.bancos;
                                          }
                                          return bancoService.bancos
                                              .where((banco) {
                                            var label = banco.codigo +
                                                " - " +
                                                banco.name;
                                            return label.toLowerCase().contains(
                                                textEditingValue.text
                                                    .toLowerCase());
                                          });
                                        },
                                        initialValue: TextEditingValue(
                                            text: _controllerBanco.text),
                                        onSelected: (Banco selectedBanco) {
                                          setState(() {
                                            bancoSelecionado = selectedBanco.id;
                                          });
                                        },
                                        displayStringForOption:
                                            (Banco option) =>
                                                option.codigo +
                                                " - " +
                                                option.name,
                                        fieldViewBuilder: (BuildContext context,
                                            TextEditingController controller,
                                            FocusNode focusNode,
                                            VoidCallback onFieldSubmitted) {
                                          return TextField(
                                            controller: controller,
                                            focusNode: focusNode,
                                            onSubmitted: (String value) {
                                              onFieldSubmitted();
                                            },
                                            style:
                                                TextStyle(color: Colors.black),
                                            decoration: InputDecoration(
                                              border: OutlineInputBorder(),
                                              enabledBorder: OutlineInputBorder(
                                                borderSide: BorderSide(
                                                    width: 1,
                                                    color:
                                                        Colors.grey.shade200),
                                              ),
                                              focusedBorder: OutlineInputBorder(
                                                borderSide: BorderSide(
                                                    width: 1,
                                                    color:
                                                        Colors.grey.shade200),
                                              ),
                                            ),
                                          );
                                        },
                                      ),
                              ],
                            ),
                          ),
                          SizedBox(width: 5),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                RichText(
                                  text: TextSpan(
                                    children: [
                                      TextSpan(
                                        text: "Tipo da conta",
                                        style: TextStyle(
                                            color: Colors.grey.shade500),
                                      ),
                                      TextSpan(
                                        text: " *",
                                        style: TextStyle(color: Colors.red),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(height: 5),
                                usuarioService.usuario.dados_bancarios != null
                                    ? TextField(
                                        enabled: false,
                                        controller: _controllerContaTipo,
                                        style: TextStyle(color: Colors.black),
                                        decoration: InputDecoration(
                                          border: OutlineInputBorder(),
                                          enabledBorder: OutlineInputBorder(
                                            borderSide: BorderSide(
                                                width: 1,
                                                color: Colors.grey.shade200),
                                          ),
                                          focusedBorder: OutlineInputBorder(
                                            borderSide: BorderSide(
                                                width: 1,
                                                color: Colors.grey.shade200),
                                          ),
                                        ),
                                      )
                                    : Autocomplete<String>(
                                        key:
                                            ValueKey('conta_tipo_autocomplete'),
                                        optionsBuilder: (TextEditingValue
                                            textEditingValue) {
                                          if (textEditingValue.text == '') {
                                            return ["POUPANCA", "CORRENTE"];
                                          }
                                          return ["POUPANCA", "CORRENTE"]
                                              .where((string) {
                                            return string
                                                .toLowerCase()
                                                .contains(textEditingValue.text
                                                    .toLowerCase());
                                          });
                                        },
                                        initialValue: TextEditingValue(
                                            text: _controllerContaTipo.text),
                                        onSelected: (selectedTipoConta) {
                                          setState(() {
                                            _controllerContaTipo.text =
                                                selectedTipoConta;
                                          });
                                        },
                                        displayStringForOption:
                                            (String option) => option,
                                        fieldViewBuilder: (BuildContext context,
                                            TextEditingController controller,
                                            FocusNode focusNode,
                                            VoidCallback onFieldSubmitted) {
                                          return TextField(
                                            controller: controller,
                                            focusNode: focusNode,
                                            onSubmitted: (String value) {
                                              onFieldSubmitted();
                                            },
                                            style:
                                                TextStyle(color: Colors.black),
                                            decoration: InputDecoration(
                                              border: OutlineInputBorder(),
                                              enabledBorder: OutlineInputBorder(
                                                borderSide: BorderSide(
                                                    width: 1,
                                                    color:
                                                        Colors.grey.shade200),
                                              ),
                                              focusedBorder: OutlineInputBorder(
                                                borderSide: BorderSide(
                                                    width: 1,
                                                    color:
                                                        Colors.grey.shade200),
                                              ),
                                            ),
                                          );
                                        },
                                      ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 20),
                      Row(
                        children: <Widget>[
                          Container(
                            child: Flexible(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  RichText(
                                    text: TextSpan(
                                      children: [
                                        TextSpan(
                                          text: "Número da conta",
                                          style: TextStyle(
                                              color: Colors.grey.shade500),
                                        ),
                                        TextSpan(
                                          text: " *",
                                          style: TextStyle(color: Colors.red),
                                        ),
                                      ],
                                    ),
                                  ),
                                  SizedBox(height: 5),
                                  TextField(
                                    onChanged: (value) {},
                                    enabled: usuarioService
                                                .usuario.dados_bancarios !=
                                            null
                                        ? false
                                        : true,
                                    controller: _controllerContaNumero,
                                    maxLength: 13,
                                    style: TextStyle(color: Colors.black),
                                    decoration: InputDecoration(
                                      border: OutlineInputBorder(),
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            width: 1,
                                            color: Colors.grey.shade200),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            width: 1,
                                            color: Colors.grey.shade200),
                                      ),
                                      errorText: usuarioService
                                                  .errorsForm['conta_numero'] !=
                                              null
                                          ? usuarioService
                                              .errorsForm['conta_numero']
                                          : null,
                                      counterText: "",
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          SizedBox(width: 5),
                          Container(
                            width: 120,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                RichText(
                                  text: TextSpan(
                                    children: [
                                      TextSpan(
                                        text: "Dígito conta",
                                        style: TextStyle(
                                            color: Colors.grey.shade500),
                                      ),
                                      TextSpan(
                                        text: " *",
                                        style: TextStyle(color: Colors.red),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(height: 5),
                                TextField(
                                  onChanged: (value) {},
                                  enabled:
                                      usuarioService.usuario.dados_bancarios !=
                                              null
                                          ? false
                                          : true,
                                  controller: _controllerContaDigito,
                                  maxLength: 2,
                                  style: TextStyle(color: Colors.black),
                                  decoration: InputDecoration(
                                    border: OutlineInputBorder(),
                                    enabledBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          width: 1,
                                          color: Colors.grey.shade200),
                                    ),
                                    focusedBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          width: 1,
                                          color: Colors.grey.shade200),
                                    ),
                                    errorText: usuarioService
                                                .errorsForm['conta_digito'] !=
                                            null
                                        ? usuarioService
                                            .errorsForm['conta_digito']
                                        : null,
                                    counterText: "",
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 25),
                      usuarioService.usuario.dados_bancarios == null
                          ? SizedBox(
                              width: double.infinity,
                              height: 50,
                              child: ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                  elevation: 0,
                                  backgroundColor: AppColors.buttonSecondary,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(6),
                                    side: BorderSide(color: Colors.white),
                                  ),
                                  minimumSize: Size(100, 40),
                                ),
                                onPressed: isLoading == true
                                    ? null
                                    : () async {
                                        await setLoaderTrue();
                                        await setTime();

                                        await cadastrar();
                                      },
                                child: Row(children: [
                                  if (isLoading == true)
                                    Expanded(
                                      child: Align(
                                        alignment: Alignment.center,
                                        child: Text(
                                          'Cadastrando',
                                          style: TextStyle(
                                              fontWeight: FontWeight.w500,
                                              fontSize: 21,
                                              letterSpacing: 2,
                                              color: Colors.white),
                                        ),
                                      ),
                                    ),
                                  if (isLoading == true)
                                    Container(
                                      width: 30,
                                      child: Text(
                                        dotText,
                                        style: TextStyle(
                                            fontWeight: FontWeight.w500,
                                            fontSize: 21,
                                            letterSpacing: 2,
                                            color: Colors.white),
                                      ),
                                    ),
                                  if (isLoading == true)
                                    CircularProgressIndicator(
                                      color: Colors.white,
                                      semanticsLabel:
                                          'Circular progress indicator',
                                    ),
                                  if (isLoading == false)
                                    Expanded(
                                      child: Align(
                                        alignment: Alignment.center,
                                        child: Text(
                                          'Próximo',
                                          style: TextStyle(
                                            fontWeight: FontWeight.w500,
                                            fontSize: 21,
                                            color: Colors.white,
                                            letterSpacing: 2,
                                          ),
                                        ),
                                      ),
                                    )
                                ]),
                              ),
                            )
                          : Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SizedBox(height: 25),
                                Container(
                                  width: double.infinity,
                                  child: Text(
                                    "Dados salvos com sucesso!",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      fontWeight: FontWeight.w500,
                                      fontSize: 16,
                                      letterSpacing: 2,
                                      color: Colors.green,
                                    ),
                                  ),
                                ),
                                SizedBox(height: 5),
                                ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    elevation: 0,
                                    backgroundColor:
                                        const Color.fromARGB(17, 21, 255, 0),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(6),
                                      side: BorderSide(color: Colors.green),
                                    ),
                                    shadowColor: Colors.transparent,
                                    minimumSize: Size(100, 40),
                                  ),
                                  onPressed: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (_) => OpcoesScreen()),
                                    );
                                  },
                                  child: Text(
                                    "Voltar",
                                    style: TextStyle(
                                      fontWeight: FontWeight.w500,
                                      fontSize: 13,
                                      letterSpacing: 2,
                                      color: Colors.green,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                      SizedBox(height: 10),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
