import 'dart:io';

import 'package:aondeir_motorista/screens/Inicio/InitialScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/BottomNavigationBar/NavigationScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/Cadastro/DadosPessoais/DadosPessoaisScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/Cadastro/Documentos/CondicoesDocumentoScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/Cadastro/Endereco/EnderecoScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/Cadastro/FotoRosto/CondicoesScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/Cadastro/Veiculo/CarroScreen.dart';
import 'package:aondeir_motorista/service/DocumentoService.dart';
import 'package:aondeir_motorista/service/SocketService.dart';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:provider/provider.dart';
import '../../../../models/Usuario.dart';
import '../../../../service/UsuarioService.dart';
import 'contaBancaria/CadastroContaBancariaScreen.dart';
import 'package:http/http.dart' as http;
import 'dart:convert' as convert;

class OpcoesScreen extends StatefulWidget {
  const OpcoesScreen({super.key});

  @override
  State<OpcoesScreen> createState() => _OpcoesScreenState();
}

class _OpcoesScreenState extends State<OpcoesScreen> {
  final storage = new FlutterSecureStorage();
  var mensagem =
      "Antes de você usar nosso app você precisa preecher os dados abaixo em qualquer ordem que desejar.";
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      await isCadastroCompleto();
    });
  }

  logout() async {
    var usuarioService = Provider.of<UsuarioService>(context, listen: false);
    String url = dotenv.env['BASE_URL']! +
        "api/motorista/logout/" +
        usuarioService.usuario.id.toString();
    var token = await storage.read(key: 'jwt');
    var response = await http.post(Uri.parse(url), headers: {
      HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
    });

    convert.jsonDecode(response.body);

    await storage.delete(key: 'jwt');
    usuarioService.usuario = new Usuario(
      id: 0,
      name: "",
      email: "",
      celular: "",
      tipoId: 0,
      status: "",
      doc: "",
      franquia: "",
      motorista: "",
      dados_bancarios: "",
      versaoAppMotorista: '0',
      versaoApp: "0",
    );

    usuarioService.dadosPessoaisForm = {};
    usuarioService.dadosEnderecoForm = {};
    usuarioService.dadosVeiculoForm = {};
    usuarioService.etapaCadastro = {};
    await usuarioService.save();

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => InitialScreen(),
      ),
    );
  }

  isCadastroCompleto() async {
    var usuarioService = Provider.of<UsuarioService>(context, listen: false);
    if (usuarioService.etapaCadastro['dados_pessoais'] == 1 &&
        usuarioService.etapaCadastro['foto_perfil'] == 1 &&
        usuarioService.etapaCadastro['endereco'] == 1 &&
        usuarioService.etapaCadastro['veiculo'] == 1 &&
        usuarioService.etapaCadastro['cnh'] == 1 &&
        usuarioService.etapaCadastro['comprovante_residencia'] == 1 &&
        usuarioService.etapaCadastro['crlv'] == 1) {
      showModalPagamento();
    }
    print("🏃‍♀️🏃‍♀️ usuarioService.usuario.id");
    print(usuarioService.usuario.id);
    var socketService = Provider.of<SocketService>(context, listen: false);
    socketService.socket?.off("motoristaAprovado" + usuarioService.usuario.id.toString());
    socketService.socket?.on("motoristaAprovado" + usuarioService.usuario.id.toString(), (data) async => {
      Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => NavigationScreen(),
          ),
      )
    });
  }

  showModalPagamento() async {
    return (showDialog<String>(
      context: context,
      builder: (BuildContext context) => MediaQuery(
        data:
            MediaQuery.of(context).copyWith(textScaler: TextScaler.linear(1.0)),
        child: AlertDialog(
          title: const Text('Aviso importante'),
          content: const Text(
              'Seus documentos e dados irão passar por análise de nossa equipe interna, aguarde, esse processo leva de 2 a 5 dias úteis, Obrigado!'),
          actions: <Widget>[
            InkWell(
              onTap: () {
                Navigator.pop(context, "Nao");
              },
              child: Padding(
                padding: EdgeInsets.all(15),
                child: Text(
                  'Ok',
                  style: TextStyle(color: Colors.orange),
                ),
              ),
            ),
          ],
        ),
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    var documentoService =
        Provider.of<DocumentoService>(context, listen: false);
    var usuarioService = Provider.of<UsuarioService>(context, listen: false);
    return MediaQuery(
      data: MediaQuery.of(context).copyWith(textScaler: TextScaler.linear(1.0)),
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          leading: null,
          title: Text(
            "Cadastro",
            style: TextStyle(fontSize: 17, color: Colors.black),
          ),
          elevation: 0,
          centerTitle: true,
          backgroundColor: Colors.white,
          actions: <Widget>[
            GestureDetector(
              onTap: () {
                logout();
              },
              child: Container(
                padding: EdgeInsets.all(17),
                margin: EdgeInsets.only(right: 20),
                child: Text(
                  "Sair",
                  style: TextStyle(
                      color: Colors.grey,
                      fontSize: 18,
                      fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ],
        ),
        body: WillPopScope(
          onWillPop: () async {
            return false;
          },
          child: Padding(
            padding: EdgeInsets.all(15),
            child: Material(
              type: MaterialType.transparency,
              child: new SingleChildScrollView(
                child: Container(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        mensagem,
                        style: TextStyle(
                          color: Colors.grey,
                          fontSize: 17,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      SizedBox(height: 30),
                      InkWell(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => DadosPessoaisScreen(),
                            ),
                          );
                        },
                        child: Row(
                          children: <Widget>[
                            Container(
                              padding: EdgeInsets.all(20),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: usuarioService
                                            .etapaCadastro['dados_pessoais'] ==
                                        1
                                    ? Colors.green.withOpacity(0.2)
                                    : Colors.grey.withOpacity(0.2),
                              ),
                              child: Text(
                                "1",
                                style: TextStyle(
                                  color: Colors.grey,
                                  fontSize: 25,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            SizedBox(width: 15),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                  "Dados pessoais",
                                  style: TextStyle(
                                    color: Colors.grey[800],
                                    fontSize: 17,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                SizedBox(height: 8),
                                if (usuarioService
                                        .etapaCadastro['dados_pessoais'] ==
                                    1)
                                  Text(
                                    "Completo",
                                    style: TextStyle(
                                      color: Colors.green,
                                      fontSize: 16,
                                      fontWeight: FontWeight.normal,
                                    ),
                                  )
                              ],
                            ),
                            Spacer(),
                            Icon(
                              Icons.arrow_forward_ios,
                              color: Colors.grey,
                              size: 20,
                            )
                          ],
                        ),
                      ),
                      Divider(),
                      InkWell(
                        onTap: () async {
                          documentoService.tipoDocumento = "FOTO_PERFIL";
                          await documentoService.save();
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => CondicoesScreen(),
                            ),
                          );
                        },
                        child: Row(
                          children: <Widget>[
                            Container(
                              padding: EdgeInsets.all(20),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: usuarioService
                                            .etapaCadastro['foto_perfil'] ==
                                        1
                                    ? Colors.green.withOpacity(0.2)
                                    : Colors.grey.withOpacity(0.2),
                              ),
                              child: Text(
                                "2",
                                style: TextStyle(
                                  color: Colors.grey,
                                  fontSize: 25,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            SizedBox(width: 15),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                  "Foto do rosto",
                                  style: TextStyle(
                                    color: Colors.grey[800],
                                    fontSize: 17,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                SizedBox(height: 8),
                                if (usuarioService
                                        .etapaCadastro['foto_perfil'] ==
                                    1)
                                  Text(
                                    "Completo",
                                    style: TextStyle(
                                      color: Colors.green,
                                      fontSize: 16,
                                      fontWeight: FontWeight.normal,
                                    ),
                                  )
                              ],
                            ),
                            Spacer(),
                            Icon(
                              Icons.arrow_forward_ios,
                              color: Colors.grey,
                              size: 20,
                            )
                          ],
                        ),
                      ),
                      Divider(),
                      // InkWell(
                      //   onTap: () {
                      //     Navigator.push(
                      //       context,
                      //       MaterialPageRoute(
                      //         builder: (_) => CadastroContaBancariaScreen(),
                      //       ),
                      //     );
                      //   },
                      //   child: Row(
                      //     children: <Widget>[
                      //       Container(
                      //         padding: EdgeInsets.all(20),
                      //         decoration: BoxDecoration(
                      //           shape: BoxShape.circle,
                      //           color: usuarioService
                      //                       .etapaCadastro['dados_bancarios'] ==
                      //                   1
                      //               ? Colors.green.withOpacity(0.2)
                      //               : Colors.grey.withOpacity(0.2),
                      //         ),
                      //         child: Text(
                      //           "3",
                      //           style: TextStyle(
                      //             color: Colors.grey,
                      //             fontSize: 25,
                      //             fontWeight: FontWeight.bold,
                      //           ),
                      //         ),
                      //       ),
                      //       SizedBox(width: 15),
                      //       Column(
                      //         crossAxisAlignment: CrossAxisAlignment.start,
                      //         children: <Widget>[
                      //           Text(
                      //             "Dados bancários",
                      //             style: TextStyle(
                      //               color: Colors.grey[800],
                      //               fontSize: 17,
                      //               fontWeight: FontWeight.bold,
                      //             ),
                      //           ),
                      //           SizedBox(height: 8),
                      //           if (usuarioService
                      //                   .etapaCadastro['dados_bancarios'] ==
                      //               1)
                      //             Text(
                      //               "Completo",
                      //               style: TextStyle(
                      //                 color: Colors.green,
                      //                 fontSize: 16,
                      //                 fontWeight: FontWeight.normal,
                      //               ),
                      //             )
                      //         ],
                      //       ),
                      //       Spacer(),
                      //       Icon(
                      //         Icons.arrow_forward_ios,
                      //         color: Colors.grey,
                      //         size: 20,
                      //       )
                      //     ],
                      //   ),
                      // ),
                      // Divider(),
                      InkWell(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => EnderecoScreen(),
                            ),
                          );
                        },
                        child: Row(
                          children: <Widget>[
                            Container(
                              padding: EdgeInsets.all(20),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color:
                                    usuarioService.etapaCadastro['endereco'] ==
                                            1
                                        ? Colors.green.withOpacity(0.2)
                                        : Colors.grey.withOpacity(0.2),
                              ),
                              child: Text(
                                "3",
                                style: TextStyle(
                                  color: Colors.grey,
                                  fontSize: 25,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            SizedBox(width: 15),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                  "Endereço",
                                  style: TextStyle(
                                    color: Colors.grey[800],
                                    fontSize: 17,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                SizedBox(height: 8),
                                if (usuarioService.etapaCadastro['endereco'] ==
                                    1)
                                  Text(
                                    "Completo",
                                    style: TextStyle(
                                      color: Colors.green,
                                      fontSize: 16,
                                      fontWeight: FontWeight.normal,
                                    ),
                                  ),
                              ],
                            ),
                            Spacer(),
                            Icon(
                              Icons.arrow_forward_ios,
                              color: Colors.grey,
                              size: 20,
                            )
                          ],
                        ),
                      ),
                      Divider(),
                      InkWell(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => CarroScreen(),
                            ),
                          );
                        },
                        child: Row(
                          children: <Widget>[
                            Container(
                              padding: EdgeInsets.all(20),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color:
                                    usuarioService.etapaCadastro['veiculo'] == 1
                                        ? Colors.green.withOpacity(0.2)
                                        : Colors.grey.withOpacity(0.2),
                              ),
                              child: Text(
                                "4",
                                style: TextStyle(
                                  color: Colors.grey,
                                  fontSize: 25,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            SizedBox(width: 15),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                  "Veículo",
                                  style: TextStyle(
                                    color: Colors.grey[800],
                                    fontSize: 17,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                SizedBox(height: 8),
                                if (usuarioService.etapaCadastro['veiculo'] ==
                                    1)
                                  Text(
                                    "Completo",
                                    style: TextStyle(
                                      color: Colors.green,
                                      fontSize: 16,
                                      fontWeight: FontWeight.normal,
                                    ),
                                  ),
                              ],
                            ),
                            Spacer(),
                            Icon(
                              Icons.arrow_forward_ios,
                              color: Colors.grey,
                              size: 20,
                            )
                          ],
                        ),
                      ),
                      Divider(),
                      // InkWell(
                      //   onTap: () async {
                      //     documentoService.tipoDocumento = "ANTECEDENTE_CRIMINAL";
                      //     await documentoService.save();

                      //     Navigator.push(
                      //       context,
                      //       MaterialPageRoute(
                      //         builder: (_) => CondicoesDocumentoScreen(),
                      //       ),
                      //     );
                      //   },
                      //   child: Row(
                      //     children: <Widget>[
                      //       Container(
                      //         padding: EdgeInsets.all(20),
                      //         decoration: BoxDecoration(
                      //           shape: BoxShape.circle,
                      //           color: usuarioService.etapaCadastro[
                      //                       'antecedente_criminal'] ==
                      //                   1
                      //               ? Colors.green.withOpacity(0.2)
                      //               : Colors.grey.withOpacity(0.2),
                      //         ),
                      //         child: Text(
                      //           "6",
                      //           style: TextStyle(
                      //             color: Colors.grey,
                      //             fontSize: 25,
                      //             fontWeight: FontWeight.bold,
                      //           ),
                      //         ),
                      //       ),
                      //       SizedBox(width: 15),
                      //       Column(
                      //         crossAxisAlignment: CrossAxisAlignment.start,
                      //         children: <Widget>[
                      //           Text(
                      //             "Certidão de antecedentes\ncriminais",
                      //             style: TextStyle(
                      //               color: Colors.grey[800],
                      //               fontSize: 17,
                      //               fontWeight: FontWeight.bold,
                      //             ),
                      //           ),
                      //           SizedBox(height: 8),
                      //         ],
                      //       ),
                      //       Spacer(),
                      //       Icon(
                      //         Icons.arrow_forward_ios,
                      //         color: Colors.grey,
                      //         size: 20,
                      //       )
                      //     ],
                      //   ),
                      // ),
                      // Divider(),
                      InkWell(
                        onTap: () async {
                          documentoService.tipoDocumento = "CNH";
                          await documentoService.save();
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => CondicoesDocumentoScreen(),
                            ),
                          );
                        },
                        child: Row(
                          children: <Widget>[
                            Container(
                              padding: EdgeInsets.all(20),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: usuarioService.etapaCadastro['cnh'] == 1
                                    ? Colors.green.withOpacity(0.2)
                                    : Colors.grey.withOpacity(0.2),
                              ),
                              child: Text(
                                "5",
                                style: TextStyle(
                                  color: Colors.grey,
                                  fontSize: 25,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            SizedBox(width: 15),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                  "CNH",
                                  style: TextStyle(
                                    color: Colors.grey[800],
                                    fontSize: 17,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                SizedBox(height: 8),
                                if (usuarioService.etapaCadastro['cnh'] == 1)
                                  Text(
                                    "Completo",
                                    style: TextStyle(
                                      color: Colors.green,
                                      fontSize: 16,
                                      fontWeight: FontWeight.normal,
                                    ),
                                  ),
                              ],
                            ),
                            Spacer(),
                            Icon(
                              Icons.arrow_forward_ios,
                              color: Colors.grey,
                              size: 20,
                            )
                          ],
                        ),
                      ),
                      Divider(),
                      InkWell(
                        onTap: () async {
                          documentoService.tipoDocumento =
                              "COMPROVANTE_RESIDENCIA";
                          await documentoService.save();
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => CondicoesDocumentoScreen(),
                            ),
                          );
                        },
                        child: Row(
                          children: <Widget>[
                            Container(
                              padding: EdgeInsets.all(20),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: usuarioService.etapaCadastro[
                                            'comprovante_residencia'] ==
                                        1
                                    ? Colors.green.withOpacity(0.2)
                                    : Colors.grey.withOpacity(0.2),
                              ),
                              child: Text(
                                "6",
                                style: TextStyle(
                                  color: Colors.grey,
                                  fontSize: 25,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            SizedBox(width: 15),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                  "Comprovante de residência",
                                  style: TextStyle(
                                    color: Colors.grey[800],
                                    fontSize: 17,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                SizedBox(height: 8),
                                if (usuarioService.etapaCadastro[
                                        'comprovante_residencia'] ==
                                    1)
                                  Text(
                                    "Completo",
                                    style: TextStyle(
                                      color: Colors.green,
                                      fontSize: 16,
                                      fontWeight: FontWeight.normal,
                                    ),
                                  ),
                              ],
                            ),
                            Spacer(),
                            Icon(
                              Icons.arrow_forward_ios,
                              color: Colors.grey,
                              size: 20,
                            )
                          ],
                        ),
                      ),
                      Divider(),
                      InkWell(
                        onTap: () async {
                          documentoService.tipoDocumento = "CRLV";
                          await documentoService.save();
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => CondicoesDocumentoScreen(),
                            ),
                          );
                        },
                        child: Row(
                          children: <Widget>[
                            Container(
                              padding: EdgeInsets.all(20),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: usuarioService.etapaCadastro['crlv'] == 1
                                    ? Colors.green.withOpacity(0.2)
                                    : Colors.grey.withOpacity(0.2),
                              ),
                              child: Text(
                                "7",
                                style: TextStyle(
                                  color: Colors.grey,
                                  fontSize: 25,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            SizedBox(width: 15),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                  "CRLV (Certidão de Registro",
                                  style: TextStyle(
                                    color: Colors.grey[800],
                                    fontSize: 17,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Text(
                                  "Licenciamento do veículo)",
                                  style: TextStyle(
                                    color: Colors.grey[800],
                                    fontSize: 17,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                SizedBox(height: 8),
                                if (usuarioService.etapaCadastro['crlv'] == 1)
                                  Text(
                                    "Completo",
                                    style: TextStyle(
                                      color: Colors.green,
                                      fontSize: 16,
                                      fontWeight: FontWeight.normal,
                                    ),
                                  ),
                              ],
                            ),
                            Spacer(),
                            Icon(
                              Icons.arrow_forward_ios,
                              color: Colors.grey,
                              size: 20,
                            )
                          ],
                        ),
                      ),
                      Divider(),
                      // InkWell(
                      //   onTap: () async {
                      //     documentoService.tipoDocumento = "VEICULO_FRONTAL";
                      //     await documentoService.save();
                      //     Navigator.push(
                      //       context,
                      //       MaterialPageRoute(
                      //         builder: (_) => CondicoesDocumentoScreen(),
                      //       ),
                      //     );
                      //   },
                      //   child: Row(
                      //     children: <Widget>[
                      //       Container(
                      //         padding: EdgeInsets.all(20),
                      //         decoration: BoxDecoration(
                      //           shape: BoxShape.circle,
                      //           color: usuarioService
                      //                       .etapaCadastro['veiculo_frontal'] ==
                      //                   1
                      //               ? Colors.green.withOpacity(0.2)
                      //               : Colors.grey.withOpacity(0.2),
                      //         ),
                      //         child: Text(
                      //           "10",
                      //           style: TextStyle(
                      //             color: Colors.grey,
                      //             fontSize: 25,
                      //             fontWeight: FontWeight.bold,
                      //           ),
                      //         ),
                      //       ),
                      //       SizedBox(width: 15),
                      //       Column(
                      //         crossAxisAlignment: CrossAxisAlignment.start,
                      //         children: <Widget>[
                      //           Text(
                      //             "Seguro APP (Opcional)",
                      //             style: TextStyle(
                      //               color: Colors.grey[800],
                      //               fontSize: 17,
                      //               fontWeight: FontWeight.bold,
                      //             ),
                      //           ),
                      //         ],
                      //       ),
                      //       Spacer(),
                      //       Icon(
                      //         Icons.arrow_forward_ios,
                      //         color: Colors.grey,
                      //         size: 20,
                      //       )
                      //     ],
                      //   ),
                      // ),
                      // Divider(),
                      // InkWell(
                      //   onTap: () async {
                      //     documentoService.tipoDocumento = "VEICULO_TRASEIRA";
                      //     await documentoService.save();
                      //     Navigator.push(
                      //       context,
                      //       MaterialPageRoute(
                      //         builder: (_) => CondicoesDocumentoScreen(),
                      //       ),
                      //     );
                      //   },
                      //   child: Row(
                      //     children: <Widget>[
                      //       Container(
                      //         padding: EdgeInsets.all(20),
                      //         decoration: BoxDecoration(
                      //           shape: BoxShape.circle,
                      //           color: usuarioService
                      //                       .etapaCadastro['veiculo_traseira'] ==
                      //                   1
                      //               ? Colors.green.withOpacity(0.2)
                      //               : Colors.grey.withOpacity(0.2),
                      //         ),
                      //         child: Text(
                      //           "11",
                      //           style: TextStyle(
                      //             color: Colors.grey,
                      //             fontSize: 25,
                      //             fontWeight: FontWeight.bold,
                      //           ),
                      //         ),
                      //       ),
                      //       SizedBox(width: 15),
                      //       Column(
                      //         crossAxisAlignment: CrossAxisAlignment.start,
                      //         children: <Widget>[
                      //           Text(
                      //             "Veículo (Foto traseira)",
                      //             style: TextStyle(
                      //               color: Colors.grey[800],
                      //               fontSize: 17,
                      //               fontWeight: FontWeight.bold,
                      //             ),
                      //           ),
                      //         ],
                      //       ),
                      //       Spacer(),
                      //       Icon(
                      //         Icons.arrow_forward_ios,
                      //         color: Colors.grey,
                      //         size: 20,
                      //       )
                      //     ],
                      //   ),
                      // ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
