import 'package:aondeir_motorista/styles/app_colors.dart';
import 'dart:io';

import 'package:aondeir_motorista/screens/Usuario/Menu/Cadastro/FotoRosto/CondicoesScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/Cadastro/OpcoesScreen.dart';
import 'package:aondeir_motorista/service/DocumentoService.dart';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../../../../../service/UsuarioService.dart';

class FotoScreen extends StatefulWidget {
  final String imagePath;

  const FotoScreen({super.key, required this.imagePath});

  @override
  State<FotoScreen> createState() => _FotoScreenState();
}

class _FotoScreenState extends State<FotoScreen> {
  final ImagePicker _pickerImageFace = ImagePicker();

  @override
  void initState() {
    super.initState();
  }

  salvaFotoPerfil() async {
    var usuarioService = Provider.of<UsuarioService>(context, listen: false);
    var documentoService =
        Provider.of<DocumentoService>(context, listen: false);
    var resp =
        await usuarioService.salvarFotoPerfil(documentoService.imagePath);
    // if (resp == true) {
    documentoService.imagePath = "";
    await documentoService.save();
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => OpcoesScreen(),
      ),
    );
    // }
  }

  Future<void> _pickImageFace() async {
    final ImageSource? source = await showDialog<ImageSource>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Escolha uma opção"),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.pop(context, ImageSource.camera),
              child: Text("Camera"),
            ),
            TextButton(
              onPressed: () => Navigator.pop(context, ImageSource.gallery),
              child: Text("Arquivo"),
            ),
          ],
        );
      },
    );

    if (source != null) {
      final XFile? image = await _pickerImageFace.pickImage(source: source);

      if (image != null) {
        var documentoService =
            Provider.of<DocumentoService>(context, listen: false);
        setState(() {
          documentoService.imagePath = image.path;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    var usuarioService = Provider.of<UsuarioService>(context, listen: true);
    var documentoService = Provider.of<DocumentoService>(context, listen: true);
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_ios_new,
            color: Colors.grey,
            size: 25,
          ),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => CondicoesScreen(),
              ),
            );
          },
        ),
        title: Text(
          "Foto do rosto",
          style: TextStyle(fontSize: 17, color: Colors.black),
        ),
        elevation: 0,
        centerTitle: true,
        backgroundColor: Colors.white,
        actions: <Widget>[
          Container(
            padding: EdgeInsets.all(17),
            margin: EdgeInsets.only(right: 20),
            child: Text(
              "2 de 5",
              style: TextStyle(
                color: Colors.grey,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
      body: WillPopScope(
        onWillPop: () async {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => CondicoesScreen(),
            ),
          );
          return false;
        },
        child: Material(
          type: MaterialType.transparency,
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 40, vertical: 40),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Text(
                  "Foto de perfil",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 22,
                  ),
                ),
                SizedBox(height: 10),
                Text(
                  "",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.grey,
                    fontWeight: FontWeight.w400,
                    fontSize: 18,
                  ),
                ),
                SizedBox(height: 10),
                ClipRRect(
                  borderRadius: BorderRadius.circular(10.0),
                  child: documentoService.imagePath.isNotEmpty
                      ? Image.file(
                          File(documentoService.imagePath),
                          width: 270,
                          height: 270,
                          fit: BoxFit.cover,
                        )
                      : usuarioService.usuario.motorista["foto_perfil"] != null
                          ? Image.network(
                              dotenv.env['BASE_URL']! +
                                  "images/" +
                                  usuarioService
                                      .usuario.motorista["foto_perfil"]
                                      .toString(),
                              width: 270,
                              height: 270,
                              fit: BoxFit.cover,
                            )
                          : Image.asset(
                              "assets/notImage.jpg",
                              width: 270,
                              height: 270,
                              fit: BoxFit.cover,
                            ),
                ),
                Container(
                  margin: EdgeInsets.only(top: 20),
                  child: Column(
                    children: <Widget>[
                      SizedBox(
                        width: double.infinity,
                        height: 50,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            elevation: 0,
                            shadowColor: Colors.transparent,
                            backgroundColor: Colors.transparent,
                            foregroundColor: Colors.orange,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(6),
                              side: BorderSide(color: AppColors.buttonBorderSecondary),
                            ),
                            minimumSize: Size(100, 40),
                          ),
                          onPressed: _pickImageFace,
                          child: Text(
                            "Enviar arquivo",
                            style:
                                TextStyle(fontSize: 18, color: Colors.orange),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                if (documentoService.imagePath.isNotEmpty)
                  Container(
                    margin: EdgeInsets.only(top: 10),
                    child: Column(
                      children: <Widget>[
                        SizedBox(
                          width: double.infinity,
                          height: 50,
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              elevation: 0,
                              backgroundColor: AppColors.buttonSecondary,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(6),
                                side: BorderSide(color: AppColors.buttonBorderSecondary),
                              ),
                              minimumSize: Size(100, 40),
                            ),
                            onPressed: () async {
                              await salvaFotoPerfil();
                            },
                            child: Text(
                              "Salvar e continuar",
                              style: TextStyle(fontSize: 18),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
