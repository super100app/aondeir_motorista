import 'package:aondeir_motorista/screens/Usuario/Menu/Cadastro/Documentos/DocumentoAntecedenteCriminalScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/Cadastro/Documentos/DocumentoCnhScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/Cadastro/Documentos/DocumentoComprovanteResidenciaScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/Cadastro/Documentos/DocumentoCrlvScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/Cadastro/Documentos/DocumentoVeiculoFrontalScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/Cadastro/Documentos/DocumentoVeiculoTraseiraScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/Cadastro/FotoRosto/FotoScreen.dart';
import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'package:provider/provider.dart';

import '../../../../../service/DocumentoService.dart';

class CameraScreen extends StatefulWidget {
  const CameraScreen({
    super.key,
  });

  @override
  State<CameraScreen> createState() => _CameraScreenState();
}

class _CameraScreenState extends State<CameraScreen> {
  late CameraController _controller;
  late Future<void> _initializeControllerFuture;

  @override
  void initState() {
    super.initState();
    _initializeControllerFuture = _initializeCamera();
  }

  Future<void> _initializeCamera() async {
    try {
      final cameras = await availableCameras();
      if (cameras.isEmpty) {
        return;
      }
      final firstCamera = cameras.first;

      _controller = CameraController(
        firstCamera,
        ResolutionPreset.medium,
      );
      await _controller.initialize();
      await _controller.initialize().then((_) {
        if (!mounted) {
          return;
        }
        setState(() {});
      }).catchError((Object e) {
        if (e is CameraException) {
          switch (e.code) {
            case 'CameraAccessDenied':
              break;
            default:
              break;
          }
        }
      });

      if (!mounted) return;

      setState(() {});
    } catch (e) {
      if (e is CameraException) {
        switch (e.code) {
          case 'CameraAccessDenied':
            break;
          default:
            break;
        }
      } else {}
    }
  }

  Future<void> _toggleCamera() async {
    try {
      final cameras = await availableCameras();
      final newCamera = cameras.firstWhere(
        (element) =>
            element.lensDirection != _controller.description.lensDirection,
      );

      if (_controller.value.isInitialized) {
        await _controller.dispose();
      }

      _controller = CameraController(
        newCamera,
        ResolutionPreset.medium,
      );

      _initializeControllerFuture = _controller.initialize();

      if (!mounted) return;

      setState(() {});
    } catch (e) {}
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var documentoService = Provider.of<DocumentoService>(context, listen: true);
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_ios_new,
            color: Colors.orange,
            size: 25,
          ),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(
          "Camera",
          style: TextStyle(fontSize: 17, color: Colors.black),
        ),
        elevation: 0,
        centerTitle: true,
        backgroundColor: Colors.white,
        actions: <Widget>[
          Container(
            padding: EdgeInsets.all(17),
            margin: EdgeInsets.only(right: 20),
            child: Text(
              "2 de 5",
              style: TextStyle(
                color: Colors.grey,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
      body: FutureBuilder<void>(
        future: _initializeControllerFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            return CameraPreview(_controller);
          } else {
            return const Center(child: CircularProgressIndicator());
          }
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          try {
            await _initializeControllerFuture;

            final image = await _controller.takePicture();

            if (!mounted) return;

            documentoService.imagePath = image.path;
            await documentoService.save();

            if (documentoService.tipoDocumento == "ANTECEDENTE_CRIMINAL") {
              await Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (context) => DocumentoAntecedenteCriminalScreen(),
                ),
              );
            } else if (documentoService.tipoDocumento == "CNH") {
              await Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (context) => DocumentoCnhScreen(),
                ),
              );
            } else if (documentoService.tipoDocumento ==
                "COMPROVANTE_RESIDENCIA") {
              await Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (context) => DocumentoComprovanteResidenciaScreen(),
                ),
              );
            } else if (documentoService.tipoDocumento == "CRLV") {
              await Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (context) => DocumentoCrlvScreen(),
                ),
              );
            } else if (documentoService.tipoDocumento == "VEICULO_FRONTAL") {
              await Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (context) => DocumentoVeiculoFrontalScreen(),
                ),
              );
            } else if (documentoService.tipoDocumento == "VEICULO_TRASEIRA") {
              await Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (context) => DocumentoVeiculoTraseiraScreen(),
                ),
              );
            } else {
              await Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (context) => FotoScreen(
                    imagePath: image.path,
                  ),
                ),
              );
            }
          } catch (e) {}
        },
        child: const Icon(Icons.camera_alt),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      bottomNavigationBar: BottomAppBar(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            IconButton(
              onPressed: _toggleCamera,
              icon: Icon(Icons.switch_camera),
            ),
          ],
        ),
      ),
    );
  }
}
