import 'package:aondeir_motorista/screens/Usuario/Menu/Cadastro/FotoRosto/FotoScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/Cadastro/OpcoesScreen.dart';
import 'package:flutter/material.dart';

class CondicoesScreen extends StatefulWidget {
  const CondicoesScreen({super.key});

  @override
  State<CondicoesScreen> createState() => _CondicoesScreenState();
}

class _CondicoesScreenState extends State<CondicoesScreen> {
  @override
  Widget build(BuildContext context) {
    return MediaQuery(
      data: MediaQuery.of(context).copyWith(textScaler: TextScaler.linear(1.0)),
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          leading: IconButton(
            icon: Icon(
              Icons.arrow_back_ios_new,
              color: Colors.grey,
              size: 25,
            ),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => OpcoesScreen(),
                ),
              );
            },
          ),
          title: Text(
            "Foto do rosto",
            style: TextStyle(fontSize: 17, color: Colors.black),
          ),
          elevation: 0,
          centerTitle: true,
          backgroundColor: Colors.white,
          actions: <Widget>[
            Container(
              padding: EdgeInsets.all(17),
              margin: EdgeInsets.only(right: 20),
              child: Text(
                "2 de 5",
                style: TextStyle(
                    color: Colors.grey,
                    fontSize: 18,
                    fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
        body: WillPopScope(
          onWillPop: () async {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => OpcoesScreen(),
              ),
            );
            return false;
          },
          child: Padding(
            padding: EdgeInsets.all(15),
            child: Material(
              type: MaterialType.transparency,
              child: Container(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      "Você pode conferir os dados que preencheu em cada etapa se desejar.",
                      style: TextStyle(
                        color: Colors.grey,
                        fontSize: 17,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    SizedBox(height: 30),
                    Expanded(
                      child: Column(
                        children: <Widget>[
                          Row(
                            children: <Widget>[
                              Container(
                                transform:
                                    Matrix4.translationValues(0.0, -20.0, 0.0),
                                padding: EdgeInsets.all(20),
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.grey.withOpacity(0.2),
                                ),
                                child: Text(
                                  "1",
                                  style: TextStyle(
                                    color: Colors.grey,
                                    fontSize: 25,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                              SizedBox(width: 15),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Container(
                                    width: 240,
                                    child: Text(
                                      "Mostre o rosto todo",
                                      style: TextStyle(
                                        color: Colors.grey[800],
                                        fontSize: 22,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                  Container(
                                    width: 260,
                                    child: Text(
                                      "Recomendamos que sua foto mostre o rosto todo e parte dos ombros.",
                                      style: TextStyle(
                                        color: Colors.grey[400],
                                        fontSize: 19,
                                        fontWeight: FontWeight.w400,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          SizedBox(height: 30),
                          Row(
                            children: <Widget>[
                              Container(
                                transform:
                                    Matrix4.translationValues(0.0, -30.0, 0.0),
                                padding: EdgeInsets.all(20),
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.grey.withOpacity(0.2),
                                ),
                                child: Text(
                                  "2",
                                  style: TextStyle(
                                    color: Colors.grey,
                                    fontSize: 25,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                              SizedBox(width: 15),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Container(
                                    width: 240,
                                    child: Text(
                                      "Foto com boa iluminação",
                                      style: TextStyle(
                                        color: Colors.grey[800],
                                        fontSize: 22,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                  Container(
                                    width: 260,
                                    child: Text(
                                      "Tire a foto num ambiente claro para seu rosto ficar bem visível.",
                                      style: TextStyle(
                                        color: Colors.grey[400],
                                        fontSize: 19,
                                        fontWeight: FontWeight.w400,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          SizedBox(height: 30),
                          Row(
                            children: <Widget>[
                              Container(
                                transform:
                                    Matrix4.translationValues(0.0, -30.0, 0.0),
                                padding: EdgeInsets.all(20),
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.grey.withOpacity(0.2),
                                ),
                                child: Text(
                                  "3",
                                  style: TextStyle(
                                    color: Colors.grey,
                                    fontSize: 25,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                              SizedBox(width: 15),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Container(
                                    width: 260,
                                    child: Text(
                                      "Não use óculos escuros nem chapéu",
                                      style: TextStyle(
                                        color: Colors.grey[800],
                                        fontSize: 22,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                  Container(
                                    width: 260,
                                    child: Text(
                                      "Acessória podem dificultar a visualização do seu rosto na foto.",
                                      style: TextStyle(
                                        color: Colors.grey[400],
                                        fontSize: 19,
                                        fontWeight: FontWeight.w400,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          elevation: 0,
                          backgroundColor: Colors.grey,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(6),
                            side: BorderSide(color: Colors.grey),
                          ),
                          minimumSize: Size(100, 40),
                        ),
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => FotoScreen(
                                imagePath: '',
                              ),
                            ),
                          );
                        },
                        child: Text(
                          "Continuar",
                          style: TextStyle(fontSize: 18, color: Colors.white),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
