import 'package:aondeir_motorista/screens/Usuario/Menu/Cadastro/OpcoesScreen.dart';
import 'package:aondeir_motorista/styles/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:provider/provider.dart';

import '../../../../../service/UsuarioService.dart';

class CarroScreen extends StatefulWidget {
  const CarroScreen({super.key});

  @override
  State<CarroScreen> createState() => _CarroScreenState();
}

class _CarroScreenState extends State<CarroScreen> {
  TextEditingController _controllerCnh = new TextEditingController();
  TextEditingController _controllerPlaca = new TextEditingController();
  TextEditingController _controllerModelo = new TextEditingController();
  TextEditingController _controllerFabricacao = new TextEditingController();
  TextEditingController _controllerCor = new TextEditingController();

  var corSelecionada;
  final List<String> cores = [
    'Branco',
    'Prata',
    'Amarelo',
    'Azul',
    'Laranja',
    'Vermelho',
    'Preto',
    'Cinza',
    'Verde',
    'Marron',
    'Rosa',
    'Roxo',
    'Dourado',
    'Bege',
    'Grená',
    'Fantasia',
  ];

  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      await preencherControladorDadosVeiculo();
    });
  }

  preencherControladorDadosVeiculo() async {
    var usuarioService = Provider.of<UsuarioService>(context, listen: false);

    setState(() {
      _controllerCnh.text =
          usuarioService.usuario.motorista['numero_cnh'] != null
              ? usuarioService.usuario.motorista['numero_cnh']
              : "";
      _controllerPlaca.text = usuarioService.usuario.motorista['placa'] != null
          ? usuarioService.usuario.motorista['placa']
          : "";
      _controllerModelo.text =
          usuarioService.usuario.motorista['modelo'] != null
              ? usuarioService.usuario.motorista['modelo']
              : "";
      _controllerFabricacao.text =
          usuarioService.usuario.motorista['ano_fabricacao'] != null
              ? usuarioService.usuario.motorista['ano_fabricacao']
              : "";
      _controllerCor.text =
          usuarioService.usuario.motorista['cor_veiculo'] != null
              ? usuarioService.usuario.motorista['cor_veiculo']
              : "";
      corSelecionada = usuarioService.usuario.motorista['cor_veiculo'] != null
          ? usuarioService.usuario.motorista['cor_veiculo']
          : "";
    });
  }

  salvarDadosVeiculos() async {
    var usuarioService = Provider.of<UsuarioService>(context, listen: false);
    usuarioService.dadosVeiculoForm = {
      "numero_cnh": _controllerCnh.text,
      "placa": _controllerPlaca.text,
      "modelo": _controllerModelo.text,
      "ano_fabricacao": _controllerFabricacao.text,
      "cor_veiculo": corSelecionada,
    };
    await usuarioService.save();
    var resultado = await usuarioService.salvarDadosVeiculo();

    if (resultado == true) {
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => OpcoesScreen(),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    var usuarioService = Provider.of<UsuarioService>(context, listen: true);
    return MediaQuery(
      data: MediaQuery.of(context).copyWith(textScaler: TextScaler.linear(1.0)),
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          leading: IconButton(
            icon: Icon(
              Icons.arrow_back_ios_new,
              color: Colors.orange,
              size: 25,
            ),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => OpcoesScreen(),
                ),
              );
            },
          ),
          title: Text(
            "Carro",
            style: TextStyle(fontSize: 17, color: Colors.black),
          ),
          elevation: 0,
          centerTitle: true,
          backgroundColor: Colors.white,
          actions: <Widget>[
            Container(
              padding: EdgeInsets.all(17),
              margin: EdgeInsets.only(right: 20),
              child: Text(
                "4 de 5",
                style: TextStyle(
                    color: Colors.grey,
                    fontSize: 18,
                    fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
        body: WillPopScope(
          onWillPop: () async {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => OpcoesScreen(),
              ),
            );
            return false;
          },
          child: Padding(
            padding: EdgeInsets.all(15),
            child: Material(
              type: MaterialType.transparency,
              child: new SingleChildScrollView(
                child: Container(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      SizedBox(height: 15),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          RichText(
                            text: TextSpan(
                              children: [
                                TextSpan(
                                  text: "CNH",
                                  style: TextStyle(color: Colors.grey.shade500),
                                ),
                                TextSpan(
                                  text: " *",
                                  style: TextStyle(color: Colors.red),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: 5),
                          TextField(
                            controller: _controllerCnh,
                            decoration: InputDecoration(
                              border: OutlineInputBorder(),
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    width: 1, color: Colors.grey.shade200),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    width: 1, color: Colors.grey.shade200),
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 15),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          RichText(
                            text: TextSpan(
                              children: [
                                TextSpan(
                                  text: "Placa",
                                  style: TextStyle(color: Colors.grey.shade500),
                                ),
                                TextSpan(
                                  text: " *",
                                  style: TextStyle(color: Colors.red),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: 5),
                          TextField(
                            controller: _controllerPlaca,
                            inputFormatters: [
                              MaskTextInputFormatter(
                                mask: '###-&@&&',
                                filter: {
                                  "#": RegExp(r'[A-Za-z]'),
                                  "@": RegExp(r'[A-Za-z0-9]'),
                                  "&": RegExp(r'[0-9]'),
                                },
                              )
                            ],
                            decoration: InputDecoration(
                              border: OutlineInputBorder(),
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    width: 1, color: Colors.grey.shade200),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    width: 1, color: Colors.grey.shade200),
                              ),
                              errorText:
                                  usuarioService.errorsForm['placa'] != null
                                      ? usuarioService.errorsForm['placa']
                                      : null,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 15),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                                  RichText(
                                    text: TextSpan(
                                      children: [
                                        TextSpan(
                                          text: "Modelo de Carro (ex: Onix, Argo, Pulse, BYD)",
                                          style: TextStyle(
                                              color: Colors.grey.shade500),
                                        ),
                                        TextSpan(
                                          text: " *",
                                          style: TextStyle(color: Colors.red),
                                        ),
                                      ],
                                    ),
                                  ),
                                  SizedBox(height: 5),
                                  TextField(
                                    controller: _controllerModelo,
                                    decoration: InputDecoration(
                                      border: OutlineInputBorder(),
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            width: 1,
                                            color: Colors.grey.shade200),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            width: 1,
                                            color: Colors.grey.shade200),
                                      ),
                                      errorText: usuarioService
                                                  .errorsForm['modelo'] !=
                                              null
                                          ? usuarioService.errorsForm['modelo']
                                          : null,
                                    ),
                                  ),
                                ]
                      ),
                      SizedBox(height: 15),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                                RichText(
                                  text: TextSpan(
                                    children: [
                                      TextSpan(
                                        text: "Ano de fabricação",
                                        style: TextStyle(
                                            color: Colors.grey.shade500),
                                      ),
                                      TextSpan(
                                        text: " *",
                                        style: TextStyle(color: Colors.red),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(height: 5),
                                TextField(
                                  maxLength: 4,
                                  controller: _controllerFabricacao,
                                  decoration: InputDecoration(
                                    border: OutlineInputBorder(),
                                    enabledBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          width: 1,
                                          color: Colors.grey.shade200),
                                    ),
                                    focusedBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          width: 1,
                                          color: Colors.grey.shade200),
                                    ),
                                    errorText: usuarioService
                                                .errorsForm['ano_fabricacao'] !=
                                            null
                                        ? usuarioService
                                            .errorsForm['ano_fabricacao']
                                        : null,
                                    counterText: "",
                                  ),
                                ),
                              ],
                      ),
                      // SizedBox(height: 15),
                      // Row(
                      //   children: <Widget>[
                      //     Container(
                      //       child: Flexible(
                      //         child: Column(
                      //           crossAxisAlignment: CrossAxisAlignment.start,
                      //           children: [
                      //             RichText(
                      //               text: TextSpan(
                      //                 children: [
                      //                   TextSpan(
                      //                     text: "Modelo de Carro (ex: Onix, Argo, Pulse, BYD)",
                      //                     style: TextStyle(
                      //                         color: Colors.grey.shade500),
                      //                   ),
                      //                   TextSpan(
                      //                     text: " *",
                      //                     style: TextStyle(color: Colors.red),
                      //                   ),
                      //                 ],
                      //               ),
                      //             ),
                      //             SizedBox(height: 5),
                      //             TextField(
                      //               controller: _controllerModelo,
                      //               decoration: InputDecoration(
                      //                 border: OutlineInputBorder(),
                      //                 enabledBorder: OutlineInputBorder(
                      //                   borderSide: BorderSide(
                      //                       width: 1,
                      //                       color: Colors.grey.shade200),
                      //                 ),
                      //                 focusedBorder: OutlineInputBorder(
                      //                   borderSide: BorderSide(
                      //                       width: 1,
                      //                       color: Colors.grey.shade200),
                      //                 ),
                      //                 errorText: usuarioService
                      //                             .errorsForm['modelo'] !=
                      //                         null
                      //                     ? usuarioService.errorsForm['modelo']
                      //                     : null,
                      //               ),
                      //             ),
                      //           ],
                      //         ),
                      //       ),
                      //     ),
                      //     SizedBox(width: 5),
                      //     Container(
                      //       width: 150,
                      //       child: Column(
                      //         crossAxisAlignment: CrossAxisAlignment.start,
                      //         children: [
                      //           RichText(
                      //             text: TextSpan(
                      //               children: [
                      //                 TextSpan(
                      //                   text: "Ano de fabricação",
                      //                   style: TextStyle(
                      //                       color: Colors.grey.shade500),
                      //                 ),
                      //                 TextSpan(
                      //                   text: " *",
                      //                   style: TextStyle(color: Colors.red),
                      //                 ),
                      //               ],
                      //             ),
                      //           ),
                      //           SizedBox(height: 5),
                      //           TextField(
                      //             maxLength: 4,
                      //             controller: _controllerFabricacao,
                      //             decoration: InputDecoration(
                      //               border: OutlineInputBorder(),
                      //               enabledBorder: OutlineInputBorder(
                      //                 borderSide: BorderSide(
                      //                     width: 1,
                      //                     color: Colors.grey.shade200),
                      //               ),
                      //               focusedBorder: OutlineInputBorder(
                      //                 borderSide: BorderSide(
                      //                     width: 1,
                      //                     color: Colors.grey.shade200),
                      //               ),
                      //               errorText: usuarioService
                      //                           .errorsForm['ano_fabricacao'] !=
                      //                       null
                      //                   ? usuarioService
                      //                       .errorsForm['ano_fabricacao']
                      //                   : null,
                      //               counterText: "",
                      //             ),
                      //           ),
                      //         ],
                      //       ),
                      //     ),
                      //   ],
                      // ),
                      SizedBox(height: 15),
                      Row(
                        children: <Widget>[
                          Container(
                            child: Flexible(
                              child: DropdownButton(
                                isExpanded: true,
                                value: corSelecionada,
                                padding: EdgeInsets.only(top: 20.0),
                                onChanged: (value) {
                                  setState(() {
                                    corSelecionada = value;
                                  });
                                },
                                items: [
                                  DropdownMenuItem<String>(
                                    value: "",
                                    child: Text("Cor do veículo"),
                                  ),
                                  ...cores.map((item) {
                                    return DropdownMenuItem<String>(
                                      value: item.toString(),
                                      child: Text(item),
                                    );
                                  }).toList(),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 25),
                      SizedBox(
                        width: double.infinity,
                        height: 50,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            elevation: 0,
                            backgroundColor: AppColors.buttonSecondary,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(6),
                              side: BorderSide(color: AppColors.buttonBorderSecondary),
                            ),
                            minimumSize: Size(100, 40),
                          ),
                          onPressed: () async {
                            await salvarDadosVeiculos();
                          },
                          child: Text(
                            "Próximo",
                            style: TextStyle(fontSize: 18, color: Colors.white),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
