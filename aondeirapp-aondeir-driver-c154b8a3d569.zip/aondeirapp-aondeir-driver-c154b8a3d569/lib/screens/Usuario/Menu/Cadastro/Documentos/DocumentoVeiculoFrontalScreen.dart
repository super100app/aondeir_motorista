import 'package:aondeir_motorista/styles/app_colors.dart';
import 'dart:io';

import 'package:aondeir_motorista/screens/Usuario/Menu/Cadastro/FotoRosto/CameraScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/Cadastro/OpcoesScreen.dart';
import 'package:aondeir_motorista/service/DocumentoService.dart';
import 'package:aondeir_motorista/service/UsuarioService.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_pdfview/flutter_pdfview.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

class DocumentoVeiculoFrontalScreen extends StatefulWidget {
  const DocumentoVeiculoFrontalScreen({super.key});

  @override
  State<DocumentoVeiculoFrontalScreen> createState() =>
      _DocumentoVeiculoFrontalScreenState();
}

class _DocumentoVeiculoFrontalScreenState
    extends State<DocumentoVeiculoFrontalScreen> {
  final ImagePicker _pickerVeiculo = ImagePicker();
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      await pegarFotoVeiculoFrontal();
    });
  }

  pegarFotoVeiculoFrontal() async {
    var documentoService =
        Provider.of<DocumentoService>(context, listen: false);

    documentoService.tipoDocumentoId = 5;
    await documentoService.save();
    await documentoService.pegarDocumento();
  }

  salvaDocumento() async {
    var usuarioService = Provider.of<UsuarioService>(context, listen: false);
    var documentoService =
        Provider.of<DocumentoService>(context, listen: false);
    var resp = await usuarioService
        .salvaDocumentoVeiculoFrontal(documentoService.imagePath);

    if (resp == true) {
      documentoService.imagePath = "";
      await documentoService.save();
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => OpcoesScreen(),
        ),
      );
    }
  }

  Future<void> _pickImageVeiculo() async {
    final String? source = await showDialog<String>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Escolha uma opção"),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.pop(context, ImageSource.camera),
              child: Text("Camera"),
            ),
            TextButton(
              onPressed: () => Navigator.pop(context, 'file'),
              child: Text("Arquivo"),
            ),
          ],
        );
      },
    );

    if (source != null) {
      if (source == 'file') {
        FilePickerResult? result = await FilePicker.platform.pickFiles(
          type: FileType.custom,
          allowedExtensions: ['jpeg', 'jpg', 'png', 'pdf'],
        );

        if (result != null) {
          var filePath = result.files.single.path;
          if (filePath != null) {
            var documentoService =
                Provider.of<DocumentoService>(context, listen: false);
            setState(() {
              documentoService.imagePath = filePath;
            });
          }
        }
      } else if (source == 'camera' || source == 'gallery') {
        final ImageSource imageSource =
            (source == 'camera') ? ImageSource.camera : ImageSource.gallery;

        final XFile? image =
            await _pickerVeiculo.pickImage(source: imageSource);

        if (image != null) {
          var documentoService =
              Provider.of<DocumentoService>(context, listen: false);
          setState(() {
            documentoService.imagePath = image.path;
          });
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    Provider.of<UsuarioService>(context, listen: true);
    var documentoService = Provider.of<DocumentoService>(context, listen: true);
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_ios_new,
            color: Colors.orange,
            size: 25,
          ),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(
          "Documentos",
          style: TextStyle(fontSize: 17, color: Colors.black),
        ),
        elevation: 0,
        centerTitle: true,
        backgroundColor: Colors.white,
        actions: <Widget>[
          Container(
            padding: EdgeInsets.all(17),
            margin: EdgeInsets.only(right: 20),
            child: Text(
              "5 de 5",
              style: TextStyle(
                color: Colors.grey,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
      body: WillPopScope(
        onWillPop: () async {
          return false;
        },
        child: Material(
          type: MaterialType.transparency,
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 40, vertical: 40),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Text(
                  "Seguro APP",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 22,
                  ),
                ),
                SizedBox(height: 10),
                Text(
                  "O Seguro APP pode ser enviada em pdf, jpg, png ou tirar a foto do documento",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.grey,
                    fontWeight: FontWeight.w400,
                    fontSize: 18,
                  ),
                ),
                SizedBox(height: 10),
                ClipRRect(
                  borderRadius: BorderRadius.circular(10.0),
                  child: documentoService.imagePath.isNotEmpty
                      ? (documentoService.imagePath.endsWith(".jpg") ||
                              documentoService.imagePath.endsWith(".png") ||
                              documentoService.imagePath.endsWith(".jpeg"))
                          ? Image.file(
                              File(documentoService.imagePath),
                              width: 270,
                              height: 270,
                              fit: BoxFit.cover,
                            )
                          : documentoService.imagePath.endsWith(".pdf")
                              ? Container(
                                  width: 270,
                                  height: 270,
                                  child: PDFView(
                                    filePath: documentoService.imagePath,
                                    onPageError: (page, error) {},
                                  ),
                                )
                              : Container(
                                  width: 270,
                                  height: 270,
                                  color: Colors.grey[300],
                                  child: Center(
                                    child: Icon(
                                      Icons.insert_drive_file,
                                      size: 50,
                                      color: Colors.red,
                                    ),
                                  ),
                                )
                      : documentoService.documento.isNotEmpty
                          ? Image.network(
                              dotenv.env['BASE_URL']! +
                                  "images/" +
                                  documentoService.documento["imagem"]
                                      .toString(),
                              width: 270,
                              height: 270,
                              fit: BoxFit.cover,
                            )
                          : Image.asset(
                              "assets/notImage.jpg",
                              width: 270, // Defina o tamanho desejado aqui
                              height: 270, // Defina o tamanho desejado aqui
                              fit: BoxFit.cover,
                            ),
                ),
                if (documentoService.documento.isEmpty ||
                    documentoService.documento['status'] != "APROVADO")
                  Container(
                    margin: EdgeInsets.only(top: 20),
                    child: Column(
                      children: <Widget>[
                        SizedBox(
                          width: double.infinity,
                          height: 50,
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              elevation: 0,
                              shadowColor: Colors.transparent,
                              backgroundColor: Colors.transparent,
                              foregroundColor: Colors.orange,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(6),
                                side: BorderSide(color: AppColors.buttonBorderSecondary),
                              ),
                              minimumSize: Size(100, 40),
                            ),
                            onPressed: _pickImageVeiculo,
                            child: Text(
                              "Enviar arquivo",
                              style:
                                  TextStyle(fontSize: 18, color: Colors.orange),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                if (documentoService.imagePath.isNotEmpty)
                  Container(
                    margin: EdgeInsets.only(top: 10),
                    child: Column(
                      children: <Widget>[
                        SizedBox(
                          width: double.infinity,
                          height: 50,
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              elevation: 0,
                              backgroundColor: AppColors.buttonSecondary,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(6),
                                side: BorderSide(color: AppColors.buttonBorderSecondary),
                              ),
                              minimumSize: Size(100, 40),
                            ),
                            onPressed: () async {
                              await salvaDocumento();
                            },
                            child: Text(
                              "Salvar e continuar",
                              style: TextStyle(fontSize: 18),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
