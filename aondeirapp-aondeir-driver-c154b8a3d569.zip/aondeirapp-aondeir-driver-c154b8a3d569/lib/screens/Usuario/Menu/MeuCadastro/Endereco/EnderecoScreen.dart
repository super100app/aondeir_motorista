import 'dart:convert';
import 'package:aondeir_motorista/styles/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:provider/provider.dart';
import '../../../../../service/UsuarioService.dart';
import '../MeuCadastroScreen.dart';

class EnderecoScreen extends StatefulWidget {
  const EnderecoScreen({super.key});

  @override
  State<EnderecoScreen> createState() => _EnderecoScreenState();
}

class _EnderecoScreenState extends State<EnderecoScreen> {
  TextEditingController _controllerCep = new TextEditingController();
  TextEditingController _controllerEndereco = new TextEditingController();
  TextEditingController _controllerNumero = new TextEditingController();
  TextEditingController _controllerComplemento = new TextEditingController();
  TextEditingController _controllerBairro = new TextEditingController();
  TextEditingController _controllerUf = new TextEditingController();
  TextEditingController _controllerCidade = new TextEditingController();

  var teste = "";

  List<String> siglasEstados = [
    "AC",
    "AL",
    "AP",
    "AM",
    "BA",
    "CE",
    "DF",
    "ES",
    "GO",
    "MA",
    "MT",
    "MS",
    "MG",
    "PA",
    "PB",
    "PR",
    "PE",
    "PI",
    "RJ",
    "RN",
    "RS",
    "RO",
    "RR",
    "SC",
    "SP",
    "SE",
    "TO"
  ];

  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      await preencherControladorEndereco();
    });
  }

  Future<void> _buscarEndereco(cep) async {
    var usuarioService = Provider.of<UsuarioService>(context, listen: false);
    final url = 'https://viacep.com.br/ws/$cep/json/';

    try {
      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        setState(() {
          _controllerCidade.text = data['localidade'];
        });

        usuarioService.ufForm = data['uf'];
        await usuarioService.save();
      } else {}
    } catch (e) {}
  }

  preencherControladorEndereco() async {
    var usuarioService = Provider.of<UsuarioService>(context, listen: false);

    setState(() {
      _controllerCep.text = usuarioService.usuario.motorista['cep'] != null
          ? usuarioService.usuario.motorista['cep']
          : "";
      _controllerEndereco.text =
          usuarioService.usuario.motorista['endereco'] != null
              ? usuarioService.usuario.motorista['endereco']
              : "";
      _controllerNumero.text =
          usuarioService.usuario.motorista['numero_endereco'] != null
              ? usuarioService.usuario.motorista['numero_endereco']
              : "";
      _controllerComplemento.text =
          usuarioService.usuario.motorista['complemento'] != null
              ? usuarioService.usuario.motorista['complemento']
              : "";
      _controllerBairro.text =
          usuarioService.usuario.motorista['bairro'] != null
              ? usuarioService.usuario.motorista['bairro']
              : "";
      _controllerUf.text = usuarioService.usuario.motorista['uf'] != null
          ? usuarioService.usuario.motorista['uf']
          : "";
      _controllerCidade.text =
          usuarioService.usuario.motorista['cidade'] != null
              ? usuarioService.usuario.motorista['cidade']
              : "";
    });
  }

  salvarEndereco() async {
    var usuarioService = Provider.of<UsuarioService>(context, listen: false);
    usuarioService.dadosEnderecoForm = {
      "cep": _controllerCep.text,
      "endereco": _controllerEndereco.text,
      "numero_endereco": _controllerNumero.text,
      "complemento": _controllerComplemento.text,
      "bairro": _controllerBairro.text,
      "uf": _controllerUf.text,
      "cidade": _controllerCidade.text
    };
    await usuarioService.save();
    var resultado = await usuarioService.salvarDadosEndereco();

    if (resultado == true) {
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => MeuCadastroScreen(),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    var usuarioService = Provider.of<UsuarioService>(context, listen: true);

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_ios_new,
            color: Colors.orange,
            size: 25,
          ),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => MeuCadastroScreen(),
              ),
            );
          },
        ),
        title: Text(
          "Dados endereço",
          style: TextStyle(fontSize: 17, color: Colors.black),
        ),
        elevation: 0,
        centerTitle: true,
        backgroundColor: Colors.white,
        actions: <Widget>[
          Container(
            padding: EdgeInsets.all(17),
            margin: EdgeInsets.only(right: 20),
            child: Text(
              "4 de 5",
              style: TextStyle(
                  color: Colors.grey,
                  fontSize: 18,
                  fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
      body: WillPopScope(
        onWillPop: () async {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => MeuCadastroScreen(),
            ),
          );
          return false;
        },
        child: Padding(
          padding: EdgeInsets.all(15),
          child: Material(
            type: MaterialType.transparency,
            child: new SingleChildScrollView(
              child: Container(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    SizedBox(height: 25),
                    TextField(
                      controller: _controllerCep,
                      inputFormatters: [
                        MaskTextInputFormatter(
                          mask: '#####-###',
                          filter: {"#": RegExp(r'[0-9]')},
                        )
                      ],
                      onChanged: (value) {
                        if (value.length == 9) {
                          _buscarEndereco(value);
                        }
                      },
                      decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        enabledBorder: OutlineInputBorder(
                          borderSide:
                              BorderSide(width: 1, color: Colors.grey.shade200),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide:
                              BorderSide(width: 1, color: Colors.grey.shade200),
                        ),
                        label: Text(
                          "CEP",
                          style: TextStyle(color: Colors.grey.shade500),
                        ),
                      ),
                    ),
                    SizedBox(height: 25),
                    Row(
                      children: <Widget>[
                        Container(
                          child: Flexible(
                            child: TextField(
                              controller: _controllerEndereco,
                              decoration: InputDecoration(
                                border: OutlineInputBorder(),
                                enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                      width: 1, color: Colors.grey.shade200),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                      width: 1, color: Colors.grey.shade200),
                                ),
                                label: Text(
                                  "Endereço",
                                  style: TextStyle(color: Colors.grey.shade500),
                                ),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(width: 5),
                        Container(
                          width: 100,
                          child: TextField(
                            controller: _controllerNumero,
                            decoration: InputDecoration(
                              border: OutlineInputBorder(),
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    width: 1, color: Colors.grey.shade200),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    width: 1, color: Colors.grey.shade200),
                              ),
                              label: Text(
                                "Número",
                                style: TextStyle(color: Colors.grey.shade500),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 25),
                    TextField(
                      controller: _controllerComplemento,
                      decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        enabledBorder: OutlineInputBorder(
                          borderSide:
                              BorderSide(width: 1, color: Colors.grey.shade200),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide:
                              BorderSide(width: 1, color: Colors.grey.shade200),
                        ),
                        label: Text(
                          "Complemento",
                          style: TextStyle(color: Colors.grey.shade500),
                        ),
                      ),
                    ),
                    SizedBox(height: 25),
                    TextField(
                      controller: _controllerBairro,
                      decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        enabledBorder: OutlineInputBorder(
                          borderSide:
                              BorderSide(width: 1, color: Colors.grey.shade200),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide:
                              BorderSide(width: 1, color: Colors.grey.shade200),
                        ),
                        label: Text(
                          "Bairro",
                          style: TextStyle(color: Colors.grey.shade500),
                        ),
                      ),
                    ),
                    SizedBox(height: 25),
                    Row(
                      children: <Widget>[
                        Container(
                          child: Flexible(
                            child: Autocomplete<String>(
                              optionsBuilder:
                                  (TextEditingValue textEditingValue) {
                                if (textEditingValue.text == '') {
                                  return siglasEstados;
                                }
                                return siglasEstados.where((string) {
                                  return string.toLowerCase().contains(
                                      textEditingValue.text.toLowerCase());
                                });
                              },
                              initialValue: TextEditingValue(
                                  text: usuarioService
                                              .usuario.motorista['uf'] !=
                                          null
                                      ? usuarioService.usuario.motorista['uf']
                                      : _controllerUf.text),
                              onSelected: (selectedUf) {
                                setState(() {
                                  _controllerUf.text = selectedUf;
                                });
                                debugPrint('You just selected $selectedUf');
                              },
                              fieldViewBuilder: (
                                BuildContext context,
                                TextEditingController controller,
                                FocusNode focusNode,
                                VoidCallback onFieldSubmitted,
                              ) {
                                return TextField(
                                  controller: controller,
                                  focusNode: focusNode,
                                  onSubmitted: (String value) {
                                    onFieldSubmitted();
                                  },
                                  decoration: InputDecoration(
                                    hintText: 'UF',
                                    border: OutlineInputBorder(),
                                    enabledBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          width: 1,
                                          color: Colors.grey.shade200),
                                    ),
                                    focusedBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          width: 1,
                                          color: Colors.grey.shade200),
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                        ),
                        SizedBox(width: 5),
                        Container(
                          child: Flexible(
                            child: TextField(
                              controller: _controllerCidade,
                              decoration: InputDecoration(
                                border: OutlineInputBorder(),
                                enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                      width: 1, color: Colors.grey.shade200),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                      width: 1, color: Colors.grey.shade200),
                                ),
                                label: Text(
                                  "Cidade",
                                  style: TextStyle(color: Colors.grey.shade500),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 25),
                    SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          elevation: 0,
                          backgroundColor: AppColors.buttonSecondary,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(6),
                            side: BorderSide(color: AppColors.buttonBorderSecondary),
                          ),
                          minimumSize: Size(100, 40),
                        ),
                        onPressed: () async {
                          await salvarEndereco();
                        },
                        child: Text(
                          "Próximo",
                          style: TextStyle(fontSize: 18),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
