import 'dart:async';

import 'package:aondeir_motorista/screens/Usuario/Menu/MeuCadastro/MeuCadastroScreen.dart';
import 'package:aondeir_motorista/service/UsuarioService.dart';
import 'package:aondeir_motorista/styles/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:provider/provider.dart';

import '../../../../../models/Banco.dart';
import '../../../../../service/BancoService.dart';

class MeuCadastroContaBancariaScreen extends StatefulWidget {
  const MeuCadastroContaBancariaScreen({super.key});

  @override
  State<MeuCadastroContaBancariaScreen> createState() =>
      _MeuCadastroContaBancariaScreenState();
}

class _MeuCadastroContaBancariaScreenState
    extends State<MeuCadastroContaBancariaScreen> {
  TextEditingController _controllerNomeTitular = TextEditingController();
  TextEditingController _controllerDocumentoTipo = TextEditingController();
  TextEditingController _controllerNumeroDocumento = TextEditingController();
  TextEditingController _controllerBanco = TextEditingController();
  TextEditingController _controllerAgencia = TextEditingController();
  TextEditingController _controllerAgenciaDigito = TextEditingController();
  TextEditingController _controllerContaTipo = TextEditingController();
  TextEditingController _controllerContaNumero = TextEditingController();
  TextEditingController _controllerContaDigito = TextEditingController();

  var tipoDocumentoSelecionado;
  var tipoContaSelecionado;
  var bancoSelecionado;
  var bancoSelecionadoTexto = "";

  bool isLoading = false;
  String dotText = '';
  late Timer timer;
  int dotCount = 1;

  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      await pegarDadosBancarios();
      await pegarBancos();
    });
  }

  setLoaderTrue() async {
    setState(() {
      isLoading = true;
      dotCount = 1;
    });
  }

  setTime() async {
    timer = Timer.periodic(Duration(seconds: 1), (timer) {
      setState(() {
        dotCount = (dotCount % 4) + 1;
      });

      if (dotCount == 1) {
        setState(() {
          dotText = '';
        });
      }
      if (dotCount == 2) {
        setState(() {
          dotText = '.';
        });
      }
      if (dotCount == 3) {
        setState(() {
          dotText = '..';
        });
      }
      if (dotCount == 4) {
        setState(() {
          dotText = '...';
        });
      }
    });
  }

  pegarDadosBancarios() async {
    var usuarioService = Provider.of<UsuarioService>(context, listen: false);

    setState(() {
      _controllerDocumentoTipo.text = "FISICA";
    });

    await usuarioService.pegarDadosBancarios();
    if (usuarioService.usuario.dados_bancarios != null) {
      setState(() {
        _controllerNomeTitular.text =
            usuarioService.usuario.dados_bancarios['nome_titular'];
        _controllerNumeroDocumento.text =
            usuarioService.usuario.dados_bancarios['numero_documento_titular'];
        _controllerBanco.text = usuarioService.usuario.dados_bancarios['banco']
                ['codigo'] +
            " - " +
            usuarioService.usuario.dados_bancarios['banco']['name'];
        _controllerAgencia.text =
            usuarioService.usuario.dados_bancarios['numero_agencia'];

        if (usuarioService.usuario.dados_bancarios['digito_validacao_agencia']
            .toString()
            .isNotEmpty) {
          _controllerAgenciaDigito.text = usuarioService
              .usuario.dados_bancarios['digito_validacao_agencia'];
        }

        _controllerContaNumero.text =
            usuarioService.usuario.dados_bancarios['numero_conta'];
        _controllerContaDigito.text =
            usuarioService.usuario.dados_bancarios['digito_validacao_conta'];
        _controllerDocumentoTipo.text =
            usuarioService.usuario.dados_bancarios['tipo_documento'];
        _controllerContaTipo.text =
            usuarioService.usuario.dados_bancarios['tipo_conta'];
      });
    }
  }

  pegarBancos() async {
    var bancoService = Provider.of<BancoService>(context, listen: false);
    await bancoService.pegarBancos();
  }

  cadastrar() async {
    try {
      var usuarioService = Provider.of<UsuarioService>(context, listen: false);

      var dataForm = {
        "nome_titular": _controllerNomeTitular.text,
        "documento_tipo_titular": _controllerDocumentoTipo.text,
        "documento_titular": _controllerNumeroDocumento.text,
        "banco": bancoSelecionado.toString(),
        "agencia": _controllerAgencia.text,
        "agencia_digito": _controllerAgenciaDigito.text,
        "conta_tipo": _controllerContaTipo.text,
        "conta_numero": _controllerContaNumero.text,
        "conta_digito": _controllerContaDigito.text,
      };

      var resultado = await usuarioService.cadastrarContaBancaria(dataForm);

      timer.cancel();

      if (resultado == true) {
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => MeuCadastroScreen(),
          ),
        );
      } else if (resultado == false) {
        setState(() {
          isLoading = false;
        });
        timer.cancel();
      }
    } catch (e) {
      throw e;
    }
  }

  @override
  Widget build(BuildContext context) {
    var usuarioService = Provider.of<UsuarioService>(context, listen: true);
    var bancoService = Provider.of<BancoService>(context, listen: true);

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_ios_new,
            color: Colors.orange,
            size: 25,
          ),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => MeuCadastroScreen(),
              ),
            );
          },
        ),
        title: Text(
          "Dados Bancários",
          style: TextStyle(fontSize: 17, color: Colors.black),
        ),
        elevation: 0,
        centerTitle: true,
        backgroundColor: Colors.white,
      ),
      body: WillPopScope(
        onWillPop: () async {
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (_) => MeuCadastroScreen(),
            ),
          );
          return false;
        },
        child: Padding(
          padding: EdgeInsets.all(15),
          child: Material(
            type: MaterialType.transparency,
            child: new SingleChildScrollView(
              child: Container(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      "O número do documento do titular deve ser igual ao documento cadastrado no seu usuário!",
                      style: TextStyle(
                        color: Colors.grey,
                        fontSize: 17,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    SizedBox(height: 25),
                    Row(children: <Widget>[
                      Container(
                        child: Flexible(
                          child: TextField(
                            enabled: true,
                            controller: _controllerNomeTitular,
                            maxLength: 30,
                            decoration: InputDecoration(
                              border: OutlineInputBorder(),
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    width: 1, color: Colors.grey.shade200),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    width: 1, color: Colors.grey.shade200),
                              ),
                              label: Text(
                                "Nome titular (Obrigatório)",
                                style: TextStyle(color: Colors.grey.shade500),
                              ),
                              errorText: usuarioService
                                          .errorsForm['nome_titular'] !=
                                      null
                                  ? usuarioService.errorsForm['nome_titular']
                                      .toString()
                                  : null,
                            ),
                          ),
                        ),
                      ),
                    ]),
                    SizedBox(height: 10),
                    Row(
                      children: <Widget>[
                        Container(
                          child: Flexible(
                            child: TextField(
                              enabled: true,
                              controller: _controllerDocumentoTipo,
                              decoration: InputDecoration(
                                border: OutlineInputBorder(),
                                enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                      width: 1, color: Colors.grey.shade200),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                      width: 1, color: Colors.grey.shade200),
                                ),
                                label: Text(
                                  "Selecione tipo do documento (Obrigatório)",
                                  style: TextStyle(color: Colors.grey.shade500),
                                ),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(width: 5),
                        Container(
                          child: Flexible(
                            child: TextField(
                              onChanged: (value) {},
                              enabled: true,
                              controller: _controllerNumeroDocumento,
                              inputFormatters: [
                                MaskTextInputFormatter(
                                    mask: "###.###.###-##",
                                    filter: {"#": RegExp(r'[0-9]')})
                              ],
                              decoration: InputDecoration(
                                border: OutlineInputBorder(),
                                enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                      width: 1, color: Colors.grey.shade200),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                      width: 1, color: Colors.grey.shade200),
                                ),
                                label: Text(
                                  "CPF (Obrigatório)",
                                  style: TextStyle(color: Colors.grey.shade500),
                                ),
                                errorText: usuarioService
                                            .errorsForm['documento_titular'] !=
                                        null
                                    ? usuarioService
                                        .errorsForm['documento_titular']
                                    : null,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 20),
                    Row(children: <Widget>[
                      Container(
                        child: Flexible(
                          child: TextField(
                            enabled: true,
                            onChanged: (value) {},
                            controller: _controllerAgencia,
                            maxLength: 4,
                            decoration: InputDecoration(
                              border: OutlineInputBorder(),
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    width: 1, color: Colors.grey.shade200),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    width: 1, color: Colors.grey.shade200),
                              ),
                              label: Text(
                                "Agência (Obrigatório)",
                                style: TextStyle(color: Colors.grey.shade500),
                              ),
                              errorText:
                                  usuarioService.errorsForm['agencia'] != null
                                      ? usuarioService.errorsForm['agencia']
                                      : null,
                            ),
                          ),
                        ),
                      ),
                      SizedBox(width: 5),
                      Container(
                        child: Flexible(
                          child: TextField(
                            enabled: true,
                            onChanged: (value) {},
                            controller: _controllerAgenciaDigito,
                            maxLength: 1,
                            decoration: InputDecoration(
                              border: OutlineInputBorder(),
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    width: 1, color: Colors.grey.shade200),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    width: 1, color: Colors.grey.shade200),
                              ),
                              label: Text(
                                "Dígito agência",
                                style: TextStyle(color: Colors.grey.shade500),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ]),
                    SizedBox(height: 10),
                    Row(
                      children: <Widget>[
                        usuarioService.usuario.dados_bancarios != null
                            ? Container(
                                child: Flexible(
                                  child: TextField(
                                    enabled: true,
                                    controller: _controllerBanco,
                                    decoration: InputDecoration(
                                      border: OutlineInputBorder(),
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            width: 1,
                                            color: Colors.grey.shade200),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            width: 1,
                                            color: Colors.grey.shade200),
                                      ),
                                      label: Text(
                                        "Digite um banco (Obrigatório)",
                                        style: TextStyle(
                                            color: Colors.grey.shade500),
                                      ),
                                    ),
                                  ),
                                ),
                              )
                            : Container(
                                child: Flexible(
                                  child: Autocomplete<Banco>(
                                    optionsBuilder:
                                        (TextEditingValue textEditingValue) {
                                      if (textEditingValue.text == '') {
                                        return bancoService.bancos;
                                      }
                                      return bancoService.bancos.where((banco) {
                                        var label =
                                            banco.codigo + " - " + banco.name;
                                        return label.toLowerCase().contains(
                                            textEditingValue.text
                                                .toLowerCase());
                                      });
                                    },
                                    initialValue: TextEditingValue(
                                        text: _controllerBanco.text),
                                    onSelected: (Banco selectedBanco) {
                                      setState(() {
                                        bancoSelecionado = selectedBanco.id;
                                      });
                                    },
                                    displayStringForOption: (Banco option) =>
                                        option.codigo + " - " + option.name,
                                    fieldViewBuilder: (BuildContext context,
                                        TextEditingController controller,
                                        FocusNode focusNode,
                                        VoidCallback onFieldSubmitted) {
                                      return TextField(
                                        controller: controller,
                                        focusNode: focusNode,
                                        onSubmitted: (String value) {
                                          onFieldSubmitted();
                                        },
                                        decoration: InputDecoration(
                                          hintText:
                                              'Digite um banco (Obrigatório)',
                                          border: OutlineInputBorder(),
                                          enabledBorder: OutlineInputBorder(
                                            borderSide: BorderSide(
                                                width: 1,
                                                color: Colors.grey.shade200),
                                          ),
                                          focusedBorder: OutlineInputBorder(
                                            borderSide: BorderSide(
                                                width: 1,
                                                color: Colors.grey.shade200),
                                          ),
                                        ),
                                      );
                                    },
                                  ),
                                ),
                              ),
                        SizedBox(width: 5),
                        usuarioService.usuario.dados_bancarios != null
                            ? Container(
                                child: Flexible(
                                  child: TextField(
                                    enabled: true,
                                    controller: _controllerContaTipo,
                                    decoration: InputDecoration(
                                      border: OutlineInputBorder(),
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            width: 1,
                                            color: Colors.grey.shade200),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            width: 1,
                                            color: Colors.grey.shade200),
                                      ),
                                      label: Text(
                                        "Selecione tipo da conta (Obrigatório)",
                                        style: TextStyle(
                                            color: Colors.grey.shade500),
                                      ),
                                    ),
                                  ),
                                ),
                              )
                            : Container(
                                child: Flexible(
                                  child: Autocomplete<String>(
                                    optionsBuilder:
                                        (TextEditingValue textEditingValue) {
                                      if (textEditingValue.text == '') {
                                        return ["POUPANCA", "CORRENTE"];
                                      }
                                      return ["POUPANCA", "CORRENTE"]
                                          .where((string) {
                                        return string.toLowerCase().contains(
                                            textEditingValue.text
                                                .toLowerCase());
                                      });
                                    },
                                    initialValue: TextEditingValue(
                                        text: _controllerContaTipo.text),
                                    onSelected: (selectedTipoConta) {
                                      setState(() {
                                        _controllerContaTipo.text =
                                            selectedTipoConta;
                                      });
                                    },
                                    displayStringForOption: (String option) =>
                                        option,
                                    fieldViewBuilder: (BuildContext context,
                                        TextEditingController controller,
                                        FocusNode focusNode,
                                        VoidCallback onFieldSubmitted) {
                                      return TextField(
                                        controller: controller,
                                        focusNode: focusNode,
                                        onSubmitted: (String value) {
                                          onFieldSubmitted();
                                        },
                                        decoration: InputDecoration(
                                          hintText:
                                              'Selecione tipo da conta (Obrigatório)',
                                          border: OutlineInputBorder(),
                                          enabledBorder: OutlineInputBorder(
                                            borderSide: BorderSide(
                                                width: 1,
                                                color: Colors.grey.shade200),
                                          ),
                                          focusedBorder: OutlineInputBorder(
                                            borderSide: BorderSide(
                                                width: 1,
                                                color: Colors.grey.shade200),
                                          ),
                                        ),
                                      );
                                    },
                                  ),
                                ),
                              ),
                      ],
                    ),
                    SizedBox(height: 20),
                    Row(
                      children: <Widget>[
                        Container(
                            child: Flexible(
                          child: TextField(
                            onChanged: (value) {},
                            enabled: true,
                            controller: _controllerContaNumero,
                            maxLength: 13,
                            decoration: InputDecoration(
                              border: OutlineInputBorder(),
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    width: 1, color: Colors.grey.shade200),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    width: 1, color: Colors.grey.shade200),
                              ),
                              label: Text(
                                "Número da conta (Obrigatório)",
                                style: TextStyle(color: Colors.grey.shade500),
                              ),
                              errorText: usuarioService
                                          .errorsForm['conta_numero'] !=
                                      null
                                  ? usuarioService.errorsForm['conta_numero']
                                  : null,
                            ),
                          ),
                        )),
                        SizedBox(width: 5),
                        Container(
                          width: 120,
                          child: TextField(
                            onChanged: (value) {},
                            enabled: true,
                            controller: _controllerContaDigito,
                            maxLength: 2,
                            decoration: InputDecoration(
                              border: OutlineInputBorder(),
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    width: 1, color: Colors.grey.shade200),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    width: 1, color: Colors.grey.shade200),
                              ),
                              label: Text(
                                "Dígito da conta (Obrigatório)",
                                style: TextStyle(color: Colors.grey.shade500),
                              ),
                              errorText: usuarioService
                                          .errorsForm['conta_digito'] !=
                                      null
                                  ? usuarioService.errorsForm['conta_digito']
                                  : null,
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 10),
                    SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          elevation: 0,
                          backgroundColor: AppColors.buttonSecondary,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(6),
                            side: BorderSide(color: Colors.white),
                          ),
                          minimumSize: Size(100, 40),
                        ),
                        onPressed: () async {
                          await cadastrar();
                        },
                        child: Row(children: [
                          Expanded(
                            child: Align(
                              alignment: Alignment.center,
                              child: Text(
                                'Salvar',
                                style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  fontSize: 21,
                                  letterSpacing: 2,
                                ),
                              ),
                            ),
                          )
                        ]),
                      ),
                    )
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
