import 'package:aondeir_motorista/screens/Usuario/Menu/MenuScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/MeuCadastro/Documentos/CondicoesDocumentoScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/MeuCadastro/Endereco/EnderecoScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/MeuCadastro/FotoRosto/CondicoesScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/MeuCadastro/Veiculo/CarroScreen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:provider/provider.dart';
import '../../../../service/DocumentoService.dart';
import '../../../../service/UsuarioService.dart';
import 'DadosPessoais/MeuCadastroDadosPessoaisScreen.dart';
import 'contaBancaria/MeuCadastroContaBancariaScreen.dart';

class MeuCadastroScreen extends StatefulWidget {
  const MeuCadastroScreen({super.key});

  @override
  State<MeuCadastroScreen> createState() => _MeuCadastroScreenState();
}

class _MeuCadastroScreenState extends State<MeuCadastroScreen> {
  final storage = new FlutterSecureStorage();
  var mensagem =
      "Qualquer alteração no cadastro, seus dados serão reavaliado pela franquia, você nao recebera corridas enquando o cadastro não for aprovado!";
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {});
  }

  isCadastroCompleto() async {
    var usuarioService = Provider.of<UsuarioService>(context, listen: false);
    if (usuarioService.etapaCadastro['dados_pessoais'] == 1 &&
        usuarioService.etapaCadastro['foto_perfil'] == 1 &&
        usuarioService.etapaCadastro['dados_bancarios'] == 1 &&
        usuarioService.etapaCadastro['endereco'] == 1 &&
        usuarioService.etapaCadastro['antecedente_criminal'] == 1 &&
        usuarioService.etapaCadastro['cnh'] == 1 &&
        usuarioService.etapaCadastro['comprovante_residencia'] == 1 &&
        usuarioService.etapaCadastro['crlv'] == 1 &&
        usuarioService.etapaCadastro['veiculo_frontal'] == 1 &&
        usuarioService.etapaCadastro['veiculo_traseira'] == 1) {
      showModalPagamento();
    }
  }

  showModalPagamento() async {
    return (showDialog<String>(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        title: const Text('Aviso importante'),
        content: const Text(
            'Seus documentos e dados irão passar por análise de nossa equipe interna, aguarde, esse processo leva de 2 a 5 dias úteis, Obrigado!'),
        actions: <Widget>[
          InkWell(
            onTap: () {
              Navigator.pop(context, "Nao");
            },
            child: Padding(
              padding: EdgeInsets.all(15),
              child: Text(
                'Ok',
                style: TextStyle(color: Colors.orange),
              ),
            ),
          ),
        ],
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    var documentoService =
        Provider.of<DocumentoService>(context, listen: false);
    var usuarioService = Provider.of<UsuarioService>(context, listen: false);
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: usuarioService.usuario.motorista['situacao_cadastral'] == 'ATIVO' ? IconButton(
          icon: Icon(
            Icons.arrow_back_ios_new,
            color: Colors.orange,
            size: 25,
          ),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => MenuScreen(),
              ),
            );
          } ,
        ) : null,
        title: Text(
          "Meu Cadastro",
          style: TextStyle(fontSize: 17, color: Colors.black),
        ),
        elevation: 0,
        centerTitle: true,
        backgroundColor: Colors.white,
      ),
      body: WillPopScope(
        onWillPop: () async {
          return true;
        },
        child: Padding(
          padding: EdgeInsets.all(15),
          child: Material(
            type: MaterialType.transparency,
            child: new SingleChildScrollView(
              child: Container(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      mensagem,
                      style: TextStyle(
                        color: Colors.grey,
                        fontSize: 17,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    SizedBox(height: 30),
                    InkWell(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => MeuCadastroDadosPessoaisScreen(),
                          ),
                        );
                      },
                      child: Row(
                        children: <Widget>[
                          Container(
                            padding: EdgeInsets.all(20),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: usuarioService
                                          .etapaCadastro['dados_pessoais'] ==
                                      1
                                  ? Colors.green.withOpacity(0.2)
                                  : Colors.grey.withOpacity(0.2),
                            ),
                            child: Text(
                              "1",
                              style: TextStyle(
                                color: Colors.grey,
                                fontSize: 25,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          SizedBox(width: 15),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(
                                "Dados pessoais",
                                style: TextStyle(
                                  color: Colors.grey[800],
                                  fontSize: 17,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              SizedBox(height: 8),
                              if (usuarioService
                                      .etapaCadastro['dados_pessoais'] ==
                                  1)
                                Text(
                                  "Completo",
                                  style: TextStyle(
                                    color: Colors.green,
                                    fontSize: 16,
                                    fontWeight: FontWeight.normal,
                                  ),
                                )
                            ],
                          ),
                          Spacer(),
                          Icon(
                            Icons.arrow_forward_ios,
                            color: Colors.grey,
                            size: 20,
                          )
                        ],
                      ),
                    ),
                    Divider(),
                    InkWell(
                      onTap: () async {
                        documentoService.tipoDocumento = "FOTO_PERFIL";
                        await documentoService.save();
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => CondicoesScreen(),
                          ),
                        );
                      },
                      child: Row(
                        children: <Widget>[
                          Container(
                            padding: EdgeInsets.all(20),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color:
                                  usuarioService.etapaCadastro['foto_perfil'] ==
                                          1
                                      ? Colors.green.withOpacity(0.2)
                                      : Colors.grey.withOpacity(0.2),
                            ),
                            child: Text(
                              "2",
                              style: TextStyle(
                                color: Colors.grey,
                                fontSize: 25,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          SizedBox(width: 15),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(
                                "Foto do rosto",
                                style: TextStyle(
                                  color: Colors.grey[800],
                                  fontSize: 17,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              SizedBox(height: 8),
                              if (usuarioService.etapaCadastro['foto_perfil'] ==
                                  1)
                                Text(
                                  "Completo",
                                  style: TextStyle(
                                    color: Colors.green,
                                    fontSize: 16,
                                    fontWeight: FontWeight.normal,
                                  ),
                                )
                            ],
                          ),
                          Spacer(),
                          Icon(
                            Icons.arrow_forward_ios,
                            color: Colors.grey,
                            size: 20,
                          )
                        ],
                      ),
                    ),
                    Divider(),
                    // InkWell(
                    //   onTap: () {
                    //     Navigator.push(
                    //       context,
                    //       MaterialPageRoute(
                    //         builder: (_) => MeuCadastroContaBancariaScreen(),
                    //       ),
                    //     );
                    //   },
                      // child: Row(
                      //   children: <Widget>[
                      //     Container(
                      //       padding: EdgeInsets.all(20),
                      //       decoration: BoxDecoration(
                      //         shape: BoxShape.circle,
                      //         color: usuarioService
                      //                     .etapaCadastro['dados_bancarios'] ==
                      //                 1
                      //             ? Colors.green.withOpacity(0.2)
                      //             : Colors.grey.withOpacity(0.2),
                      //       ),
                      //       child: Text(
                      //         "3",
                      //         style: TextStyle(
                      //           color: Colors.grey,
                      //           fontSize: 25,
                      //           fontWeight: FontWeight.bold,
                      //         ),
                      //       ),
                      //     ),
                      //     SizedBox(width: 15),
                      //     Column(
                      //       crossAxisAlignment: CrossAxisAlignment.start,
                      //       children: <Widget>[
                      //         Text(
                      //           "Dados bancários",
                      //           style: TextStyle(
                      //             color: Colors.grey[800],
                      //             fontSize: 17,
                      //             fontWeight: FontWeight.bold,
                      //           ),
                      //         ),
                      //         SizedBox(height: 8),
                      //         if (usuarioService
                      //                 .etapaCadastro['dados_bancarios'] ==
                      //             1)
                      //           Text(
                      //             "Completo",
                      //             style: TextStyle(
                      //               color: Colors.green,
                      //               fontSize: 16,
                      //               fontWeight: FontWeight.normal,
                      //             ),
                      //           )
                      //       ],
                      //     ),
                      //     Spacer(),
                      //     Icon(
                      //       Icons.arrow_forward_ios,
                      //       color: Colors.grey,
                      //       size: 20,
                      //     )
                      //   ],
                      // ),
                    // ),
                    Divider(),
                    InkWell(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => EnderecoScreen(),
                          ),
                        );
                      },
                      child: Row(
                        children: <Widget>[
                          Container(
                            padding: EdgeInsets.all(20),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color:
                                  usuarioService.etapaCadastro['endereco'] == 1
                                      ? Colors.green.withOpacity(0.2)
                                      : Colors.grey.withOpacity(0.2),
                            ),
                            child: Text(
                              "4",
                              style: TextStyle(
                                color: Colors.grey,
                                fontSize: 25,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          SizedBox(width: 15),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(
                                "Endereço",
                                style: TextStyle(
                                  color: Colors.grey[800],
                                  fontSize: 17,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              SizedBox(height: 8),
                              if (usuarioService.etapaCadastro['endereco'] == 1)
                                Text(
                                  "Completo",
                                  style: TextStyle(
                                    color: Colors.green,
                                    fontSize: 16,
                                    fontWeight: FontWeight.normal,
                                  ),
                                ),
                            ],
                          ),
                          Spacer(),
                          Icon(
                            Icons.arrow_forward_ios,
                            color: Colors.grey,
                            size: 20,
                          )
                        ],
                      ),
                    ),
                    Divider(),
                    InkWell(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => CarroScreen(),
                          ),
                        );
                      },
                      child: Row(
                        children: <Widget>[
                          Container(
                            padding: EdgeInsets.all(20),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color:
                                  usuarioService.etapaCadastro['veiculo'] == 1
                                      ? Colors.green.withOpacity(0.2)
                                      : Colors.grey.withOpacity(0.2),
                            ),
                            child: Text(
                              "5",
                              style: TextStyle(
                                color: Colors.grey,
                                fontSize: 25,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          SizedBox(width: 15),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(
                                "Veículo",
                                style: TextStyle(
                                  color: Colors.grey[800],
                                  fontSize: 17,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              SizedBox(height: 8),
                              if (usuarioService.etapaCadastro['veiculo'] == 1)
                                Text(
                                  "Completo",
                                  style: TextStyle(
                                    color: Colors.green,
                                    fontSize: 16,
                                    fontWeight: FontWeight.normal,
                                  ),
                                ),
                            ],
                          ),
                          Spacer(),
                          Icon(
                            Icons.arrow_forward_ios,
                            color: Colors.grey,
                            size: 20,
                          )
                        ],
                      ),
                    ),
                    Divider(),
                    // InkWell(
                    //   onTap: () async {
                    //     documentoService.tipoDocumento = "ANTECEDENTE_CRIMINAL";
                    //     await documentoService.save();

                    //     Navigator.push(
                    //       context,
                    //       MaterialPageRoute(
                    //         builder: (_) => CondicoesDocumentoScreen(),
                    //       ),
                    //     );
                    //   },
                    //   child: Row(
                    //     children: <Widget>[
                    //       Container(
                    //         padding: EdgeInsets.all(20),
                    //         decoration: BoxDecoration(
                    //           shape: BoxShape.circle,
                    //           color: usuarioService.etapaCadastro[
                    //                       'antecedente_criminal'] ==
                    //                   1
                    //               ? Colors.green.withOpacity(0.2)
                    //               : Colors.grey.withOpacity(0.2),
                    //         ),
                    //         child: Text(
                    //           "6",
                    //           style: TextStyle(
                    //             color: Colors.grey,
                    //             fontSize: 25,
                    //             fontWeight: FontWeight.bold,
                    //           ),
                    //         ),
                    //       ),
                    //       SizedBox(width: 15),
                    //       // Column(
                    //       //   crossAxisAlignment: CrossAxisAlignment.start,
                    //       //   children: <Widget>[
                    //       //     Text(
                    //       //       "Certidão de antecedentes criminais",
                    //       //       style: TextStyle(
                    //       //         color: Colors.grey[800],
                    //       //         fontSize: 17,
                    //       //         fontWeight: FontWeight.bold,
                    //       //       ),
                    //       //     ),
                    //       //     SizedBox(height: 8),
                    //       //   ],
                    //       // ),
                    //       Spacer(),
                    //       Icon(
                    //         Icons.arrow_forward_ios,
                    //         color: Colors.grey,
                    //         size: 20,
                    //       )
                    //     ],
                    //   ),
                    // ),
                    // Divider(),
                    InkWell(
                      onTap: () async {
                        documentoService.tipoDocumento = "CNH";
                        await documentoService.save();
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => CondicoesDocumentoScreen(),
                          ),
                        );
                      },
                      child: Row(
                        children: <Widget>[
                          Container(
                            padding: EdgeInsets.all(20),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: usuarioService.etapaCadastro['cnh'] == 1
                                  ? Colors.green.withOpacity(0.2)
                                  : Colors.grey.withOpacity(0.2),
                            ),
                            child: Text(
                              "6",
                              style: TextStyle(
                                color: Colors.grey,
                                fontSize: 25,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          SizedBox(width: 15),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(
                                "CNH",
                                style: TextStyle(
                                  color: Colors.grey[800],
                                  fontSize: 17,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                          Spacer(),
                          Icon(
                            Icons.arrow_forward_ios,
                            color: Colors.grey,
                            size: 20,
                          )
                        ],
                      ),
                    ),
                    Divider(),
                    InkWell(
                      onTap: () async {
                        documentoService.tipoDocumento =
                            "COMPROVANTE_RESIDENCIA";
                        await documentoService.save();
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => CondicoesDocumentoScreen(),
                          ),
                        );
                      },
                      child: Row(
                        children: <Widget>[
                          Container(
                            padding: EdgeInsets.all(20),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: usuarioService.etapaCadastro[
                                          'comprovante_residencia'] ==
                                      1
                                  ? Colors.green.withOpacity(0.2)
                                  : Colors.grey.withOpacity(0.2),
                            ),
                            child: Text(
                              "7",
                              style: TextStyle(
                                color: Colors.grey,
                                fontSize: 25,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          SizedBox(width: 15),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(
                                "Comprovante de residência:",
                                style: TextStyle(
                                  color: Colors.grey[800],
                                  fontSize: 17,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                          Spacer(),
                          Icon(
                            Icons.arrow_forward_ios,
                            color: Colors.grey,
                            size: 20,
                          )
                        ],
                      ),
                    ),
                    Divider(),
                    InkWell(
                      onTap: () async {
                        documentoService.tipoDocumento = "CRLV";
                        await documentoService.save();
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => CondicoesDocumentoScreen(),
                          ),
                        );
                      },
                      child: Row(
                        children: <Widget>[
                          Container(
                            padding: EdgeInsets.all(20),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: usuarioService.etapaCadastro['crlv'] == 1
                                  ? Colors.green.withOpacity(0.2)
                                  : Colors.grey.withOpacity(0.2),
                            ),
                            child: Text(
                              "9",
                              style: TextStyle(
                                color: Colors.grey,
                                fontSize: 25,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          SizedBox(width: 15),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(
                                "CRLV (Certidão de Registro",
                                style: TextStyle(
                                  color: Colors.grey[800],
                                  fontSize: 17,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Text(
                                "Licenciamento do veículo)",
                                style: TextStyle(
                                  color: Colors.grey[800],
                                  fontSize: 17,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                          Spacer(),
                          Icon(
                            Icons.arrow_forward_ios,
                            color: Colors.grey,
                            size: 20,
                          )
                        ],
                      ),
                    ),
                    Divider(),
                    // InkWell(
                    //   onTap: () async {
                    //     documentoService.tipoDocumento = "VEICULO_FRONTAL";
                    //     await documentoService.save();
                    //     Navigator.push(
                    //       context,
                    //       MaterialPageRoute(
                    //         builder: (_) => CondicoesDocumentoScreen(),
                    //       ),
                    //     );
                    //   },
                    //   child: Row(
                    //     children: <Widget>[
                    //       Container(
                    //         padding: EdgeInsets.all(20),
                    //         decoration: BoxDecoration(
                    //           shape: BoxShape.circle,
                    //           color: usuarioService
                    //                       .etapaCadastro['veiculo_frontal'] ==
                    //                   1
                    //               ? Colors.green.withOpacity(0.2)
                    //               : Colors.grey.withOpacity(0.2),
                    //         ),
                    //         child: Text(
                    //           "10",
                    //           style: TextStyle(
                    //             color: Colors.grey,
                    //             fontSize: 25,
                    //             fontWeight: FontWeight.bold,
                    //           ),
                    //         ),
                    //       ),
                    //       SizedBox(width: 15),
                    //       Column(
                    //         crossAxisAlignment: CrossAxisAlignment.start,
                    //         children: <Widget>[
                    //           Text(
                    //             "Seguro APP",
                    //             style: TextStyle(
                    //               color: Colors.grey[800],
                    //               fontSize: 17,
                    //               fontWeight: FontWeight.bold,
                    //             ),
                    //           ),
                    //         ],
                    //       ),
                    //       Spacer(),
                    //       Icon(
                    //         Icons.arrow_forward_ios,
                    //         color: Colors.grey,
                    //         size: 20,
                    //       )
                    //     ],
                    //   ),
                    // ),
                    // Divider(),
                    // InkWell(
                    //   onTap: () async {
                    //     documentoService.tipoDocumento = "VEICULO_TRASEIRA";
                    //     await documentoService.save();
                    //     Navigator.push(
                    //       context,
                    //       MaterialPageRoute(
                    //         builder: (_) => CondicoesDocumentoScreen(),
                    //       ),
                    //     );
                    //   },
                    //   child: Row(
                    //     children: <Widget>[
                    //       Container(
                    //         padding: EdgeInsets.all(20),
                    //         decoration: BoxDecoration(
                    //           shape: BoxShape.circle,
                    //           color: usuarioService
                    //                       .etapaCadastro['veiculo_traseira'] ==
                    //                   1
                    //               ? Colors.green.withOpacity(0.2)
                    //               : Colors.grey.withOpacity(0.2),
                    //         ),
                    //         child: Text(
                    //           "11",
                    //           style: TextStyle(
                    //             color: Colors.grey,
                    //             fontSize: 25,
                    //             fontWeight: FontWeight.bold,
                    //           ),
                    //         ),
                    //       ),
                    //       SizedBox(width: 15),
                    //       Column(
                    //         crossAxisAlignment: CrossAxisAlignment.start,
                    //         children: <Widget>[
                    //           Text(
                    //             "Veículo (Foto traseira)",
                    //             style: TextStyle(
                    //               color: Colors.grey[800],
                    //               fontSize: 17,
                    //               fontWeight: FontWeight.bold,
                    //             ),
                    //           ),
                    //         ],
                    //       ),
                    //       Spacer(),
                    //       Icon(
                    //         Icons.arrow_forward_ios,
                    //         color: Colors.grey,
                    //         size: 20,
                    //       )
                    //     ],
                    //   ),
                    // ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
