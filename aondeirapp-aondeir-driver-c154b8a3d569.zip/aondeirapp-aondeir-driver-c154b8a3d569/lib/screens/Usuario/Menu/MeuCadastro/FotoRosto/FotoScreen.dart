import 'dart:io';

import 'package:aondeir_motorista/models/UsuarioMotorista.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/MeuCadastro/FotoRosto/CameraScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/MeuCadastro/FotoRosto/CondicoesScreen.dart';
import 'package:aondeir_motorista/service/DocumentoService.dart';
import 'package:aondeir_motorista/styles/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:provider/provider.dart';
import '../../../../../service/UsuarioService.dart';
import '../MeuCadastroScreen.dart';
import 'package:http/http.dart' as http;
import 'dart:convert' as convert;

class FotoScreen extends StatefulWidget {
  final String imagePath;

  const FotoScreen({super.key, required this.imagePath});

  @override
  State<FotoScreen> createState() => _FotoScreenState();
}

class _FotoScreenState extends State<FotoScreen> {
  final storage = new FlutterSecureStorage();
  UsuarioMotorista? _usuario;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      await fetchUser();
    });
  }

  fetchUser() async {
    try {
      String url =
          dotenv.env['BASE_URL']! + "api/motorista/pegar-dados-pessoais";
      var token = await storage.read(key: 'jwt');
      var response = await http.get(Uri.parse(url), headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        final json = await convert.jsonDecode(response.body);
        UsuarioMotorista usuario = UsuarioMotorista.fromJson(json['usuario']);
        setState(() {
          _isLoading =
              false; 
          _usuario = usuario; 
        });
      }
    } catch (e) {
      showModalAlertError(e.toString());
    }
  }

  showModalAlertError(String message) async {
    showDialog<String>(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(12.0))),
        title: Text(
          'Ops!',
          textAlign: TextAlign.center, 
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.error,
              color: Colors.red,
              size: 50,
            ),
            SizedBox(
                height: 10), 
            Text(
              message,
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.black),
            ),
          ],
        ),
        actions: <Widget>[
          InkWell(
            onTap: () {
              Navigator.pop(context, "Fechar");
            },
            child: Padding(
              padding: EdgeInsets.only(bottom: 10, left: 15, right: 15),
              child: Text(
                'Fechar',
                style: TextStyle(color: Colors.orange),
              ),
            ),
          ),
        ],
      ),
    );
  }

  salvaFotoPerfil() async {
    var usuarioService = Provider.of<UsuarioService>(context, listen: false);
    var documentoService =
        Provider.of<DocumentoService>(context, listen: false);
    var resp =
        await usuarioService.salvarFotoPerfil(documentoService.imagePath);
    if (resp == true) {
      documentoService.imagePath = "";
      await documentoService.save();
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => MeuCadastroScreen(),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    var documentoService = Provider.of<DocumentoService>(context, listen: true);
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_ios_new,
            color: Colors.grey,
            size: 25,
          ),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => CondicoesScreen(),
              ),
            );
          },
        ),
        title: Text(
          "Foto do rosto",
          style: TextStyle(fontSize: 17, color: Colors.black),
        ),
        elevation: 0,
        centerTitle: true,
        backgroundColor: Colors.white,
      ),
      body: WillPopScope(
        onWillPop: () async {
          
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => CondicoesScreen(),
            ),
          );
          return false;
        },
        child: Material(
          type: MaterialType.transparency,
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 40, vertical: 40),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Text(
                  "Foto de perfil",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 22,
                  ),
                ),
                SizedBox(height: 10),
                Text(
                  "",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.grey,
                    fontWeight: FontWeight.w400,
                    fontSize: 18,
                  ),
                ),
                SizedBox(height: 10),
                ClipRRect(
                  borderRadius: BorderRadius.circular(10.0), 
                  child: documentoService.imagePath.isNotEmpty
                      ? Image.file(
                          File(documentoService.imagePath),
                          width: 270, 
                          height: 270, 
                          fit: BoxFit.cover,
                        )
                      : _isLoading
                          ? Image.asset(
                              "assets/notImage.jpg",
                              width: 270, 
                              height: 270, 
                              fit: BoxFit.cover,
                            )
                          : _usuario!.motorista["foto_perfil"] != null
                              ? Image.network(
                                  dotenv.env['BASE_URL']! +
                                      "images/" +
                                      _usuario!.motorista["foto_perfil"]
                                          .toString(),
                                  width: 270, 
                                  height: 270, 
                                  fit: BoxFit.cover,
                                  loadingBuilder: (BuildContext context,
                                      Widget child,
                                      ImageChunkEvent? loadingProgress) {
                                    if (loadingProgress == null) {
                                      
                                      return child;
                                    } else {
                                      
                                      return Center(
                                        child: CircularProgressIndicator(
                                          value: loadingProgress
                                                      .expectedTotalBytes !=
                                                  null
                                              ? loadingProgress
                                                      .cumulativeBytesLoaded /
                                                  loadingProgress
                                                      .expectedTotalBytes!
                                              : null,
                                        ),
                                      );
                                    }
                                  },
                                  errorBuilder: (BuildContext context,
                                      Object exception,
                                      StackTrace? stackTrace) {
                                    
                                    return Image.asset(
                                      "assets/notImage.jpg",
                                      width:
                                          270, 
                                      height:
                                          270, 
                                      fit: BoxFit.cover,
                                    );
                                  },
                                )
                              : Image.asset(
                                  "assets/notImage.jpg",
                                  width: 270, 
                                  height: 270, 
                                  fit: BoxFit.cover,
                                ),
                ),
                Container(
                  margin: EdgeInsets.only(top: 20),
                  child: Column(
                    children: <Widget>[
                      SizedBox(
                        width: double.infinity, 
                        height: 50, 
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            elevation: 0,
                            shadowColor: Colors.transparent,
                            backgroundColor: Colors.transparent,
                            foregroundColor: Colors.orange,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(6),
                              side: BorderSide(color: Colors.orange),
                            ),
                            minimumSize: Size(100, 40), 
                          ),
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => CameraScreen(),
                              ),
                            );
                          },
                          child: Text(
                            "Enviar arquivo",
                            style:
                                TextStyle(fontSize: 18, color: Colors.orange),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                if (documentoService.imagePath.isNotEmpty)
                  Container(
                    margin: EdgeInsets.only(top: 10),
                    child: Column(
                      children: <Widget>[
                        SizedBox(
                          width: double.infinity, 
                          height: 50, 
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              elevation: 0,
                              backgroundColor: AppColors.buttonSecondary,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(6),
                                side: BorderSide(color: Colors.orange),
                              ),
                              minimumSize: Size(100, 40), 
                            ),
                            onPressed: () async {
                              await salvaFotoPerfil();
                            },
                            child: Text(
                              "Salvar e continuar",
                              style: TextStyle(fontSize: 18),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
