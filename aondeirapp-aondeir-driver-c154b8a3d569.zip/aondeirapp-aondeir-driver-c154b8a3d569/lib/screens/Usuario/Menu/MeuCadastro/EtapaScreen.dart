import 'package:aondeir_motorista/screens/Usuario/Menu/Cadastro/Documentos/DocumentoCnhScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/Cadastro/Documentos/DocumentoComprovanteResidenciaScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/Cadastro/Documentos/DocumentoCrlvScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/Cadastro/Documentos/DocumentoVeiculoFrontalScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/Cadastro/Documentos/DocumentoVeiculoTraseiraScreen.dart';
import 'package:aondeir_motorista/service/UsuarioService.dart';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:provider/provider.dart';
import 'package:sliding_up_panel/sliding_up_panel.dart';
import '../../../../service/DocumentoService.dart';
import 'DadosPessoais/MeuCadastroDadosPessoaisScreen.dart';
import 'Documentos/CondicoesDocumentoScreen.dart';
import 'Endereco/EnderecoScreen.dart';
import 'FotoRosto/CondicoesScreen.dart';
import 'MeuCadastroScreen.dart';
import 'Veiculo/CarroScreen.dart';
import 'contaBancaria/MeuCadastroContaBancariaScreen.dart';

class EtapaScreen extends StatefulWidget {
  @override
  _EtapaScreenState createState() => _EtapaScreenState();
}

class _EtapaScreenState extends State<EtapaScreen> {
  PanelController panelController = PanelController();
  ScrollController scrollController = ScrollController();
  final storage = new FlutterSecureStorage();
  var expanded = false;
  Widget _widgetOptions1(etapa) {
    var documentoService =
        Provider.of<DocumentoService>(context, listen: false);
    if (etapa['dados_pessoais'] == 0) {
      return MeuCadastroDadosPessoaisScreen();
    } else if (etapa['foto_perfil'] == 0) {
      return CondicoesScreen();
    } else if (etapa['dados_bancarios'] == 0) {
      return MeuCadastroContaBancariaScreen();
    } else if (etapa['endereco'] == 0) {
      return EnderecoScreen();
    } else if (etapa['veiculo'] == 0) {
      return CarroScreen();
    } else if (etapa['antecedente_criminal'] == 0) {
      documentoService.tipoDocumento = 'ANTECEDENTE_CRIMINAL';
      documentoService.save();
      return CondicoesDocumentoScreen();
    } else if (etapa['cnh'] == 0) {
      documentoService.tipoDocumento = 'CNH';
      documentoService.save();
      return DocumentoCnhScreen();
    } else if (etapa['comprovante_residencia'] == 0) {
      documentoService.tipoDocumento = 'COMPROVANTE_RESIDENCIA';
      documentoService.save();
      return DocumentoComprovanteResidenciaScreen();
    } else if (etapa['crlv'] == 0) {
      documentoService.tipoDocumento = 'CRLV';
      documentoService.save();
      return DocumentoCrlvScreen();
    } else if (etapa['veiculo_frontal'] == 0) {
      documentoService.tipoDocumento = 'VEICULO_FRONTAL';
      documentoService.save();
      return DocumentoVeiculoFrontalScreen();
    } else if (etapa['veiculo_traseira'] == 0) {
      documentoService.tipoDocumento = 'VEICULO_TRASEIRA';
      documentoService.save();
      return DocumentoVeiculoTraseiraScreen();
    } else {
      return MeuCadastroScreen();
    }
  }

  final ScrollController NavigationScreen = ScrollController();

  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    var usuarioService = Provider.of<UsuarioService>(context, listen: true);
    return Scaffold(
      body: WillPopScope(
        onWillPop: () async {
          return false;
        },
        child: CustomScrollView(
          slivers: <Widget>[
            SliverAppBar(
              automaticallyImplyLeading: false,
              expandedHeight: MediaQuery.of(context).size.height,
              flexibleSpace: _widgetOptions1(usuarioService.etapaCadastro),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildDragHandle() => Center(
        child: Container(
          margin: EdgeInsets.only(top: 10, bottom: 5),
          width: 40,
          height: 4,
          decoration: BoxDecoration(
              color: Colors.grey[300], borderRadius: BorderRadius.circular(12)),
        ),
      );

  onTabTapped(int index) {
    setState(() {});
  }
}
