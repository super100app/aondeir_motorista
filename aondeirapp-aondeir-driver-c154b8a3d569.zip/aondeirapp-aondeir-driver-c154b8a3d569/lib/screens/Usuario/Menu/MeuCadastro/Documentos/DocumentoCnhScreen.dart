import 'dart:io';
import 'package:aondeir_motorista/screens/Modal/ModalPadrao.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/Cadastro/FotoRosto/CameraScreen.dart';
import 'package:aondeir_motorista/service/DocumentoService.dart';
import 'package:aondeir_motorista/service/UsuarioService.dart';
import 'package:aondeir_motorista/styles/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:provider/provider.dart';

import '../MeuCadastroScreen.dart';

class DocumentoCnhScreen extends StatefulWidget {
  const DocumentoCnhScreen({super.key});

  @override
  State<DocumentoCnhScreen> createState() => _DocumentoCnhScreenState();
}

class _DocumentoCnhScreenState extends State<DocumentoCnhScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      await pegarCnh();
    });
  }

  pegarCnh() async {
    var documentoService =
        Provider.of<DocumentoService>(context, listen: false);

    documentoService.tipoDocumentoId = 2;
    await documentoService.save();
    await documentoService.pegarDocumento();
  }

  salvaDocumento() async {
    var usuarioService = Provider.of<UsuarioService>(context, listen: false);
    var documentoService =
        Provider.of<DocumentoService>(context, listen: false);
      showDialog<String>(
      context: context,
      builder: (BuildContext context) => ModalPadrao(
        message: "Aguarde, estamos salvando seu documento.",
        loading: true
      ));
    var resp =
        await usuarioService.salvaDocumentoCnh(documentoService.imagePath);

    if (resp == true) {
      documentoService.imagePath = "";
      await documentoService.save();
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => MeuCadastroScreen(),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    var documentoService = Provider.of<DocumentoService>(context, listen: true);
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_ios_new,
            color: Colors.orange,
            size: 25,
          ),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(
          "Documentos",
          style: TextStyle(fontSize: 17, color: Colors.black),
        ),
        elevation: 0,
        centerTitle: true,
        backgroundColor: Colors.white,
        actions: <Widget>[
          Container(
            padding: EdgeInsets.all(17),
            margin: EdgeInsets.only(right: 20),
            child: Text(
              "5 de 5",
              style: TextStyle(
                color: Colors.grey,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
      body: Material(
        type: MaterialType.transparency,
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: 40, vertical: 40),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Text(
                "CNH (Carteira Nacional de Habilitação).",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                  fontSize: 22,
                ),
              ),
              SizedBox(height: 10),
              Text(
                "A CNH pode ser enviada em pdf, jpg, png ou tirar a foto do documento",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.grey,
                  fontWeight: FontWeight.w400,
                  fontSize: 18,
                ),
              ),
              SizedBox(height: 10),
              ClipRRect(
                borderRadius: BorderRadius.circular(10.0),
                child: documentoService.imagePath.isNotEmpty
                    ? Image.file(
                        File(documentoService.imagePath),
                        width: 270,
                        height: 270,
                        fit: BoxFit.cover,
                      )
                    : documentoService.documento.isNotEmpty
                        ? Image.network(
                            dotenv.env['BASE_URL']! +
                                "images/" +
                                documentoService.documento["imagem"].toString(),
                            width: 270,
                            height: 270,
                            fit: BoxFit.cover,
                          )
                        : Image.asset(
                            "assets/notImage.jpg",
                            width: 270,
                            height: 270,
                            fit: BoxFit.cover,
                          ),
              ),
              if (documentoService.documento.isEmpty ||
                  documentoService.documento['status'] != "APROVADO")
                Container(
                  margin: EdgeInsets.only(top: 20),
                  child: Column(
                    children: <Widget>[
                      SizedBox(
                        width: double.infinity,
                        height: 50,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            elevation: 0,
                            shadowColor: Colors.transparent,
                            backgroundColor: Colors.transparent,
                            foregroundColor: Colors.orange,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(6),
                              side: BorderSide(color: AppColors.buttonBorderSecondary),
                            ),
                            minimumSize: Size(100, 40),
                          ),
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => CameraScreen(),
                              ),
                            );
                          },
                          child: Text(
                            "Enviar arquivo",
                            style:
                                TextStyle(fontSize: 18, color: Colors.orange),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              if (documentoService.imagePath.isNotEmpty)
                Container(
                  margin: EdgeInsets.only(top: 10),
                  child: Column(
                    children: <Widget>[
                      SizedBox(
                        width: double.infinity,
                        height: 50,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            elevation: 0,
                            backgroundColor: AppColors.buttonSecondary,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(6),
                              side: BorderSide(color: AppColors.buttonBorderSecondary),
                            ),
                            minimumSize: Size(100, 40),
                          ),
                          onPressed: () async {
                            await salvaDocumento();
                          },
                          child: Text(
                            "Salvar e continuar",
                            style: TextStyle(fontSize: 18),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
