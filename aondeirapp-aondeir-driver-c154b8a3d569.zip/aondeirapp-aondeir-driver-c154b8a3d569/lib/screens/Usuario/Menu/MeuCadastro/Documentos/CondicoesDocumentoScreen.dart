import 'package:aondeir_motorista/screens/Usuario/Menu/Cadastro/Documentos/DocumentoAntecedenteCriminalScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/Cadastro/Documentos/DocumentoCnhScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/Cadastro/Documentos/DocumentoComprovanteResidenciaScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/Cadastro/Documentos/DocumentoCrlvScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/Cadastro/Documentos/DocumentoVeiculoFrontalScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/Cadastro/Documentos/DocumentoVeiculoTraseiraScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/Cadastro/FotoRosto/CondicoesScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/MeuCadastro/MeuCadastroScreen.dart';
import 'package:aondeir_motorista/styles/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../../service/DocumentoService.dart';

class CondicoesDocumentoScreen extends StatefulWidget {
  const CondicoesDocumentoScreen({super.key});

  @override
  State<CondicoesDocumentoScreen> createState() =>
      _CondicoesDocumentoScreenState();
}

class _CondicoesDocumentoScreenState extends State<CondicoesDocumentoScreen> {
  carregarComponete() async {
    var documentoService =
        Provider.of<DocumentoService>(context, listen: false);
    if (documentoService.tipoDocumento == "ANTECEDENTE_CRIMINAL") {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => DocumentoAntecedenteCriminalScreen(),
        ),
      );
    } else if (documentoService.tipoDocumento == "CNH") {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => DocumentoCnhScreen(),
        ),
      );
    } else if (documentoService.tipoDocumento == "COMPROVANTE_RESIDENCIA") {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => DocumentoComprovanteResidenciaScreen(),
        ),
      );
    } else if (documentoService.tipoDocumento == "CRLV") {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => DocumentoCrlvScreen(),
        ),
      );
    } else if (documentoService.tipoDocumento == "VEICULO_FRONTAL") {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => DocumentoVeiculoFrontalScreen(),
        ),
      );
    } else if (documentoService.tipoDocumento == "VEICULO_TRASEIRA") {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => DocumentoVeiculoTraseiraScreen(),
        ),
      );
    } else if (documentoService.tipoDocumento == "FOTO_PERFIL") {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => CondicoesScreen(),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_ios_new,
            color: Colors.orange,
            size: 25,
          ),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => MeuCadastroScreen(),
              ),
            );
          },
        ),
        title: Text(
          "Documentos",
          style: TextStyle(
            fontSize: 17,
            color: Colors.black,
          ),
        ),
        elevation: 0,
        centerTitle: true,
        backgroundColor: Colors.white,
        actions: <Widget>[
          Container(
            padding: EdgeInsets.all(17),
            margin: EdgeInsets.only(right: 20),
            child: Text(
              "5 de 5",
              style: TextStyle(
                color: Colors.grey,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
      body: WillPopScope(
        onWillPop: () async {
          
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => MeuCadastroScreen(),
            ),
          );
          return false;
        },
        child: Padding(
          padding: EdgeInsets.all(15),
          child: Material(
            type: MaterialType.transparency,
            child: Container(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    "Para tirar as fotos dos documentos, fique atento às orientações a seguir.",
                    style: TextStyle(
                      color: Colors.grey,
                      fontSize: 17,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  SizedBox(height: 30),
                  Expanded(
                    child: Column(
                      children: <Widget>[
                        Row(
                          children: <Widget>[
                            Container(
                              transform:
                                  Matrix4.translationValues(0.0, -10.0, 0.0),
                              padding: EdgeInsets.all(20),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: Colors.orange.withOpacity(0.2),
                              ),
                              child: Text(
                                "1",
                                style: TextStyle(
                                  color: Colors.orange,
                                  fontSize: 25,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            SizedBox(width: 15),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Container(
                                  width: 240,
                                  child: Text(
                                    "Foco no documento",
                                    style: TextStyle(
                                      color: Colors.grey[800],
                                      fontSize: 22,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                                Container(
                                  width: 260,
                                  child: Text(
                                    "Tire a foto com a câmera próxima ao documento.",
                                    style: TextStyle(
                                      color: Colors.grey[400],
                                      fontSize: 19,
                                      fontWeight: FontWeight.w400,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                        SizedBox(height: 30),
                        Row(
                          children: <Widget>[
                            Container(
                              transform:
                                  Matrix4.translationValues(0.0, -30.0, 0.0),
                              padding: EdgeInsets.all(20),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: Colors.orange.withOpacity(0.2),
                              ),
                              child: Text(
                                "2",
                                style: TextStyle(
                                  color: Colors.orange,
                                  fontSize: 25,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            SizedBox(width: 15),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Container(
                                  width: 240,
                                  child: Text(
                                    "Foto com boa iluminação",
                                    style: TextStyle(
                                      color: Colors.grey[800],
                                      fontSize: 22,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                                Container(
                                  width: 260,
                                  child: Text(
                                    "Tire a foto num ambiente claro para seus dados ficarem legíveis.",
                                    style: TextStyle(
                                      color: Colors.grey[400],
                                      fontSize: 19,
                                      fontWeight: FontWeight.w400,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                        SizedBox(height: 30),
                        Row(
                          children: <Widget>[
                            Container(
                              transform:
                                  Matrix4.translationValues(0.0, -20.0, 0.0),
                              padding: EdgeInsets.all(20),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: Colors.orange.withOpacity(0.2),
                              ),
                              child: Text(
                                "3",
                                style: TextStyle(
                                  color: Colors.orange,
                                  fontSize: 25,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            SizedBox(width: 15),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Container(
                                  width: 260,
                                  child: Text(
                                    "Documento aberto",
                                    style: TextStyle(
                                      color: Colors.grey[800],
                                      fontSize: 22,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                                Container(
                                  width: 260,
                                  child: Text(
                                    "Abra documentos \"dobráveis\" como a CNH e tire a foto da frente e do verso.",
                                    style: TextStyle(
                                      color: Colors.grey[400],
                                      fontSize: 19,
                                      fontWeight: FontWeight.w400,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    width: double.infinity, 
                    height: 50, 
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        elevation: 0,
                        backgroundColor: AppColors.buttonSecondary,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(6),
                          side: BorderSide(color: AppColors.buttonBorderSecondary),
                        ),
                        minimumSize: Size(100, 40), 
                      ),
                      onPressed: () async {
                        await carregarComponete();
                      },
                      child: Text(
                        "Continuar",
                        style: TextStyle(fontSize: 18),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
