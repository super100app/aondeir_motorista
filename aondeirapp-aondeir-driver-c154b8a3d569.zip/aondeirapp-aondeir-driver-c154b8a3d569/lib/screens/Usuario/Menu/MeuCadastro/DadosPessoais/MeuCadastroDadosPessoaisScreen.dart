import 'dart:ffi';
import 'dart:io';

import 'package:aondeir_motorista/screens/Usuario/Menu/MeuCadastro/MeuCadastroScreen.dart';
import 'package:aondeir_motorista/service/UsuarioService.dart';
import 'package:aondeir_motorista/styles/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:intl/intl.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:provider/provider.dart';
import 'package:http/http.dart' as http;
import 'dart:convert' as convert;

import '../../../../../models/UsuarioMotorista.dart';

class MeuCadastroDadosPessoaisScreen extends StatefulWidget {
  const MeuCadastroDadosPessoaisScreen({super.key});

  @override
  State<MeuCadastroDadosPessoaisScreen> createState() =>
      _MeuCadastroDadosPessoaisScreenState();
}

class _MeuCadastroDadosPessoaisScreenState
    extends State<MeuCadastroDadosPessoaisScreen> {
  TextEditingController _controllerNome = new TextEditingController();
  TextEditingController _controllerEmail = new TextEditingController();
  TextEditingController _controllerCpf = new TextEditingController();
  TextEditingController _controllerTelefone = new TextEditingController();
  TextEditingController _controllerNascimento = new TextEditingController();
  TextEditingController _controllerGenero = new TextEditingController();
  TextEditingController _controllerChavePix = new TextEditingController();
  bool edicao = false;

  final _maskFormatter = MaskTextInputFormatter(
    mask: '##/##/####',
    filter: {"#": RegExp(r'[0-9]')},
  );

  bool isLoading = false;

  final storage = new FlutterSecureStorage();

  var errorsForm = {};

  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      await fetchDados();
    });
  }

  fetchDados() async {
    try {
      String url =
          dotenv.env['BASE_URL']! + "api/motorista/pegar-dados-pessoais";
      var token = await storage.read(key: 'jwt');
      var response = await http.get(Uri.parse(url), headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        final json = await convert.jsonDecode(response.body);
        UsuarioMotorista usuario = UsuarioMotorista.fromJson(json['usuario']);
        preencherControladorDadosPessoais(usuario);
      }
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      showModalAlertError(e.toString());
    }
  }

  preencherControladorDadosPessoais(UsuarioMotorista usuario) async {
    
    if (usuario.motorista['situacao_cadastral'] == 'ATIVO' || usuario.motorista['situacao_cadastral'] == 'AGUARDANDO_ATIVACAO' || usuario.motorista['situacao_cadastral'] == 'FASE_CADASTRO') {
      setState(() {
        edicao = true;
      });
    }
    print("✅usuario.motorista.situacao_cadastral");
    print(edicao);
    print("✅usuario.motorista.situacao_cadastral");
    _controllerNome.text = usuario.name;
    _controllerEmail.text = usuario.email;
    _controllerCpf.text = usuario.doc;
    _controllerTelefone.text = usuario.celular;
    _controllerNascimento.text = usuario.motorista['nascimento'] != null
        ? formatarDataDoBanco(usuario.motorista['nascimento'])
        : "";
    _controllerGenero.text =
        usuario.motorista['genero'] != null ? usuario.motorista['genero'] : "";
    _controllerChavePix.text = usuario.motorista['chave_pix'] != null
        ? usuario.motorista['chave_pix']
        : "";
  }

  String formatarDataDoBanco(String data) {
    DateTime dataFormatada = DateTime.parse(data);
    String dataFormatadaString = DateFormat('dd/MM/yyyy').format(dataFormatada);
    return dataFormatadaString;
  }

  updateDadosPessoais() async {
    try {
      setState(() {
        isLoading = true;
      });

      showLoader();
      await Future.delayed(Duration(seconds: 3));

      var form = {
        "nome": _controllerNome.text,
        "email": _controllerEmail.text,
        "doc": _controllerCpf.text,
        "telefone": _controllerTelefone.text,
        "nascimento": _controllerNascimento.text,
        "genero": _controllerGenero.text,
        "pix": _controllerChavePix.text
      };

      String url =
          dotenv.env['BASE_URL']! + "api/motorista/update-dados-pessoais";
      var token = await storage.read(key: 'jwt');
      var response = await http.post(Uri.parse(url), body: form, headers: {
        HttpHeaders.authorizationHeader: 'Bearer ' + token.toString(),
      });

      if (response.statusCode == 200) {
        showModalAlertSucesso("Dados alterado com sucess!");
        await Future.delayed(Duration(seconds: 3));
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => MeuCadastroScreen(),
          ),
        );
      } else {
        
        final json = await convert.jsonDecode(response.body);
        print('❌ response.statusCode == 400 ');
        print(json);
        setState(() {
          errorsForm = json;
          isLoading = false;
        });
        if (Navigator.canPop(context)) {
          Navigator.pop(context);
        }
      }
      
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      showModalAlertError(e.toString());
    }
  }

  showLoader() {
    if (isLoading == true) {
      showDialog<String>(
        barrierDismissible: false,
        context: context,
        builder: (BuildContext context) => AlertDialog(
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(12.0))),
          title: Container(
            child: Text(
              "Salvando dados...",
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 13,
                color: Colors.grey[700],
              ),
            ),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(),
              SizedBox(height: 16),
              Text('Carregando...'),
            ],
          ),
        ),
      );
    }
  }

  showModalAlertSucesso(String message) async {
    showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) => AlertDialog(
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(12.0))),
        title: Text(
          'Sucesso!',
          textAlign: TextAlign.center,
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.check_circle,
              color: Colors.green,
              size: 50,
            ),
            SizedBox(height: 10),
            Text(
              message,
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.black),
            ),
          ],
        ),
      ),
    );
  }

  showModalAlertError(String message) async {
    showDialog<String>(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(12.0))),
        title: Text(
          'Ops!',
          textAlign: TextAlign.center,
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.error,
              color: Colors.red,
              size: 50,
            ),
            SizedBox(height: 10),
            Text(
              message,
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.black),
            ),
          ],
        ),
        actions: <Widget>[
          InkWell(
            onTap: () {
              Navigator.pop(context, "Fechar");
            },
            child: Padding(
              padding: EdgeInsets.only(bottom: 10, left: 15, right: 15),
              child: Text(
                'Fechar',
                style: TextStyle(color: Colors.orange),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    var usuarioService = Provider.of<UsuarioService>(context, listen: true);
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_ios_new,
            color: Colors.orange,
            size: 25,
          ),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => MeuCadastroScreen(),
              ),
            );
          },
        ),
        title: Text(
          "Dados pessoais",
          style: TextStyle(fontSize: 17, color: Colors.black),
        ),
        elevation: 0,
        centerTitle: true,
        backgroundColor: Colors.white,
      ),
      body: WillPopScope(
        onWillPop: () async {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => MeuCadastroScreen(),
            ),
          );
          return false;
        },
        child: Padding(
          padding: EdgeInsets.all(15),
          child: Material(
            type: MaterialType.transparency,
            child: new SingleChildScrollView(
              child: Container(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    SizedBox(height: 25),
                    TextField(
                      controller: _controllerNome,
                      enabled: !edicao,
                      decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        enabledBorder: OutlineInputBorder(
                          borderSide:
                              BorderSide(width: 1, color: Colors.grey.shade200),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide:
                              BorderSide(width: 1, color: Colors.grey.shade200),
                        ),
                        label: Text(
                          "Nome completo",
                          style: TextStyle(color: Colors.grey.shade500),
                        ),
                      ),
                    ),
                    SizedBox(height: 25),
                    Row(
                      children: <Widget>[
                        Container(
                          child: Flexible(
                            child: TextField(
                              enabled: true,
                              controller: _controllerEmail,
                              decoration: InputDecoration(
                                border: OutlineInputBorder(),
                                enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                      width: 1, color: Colors.grey.shade200),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                      width: 1, color: Colors.grey.shade200),
                                ),
                                label: Text(
                                  "Email",
                                  style: TextStyle(color: Colors.grey.shade500),
                                ),
                                hintText: 'E-mail',
                                errorText: errorsForm?['email'] != null
                                    ? errorsForm['email']
                                    : null,
                              ),
                            ),
                          ),
                        ),
                        SizedBox(width: 5),
                        Container(
                          child: Flexible(
                            child: TextField(
                              enabled: !edicao,
                              controller: _controllerCpf,
                              decoration: InputDecoration(
                                border: OutlineInputBorder(),
                                enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                      width: 1, color: Colors.grey.shade200),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                      width: 1, color: Colors.grey.shade200),
                                ),
                                label: Text(
                                  "CPF",
                                  style: TextStyle(color: Colors.grey.shade500),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 25),
                    Row(
                      children: <Widget>[
                        Container(
                          child: Flexible(
                            child: TextField(
                              enabled: true,
                              controller: _controllerTelefone,
                              decoration: InputDecoration(
                                border: OutlineInputBorder(),
                                enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                      width: 1, color: Colors.grey.shade200),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                      width: 1, color: Colors.grey.shade200),
                                ),
                                label: Text(
                                  "Telefone de contato",
                                  style: TextStyle(color: Colors.grey.shade500),
                                ),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(width: 5),
                        Container(
                          child: Flexible(
                            child: TextField(
                              controller: _controllerNascimento,
                              inputFormatters: [_maskFormatter],
                              decoration: InputDecoration(
                                border: OutlineInputBorder(),
                                enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                      width: 1, color: Colors.grey.shade200),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                      width: 1, color: Colors.grey.shade200),
                                ),
                                label: Text(
                                  "Data de nascimento (Obrigatório)",
                                  style: TextStyle(color: Colors.grey.shade500),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 25),
                    Row(children: <Widget>[
                      Container(
                        child: Flexible(
                          child: Autocomplete<String>(
                            optionsBuilder:
                                (TextEditingValue textEditingValue) {
                              if (textEditingValue.text == '') {
                                return ["MASCULINO", "FEMININO"];
                              }
                              return ["MASCULINO", "FEMININO"].where((string) {
                                return string.toLowerCase().contains(
                                    textEditingValue.text.toLowerCase());
                              });
                            },
                            initialValue: TextEditingValue(
                                text: usuarioService
                                            .usuario.motorista['genero'] !=
                                        null
                                    ? usuarioService.usuario.motorista['genero']
                                    : ""),
                            onSelected: (selectedGenero) {
                              setState(() {
                                _controllerGenero.text = selectedGenero;
                              });
                              debugPrint('You just selected $selectedGenero');
                            },
                            fieldViewBuilder: (BuildContext context,
                                TextEditingController controller,
                                FocusNode focusNode,
                                VoidCallback onFieldSubmitted) {
                              return TextField(
                                controller: controller,
                                enabled: !edicao,
                                focusNode: focusNode,
                                onSubmitted: (String value) {
                                  onFieldSubmitted();
                                },
                                decoration: InputDecoration(
                                  hintText: 'Selecione o genero (Obrigatório)',
                                  border: OutlineInputBorder(),
                                  enabledBorder: OutlineInputBorder(
                                    borderSide: BorderSide(
                                        width: 1, color: Colors.grey.shade200),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderSide: BorderSide(
                                        width: 1, color: Colors.grey.shade200),
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                      ),
                    ]),
                    SizedBox(height: 25),
                    TextField(
                      controller: _controllerChavePix,
                      decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        enabledBorder: OutlineInputBorder(
                          borderSide:
                              BorderSide(width: 1, color: Colors.grey.shade200),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide:
                              BorderSide(width: 1, color: Colors.grey.shade200),
                        ),
                        label: Text(
                          "Chave Pix",
                          style: TextStyle(color: Colors.grey.shade500),
                        ),
                      ),
                    ),
                    SizedBox(height: 25),
                    SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          elevation: 0,
                          backgroundColor: AppColors.buttonSecondary,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(6),
                            side: BorderSide(color: AppColors.buttonBorderSecondary),
                          ),
                          // minimumSize: Size(100, 40),
                        ),
                        onPressed: () async {
                          await updateDadosPessoais();
                        },
                        child: Text(
                          "Salvar",
                          style: TextStyle(fontSize: 18),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
