import 'package:aondeir_motorista/screens/Usuario/Menu/Legal/PoliticaPrivacidadeScreen.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

class TermoUsoScreen extends StatefulWidget {
  const TermoUsoScreen({super.key});

  @override
  State<TermoUsoScreen> createState() => _TermoUsoScreenState();
}

class _TermoUsoScreenState extends State<TermoUsoScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_ios_new,
            color: Colors.orange,
            size: 25,
          ),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(
          "Termos de uso",
          style: TextStyle(fontSize: 17, color: Colors.black),
        ),
        elevation: 0,
        centerTitle: true,
        backgroundColor: Colors.white,
      ),
      body: Padding(
        padding: EdgeInsets.all(15),
        child: Material(
          type: MaterialType.transparency,
          child: new SingleChildScrollView(
            child: Container(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Container(
                    width: double.infinity,
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey.shade300),
                      borderRadius: BorderRadius.circular(15),
                    ),
                    padding: EdgeInsets.all(15),
                    child: Text(
                      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus auctor tincidunt mi scelerisque convallis. Nunc id malesuada arcu. Nunc egestas facilisis enim, eget condimentum risus finibus ac. Ut gravida ac urna tincidunt consequat. Phasellus sagittis tincidunt velit eu volutpat. Quisque sollicitudin, lorem eu volutpat commodo, mauris velit sollicitudin turpis, non vulputate magna arcu nec justo. In imperdiet lobortis ipsum quis luctus. Nulla a dui sit amet arcu egestas tempor ac et nisi. Praesent eget metus pellentesque, molestie ipsum non, dapibus nibh. Pellentesque sed molestie sem. Mauris arcu mauris, aliquam eget libero id, luctus ornare ipsum. Phasellus consectetur, neque vel sollicitudin semper, nisi nisl porttitor sapien, sed lobortis diam leo nec diam. In luctus sit amet leo vitae commodo. Cras dignissim, urna vitae porta pharetra, nulla mi lobortis quam, vel lobortis lacus enim vel sapien. Nunc vel lectus fringilla, maximus est vel, pretium neque. Morbi nibh odio, placerat ultrices felis nec, dignissim facilisis lectus. Aenean consequat eleifend egestas. Praesent risus massa, imperdiet nec feugiat eu, dapibus volutpat libero. Curabitur efficitur lectus eget suscipit iaculis. Aliquam facilisis molestie ex sed viverra. Fusce viverra augue a feugiat accumsan. Ut dapibus justo non vestibulum sollicitudin. Maecenas non iaculis sapien. Donec in neque purus. Proin non nulla at purus ornare suscipit ac non ipsum. Fusce id erat sit amet risus luctus efficitur vel dignissim libero. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nunc eu maximus nibh. Nullam non condimentum ante. Etiam sed elit scelerisque, sollicitudin lacus mollis, eleifend lacus. Sed non ligula dictum, pretium risus vel, ultrices ex. In ante magna, dictum non felis quis, vestibulum eleifend purus. Proin non velit malesuada, molestie sapien non, pulvinar ipsum. Vivamus lacinia leo non nisi sodales imperdiet. Nam fermentum, dui eu dapibus ullamcorper, elit elit dignissim nibh, eget tempus velit dolor non massa. Nulla laoreet gravida facilisis. Vestibulum eget tincidunt nunc. In aliquet, nibh eu maximus venenatis, nisi nibh lacinia leo, malesuada molestie orci diam in felis. Ut et dui condimentum, fermentum diam vel, tincidunt magna. Proin sed aliquam arcu. Duis et imperdiet mi. Donec eu lorem vel arcu volutpat euismod ullamcorper at turpis. Ut ut dictum tellus, non accumsan orci. Sed tempor turpis a arcu auctor, in placerat elit molestie. Etiam lorem tellus, accumsan vel nibh id, semper fermentum mi. Integer semper dictum nisi eu commodo. Phasellus et facilisis libero, vel consectetur dolor. Duis tellus erat, ultricies eget massa sit amet, bibendum sollicitudin augue. Maecenas hendrerit elit at lobortis bibendum. Ut ullamcorper felis sed libero viverra feugiat. Aliquam iaculis at metus vel iaculis. Cras efficitur augue ut purus fermentum pharetra. In vitae turpis quam. Ut eget lorem lorem. Aenean luctus dolor non arcu pulvinar feugiat.",
                      style: TextStyle(color: Colors.grey[600], fontSize: 16),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(top: 20),
                    child: RichText(
                      text: TextSpan(
                        text: 'É importante também que você leia a nossa',
                        style: TextStyle(color: Colors.grey[600], fontSize: 17),
                        children: <TextSpan>[
                          TextSpan(
                            text: ' Política de Privacidade.',
                            style: TextStyle(
                              color: Colors.orange,
                              decoration: TextDecoration.underline,
                            ),
                            recognizer: TapGestureRecognizer()
                              ..onTap = () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => PoliticaPrivacidadeScreen(),
                                  ),
                                );
                              },
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
