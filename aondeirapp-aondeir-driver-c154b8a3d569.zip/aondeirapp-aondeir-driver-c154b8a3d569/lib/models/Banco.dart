class Banco {
  int id;
  String name;
  String codigo;

  Banco({
    required this.id,
    required this.name,
    required this.codigo,
  });

  factory Banco.fromJson(Map<String, dynamic> cartoaJson) {
    Banco banco = Banco(
      id: cartoaJson["id"],
      name: cartoaJson["name"],
      codigo: cartoaJson["codigo"],
    );

    return banco;
  }
}
