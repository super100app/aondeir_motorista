class Franquia {
  int id;
  String nome;

  Franquia({
    required this.id,
    required this.nome,
  });

  factory Franquia.fromJson(Map<String, dynamic> cartoaJson) {
    Franquia franquia = Franquia(
      id: cartoaJson["id"],
      nome: cartoaJson["nome"],
    );

    return franquia;
  }
}
