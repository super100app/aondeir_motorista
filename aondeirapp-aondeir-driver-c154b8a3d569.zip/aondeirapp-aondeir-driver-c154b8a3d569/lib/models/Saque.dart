class Saque {
  final int id;
  final double valor;
  final String observacao;
  final String status;
  final DateTime data;
  final double taxa;
  final String pix;
  final String tipo;

  Saque({
    required this.id,
    required this.valor,
    required this.observacao,
    required this.status,
    required this.data,
    required this.taxa,
    required this.pix,
    required this.tipo,
  });

  factory Saque.fromJson(Map<String, dynamic> json) {
    return Saque(
      id: json['id'],
      valor: double.tryParse(json['valor'].toString()) ?? 0.0,
      taxa: double.tryParse(json['taxa'].toString()) ?? 0.0,
      observacao: json['observacao'] ?? '',
      status: json['status'] ?? '',
      pix: json['pix'] ?? '',
      tipo: json['tipo'] ?? '',
      data: DateTime.parse(json['data']),
    );
  }

  @override
  String toString() {
    return 'Saque(id: $id, valor: $valor, observacao: $observacao, status: $status, data: $data, taxa: $taxa, pix: $pix)';
  }
}
