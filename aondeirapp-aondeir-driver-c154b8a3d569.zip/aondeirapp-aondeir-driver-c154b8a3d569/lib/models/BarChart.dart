class BarMmodel {
  final String year;
  final int value;
  BarMmodel(this.year, this.value);
}