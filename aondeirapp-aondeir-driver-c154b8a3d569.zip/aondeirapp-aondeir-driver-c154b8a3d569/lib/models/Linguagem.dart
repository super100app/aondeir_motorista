class Linguagem {
  String email;
  String senha;

  Linguagem({
    required this.email,
    required this.senha,

  });

  factory Linguagem.fromJson(Map<String, dynamic> cartoaJson) {

    Linguagem login = Linguagem(
      email: cartoaJson["email"],
      senha: cartoaJson["senha"],

    );
 
    return login;
  }
}
