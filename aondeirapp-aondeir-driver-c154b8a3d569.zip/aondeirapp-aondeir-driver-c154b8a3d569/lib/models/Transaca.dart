class Transacao {
  String? pix_provider_tid;
  String qr_code;
  String qr_code_url;
  String expires_at;
  dynamic additional_information;
  String id;
  String transaction_type;
  String gateway_id;
  int amount;
  String status;
  bool success;
  String created_at;
  String updated_at;
  dynamic gateway_response;
  dynamic antifraud_response;
  dynamic metadata;

  Transacao({
    required this.pix_provider_tid,
    required this.qr_code,
    required this.qr_code_url,
    required this.expires_at,
    required this.additional_information,
    required this.id,
    required this.transaction_type,
    required this.gateway_id,
    required this.amount,
    required this.status,
    required this.success,
    required this.created_at,
    required this.updated_at,
    required this.gateway_response,
    required this.antifraud_response,
    required this.metadata,
  });

  factory Transacao.fromJson(Map<String, dynamic> cartoaJson) {
    Transacao transacao = Transacao(
      pix_provider_tid: cartoaJson["pix_provider_tid"],
      qr_code: cartoaJson["qr_code"],
      qr_code_url: cartoaJson["qr_code_url"],
      expires_at: cartoaJson["expires_at"],
      additional_information: cartoaJson["additional_information"],
      id: cartoaJson["id"],
      transaction_type: cartoaJson["transaction_type"],
      gateway_id: cartoaJson["gateway_id"],
      amount: cartoaJson["amount"],
      status: cartoaJson["status"],
      success: cartoaJson["success"],
      created_at: cartoaJson["created_at"],
      updated_at: cartoaJson["updated_at"],
      gateway_response: cartoaJson["gateway_response"],
      antifraud_response: cartoaJson["antifraud_response"],
      metadata: cartoaJson["metadata"],
    );

    return transacao;
  }
}
