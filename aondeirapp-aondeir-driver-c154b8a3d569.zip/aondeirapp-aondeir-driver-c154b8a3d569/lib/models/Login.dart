import 'package:aondeir_motorista/models/ValorMoeda.dart';

class Login {
  ValorMoeda DefaultCurrencyValues;

  Login({
    required this.DefaultCurrencyValues,
  });

  factory Login.fromJson(Map<String, dynamic> cartoaJson) {
    Login login =
        Login(DefaultCurrencyValues: cartoaJson["DefaultCurrencyValues"]);

    return login;
  }
}
