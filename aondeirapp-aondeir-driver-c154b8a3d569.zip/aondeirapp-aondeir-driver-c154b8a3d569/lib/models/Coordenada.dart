class Coordenada {
  double latitude;
  double longitude;

  Coordenada({
    required this.latitude,
    required this.longitude,
  });

  factory Coordenada.fromJson(Map<String, dynamic> cartoaJson) {
    Coordenada coordenada = Coordenada(
      latitude: cartoaJson["latitude"],
      longitude: cartoaJson["longitude"],
    );

    return coordenada;
  }
}
