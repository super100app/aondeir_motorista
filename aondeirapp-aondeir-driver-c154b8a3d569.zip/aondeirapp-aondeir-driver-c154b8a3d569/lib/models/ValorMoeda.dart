class ValorMoeda {
  String iCurrencyId;
  String vName;
  String vSymbol;
  String iDispOrder;
  String eDefault;
  String Ratio;
  String fThresholdAmount;
  String eStatus;

  ValorMoeda({
    required this.iCurrencyId,
    required this.vName,
    required this.vSymbol,
    required this.iDispOrder,
    required this.eDefault,
    required this.Ratio,
    required this.fThresholdAmount,
    required this.eStatus,
  });

  factory ValorMoeda.fromJson(Map<String, dynamic> cartoaJson) {
    ValorMoeda valorMoeda = ValorMoeda(
      iCurrencyId: cartoaJson["iCurrencyId"],
      vSymbol: cartoaJson["vSymbol"],
      vName: cartoaJson["vName"],
      iDispOrder: cartoaJson["iDispOrder"],
      eDefault: cartoaJson["eDefault"],
      Ratio: cartoaJson["Ratio"],
      fThresholdAmount: cartoaJson["fThresholdAmount"],
      eStatus: cartoaJson["eStatus"],
    );

    return valorMoeda;
  }
}
