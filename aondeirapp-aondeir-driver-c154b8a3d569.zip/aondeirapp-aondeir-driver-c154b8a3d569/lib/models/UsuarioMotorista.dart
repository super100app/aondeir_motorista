class UsuarioMotorista {
  int id;
  String name;
  String email;
  String celular;
  int tipoId;
  String status;
  String doc;
  dynamic franquia;
  dynamic motorista;
  dynamic dados_bancarios;

  UsuarioMotorista({
    required this.id,
    required this.name,
    required this.email,
    required this.celular,
    required this.tipoId,
    required this.status,
    required this.doc,
    required this.franquia,
    required this.motorista,
    required this.dados_bancarios,
  });

  factory UsuarioMotorista.fromJson(Map<String, dynamic> cartoaJson) {
    UsuarioMotorista usuario = UsuarioMotorista(
      id: cartoaJson["id"],
      name: cartoaJson["name"],
      email: cartoaJson["email"],
      celular: cartoaJson["celular"],
      tipoId: cartoaJson["tipoId"],
      status: cartoaJson["status"],
      doc: cartoaJson["doc"],
      franquia: cartoaJson["franquia"],
      motorista: cartoaJson["motorista"],
      dados_bancarios: cartoaJson["dados_bancarios"],
    );

    return usuario;
  }
}
