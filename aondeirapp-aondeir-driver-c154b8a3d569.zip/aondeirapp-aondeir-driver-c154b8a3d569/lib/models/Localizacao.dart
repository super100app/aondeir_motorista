class Localizacao {
  double latitude;
  double longitude;

  Localizacao({
    required this.latitude,
    required this.longitude,
  });

  factory Localizacao.fromJson(Map<String, dynamic> cartoaJson) {
    Localizacao localizacao = Localizacao(
      latitude: cartoaJson['latitude'],
      longitude: cartoaJson['longitude'],
    );

    return localizacao;
  }
}
