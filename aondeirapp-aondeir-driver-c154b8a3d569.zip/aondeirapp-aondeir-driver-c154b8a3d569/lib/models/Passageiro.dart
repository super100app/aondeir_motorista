class Passageiro {
  int id;
  String name;
  String celular;

  Passageiro({
    required this.id,
    required this.name,
    required this.celular,
  });

  factory Passageiro.fromJson(Map<String, dynamic> cartoaJson) {
    Passageiro passageiro = Passageiro(
      id: cartoaJson["id"],
      name: cartoaJson["name"],
      celular: cartoaJson["celular"],
    );

    return passageiro;
  }
}
