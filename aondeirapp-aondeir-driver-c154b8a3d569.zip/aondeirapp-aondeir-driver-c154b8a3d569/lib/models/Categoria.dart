class Categoria {
  int id;
  String name;

  Categoria({
    required this.id,
    required this.name,
  });

  factory Categoria.fromJson(Map<String, dynamic> cartoaJson) {
    Categoria categoria = Categoria(
      id: cartoaJson["id"],
      name: cartoaJson["name"],
    );

    return categoria;
  }
}
