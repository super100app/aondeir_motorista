class Mensagem {
  int id;
  String mensagem;
  dynamic remetente;
  dynamic destinatario;
  dynamic corrida;

  Mensagem({
    required this.id,
    required this.mensagem,
    required this.remetente,
    required this.destinatario,
    required this.corrida,
  });

  factory Mensagem.fromJson(Map<String, dynamic> cartoaJson) {
    Mensagem mensagem = Mensagem(
      id: cartoaJson["id"],
      mensagem: cartoaJson["mensagem"],
      remetente: cartoaJson["remetente"],
      destinatario: cartoaJson["destinatario"],
      corrida: cartoaJson["corrida"],
    );

    return mensagem;
  }
}
