class MensagemFranquia {
  int id;
  String? mensagem;
  dynamic remetente;
  dynamic destinatario;
  dynamic franquia;
  int? lida;

  MensagemFranquia({
    required this.id,
    required this.mensagem,
    required this.remetente,
    required this.destinatario,
    required this.franquia,
    required this.lida,
  });

  factory MensagemFranquia.fromJson(Map<String, dynamic> cartoaJson) {
    MensagemFranquia mensagem = MensagemFranquia(
      id: cartoaJson["id"],
      mensagem: cartoaJson["mensagem"],
      remetente: cartoaJson["remetente"],
      destinatario: cartoaJson["destinatario"],
      franquia: cartoaJson["franquia"],
      lida: cartoaJson["lida"],
    );

    return mensagem;
  }
}
