class Usuario {
  int id;
  String name;
  String email;
  String celular;
  int tipoId;
  String status;
  String doc;
  dynamic franquia;
  dynamic motorista;
  dynamic dados_bancarios;
  String versaoApp;
  String versaoAppMotorista;

  Usuario({
    required this.id,
    required this.name,
    required this.email,
    required this.celular,
    required this.tipoId,
    required this.status,
    required this.doc,
    required this.franquia,
    required this.motorista,
    required this.dados_bancarios,
    required this.versaoApp,
    required this.versaoAppMotorista,

  });

  factory Usuario.fromJson(Map<String, dynamic> cartoaJson) {
    Usuario usuario = Usuario(
      id: cartoaJson["id"],
      name: cartoaJson["name"],
      email: cartoaJson["email"],
      celular: cartoaJson["celular"],
      tipoId: cartoaJson["tipoId"],
      status: cartoaJson["status"],
      doc: cartoaJson["doc"],
      franquia: cartoaJson["franquia"],
      motorista: cartoaJson["motorista"],
      dados_bancarios: cartoaJson["dados_bancarios"],
      versaoAppMotorista: cartoaJson["app_versao_nova"],
      versaoApp: '0.0',
    );

    return usuario;
  }
}
