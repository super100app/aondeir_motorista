class Register {
  String iUserId;
  String iCompanyId;
  String iRefUserId;
  String eRefType;
  String vFbId;
  String iHotelId;
  String vName;
  String vLastName;
  String vEmail;
  String vCPForCNPJ;
  String vPassword;
  String vCountry;
  String vState;
  String vPhone;
  String eGender;
  String vCreditCard;
  String dBirthDate;
  String vExpMonth;
  String vExpYear;

  Register({
    required this.iUserId,
    required this.iCompanyId,
    required this.iRefUserId,
    required this.eRefType,
    required this.vFbId,
    required this.iHotelId,
    required this.vName,
    required this.vLastName,
    required this.vEmail,
    required this.vCPForCNPJ,
    required this.vPassword,
    required this.vCountry,
    required this.vState,
    required this.vPhone,
    required this.eGender,
    required this.vCreditCard,
    required this.dBirthDate,
    required this.vExpMonth,
    required this.vExpYear,
  });

  factory Register.fromJson(Map<String, dynamic> cartoaJson) {
    Register register = Register(
      iUserId: cartoaJson["iUserId"],
      iCompanyId: cartoaJson["iCompanyId"],
      iRefUserId: cartoaJson["iRefUserId"],
      eRefType: cartoaJson["eRefType"],
      vFbId: cartoaJson["vFbId"],
      iHotelId: cartoaJson["iHotelId"],
      vName: cartoaJson["vName"],
      vLastName: cartoaJson["vLastName"],
      vEmail: cartoaJson["vEmail"],
      vCPForCNPJ: cartoaJson["vCPForCNPJ"],
      vPassword: cartoaJson["vPassword"],
      vCountry: cartoaJson["vCountry"],
      vState: cartoaJson["vState"],
      vPhone: cartoaJson["vPhone"],
      eGender: cartoaJson["eGender"],
      vCreditCard: cartoaJson["vCreditCard"],
      dBirthDate: cartoaJson["dBirthDate"],
      vExpMonth: cartoaJson["vExpMonth"],
      vExpYear: cartoaJson["vExpYear"],
    );

    return register;
  }
}
