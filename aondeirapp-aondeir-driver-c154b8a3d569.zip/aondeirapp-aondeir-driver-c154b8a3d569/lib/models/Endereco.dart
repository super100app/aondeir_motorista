class Endereco {
  String texto;
  double latitude;
  double longitude;



  Endereco({
    required this.texto,
    required this.latitude,
    required this.longitude,

  });

  factory Endereco.fromJson(Map<String, dynamic> cartoaJson) {

    Endereco endereco = Endereco(
      texto: cartoaJson["car_nome"],
      latitude: cartoaJson["car_display_numero"],
      longitude: 0,
 
    );
 
    return endereco;
  }
}
