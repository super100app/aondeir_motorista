class Recarga {
  int id;
  String valor;
  String observacao;
  String data;

  Recarga({
    required this.id,
    required this.valor,
    required this.observacao,
    required this.data,
  });

  factory Recarga.fromJson(Map<String, dynamic> cartoaJson) {
    Recarga recarga = Recarga(
      id: cartoaJson["id"],
      valor: cartoaJson["valor"],
      observacao: cartoaJson["observacao"],
      data: cartoaJson["data"],
    );

    return recarga;
  }
}
