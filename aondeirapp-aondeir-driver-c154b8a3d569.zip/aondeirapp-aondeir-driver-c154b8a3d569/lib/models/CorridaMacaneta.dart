class CorridaMacaneta {
  int? id;
  String? nome;
  String? endereco_partida;
  String? latitude_partida;
  String? longitude_partida;
  String? metodo_pagamento;
  String? endereco_destino;
  String? latitude_destino;
  String? longitude_destino;
  String? valor_corrida;
  String? mensagem_info_pos_aceite;
  String? complemento_partida;
  String? referencia_partida;
  int? distancia_viagem_metros;
  int? tempo_estimado_segundos;
  String? valor_estimado;
  String? valor_final;
  dynamic status;
  String? buscar_cliente;
  String? ddd;
  String? telefone_cadastro;
  String? cpf;
  String? telefone_contato;
  String? data_agendar;
  String? hora_agendar;
  String? antecedencia_agendar;
  String? visivel;
  String? antecedencia;
  String? mensagem_info_interna;
  String? porta_malas_grande;
  String? aceita_animais;
  String? motorista_mulher;
  String? pcd;
  String? mais_carros;
  String? corridas_apenas_motorista;
  String? data_iniciado;
  String? data_finalizado;
  dynamic categoria;
  String? endereco_finalizacao;
  String? endereco_latitude_finalizacao;
  String? endereco_longitude_finalizacao;
  dynamic tarifa;

  CorridaMacaneta({
    required this.nome,
    required this.endereco_partida,
    required this.latitude_partida,
    required this.longitude_partida,
    required this.metodo_pagamento,
    required this.endereco_destino,
    required this.latitude_destino,
    required this.longitude_destino,
    required this.valor_corrida,
    required this.mensagem_info_pos_aceite,
    required this.complemento_partida,
    required this.referencia_partida,
    required this.distancia_viagem_metros,
    required this.tempo_estimado_segundos,
    required this.valor_estimado,
    required this.valor_final,
    required this.tarifa,
    required this.status,
    required this.buscar_cliente,
    required this.ddd,
    required this.telefone_cadastro,
    required this.cpf,
    required this.telefone_contato,
    required this.data_agendar,
    required this.hora_agendar,
    required this.antecedencia_agendar,
    required this.visivel,
    required this.antecedencia,
    required this.mensagem_info_interna,
    required this.porta_malas_grande,
    required this.aceita_animais,
    required this.motorista_mulher,
    required this.pcd,
    required this.mais_carros,
    required this.corridas_apenas_motorista,
    required this.id,
    required this.data_iniciado,
    required this.data_finalizado,
    required this.categoria,
    required this.endereco_finalizacao,
    required this.endereco_latitude_finalizacao,
    required this.endereco_longitude_finalizacao,
  });

  factory CorridaMacaneta.fromJson(Map<String, dynamic> cartoaJson) {
    CorridaMacaneta corridaMacaneta = CorridaMacaneta(
      nome: cartoaJson["nome"],
      endereco_partida: cartoaJson["endereco_partida"],
      latitude_partida: cartoaJson["latitude_partida"],
      longitude_partida: cartoaJson["longitude_partida"],
      metodo_pagamento: cartoaJson["metodo_pagamento"],
      endereco_destino: cartoaJson["endereco_destino"],
      latitude_destino: cartoaJson["latitude_destino"],
      longitude_destino: cartoaJson["longitude_destino"],
      distancia_viagem_metros: cartoaJson["distancia_viagem_metros"],
      valor_corrida: cartoaJson["valor_corrida"],
      mensagem_info_pos_aceite: cartoaJson["mensagem_info_pos_aceite"],
      complemento_partida: cartoaJson["complemento_partida"],
      referencia_partida: cartoaJson["referencia_partida"],
      tempo_estimado_segundos: cartoaJson["tempo_estimado_segundos"],
      valor_estimado: cartoaJson["valor_estimado"],
      valor_final: cartoaJson["valor_final"],
      tarifa: cartoaJson["tarifa"],
      status: cartoaJson["status"],
      buscar_cliente: cartoaJson["buscar_cliente"],
      ddd: cartoaJson["ddd"],
      telefone_cadastro: cartoaJson["telefone_cadastro"],
      cpf: cartoaJson["cpf"],
      telefone_contato: cartoaJson["telefone_contato"],
      data_agendar: cartoaJson["data_agendar"],
      hora_agendar: cartoaJson["hora_agendar"],
      antecedencia_agendar: cartoaJson["antecedencia_agendar"],
      visivel: cartoaJson["visivel"],
      antecedencia: cartoaJson["antecedencia"],
      mensagem_info_interna: cartoaJson["mensagem_info_interna"],
      porta_malas_grande: cartoaJson["porta_malas_grande"],
      aceita_animais: cartoaJson["aceita_animais"],
      motorista_mulher: cartoaJson["motorista_mulher"],
      pcd: cartoaJson["pcd"],
      mais_carros: cartoaJson["mais_carros"],
      data_iniciado: cartoaJson["data_iniciado"],
      data_finalizado: cartoaJson["data_finalizado"],
      corridas_apenas_motorista: cartoaJson["corridas_apenas_motorista"],
      id: cartoaJson["id"],
      categoria: cartoaJson["categoria"],
      endereco_finalizacao: cartoaJson["endereco_finalizacao"],
      endereco_latitude_finalizacao:
          cartoaJson["endereco_latitude_finalizacao"],
      endereco_longitude_finalizacao:
          cartoaJson["endereco_longitude_finalizacao"],
    );

    return corridaMacaneta;
  }
}
