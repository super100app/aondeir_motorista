class Cartao {
  int id;
  String card_pagarme_id;
  String brand;
  String last_four_digits;

  Cartao({
    required this.id,
    required this.card_pagarme_id,
    required this.brand,
    required this.last_four_digits,
  });

  factory Cartao.fromJson(Map<String, dynamic> cartoaJson) {
    Cartao cartao = Cartao(
      id: cartoaJson["id"],
      card_pagarme_id: cartoaJson["card_pagarme_id"],
      brand: cartoaJson["brand"],
      last_four_digits: cartoaJson["last_four_digits"],
    );

    return cartao;
  }
}
