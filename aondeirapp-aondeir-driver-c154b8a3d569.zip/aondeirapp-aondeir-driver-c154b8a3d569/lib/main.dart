import 'dart:async';
import 'dart:io';
import 'dart:isolate';
import 'package:flutter/foundation.dart';
import 'package:aondeir_motorista/screens/Carregamento/CarregamentoScreen.dart';
import 'package:aondeir_motorista/screens/Modal/ModalPadraoGeral.dart';
import 'package:aondeir_motorista/screens/Permissao/PermissaoGeolocatorScreen.dart';
import 'package:aondeir_motorista/screens/Permissao/PermissaoOverlayScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/BottomNavigationBar/NavigationScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Home/Corrida/CheckoutScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Home/Corrida/DetalhesCorridaScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/AberturaCorrida/ChatMensagem/MensagemScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/AberturaCorrida/DetalhesMacanetaScreen.dart';
import 'package:aondeir_motorista/screens/Usuario/Menu/Cadastro/OpcoesScreen.dart';
import 'package:aondeir_motorista/service/BancoService.dart';
import 'package:aondeir_motorista/service/CartaoService.dart';
import 'package:aondeir_motorista/service/CorridaService.dart';
import 'package:aondeir_motorista/service/DocumentoService.dart';
import 'package:aondeir_motorista/service/FranquiaService.dart';
import 'package:aondeir_motorista/service/GanhoService.dart';
import 'package:aondeir_motorista/service/LocalizacaoService.dart';
import 'package:aondeir_motorista/service/LogErroService.dart';
import 'package:aondeir_motorista/service/MensagemService.dart';
import 'package:aondeir_motorista/service/NavigationService.dart';
import 'package:aondeir_motorista/service/RecargaService.dart';
import 'package:aondeir_motorista/service/StatusService.dart';
import 'package:aondeir_motorista/service/UsuarioService.dart';
import 'package:aondeir_motorista/service/UpdateService.dart';
import 'package:aondeir_motorista/service/auth/CadastroCompletoService.dart';
import 'package:aondeir_motorista/service/auth/LoginSimplesService.dart';
import 'package:aondeir_motorista/service/categoria/CategoriaService.dart';
import 'package:aondeir_motorista/service/corrida/CorridaSalvarCoordenadaRotaService.dart';
import 'package:aondeir_motorista/service/corrida/CorridaBuscarService.dart';
import 'package:aondeir_motorista/service/corrida/MotoristaAtualizaLocalizacaoService.dart';
import 'package:aondeir_motorista/service/corrida/macaneta/parada/CorridaMacanetaAdicionarParadaService.dart';
import 'package:aondeir_motorista/service/corrida/macaneta/parada/CorridaMacanetaBuscarDuracaoParadaService.dart';
import 'package:aondeir_motorista/service/corrida/macaneta/parada/CorridaMacanetaFinalizarParadaService.dart';
import 'package:aondeir_motorista/service/corrida/macaneta/parada/CorridaMacanetaPegarDuracaoParadaService.dart';
import 'package:aondeir_motorista/service/corrida/parada/CorridaAdicionarParadaService.dart';
import 'package:aondeir_motorista/service/corrida/CorridaAlterarPontosRotaParaCalculadoService.dart';
import 'package:aondeir_motorista/service/corrida/CorridaBuscarCorridaDisponivelService.dart';
import 'package:aondeir_motorista/service/corrida/CorridaBuscarCorridaIndisponivelDisparadaService.dart';
import 'package:aondeir_motorista/service/corrida/CorridaBuscarCorridaPendenteDisponivelService.dart';
import 'package:aondeir_motorista/service/corrida/CorridaBuscarDuracaoParadaService.dart';
import 'package:aondeir_motorista/service/corrida/CorridaConverterDistanciaParaTextoService.dart';
import 'package:aondeir_motorista/service/corrida/CorridaConverterDuracaoParaTextoService.dart';
import 'package:aondeir_motorista/service/corrida/CorridaPegarCoordenadasNaoCalculadaService.dart';
import 'package:aondeir_motorista/service/corrida/parada/CorridaFinalizarParadaService.dart';
import 'package:aondeir_motorista/service/corrida/parada/CorridaPegarDuracaoParadaService.dart';
import 'package:aondeir_motorista/service/corrida/CorridaRecalcularValorCorridaMacanetaService.dart';
import 'package:aondeir_motorista/service/corrida/CorridaRecusarCorridaDisponivelService.dart';
import 'package:aondeir_motorista/service/corrida/CorridaRecusarCorridaPendenteDisponivelService.dart';
import 'package:aondeir_motorista/service/corrida/macaneta/CorridaMacanetaAlterarStatusAguardandoPassageiroService.dart';
import 'package:aondeir_motorista/service/corrida/macaneta/CorridaMacanetaConfirmarPagamentoService.dart';
import 'package:aondeir_motorista/service/corrida/macaneta/CorridaMacanetaFinalizarService.dart';
import 'package:aondeir_motorista/service/corrida/macaneta/CorridaMacanetaIniciarCorridaService.dart';
import 'package:aondeir_motorista/service/corrida/macaneta/CorridaMacanetaPegarEmAndamentoService.dart';
import 'package:aondeir_motorista/service/corrida/macaneta/CorridaMacanetaSalvarCoordenadaRotaService.dart';
import 'package:aondeir_motorista/service/corrida/macaneta/CorridaMacanetaSalvarPrimeiraCoordenadaRotaService.dart';
import 'package:aondeir_motorista/service/corrida/proximo-destino/CorridaAdicionarProximoDestinoService.dart';
import 'package:aondeir_motorista/service/firebase/FireBaseSalvarTokenService.dart';
import 'package:aondeir_motorista/service/helper/ConverterDinheiroParaReaisService.dart';
import 'package:aondeir_motorista/service/helper/VariavelControleService.dart';
import 'package:aondeir_motorista/service/ligacao/FazerLigacaoService.dart';
import 'package:aondeir_motorista/service/ligacao/ManipularPermissoesLigacaoService.dart';
import 'package:aondeir_motorista/service/localizacao/LocalizacaoAtualizarService.dart';
import 'package:aondeir_motorista/service/localizacao/LocalizacaoCheckPermissao.dart';
import 'package:aondeir_motorista/service/localizacao/LocalizacaoCheckPermissaoLocalizacao.dart';
import 'package:aondeir_motorista/service/localizacao/LocalizacaoGetCurrentLocationService.dart';
import 'package:aondeir_motorista/service/localizacao/LocalizacaoRequestPermissao.dart';
import 'package:aondeir_motorista/service/localizacao/LocalizacaoStartListenService.dart';
import 'package:aondeir_motorista/service/localizacao/PesquisaEnderecoGeocodificacaoPorCoordenadaService.dart';
import 'package:aondeir_motorista/service/mapbox/MapboxRecalcularRotaService.dart';
import 'package:aondeir_motorista/service/corrida/CorridaSomarDistanciaPercorridaEntrePontosRotaService.dart';
import 'package:aondeir_motorista/service/corrida/CorridaGuardarDistanciaPercorridaOfflineService.dart';
import 'package:aondeir_motorista/service/corrida/CorridaGuardarCoordenadasOfflineService.dart';
import 'package:aondeir_motorista/service/corrida/CorridaPegarCoordenadasResitradaService.dart';
import 'package:aondeir_motorista/service/corrida/CorridaPegarDistanciaEntrePontosService.dart';
import 'package:aondeir_motorista/service/corrida/CorridaPegarDistanciaPercorridaService.dart';
import 'package:aondeir_motorista/service/corrida/macaneta/CorridaMacanetaPegarUltimaCoordenadaResitradaService.dart';
import 'package:aondeir_motorista/service/corrida/CorridaSalvarCoordenadasService.dart';
import 'package:aondeir_motorista/service/corrida/CorridaPegarDuracaoService.dart';
import 'package:aondeir_motorista/service/corrida/CorridaSalvarDistanciaPercorridaService.dart';
import 'package:aondeir_motorista/service/corrida/CorridaSalvarDurancaoService.dart';
import 'package:aondeir_motorista/service/corrida/CorridaSomarTotalDistanciaPercorridaRotaService.dart';
import 'package:aondeir_motorista/service/helper/CalcularSegundosRestanteService.dart';
import 'package:aondeir_motorista/service/helper/CheckConexaoService.dart';
import 'package:aondeir_motorista/service/helper/ConverterSegundoParaMinutoService.dart';
import 'package:aondeir_motorista/service/mapbox/MapboxConverterCordenadasService.dart';
import 'package:aondeir_motorista/service/mapbox/MapboxObterDistanciaPercorridaRotaPorCoordenadasService.dart';
import 'package:aondeir_motorista/service/mensagem/PegarMensagensNaoLidaService.dart';
import 'package:aondeir_motorista/service/middleware/CurrentScreenService.dart';
import 'package:aondeir_motorista/service/middleware/VerificaCorridaAndamentoService.dart';
import 'package:aondeir_motorista/service/passageiro/PassageiroService.dart';
import 'package:aondeir_motorista/service/toque/ToqueService.dart';
import 'package:aondeir_motorista/service/localizacao/LocalizacaoGetPlaceMarkFromCoordinatesService.dart';
import 'package:aondeir_motorista/service/NotificationService.dart';
import 'package:aondeir_motorista/service/firebase/FirebaseRealtimeService.dart';
import 'package:aondeir_motorista/service/FirebasePresenceService.dart';
import 'package:aondeir_motorista/service/OverlayService.dart';
import 'package:aondeir_motorista/service/OverlayLifecycleService.dart';
export 'package:aondeir_motorista/service/OverlayService.dart' show overlayMain;

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:geolocator/geolocator.dart';
import 'package:provider/provider.dart';
import 'package:flutter/material.dart';
import 'package:aondeir_motorista/screens/Inicio/InitialScreen.dart';
import 'package:aondeir_motorista/service/EnderecoService.dart';
import 'package:aondeir_motorista/service/LoginService.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:aondeir_motorista/service/SocketService.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:socket_io_client/socket_io_client.dart';
import 'firebase_options.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart' as overlay;
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:app_tracking_transparency/app_tracking_transparency.dart';

/// Entry point para o overlay - executado em isolate separado
@pragma("vm:entry-point")
void overlayMain() {
  runApp(OverlayMainApp());
}

Future<void> checkAndRequestOverlayPermission() async {
  if (Platform.isAndroid) {
    bool? status = await overlay.FlutterOverlayWindow.isPermissionGranted();
    if (status != true) {
      print("⚠️ Permissão de overlay não concedida. Solicitando...");
      await overlay.FlutterOverlayWindow.requestPermission();
    } else {
      print("✅ Permissão de overlay concedida!");
    }
    
    // Garantir que não há overlay ativo ao iniciar o app
    bool isActive = await overlay.FlutterOverlayWindow.isActive();
    if (isActive) {
      print("🔄 Fechando overlay existente ao iniciar o app...");
      await overlay.FlutterOverlayWindow.closeOverlay();
    }
  }
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Suprime logs de debug em produção
  if (kReleaseMode) {
    debugPrint = (String? message, {int? wrapWidth}) {};
  }
  
  dotenv.load(fileName: '.env');
  startListeningFirebase();
  
  // NÃO solicitar permissão de overlay ao iniciar o app
  // A permissão será solicitada apenas quando o motorista se conectar
  // await checkAndRequestOverlayPermission();

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider<StatusService>.value(
          value: StatusService(),
        ),
        ChangeNotifierProvider<EnderecoService>.value(
          value: EnderecoService(),
        ),
        ChangeNotifierProvider<LogErroService>.value(
          value: LogErroService(),
        ),
        ChangeNotifierProvider<LoginService>(
          create: (context) => LoginService(context),
        ),
        ChangeNotifierProvider<CorridaService>(
          create: (context) => CorridaService(context),
        ),
        ChangeNotifierProvider<CurrentScreenService>.value(
          value: CurrentScreenService(),
        ),
        ChangeNotifierProvider<VerificaCorridaAndamentoService>(
          create: (context) => VerificaCorridaAndamentoService(context),
        ),
        ChangeNotifierProvider<UsuarioService>(
          create: (context) => UsuarioService(context),
        ),
        ChangeNotifierProvider<UpdateService>.value(
          value: UpdateService(),
        ),
        ChangeNotifierProvider<SocketService>(
          create: (context) => SocketService(context),
        ),
       
        ChangeNotifierProvider<LocalizacaoService>(
          create: (context) => LocalizacaoService(context),
        ),
        ChangeNotifierProvider<VariavelControleService>(
          create: (context) => VariavelControleService(context),
        ),
        ChangeNotifierProvider<RecargaService>.value(
          value: RecargaService(),
        ),
        ChangeNotifierProvider<CartaoService>.value(
          value: CartaoService(),
        ),
        ChangeNotifierProvider<FranquiaService>.value(
          value: FranquiaService(),
        ),
        ChangeNotifierProvider<GanhoService>.value(
          value: GanhoService(),
        ),
        ChangeNotifierProvider<MensagemService>.value(
          value: MensagemService(),
        ),
        ChangeNotifierProvider<DocumentoService>.value(
          value: DocumentoService(),
        ),
        ChangeNotifierProvider<BancoService>.value(
          value: BancoService(),
        ),
        ChangeNotifierProvider<CorridaSalvarDistanciaPercorridaService>.value(
          value: CorridaSalvarDistanciaPercorridaService(),
        ),
        ChangeNotifierProvider<CorridaSalvarDurancaoService>.value(
          value: CorridaSalvarDurancaoService(),
        ),
        ChangeNotifierProvider<CorridaPegarDuracaoService>.value(
          value: CorridaPegarDuracaoService(),
        ),
        ChangeNotifierProvider<ConverterSegundoParaMinutoService>.value(
          value: ConverterSegundoParaMinutoService(),
        ),
        ChangeNotifierProvider<CalcularSegundosRestanteService>.value(
          value: CalcularSegundosRestanteService(),
        ),
        ChangeNotifierProvider<CorridaGuardarCoordenadasOfflineService>.value(
          value: CorridaGuardarCoordenadasOfflineService(),
        ),
        ChangeNotifierProvider<CheckConexaoService>.value(
          value: CheckConexaoService(),
        ),
        ChangeNotifierProvider<CorridaSalvarCoordenadasService>.value(
          value: CorridaSalvarCoordenadasService(),
        ),
        ChangeNotifierProvider<
            CorridaGuardarDistanciaPercorridaOfflineService>.value(
          value: CorridaGuardarDistanciaPercorridaOfflineService(),
        ),
        ChangeNotifierProvider<CorridaPegarDistanciaPercorridaService>.value(
          value: CorridaPegarDistanciaPercorridaService(),
        ),
        ChangeNotifierProvider<
            CorridaMacanetaPegarUltimaCoordenadaResitradaService>.value(
          value: CorridaMacanetaPegarUltimaCoordenadaResitradaService(),
        ),
        // ChangeNotifierProvider<MapboxPegarRotaService>.value(
        //   value: MapboxPegarRotaService(),
        // ),
        ChangeNotifierProvider<
            MapboxObterDistanciaPercorridaRotaPorCoordenadasService>.value(
          value: MapboxObterDistanciaPercorridaRotaPorCoordenadasService(),
        ),
        ChangeNotifierProvider<CorridaPegarCoordenadasResitradaService>.value(
          value: CorridaPegarCoordenadasResitradaService(),
        ),
        ChangeNotifierProvider<MapboxConverterCordenadasService>.value(
          value: MapboxConverterCordenadasService(),
        ),
        ChangeNotifierProvider<CorridaPegarDistanciaEntrePontosService>.value(
          value: CorridaPegarDistanciaEntrePontosService(),
        ),
        ChangeNotifierProvider<
            CorridaSomarDistanciaPercorridaEntrePontosRotaService>.value(
          value: CorridaSomarDistanciaPercorridaEntrePontosRotaService(),
        ),
        ChangeNotifierProvider<
            CorridaSomarTotalDistanciaPercorridaRotaService>.value(
          value: CorridaSomarTotalDistanciaPercorridaRotaService(),
        ),
        ChangeNotifierProvider<MapboxRecalcularRotaService>.value(
          value: MapboxRecalcularRotaService(),
        ),
        ChangeNotifierProvider<
            CorridaPegarCoordenadasNaoCalculadaService>.value(
          value: CorridaPegarCoordenadasNaoCalculadaService(),
        ),
        ChangeNotifierProvider<
            CorridaAlterarPontosRotaParaCalculadoService>.value(
          value: CorridaAlterarPontosRotaParaCalculadoService(),
        ),
        ChangeNotifierProvider<
            CorridaRecalcularValorCorridaMacanetaService>.value(
          value: CorridaRecalcularValorCorridaMacanetaService(),
        ),
        ChangeNotifierProvider<CorridaConverterDistanciaParaTextoService>.value(
          value: CorridaConverterDistanciaParaTextoService(),
        ),
        ChangeNotifierProvider<CorridaConverterDuracaoParaTextoService>.value(
          value: CorridaConverterDuracaoParaTextoService(),
        ),
        ChangeNotifierProvider<ConverterDinheiroParaReaisService>.value(
          value: ConverterDinheiroParaReaisService(),
        ),
        ChangeNotifierProvider<LocalizacaoAtualizarService>.value(
          value: LocalizacaoAtualizarService(),
        ),
        ChangeNotifierProvider<LocalizacaoStartListenService>(
          create: (context) => LocalizacaoStartListenService(context),
        ),
        ChangeNotifierProvider<LocalizacaoCheckPermissao>.value(
          value: LocalizacaoCheckPermissao(),
        ),
        ChangeNotifierProvider<NavigationService>.value(
          value: NavigationService(),
        ),
        ChangeNotifierProvider<FazerLigacaoService>.value(
          value: FazerLigacaoService(),
        ),
        ChangeNotifierProvider<ManipularPermissoesLigacaoService>.value(
          value: ManipularPermissoesLigacaoService(),
        ),
        ChangeNotifierProvider<ToqueService>.value(
          value: ToqueService(),
        ),
        ChangeNotifierProvider<LocalizacaoCheckPermissaoLocalizacao>.value(
          value: LocalizacaoCheckPermissaoLocalizacao(),
        ),
        ChangeNotifierProvider<LocalizacaoRequestPermissao>.value(
          value: LocalizacaoRequestPermissao(),
        ),
        ChangeNotifierProvider<LocalizacaoGetCurrentLocationService>.value(
          value: LocalizacaoGetCurrentLocationService(),
        ),
        ChangeNotifierProvider<FireBaseSalvarTokenService>.value(
          value: FireBaseSalvarTokenService(),
        ),
        ChangeNotifierProvider<CadastroCompletoService>(
          create: (context) => CadastroCompletoService(context),
        ),
        ChangeNotifierProvider<LoginSimplesService>.value(
          value: LoginSimplesService(),
        ),
        ChangeNotifierProvider<PegarMensagensNaoLidaService>.value(
          value: PegarMensagensNaoLidaService(),
        ),
        ChangeNotifierProvider<CorridaMacanetaPegarEmAndamentoService>.value(
          value: CorridaMacanetaPegarEmAndamentoService(),
        ),
        ChangeNotifierProvider<PassageiroService>.value(
          value: PassageiroService(),
        ),
        ChangeNotifierProvider<CategoriaService>.value(
          value: CategoriaService(),
        ),
        ChangeNotifierProvider<
            PesquisaEnderecoGeocodificacaoPorCoordenadaService>.value(
          value: PesquisaEnderecoGeocodificacaoPorCoordenadaService(),
        ),
        ChangeNotifierProvider<CorridaMacanetaIniciarCorridaService>.value(
          value: CorridaMacanetaIniciarCorridaService(),
        ),
        ChangeNotifierProvider<
            CorridaMacanetaAlterarStatusAguardandoPassageiroService>.value(
          value: CorridaMacanetaAlterarStatusAguardandoPassageiroService(),
        ),
        ChangeNotifierProvider<CorridaMacanetaFinalizarService>.value(
          value: CorridaMacanetaFinalizarService(),
        ),
        ChangeNotifierProvider<
            CorridaMacanetaSalvarCoordenadaRotaService>.value(
          value: CorridaMacanetaSalvarCoordenadaRotaService(),
        ),
        ChangeNotifierProvider<CorridaMacanetaConfirmarPagamentoService>.value(
          value: CorridaMacanetaConfirmarPagamentoService(),
        ),
        ChangeNotifierProvider<
            CorridaMacanetaSalvarPrimeiraCoordenadaRotaService>.value(
          value: CorridaMacanetaSalvarPrimeiraCoordenadaRotaService(),
        ),
        ChangeNotifierProvider<CorridaBuscarCorridaDisponivelService>.value(
          value: CorridaBuscarCorridaDisponivelService(),
        ),
        ChangeNotifierProvider<
            CorridaBuscarCorridaPendenteDisponivelService>.value(
          value: CorridaBuscarCorridaPendenteDisponivelService(),
        ),
        ChangeNotifierProvider<
            CorridaRecusarCorridaPendenteDisponivelService>.value(
          value: CorridaRecusarCorridaPendenteDisponivelService(),
        ),
        ChangeNotifierProvider<
            CorridaBuscarCorridaIndisponivelDisparadaService>.value(
          value: CorridaBuscarCorridaIndisponivelDisparadaService(),
        ),
        ChangeNotifierProvider<CorridaRecusarCorridaDisponivelService>.value(
          value: CorridaRecusarCorridaDisponivelService(),
        ),
        ChangeNotifierProvider<CorridaAdicionarParadaService>.value(
          value: CorridaAdicionarParadaService(),
        ),
        ChangeNotifierProvider<CorridaPegarDuracaoParadaService>.value(
          value: CorridaPegarDuracaoParadaService(),
        ),
        ChangeNotifierProvider<CorridaBuscarDuracaoParadaService>.value(
          value: CorridaBuscarDuracaoParadaService(),
        ),
        ChangeNotifierProvider<CorridaFinalizarParadaService>.value(
          value: CorridaFinalizarParadaService(),
        ),
        ChangeNotifierProvider<CorridaMacanetaAdicionarParadaService>.value(
          value: CorridaMacanetaAdicionarParadaService(),
        ),
        ChangeNotifierProvider<CorridaMacanetaPegarDuracaoParadaService>.value(
          value: CorridaMacanetaPegarDuracaoParadaService(),
        ),
        ChangeNotifierProvider<CorridaMacanetaBuscarDuracaoParadaService>.value(
          value: CorridaMacanetaBuscarDuracaoParadaService(),
        ),
        ChangeNotifierProvider<CorridaMacanetaFinalizarParadaService>.value(
          value: CorridaMacanetaFinalizarParadaService(),
        ),
        ChangeNotifierProvider<CorridaIniciarProximoDestinoService>.value(
          value: CorridaIniciarProximoDestinoService(),
        ),
        ChangeNotifierProvider<CorridaSalvarCoordenadaRotaService>.value(
          value: CorridaSalvarCoordenadaRotaService(),
        ),
        ChangeNotifierProvider<
            LocalizacaoGetPlaceMarkFromCoordinatesService>.value(
          value: LocalizacaoGetPlaceMarkFromCoordinatesService(),
        ),
        ChangeNotifierProvider<CorridaBuscarService>(
          create: (context) => CorridaBuscarService(context),
        ),
        ChangeNotifierProvider<MotoristaAtualizaLocalizacaoService>(
          create: (context) => MotoristaAtualizaLocalizacaoService(context),
        ),
        ChangeNotifierProvider<NotificationService>.value(
          value: NotificationService(),
        ),
        // Adicione o FirebaseRealtimeService
        ChangeNotifierProxyProvider<UsuarioService, FirebaseRealtimeService>(
          create: (context) => FirebaseRealtimeService(context),
          update: (context, usuarioService, previous) {
            if (previous == null) {
              return FirebaseRealtimeService(context);
            }
            return previous;
          },
        ),
      ],
      child: MaterialApp(
        title: 'App motorista',
        builder: (context, child) {
          return MediaQuery(
            data: MediaQuery.of(context).copyWith(textScaler: TextScaler.linear(1.0)),
            child: child!,
          );
        },
        home: MyApp(),
        routes: {
          'home': (_) => NavigationScreen(),
          '/corrida': (_) => DetalhesCorridaScreen(),
          '/corrida_checkout': (_) => CheckoutScreen(),
          '/mensagem': (_) => MensagemScreen(),
        },
        initialRoute: '/',
      ),
    ),
  );
}

startListeningFirebase() async {

  try {
    print(Firebase.apps.isNotEmpty);
    if (Firebase.apps.isNotEmpty) {
      print("✅ Firebase já inicializado");
      return;
    }
    if (Firebase.apps.isEmpty) {
      await Firebase.initializeApp(
        options: DefaultFirebaseOptions.currentPlatform,
      );

      final FirebaseMessaging messaging = FirebaseMessaging.instance;
      await notificacaoSettings(messaging);
      await initialNotificacaoSettings();

      // disparoNotificacao();
    }
  } catch (e) {
    print("🔥 Erro ao inicializar Firebase: $e");
  }
}

disparoNotificacao(BuildContext context) async {
  final corridaBuscarService =
      Provider.of<CorridaBuscarService>(context, listen: false);
  FirebaseMessaging.onMessage.listen((RemoteMessage message) {
    if (message.data['tipo'] == 'CORRIDA_DISPONIVEL') {
      print("🚀 Nova corrida disponível - App em foreground");
      // App aberto - comportamento normal
      notificacao(message.notification!, message, 'toque_viagemdisponivel_motorista', '1',
          'corridaDisponivelChannel');
      corridaBuscarService.execute('', '');
      _chamarBuscarCorrida();
    } else if (message.data['tipo'] == 'MENSAGEM_PASSAGEIRO') {
      notificacao(message.notification!, message, 'toque_notificacao_de_mensagem_motorista_passageiro',
          '2', 'mensagemPassageiroChannel');
    } else if (message.data['tipo'] == 'FRANQUIA_MENSAGEM_MOTORISTA') {
      notificacao(message.notification!, message, 'toque_notificacao_de_mensagem_motorista_passageiro',
          '3', 'mensagemFraquiaChannel');
    } else if (message.data['tipo'] == 'CORRIDA_CANCELADA_PELO_PASSAGEIRO') {
      notificacao(message.notification!, message, 'CORRIDA_CANCELADA',
          '4', 'corridaCanceladaPeloPassageiroChannel');
    } else if (message.data['tipo'] == 'MOTORISTA_CORRIDA_ACEITA') {
      notificacao(
          message.notification!, message, 'toque_motorista_corrida_aceita', '5', message.data['tipo']);
    } else {
      notificacao(
          message.notification!, message, 'toque_motorista_corrida_aceita', '6', message.data['tipo']);
    }
  });
  
  // Handler para mensagens quando app está em background/terminado
  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
}

// Handler para mensagens em background
@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  print("🚀 Notificação recebida em background: ${message.data}");
  
  if (message.data['tipo'] == 'CORRIDA_DISPONIVEL') {
    print("✅ [Background Handler] É uma CORRIDA_DISPONIVEL");
    
    // Verificar se é corrida cancelada
    String? status = message.data['status']?.toString().toUpperCase();
    bool corridaCancelada = status != null && status.contains('CANCELADA');
    
    if (corridaCancelada) {
      print("⚠️ [Background Handler] Corrida está CANCELADA");
      
      // TODO: Verificar se é corrida em andamento
      // Como não temos acesso ao CorridaService aqui no isolate,
      // sempre vamos mostrar a notificação de corrida cancelada
      // O tratamento completo será feito no FirebaseRealtimeService
      print("⚠️ [Background Handler] Corrida cancelada - não mostrando overlay");
      return;
    }
    
    print("🎯 [Background Handler] Chamando showNovaCorridaOverlay...");
    
    try {
      await OverlayService.showNovaCorridaOverlay(message.data);
      print("✅ [Background Handler] showNovaCorridaOverlay executado");
    } catch (e) {
      print("❌ [Background Handler] ERRO ao mostrar overlay: $e");
      print("❌ [Background Handler] Stack: ${StackTrace.current}");
    }
  } else {
    print("⚠️ [Background Handler] Não é CORRIDA_DISPONIVEL, tipo: ${message.data['tipo']}");
  }
}

// Função para chamar buscarCorrida() do NavigationScreen
void _chamarBuscarCorrida() {
  try {
    // Usa o contexto global para acessar o Provider
    WidgetsBinding.instance.addPostFrameCallback((_) {
      // Notifica o sistema que uma nova corrida chegou via notificação
      print("🔔 Notificação recebida - buscando novas corridas...");
      
      // O CorridaBuscarService já foi executado acima, então só precisamos
      // garantir que o NavigationScreen seja notificado para atualizar a UI
      _notificarNavigationScreen();
    });
  } catch (e) {
    print("❌ Erro ao chamar buscarCorrida(): $e");
  }
}

// Função para notificar o NavigationScreen
void _notificarNavigationScreen() {
  // Emite um evento global para que o NavigationScreen possa reagir
  // Isso será implementado através do Provider
  print("📱 Notificando NavigationScreen sobre nova corrida...");
  
  // Usa o NotificationService para notificar sobre nova corrida
  WidgetsBinding.instance.addPostFrameCallback((_) {
    try {
      // Acessa o NotificationService através do contexto global
      final notificationService = NotificationService();
      notificationService.notificarNovaCorrida('CORRIDA_DISPONIVEL');
      print("✅ NotificationService notificado com sucesso!");
    } catch (e) {
      print("❌ Erro ao notificar NotificationService: $e");
    }
  });
}

initialNotificacaoSettings() async {
  FlutterLocalNotificationsPlugin notificationsPlugin = FlutterLocalNotificationsPlugin();
  AndroidInitializationSettings initializationSettingsAndroid = const AndroidInitializationSettings('launch_background');


  final DarwinInitializationSettings initializationSettingsIOS =
      DarwinInitializationSettings(
    requestSoundPermission: true, // Solicita permissão para som
  );
  var initializationSettings = InitializationSettings(
      android: initializationSettingsAndroid, iOS: initializationSettingsIOS);

  notificationsPlugin.initialize(
    initializationSettings, 
    onDidReceiveNotificationResponse: (NotificationResponse notificationResponse) async {
      // Quando o usuário tocar na notificação
      if (notificationResponse.payload == 'nova_corrida') {
        print("🚀 Usuário tocou na notificação de nova corrida");
        // A notificação vai abrir o app automaticamente
        // O app já vai buscar as corridas disponíveis quando abrir
      }
    }
  );
}

notificacaoSettings(FirebaseMessaging messaging) async {
  NotificationSettings settings = await messaging.requestPermission(
    alert: true,
    badge: true,
    sound: true,
  );

  if (settings.authorizationStatus == AuthorizationStatus.authorized) {
  } else if (settings.authorizationStatus == AuthorizationStatus.provisional) {
  } else {}
}

notificacao(RemoteNotification notification, message, toque, idNotificacao, tituloConfig) async {
  final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
      FlutterLocalNotificationsPlugin();
  final DarwinNotificationDetails iosPlatformChannelSpecifics =
    DarwinNotificationDetails(
      presentAlert: true,
      presentSound: true,
      sound: '${toque}.caf', // 🔊 Nome do som personalizado
    );

  AndroidNotificationDetails androidPlatformChannelSpecifics =
      AndroidNotificationDetails(
    idNotificacao,
    tituloConfig,
    importance: Importance.max,
    priority: Priority.high,
    showProgress: true,
    enableVibration: true,
    playSound: true,
    sound: RawResourceAndroidNotificationSound(toque),
  );

  NotificationDetails platformChannelSpecifics =
      NotificationDetails(
        android: androidPlatformChannelSpecifics,
        iOS: iosPlatformChannelSpecifics,
        );

  await flutterLocalNotificationsPlugin.show(
        0,
        notification.title ?? 'Sem título',
        notification.body ?? 'Sem conteúdo',
        platformChannelSpecifics,
        payload: message.data['click_action']
  );
}

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> with WidgetsBindingObserver {
  final storage = new FlutterSecureStorage();
  var deslogado = false;
  SendPort? homePort;
  String? latestMessageFromOverlay;
  late final StreamController overlayStream;
  var pegandoCorridaId = '0';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    requestTrackingPermission();
    _initializeForegroundTask();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      _startTimer();
      disparoNotificacao(context);
    });
  }
  
  @override
  void dispose() {
    _connectionTimer?.cancel();
    _locationUpdateTimer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  /// Método separado para lidar com o app pausado
  Future<void> _handleAppPaused() async {
    try {
      print("🟡 [main] Iniciando processamento do app pausado...");
      print("🟡 [main] mounted: $mounted");
      
      // Verificar se o contexto ainda está válido
      if (!mounted) {
        print("⚠️ [main] Context não está mais montado, abortando...");
        return;
      }
      
      // ✅ IMPORTANTE: Aguardar um pouco mais quando o app foi recém aberto
      // Isso garante que todos os serviços estejam inicializados
      await Future.delayed(Duration(milliseconds: 300));
      
      if (!mounted) {
        print("⚠️ [main] Context não está mais montado após delay, abortando...");
        return;
      }
      
      // Verificar se o Provider está disponível
      try {
        var usuarioService = Provider.of<UsuarioService>(context, listen: false);
        print("🟡 [main] UsuarioService obtido, verificando status do motorista...");
        
        // ✅ Usar método robusto que verifica memória e storage
        String? logado = await usuarioService.getMotoristaLogadoStatus();
        
        if (logado == 'CONECTADO') {
          print("🟡 [main] Motorista está CONECTADO - Iniciando serviços...");
          
          // Quando minimizado, usar apenas foreground service (não overlay)
          bool isRunning = await FlutterForegroundTask.isRunningService;
          if (!isRunning) {
            print("🚀 Iniciando foreground service (app minimizado)...");
            await FlutterForegroundTask.startService(
              notificationTitle: 'Aondeir',
              notificationText: 'Monitorando corridas...',
            );
          } else {
            print("✅ Foreground service já está rodando");
          }
          
          // ✅ NOVA FUNCIONALIDADE: Mostrar overlay quando minimizado
          // Executa de forma assíncrona para não bloquear o ciclo de vida do app
          print("🟡 [main] Chamando OverlayLifecycleService.handleAppPaused...");
          try {
            if (mounted) {
              await OverlayLifecycleService.handleAppPaused(context);
              print("🟡 [main] handleAppPaused concluído com sucesso");
            } else {
              print("⚠️ [main] Context não está mais montado, abortando handleAppPaused");
            }
          } catch (e, stackTrace) {
            print("❌ [main] Erro ao chamar handleAppPaused: $e");
            print("❌ [main] StackTrace: $stackTrace");
          }
        } else {
          print("⚠️ [main] Motorista NÃO está conectado (status: $logado) - Overlay não será criado");
        }
      } catch (e) {
        print("❌ [main] Erro ao obter UsuarioService: $e");
        print("⚠️ [main] Tentando novamente após delay adicional...");
        
        // Tentar novamente após um delay maior
        await Future.delayed(Duration(milliseconds: 500));
        
        if (mounted) {
          try {
            var usuarioService = Provider.of<UsuarioService>(context, listen: false);
            String? logado = await usuarioService.getMotoristaLogadoStatus();
            
            if (logado == 'CONECTADO') {
              print("🟡 [main] Segunda tentativa - Motorista CONECTADO, criando overlay...");
              await OverlayLifecycleService.handleAppPaused(context);
            }
          } catch (e2) {
            print("❌ [main] Erro na segunda tentativa: $e2");
          }
        }
      }
    } catch (e, stackTrace) {
      print("❌ [main] Erro ao processar app pausado: $e");
      print("❌ [main] StackTrace: $stackTrace");
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) async {
    super.didChangeAppLifecycleState(state);
    print("🔄 [main] didChangeAppLifecycleState chamado - Estado: $state");

    if (state == AppLifecycleState.paused) {
      print("🟡 O app foi MINIMIZADO!");
      
      // ✅ Chamar método diretamente, sem Future.microtask
      // Usar unawaited para não bloquear o ciclo de vida
      _handleAppPaused();
    } else if (state == AppLifecycleState.detached) {
      print("🔴 O app foi FECHADO, usando overlay!");
      
      // 🔥 IMPORTANTE: Marcar usuário como offline no Firebase
      try {
        final firebaseService = FirebasePresenceService();
        
        await firebaseService.setOffline();
      } catch (e) {
        print("❌ [DETACHED] Erro ao marcar como offline: $e");
      }
      
      // Verificar se o motorista está conectado
      var usuarioService = Provider.of<UsuarioService>(context, listen: false);
      if (usuarioService.usuario.motorista['logado'] == 'CONECTADO') {
        // Quando o app está fechado, usar overlay
        // Garantir que o foreground service continue rodando
        bool isRunning = await FlutterForegroundTask.isRunningService;
        if (!isRunning) {
          print("⚠️ Iniciando foreground service para manter overlay...");
          await FlutterForegroundTask.startService(
            notificationTitle: 'Aondeir',
            notificationText: 'Overlay ativo - Aguardando eventos...',
          );
        }
        // Criar o overlay quando o app está fechado
        await OverlayService.showFloatingOverlay();
        print("✅ Overlay criado para app fechado");
      }
    } else if (state == AppLifecycleState.resumed) {
      print("🟢 O app foi ABERTO/RETOMADO!");
      // Fecha o overlay quando o app voltar ao foco (se estiver aberto)
      // Mas não bloqueia - permite que seja recriado rapidamente se minimizado novamente
      OverlayService.closeOverlay().catchError((e) {
        print("⚠️ [RESUMED] Erro ao fechar overlay: $e");
      });
    }
  }

  Future<void> _initializeForegroundTask() async {
    FlutterForegroundTask.init(
      androidNotificationOptions: AndroidNotificationOptions(
        channelId: 'overlay_service',
        channelName: 'Overlay Service',
        channelDescription: 'Mantém o overlay ativo quando o app está fechado.',
        onlyAlertOnce: true,
      ),
      iosNotificationOptions: const IOSNotificationOptions(
        showNotification: false,
        playSound: false,
      ),
      foregroundTaskOptions: ForegroundTaskOptions(
        eventAction: ForegroundTaskEventAction.repeat(30000), // 30 segundos
        autoRunOnBoot: true,
        autoRunOnMyPackageReplaced: true,
        allowWakeLock: true,
        allowWifiLock: true,
      ),
    );
  }

  void requestPermission() async {
    if (Platform.isIOS || await overlay.FlutterOverlayWindow.isPermissionGranted() == true) {
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => NavigationScreen(),
        ),
      );
    }
  }

  redirectToCorridaDetalhes() async {
    final corridaService = Provider.of<CorridaService>(context, listen: false);
    final toqueService = Provider.of<ToqueService>(context, listen: false);
    var currentScreenService =
        Provider.of<CurrentScreenService>(context, listen: false);

    corridaService.corridas.clear();

    if (corridaService.corridasPendentes.isNotEmpty) {
      corridaService.corridasPendentes.clear();
    }

    await corridaService.pegarCorridaAndamento();
    currentScreenService.setCurrentScreen("DetalhesCorridaScreen");

    var usuarioService = Provider.of<UsuarioService>(context, listen: false);
    usuarioService.usuario.motorista['situacao'] = 'OCUPADO';
    await usuarioService.save();

    toqueService.execute('toques/toque_motorista_corrida_aceita.mp3');
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => DetalhesCorridaScreen(),
      ),
    );
  }

  Timer? _connectionTimer;
  Timer? _locationUpdateTimer;

  void _startTimer() {
    _connectionTimer?.cancel(); // Cancela timer anterior se existir
    _connectionTimer = Timer.periodic(Duration(seconds: 10), (timer) async {
      if (!mounted) {
        timer.cancel();
        return;
      }
      var variavelControleService =
          Provider.of<VariavelControleService>(context, listen: false);

      if (variavelControleService.checkIsLogged == true &&
          variavelControleService.startSocket == false) {
          var checkConexaoService =
              Provider.of<CheckConexaoService>(context, listen: false);
          await checkConexaoService.execute();
          variavelControleService.startSocket = true;
          await variavelControleService.save();
      }
    });
    
    // Timer para atualizar localização a cada 20 minutos
    _startLocationUpdateTimer();
  }
  
  void _startLocationUpdateTimer() {
    _locationUpdateTimer?.cancel(); // Cancela timer anterior se existir
    _locationUpdateTimer = Timer.periodic(Duration(minutes: 20), (timer) async {
      if (!mounted) {
        timer.cancel();
        return;
      }
      
      try {
        var usuarioService = Provider.of<UsuarioService>(context, listen: false);
        
        // Só atualiza localização se o motorista estiver logado/conectado
        if (usuarioService.usuario.motorista['logado'] == 'CONECTADO') {
          print("📍 Atualizando localização do motorista (timer 20 min)...");
          
          // Obter localização atual
          var localizacaoGetCurrentLocationService = 
              Provider.of<LocalizacaoGetCurrentLocationService>(context, listen: false);
          Position? position = await localizacaoGetCurrentLocationService.execute();
          
          if (position != null) {
            var motoristaAtualizaLocalizacaoService = 
                Provider.of<MotoristaAtualizaLocalizacaoService>(context, listen: false);
            
            int motoristaId = usuarioService.usuario.id;
            await motoristaAtualizaLocalizacaoService.execute(motoristaId, position);
            
            print("✅ Localização atualizada com sucesso!");
          } else {
            print("⚠️ Não foi possível obter a localização atual");
          }
        }
      } catch (e) {
        print("❌ Erro ao atualizar localização: $e");
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    var corridaBuscarService =
        Provider.of<CorridaBuscarService>(context, listen: false);

    return RefreshIndicator(
      onRefresh: () async {
        await corridaBuscarService.execute('', '');
      },
      child: FutureBuilder<bool>(
        future: isUserLoggedIn(context),
        builder: (BuildContext context, AsyncSnapshot<bool> snapshot) {
          Provider.of<UsuarioService>(context, listen: false);

          if (snapshot.connectionState == ConnectionState.waiting) {
            return CarregamentoScreen();
          } else if (snapshot.hasError) {
            return InitialScreen();
          } else if (snapshot.data == true) {
            return Scaffold(
              body: FutureBuilder<bool>(
                  future: isMotoristaAtivo(context),
                  builder: (BuildContext context,
                      AsyncSnapshot<bool> snapshotMotorista) {
                    if (snapshotMotorista.connectionState ==
                        ConnectionState.waiting) {
                      return CarregamentoScreen();
                    } else if (snapshotMotorista.hasError) {
                      return InitialScreen();
                    } else if (snapshotMotorista.data == true) {
                      return Scaffold(
                        body: FutureBuilder<bool>(
                          future: isLocationPermissionEnable(context),
                          builder: (BuildContext context,
                              AsyncSnapshot<bool> snapshotLocationPermission) {
                            if (snapshotLocationPermission.connectionState ==
                                ConnectionState.waiting) {
                              return CarregamentoScreen();
                            } else if (snapshotLocationPermission.hasError) {
                              return InitialScreen();
                            } else if (snapshotLocationPermission.data ==
                                true) {
                              return Scaffold(
                                body: FutureBuilder<bool>(
                                    future: isOverlayAble(context),
                                    builder: (BuildContext context,
                                        AsyncSnapshot<bool>
                                            snapshotOverlayPermission) {
                                      if (snapshotOverlayPermission
                                              .connectionState ==
                                          ConnectionState.waiting) {
                                        return CarregamentoScreen();
                                      } else if (snapshotOverlayPermission
                                          .hasError) {
                                        return InitialScreen();
                                      } else if (snapshotOverlayPermission
                                              .data ==
                                          true) {
                                        return Scaffold(
                                          body: FutureBuilder<bool>(
                                            future: hasCorridaAdamento(context),
                                            builder: (BuildContext context,
                                                AsyncSnapshot<bool>
                                                    snapshotCorrida) {
                                              if (snapshotCorrida
                                                      .connectionState ==
                                                  ConnectionState.waiting) {
                                                return CarregamentoScreen();
                                              } else if (snapshotCorrida
                                                  .hasError) {
                                                return InitialScreen();
                                              } else if (snapshotCorrida.data ==
                                                  true) {
                                                return DetalhesCorridaScreen();
                                              } else {
                                                return Scaffold(
                                                  body: FutureBuilder<bool>(
                                                      future:
                                                          isCorridaAdamentoMacaneta(
                                                              context),
                                                      builder: (BuildContext
                                                              context,
                                                          AsyncSnapshot<bool>
                                                              snapshotCorridaMacaneta) {
                                                        if (snapshotCorridaMacaneta
                                                                .connectionState ==
                                                            ConnectionState
                                                                .waiting) {
                                                          return CarregamentoScreen();
                                                        } else if (snapshotCorridaMacaneta
                                                            .hasError) {
                                                          return InitialScreen();
                                                        } else if (snapshotCorridaMacaneta
                                                                .data ==
                                                            true) {
                                                          return DetalhesMacanetaScreen();
                                                        } else {
                                                          return NavigationScreen();
                                                        }
                                                      }),
                                                );
                                              }
                                            },
                                          ),
                                        );
                                      } else {
                                        return PermissaoOverlayScreen();
                                      }
                                    }),
                              );
                            } else {
                              return PermissaoGeolocatorScreen();
                            }
                          },
                        ),
                      );
                    } else {
                      return OpcoesScreen();
                    }
                  }),
            );
          } else {
            return InitialScreen();
          }
        },
      ),
    );
  }
}

Future<bool> isUserLoggedIn(BuildContext? context) async {
  final storage = new FlutterSecureStorage();
  var token = await storage.read(key: 'jwt');

  await Future.delayed(Duration(seconds: 1));
  if (token != null) {
    LoginService loginService = LoginService(context);

    var logado = await loginService.getUsarioLogado(token);

    if (logado == true) {
      var variavelControleService =
          Provider.of<VariavelControleService>(context!, listen: false);
      variavelControleService.checkIsLogged = true;
      await variavelControleService.save();
      
      // 🔥 Inicializar Firebase Presence quando o app abre com usuário já logado
      try {
        var usuarioService = Provider.of<UsuarioService>(context, listen: false);
        await FirebasePresenceService().initialize(usuarioService.usuario.id);
      } catch (e, stackTrace) {
        print('❌❌❌ [isUserLoggedIn] ERRO ao inicializar Firebase Presence: $e');
      }
    }
    return logado;
  } else {
    return false;
  }
}

Future<bool> isOverlayAble(BuildContext? context) async {
  if(Platform.isIOS ) {
    return true;
  }
  var permissionOverlay = await overlay.FlutterOverlayWindow.isPermissionGranted();
  if (permissionOverlay == true) {
    return true;
  } else {
    return false;
  }
}




Future<bool> hasCorridaAdamento(BuildContext context) async {
  try {
    var corridaService = Provider.of<CorridaService>(context, listen: false);
    var corridaAndamento = await corridaService.pegarCorridaAndamento();
    await Future.delayed(Duration(seconds: 1));
    
    if (corridaAndamento != null) {
      return true;
    } else {
      return false;
    }
  } catch (e) {
    print('🌕🌕 [hasCorridaAdamento] ERRO: $e');
    throw e;
  }
}

Future<bool> isCorridaAdamentoMacaneta(BuildContext context) async {
  try {
    var corridaMacanetaPegarEmAndamentoService =
        Provider.of<CorridaMacanetaPegarEmAndamentoService>(context,
            listen: false);

    var corrida = await corridaMacanetaPegarEmAndamentoService.execute();

    if (corrida == null) {
      return false;
    }

    var corridaService = Provider.of<CorridaService>(context, listen: false);

    corridaService.corrida = corrida;

    corridaService.status = corrida['status']['id'].toString();

    corridaService.pedido = corrida['pedidos'][0];

    corridaService.tarifa = corrida['tarifa'];

    await corridaService.save();

    await Future.delayed(Duration(seconds: 1));
    if (corrida != null) {
      return true;
    } else {
      return false;
    }
  } catch (e) {
    throw e;
  }
}

Future<bool> isMotoristaAtivo(BuildContext context) async {
  try {
    var usuarioService = Provider.of<UsuarioService>(context, listen: false);

    var situacao_cadastral =
        usuarioService.usuario.motorista['situacao_cadastral'];
    if (situacao_cadastral == 'AGUARDANDO_ATIVACAO' || situacao_cadastral == 'FASE_CADASTRO') {
      await usuarioService.pegarEtapaAtualCadastro();
    }

    await Future.delayed(Duration(seconds: 1));

    if (situacao_cadastral != 'AGUARDANDO_ATIVACAO' && situacao_cadastral != 'FASE_CADASTRO') {
      return true;
    } else {
      return false;
    }
  } catch (e) {
    throw e;
  }
}

Future<bool> isLocationPermissionEnable(BuildContext context) async {
  try {
    LocationPermission permission = await Geolocator.checkPermission();
    await Future.delayed(Duration(seconds: 1));

    if (permission == LocationPermission.denied) {
      return false;
    } else {
      return true;
    }
  } catch (e) {
    throw e;
  }
}

mensagemSemInternet(context) async {
  final snackBar = SnackBar(
    content: Text(
      'Sem internet Conecte-se á rede Wi-Fi ou aos dados móveis!',
      selectionColor: Colors.white,
    ),
    duration: Duration(days: 365), // Torna o SnackBar fixo
    backgroundColor: const Color.fromARGB(255, 233, 43, 29),
  );
  ScaffoldMessenger.of(context).showSnackBar(snackBar);
}

fecharSnackBar(context) async {
  ScaffoldMessenger.of(context).hideCurrentSnackBar();
}

verificacao(context) async {
  var verificaCorridaAndamentoService =
      Provider.of<VerificaCorridaAndamentoService>(context, listen: false);
  await verificaCorridaAndamentoService.execute(context);

  var socketService = Provider.of<SocketService>(context!, listen: false);
  
  print("🔌 main.dart: Verificando status do socket...");
  socketService.logSocketStatus();

  socketService.socket
      ?.onConnect((data) => {
        print("🔌 main.dart: Socket conectado, executando verificação de corrida..."),
        verificaCorridaAndamentoService.execute(context)
      });
}

buscarFranquiaCadastro(context) async {
  var franquiaService = Provider.of<FranquiaService>(context, listen: false);
  await franquiaService.pegarFranquias();
}

showModalAlerta(context, msg) async {
  showDialog<String>(
      context: context,
      builder: (BuildContext context) => ModalPadraoGeral(
          message: msg, btnAcao: false, loading: true, closeButton: true));
}

Future<void> requestTrackingPermission() async {
  final TrackingStatus status =
      await AppTrackingTransparency.trackingAuthorizationStatus;

  if (status == TrackingStatus.notDetermined) {
    final TrackingStatus newStatus =
        await AppTrackingTransparency.requestTrackingAuthorization();
    print('New Tracking Status: $newStatus');
    // Processa o novo status da permissão aqui
  } else {
    print('Current Tracking Status: $status');
    // Processa o status atual da permissão aqui
  }
}
