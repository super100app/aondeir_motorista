import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      case TargetPlatform.macOS:
        return macos;
      case TargetPlatform.windows:
        return windows;
      case TargetPlatform.linux:
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for linux - '
          'you can reconfigure this by running the FlutterFire CLI again.',
        );
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyAVEMltJzB55d19Svb41srwSP64mSP5iPY',
    appId: '1:192200148519:web:df0fb8d9dc97a2edbff002',
    messagingSenderId: '192200148519',
    projectId: 'aondeirnotificacao',
    authDomain: 'aondeirnotificacao.firebaseapp.com',
    storageBucket: 'aondeirnotificacao.firebasestorage.app',
    measurementId: 'G-7EFVG8WSGD',
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyBGB5TkETVVxVcB_V2e8Km45qlLegotITY',
    appId: '1:192200148519:android:f9ce37448be28cb3bff002',
    messagingSenderId: '192200148519',
    projectId: 'aondeirnotificacao',
    storageBucket: 'aondeirnotificacao.firebasestorage.app',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyBfUoua9CuwiQqJVESpd-BHYOhKUEgLGag',
    appId: '1:192200148519:ios:580bd61472921573bff002',
    messagingSenderId: '192200148519',
    projectId: 'aondeirnotificacao',
    storageBucket: 'aondeirnotificacao.firebasestorage.app',
    iosBundleId: 'com.aondeir.driver',
  );

  static const FirebaseOptions macos = FirebaseOptions(
    apiKey: 'AIzaSyBfUoua9CuwiQqJVESpd-BHYOhKUEgLGag',
    appId: '1:192200148519:ios:6798688755d3f53cbff002',
    messagingSenderId: '192200148519',
    projectId: 'aondeirnotificacao',
    storageBucket: 'aondeirnotificacao.firebasestorage.app',
    iosBundleId: 'com.yourdomain.aondeir',
  );

  static const FirebaseOptions windows = FirebaseOptions(
    apiKey: 'AIzaSyCbFoXxXtZz22UoFOjv5byBsqAWbKaA2Eg',
    appId: '1:192200148519:web:85d2f271a92cb648bff002',
    messagingSenderId: '192200148519',
    projectId: 'aondeirnotificacao',
    authDomain: 'aondeirnotificacao.firebaseapp.com',
    storageBucket: 'aondeirnotificacao.firebasestorage.app',
    measurementId: 'G-RY180218JG',
  );

}